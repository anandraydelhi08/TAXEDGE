import React, { useState, useMemo } from 'react';
import {
  FileText,
  ShoppingBag,
  Users,
  Wallet,
  Receipt,
  Boxes,
  Truck,
  QrCode,
  FileSpreadsheet,
  Plus,
  Search,
  Filter,
  Download,
  Send,
  MessageCircle,
  Mail,
  AlertCircle,
  CheckCircle2,
  Calendar,
  IndianRupee,
  Clock,
  ArrowUpRight,
  ArrowDownLeft,
  X,
  Building2,
  Trash2,
  Edit2
} from 'lucide-react';
import {
  Party,
  PartyLedgerEntry,
  PaymentRecord,
  ExpenseRecord,
  InventoryItem,
  EInvoiceRecord,
  EWayBillRecord,
  PaymentMode,
  ExpenseCategory
} from '../../types/accounting';
import { TransactionInvoice } from '../../types/gst';
import { ClientMaster } from '../../types/client';
import { accountingService, AccountingWorkspaceData } from '../../services/accountingService';
import { formatINR } from '../../utils/taxMath';
import { INDIAN_STATES, HSN_SAC_DIRECTORY } from '../../data/masterData';

interface BusinessAccountingHubProps {
  currentClient: ClientMaster;
  currentGstin: string;
  sales: TransactionInvoice[];
  purchases: TransactionInvoice[];
  onAddSaleInvoice: (invoice: TransactionInvoice) => void;
  onAddPurchaseInvoice: (invoice: TransactionInvoice) => void;
}

export type AccountingTab =
  | 'sales_invoices'
  | 'purchase_bills'
  | 'parties'
  | 'party_ledger'
  | 'payments'
  | 'expenses'
  | 'inventory'
  | 'e_invoice_ewb'
  | 'reports';

export const BusinessAccountingHub: React.FC<BusinessAccountingHubProps> = ({
  currentClient,
  currentGstin,
  sales,
  purchases,
  onAddSaleInvoice,
  onAddPurchaseInvoice
}) => {
  const [activeTab, setActiveTab] = useState<AccountingTab>('sales_invoices');
  const [data, setData] = useState<AccountingWorkspaceData>(() =>
    accountingService.getData(currentClient.id, currentGstin)
  );

  // Reload accounting data when client or GSTIN switches
  React.useEffect(() => {
    setData(accountingService.getData(currentClient.id, currentGstin));
  }, [currentClient.id, currentGstin]);

  const refreshData = () => {
    setData({ ...accountingService.getData(currentClient.id, currentGstin) });
  };

  // Modals
  const [isSaleModalOpen, setIsSaleModalOpen] = useState(false);
  const [isPurchaseModalOpen, setIsPurchaseModalOpen] = useState(false);
  const [isPartyModalOpen, setIsPartyModalOpen] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState(false);
  const [isItemModalOpen, setIsItemModalOpen] = useState(false);
  const [selectedPartyForLedger, setSelectedPartyForLedger] = useState<string>('');
  const [reminderModalInvoice, setReminderModalInvoice] = useState<TransactionInvoice | null>(null);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [reportPeriod, setReportPeriod] = useState<'MONTHLY' | 'QUARTERLY' | 'YEARLY'>('MONTHLY');

  // New Sale Form State
  const [saleForm, setSaleForm] = useState({
    invoiceNumber: `INV-${new Date().getFullYear()}-${String(sales.length + 1).padStart(3, '0')}`,
    invoiceDate: new Date().toISOString().split('T')[0],
    customerName: '',
    customerGstin: '',
    placeOfSupply: currentClient.state || 'Maharashtra',
    classification: 'B2B' as any,
    itemDescription: 'IT Consulting & Business Automation Services',
    hsnSac: '998313',
    quantity: 1,
    unit: 'NOS',
    rate: 50000,
    discount: 0,
    gstRate: 18,
    isRcm: false
  });

  // New Purchase Form State
  const [purchaseForm, setPurchaseForm] = useState({
    invoiceNumber: `BILL-${String(purchases.length + 1).padStart(3, '0')}`,
    invoiceDate: new Date().toISOString().split('T')[0],
    supplierName: '',
    supplierGstin: '',
    placeOfSupply: currentClient.state || 'Maharashtra',
    itemDescription: 'Enterprise Cloud Rack Hardware & Network Devices',
    hsnSac: '847141',
    taxableValue: 80000,
    gstRate: 18,
    isRcm: false,
    itcStatus: 'ELIGIBLE' as any
  });

  // Party Form State
  const [partyForm, setPartyForm] = useState<Partial<Party>>({
    name: '',
    type: 'CUSTOMER',
    gstin: '',
    pan: '',
    state: currentClient.state || 'Maharashtra',
    stateCode: currentClient.primaryGstin?.substring(0, 2) || '27',
    address: '',
    mobile: '+91 ',
    email: '',
    openingBalance: 0,
    creditLimit: 500000,
    paymentTermsDays: 30
  });

  // Payment Form State
  const [paymentForm, setPaymentForm] = useState<Partial<PaymentRecord>>({
    type: 'PAYMENT_IN',
    partyId: '',
    partyName: '',
    date: new Date().toISOString().split('T')[0],
    amount: 10000,
    paymentMode: 'BANK_TRANSFER',
    referenceNumber: '',
    notes: ''
  });

  // Expense Form State
  const [expenseForm, setExpenseForm] = useState<Partial<ExpenseRecord>>({
    date: new Date().toISOString().split('T')[0],
    category: 'RENT',
    partyName: '',
    taxableAmount: 25000,
    gstRate: 18,
    paymentMode: 'BANK_TRANSFER',
    isItcEligible: true,
    notes: ''
  });

  // Inventory Item Form State
  const [itemForm, setItemForm] = useState<Partial<InventoryItem>>({
    name: '',
    sku: '',
    hsnSac: '847141',
    unit: 'NOS',
    purchasePrice: 1000,
    salePrice: 1500,
    gstRate: 18,
    openingStock: 10,
    minStockAlert: 2,
    currentStock: 10
  });

  // Auto-calculated sale tax
  const saleCalculations = useMemo(() => {
    const gross = (saleForm.quantity || 1) * (saleForm.rate || 0);
    const taxable = Math.max(0, gross - (saleForm.discount || 0));
    const isInterState = saleForm.placeOfSupply !== currentClient.state;
    const rate = saleForm.gstRate || 18;

    let igst = 0;
    let cgst = 0;
    let sgst = 0;

    if (isInterState) {
      igst = (taxable * rate) / 100;
    } else {
      cgst = (taxable * (rate / 2)) / 100;
      sgst = (taxable * (rate / 2)) / 100;
    }

    const total = taxable + igst + cgst + sgst;
    return { gross, taxable, isInterState, igst, cgst, sgst, total };
  }, [saleForm, currentClient.state]);

  // Aggregate Metrics for Active Client
  const accountingMetrics = useMemo(() => {
    const totalSalesAmount = sales.reduce((s, inv) => s + inv.totalAmount, 0);
    const totalPurchaseAmount = purchases.reduce((s, inv) => s + inv.totalAmount, 0);
    const totalReceivables = data.parties
      .filter(p => p.currentBalance > 0)
      .reduce((s, p) => s + p.currentBalance, 0);
    const totalPayables = data.parties
      .filter(p => p.currentBalance < 0)
      .reduce((s, p) => s + Math.abs(p.currentBalance), 0);
    const totalStockValue = data.inventory.reduce(
      (s, item) => s + item.currentStock * item.purchasePrice,
      0
    );
    const totalExpenses = data.expenses.reduce((s, e) => s + e.totalAmount, 0);

    return {
      totalSalesAmount,
      totalPurchaseAmount,
      totalReceivables,
      totalPayables,
      totalStockValue,
      totalExpenses
    };
  }, [sales, purchases, data]);

  // Handle Save New Sale Invoice
  const handleSaveSale = (e: React.FormEvent) => {
    e.preventDefault();
    if (!saleForm.invoiceNumber || !saleForm.customerName) return;

    const isInter = saleCalculations.isInterState;
    const stateObj = INDIAN_STATES.find(s => s.name === saleForm.placeOfSupply);
    const posCode = stateObj?.code || currentClient.primaryGstin?.substring(0, 2) || '27';

    const newInvoice: TransactionInvoice = {
      id: `SL-${Date.now()}`,
      invoiceNumber: saleForm.invoiceNumber.trim().toUpperCase(),
      invoiceDate: saleForm.invoiceDate,
      documentType: 'INVOICE',
      supplierGstin: currentGstin,
      supplierName: currentClient.legalName,
      supplierState: currentClient.state,
      supplierStateCode: currentClient.primaryGstin?.substring(0, 2) || '27',
      recipientGstin: saleForm.customerGstin.trim().toUpperCase() || 'URP-CONSUMER',
      recipientName: saleForm.customerName.trim(),
      recipientState: saleForm.placeOfSupply,
      recipientStateCode: posCode,
      placeOfSupply: saleForm.placeOfSupply,
      placeOfSupplyCode: posCode,
      supplyType: isInter ? 'INTER_STATE' : 'INTRA_STATE',
      classification: saleForm.classification,
      taxTreatment: 'TAXABLE',
      hsnSacPrimary: saleForm.hsnSac,
      descriptionPrimary: saleForm.itemDescription,
      taxableValue: saleCalculations.taxable,
      gstRate: saleForm.gstRate,
      cgst: saleCalculations.cgst,
      sgst: saleCalculations.sgst,
      igst: saleCalculations.igst,
      cess: 0,
      totalAmount: saleCalculations.total,
      rcm: saleForm.isRcm,
      ecommerce: false,
      itcStatus: 'ELIGIBLE',
      itcEligibleAmount: 0,
      itcIneligibleAmount: 0,
      confidence: 1.0,
      reviewRequired: false,
      items: [
        {
          id: `item-1`,
          itemDescription: saleForm.itemDescription,
          hsnSac: saleForm.hsnSac,
          quantity: saleForm.quantity,
          unit: saleForm.unit,
          unitPrice: saleForm.rate,
          taxableValue: saleCalculations.taxable,
          gstRate: saleForm.gstRate,
          cgst: saleCalculations.cgst,
          sgst: saleCalculations.sgst,
          igst: saleCalculations.igst,
          cess: 0,
          total: saleCalculations.total
        }
      ]
    };

    // 1. Process inventory deduction and update customer ledger
    accountingService.processInvoiceInventoryAndLedger(
      currentClient.id,
      currentGstin,
      newInvoice,
      'SALE'
    );

    // 2. Add to central Sales Register (which recomputes GSTR-1 & GSTR-3B automatically)
    onAddSaleInvoice(newInvoice);

    refreshData();
    setIsSaleModalOpen(false);
  };

  // Handle Save New Purchase Bill
  const handleSavePurchase = (e: React.FormEvent) => {
    e.preventDefault();
    if (!purchaseForm.invoiceNumber || !purchaseForm.supplierName) return;

    const isInter = purchaseForm.placeOfSupply !== currentClient.state;
    const stateObj = INDIAN_STATES.find(s => s.name === purchaseForm.placeOfSupply);
    const posCode = stateObj?.code || currentClient.primaryGstin?.substring(0, 2) || '27';
    const rate = purchaseForm.gstRate;
    const taxable = purchaseForm.taxableValue;

    const igst = isInter ? (taxable * rate) / 100 : 0;
    const cgst = !isInter ? (taxable * (rate / 2)) / 100 : 0;
    const sgst = !isInter ? (taxable * (rate / 2)) / 100 : 0;
    const total = taxable + igst + cgst + sgst;

    const newInvoice: TransactionInvoice = {
      id: `PR-${Date.now()}`,
      invoiceNumber: purchaseForm.invoiceNumber.trim().toUpperCase(),
      invoiceDate: purchaseForm.invoiceDate,
      documentType: 'INVOICE',
      supplierGstin: purchaseForm.supplierGstin.trim().toUpperCase() || '27AAACG0914K1ZH',
      supplierName: purchaseForm.supplierName.trim(),
      supplierState: purchaseForm.placeOfSupply,
      supplierStateCode: posCode,
      recipientGstin: currentGstin,
      recipientName: currentClient.legalName,
      recipientState: currentClient.state,
      recipientStateCode: currentClient.primaryGstin?.substring(0, 2) || '27',
      placeOfSupply: currentClient.state,
      placeOfSupplyCode: currentClient.primaryGstin?.substring(0, 2) || '27',
      supplyType: isInter ? 'INTER_STATE' : 'INTRA_STATE',
      classification: 'B2B',
      taxTreatment: 'TAXABLE',
      hsnSacPrimary: purchaseForm.hsnSac,
      descriptionPrimary: purchaseForm.itemDescription,
      taxableValue: taxable,
      gstRate: rate,
      cgst,
      sgst,
      igst,
      cess: 0,
      totalAmount: total,
      rcm: purchaseForm.isRcm,
      ecommerce: false,
      itcStatus: purchaseForm.itcStatus,
      itcEligibleAmount: purchaseForm.itcStatus === 'ELIGIBLE' ? cgst + sgst + igst : 0,
      itcIneligibleAmount: purchaseForm.itcStatus === 'INELIGIBLE' ? cgst + sgst + igst : 0,
      confidence: 1.0,
      reviewRequired: false,
      items: [
        {
          id: `item-pr-1`,
          itemDescription: purchaseForm.itemDescription,
          hsnSac: purchaseForm.hsnSac,
          quantity: 1,
          unit: 'NOS',
          unitPrice: taxable,
          taxableValue: taxable,
          gstRate: rate,
          cgst,
          sgst,
          igst,
          cess: 0,
          total
        }
      ]
    };

    // 1. Process inventory stock addition and update supplier ledger
    accountingService.processInvoiceInventoryAndLedger(
      currentClient.id,
      currentGstin,
      newInvoice,
      'PURCHASE'
    );

    // 2. Add to central Purchase Register (which immediately feeds 2B Reconciliation & GSTR-3B)
    onAddPurchaseInvoice(newInvoice);

    refreshData();
    setIsPurchaseModalOpen(false);
  };

  // Handle Save Party
  const handleSaveParty = (e: React.FormEvent) => {
    e.preventDefault();
    if (!partyForm.name?.trim()) return;

    const party: Party = {
      id: `PRT-${Date.now()}`,
      clientId: currentClient.id,
      gstinReference: currentGstin,
      type: partyForm.type || 'CUSTOMER',
      name: partyForm.name.trim(),
      tradeName: partyForm.tradeName?.trim() || partyForm.name.trim(),
      gstin: partyForm.gstin?.trim().toUpperCase() || '',
      pan: partyForm.pan?.trim().toUpperCase() || (partyForm.gstin && partyForm.gstin.length >= 12 ? partyForm.gstin.substring(2, 12) : ''),
      state: partyForm.state || currentClient.state,
      stateCode: partyForm.stateCode || '27',
      address: partyForm.address || '',
      mobile: partyForm.mobile || '',
      email: partyForm.email || '',
      openingBalance: Number(partyForm.openingBalance) || 0,
      currentBalance: Number(partyForm.openingBalance) || 0,
      creditLimit: Number(partyForm.creditLimit) || 500000,
      paymentTermsDays: Number(partyForm.paymentTermsDays) || 30,
      createdAt: new Date().toISOString()
    };

    accountingService.addParty(currentClient.id, currentGstin, party);
    refreshData();
    setIsPartyModalOpen(false);
  };

  // Handle Save Payment
  const handleSavePayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentForm.partyId || !paymentForm.amount) return;

    const party = data.parties.find(p => p.id === paymentForm.partyId);
    const payment: PaymentRecord = {
      id: `PAY-${Date.now()}`,
      clientId: currentClient.id,
      gstinReference: currentGstin,
      type: paymentForm.type || 'PAYMENT_IN',
      partyId: paymentForm.partyId,
      partyName: party?.name || 'Party',
      date: paymentForm.date || new Date().toISOString().split('T')[0],
      amount: Number(paymentForm.amount),
      paymentMode: paymentForm.paymentMode || 'BANK_TRANSFER',
      referenceNumber: paymentForm.referenceNumber || '',
      notes: paymentForm.notes || '',
      createdAt: new Date().toISOString()
    };

    accountingService.recordPayment(currentClient.id, currentGstin, payment);
    refreshData();
    setIsPaymentModalOpen(false);
  };

  // Handle Save Expense
  const handleSaveExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!expenseForm.taxableAmount) return;

    const rate = Number(expenseForm.gstRate) || 0;
    const taxable = Number(expenseForm.taxableAmount) || 0;
    const cgst = (taxable * (rate / 2)) / 100;
    const sgst = (taxable * (rate / 2)) / 100;
    const total = taxable + cgst + sgst;

    const expense: ExpenseRecord = {
      id: `EXP-${Date.now()}`,
      clientId: currentClient.id,
      gstinReference: currentGstin,
      date: expenseForm.date || new Date().toISOString().split('T')[0],
      category: (expenseForm.category as ExpenseCategory) || 'OTHER_OVERHEADS',
      partyName: expenseForm.partyName || 'Vendor',
      taxableAmount: taxable,
      gstRate: rate,
      cgst,
      sgst,
      igst: 0,
      totalAmount: total,
      paymentMode: expenseForm.paymentMode || 'BANK_TRANSFER',
      isItcEligible: expenseForm.isItcEligible ?? true,
      notes: expenseForm.notes || '',
      createdAt: new Date().toISOString()
    };

    accountingService.recordExpense(currentClient.id, currentGstin, expense);
    refreshData();
    setIsExpenseModalOpen(false);
  };

  // Handle Save Inventory Item
  const handleSaveItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemForm.name?.trim()) return;

    const item: InventoryItem = {
      id: `ITEM-${Date.now()}`,
      clientId: currentClient.id,
      gstinReference: currentGstin,
      name: itemForm.name.trim(),
      sku: itemForm.sku?.trim().toUpperCase() || `SKU-${Date.now().toString(16)}`,
      hsnSac: itemForm.hsnSac || '847141',
      unit: itemForm.unit || 'NOS',
      purchasePrice: Number(itemForm.purchasePrice) || 0,
      salePrice: Number(itemForm.salePrice) || 0,
      gstRate: Number(itemForm.gstRate) || 18,
      openingStock: Number(itemForm.openingStock) || 0,
      minStockAlert: Number(itemForm.minStockAlert) || 5,
      currentStock: Number(itemForm.currentStock) || Number(itemForm.openingStock) || 0,
      createdAt: new Date().toISOString()
    };

    accountingService.addInventoryItem(currentClient.id, currentGstin, item);
    refreshData();
    setIsItemModalOpen(false);
  };

  // Selected ledger party entries
  const selectedLedgerEntries = useMemo(() => {
    if (!selectedPartyForLedger) return data.ledgers;
    return data.ledgers.filter(l => l.partyId === selectedPartyForLedger);
  }, [data.ledgers, selectedPartyForLedger]);

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner & Client Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-gradient-to-r from-slate-900 via-slate-900 to-emerald-950/40 p-5 rounded-2xl border border-[#E5E7EB] shadow-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-xl bg-[#176B4D]/10 border border-[#176B4D]/30 text-[#176B4D]">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold text-[#202124] tracking-tight">Business Accounting & Invoicing</h1>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-[#176B4D]/20 text-[#176B4D] border border-[#176B4D]/30">
                  Client Mode
                </span>
              </div>
              <p className="text-xs text-[#6B7280]">
                Entity: <strong className="text-[#202124]">{currentClient.name}</strong> • GSTIN:{' '}
                <span className="font-mono text-[#176B4D] font-semibold">{currentGstin}</span> • Seamless sync with GSTR-1, 3B, and 2B Reconciliation
              </p>
            </div>
          </div>
        </div>

        {/* Quick Create CTAs */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setIsSaleModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-slate-500 hover:from-emerald-500 hover:to-slate-400 text-slate-950 font-bold text-xs shadow-md transition transform active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>New Sale Invoice</span>
          </button>

          <button
            onClick={() => setIsPurchaseModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white hover:bg-[#E8F5EF] text-[#176B4D] border border-[#176B4D]/40 font-bold shadow-sm font-semibold text-xs transition"
          >
            <Plus className="w-4 h-4 text-[#176B4D]" />
            <span>New Purchase Bill</span>
          </button>

          <button
            onClick={() => setIsPaymentModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-[#E8F5EF] text-[#176B4D] border border-[#176B4D]/40 font-bold shadow-sm font-semibold text-xs transition"
          >
            <Wallet className="w-3.5 h-3.5 text-[#176B4D]" />
            <span>Record Payment</span>
          </button>

          <button
            onClick={() => setIsExpenseModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-[#E8F5EF] text-[#176B4D] border border-[#176B4D]/40 font-bold shadow-sm font-semibold text-xs transition"
          >
            <Receipt className="w-3.5 h-3.5 text-[#B7791F]" />
            <span>Add Expense</span>
          </button>
        </div>
      </div>

      {/* Accounting Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-3.5 rounded-xl bg-white border border-[#E5E7EB]">
          <div className="text-[10px] uppercase font-bold text-[#6B7280]">Total Sales</div>
          <div className="text-xl font-bold text-[#176B4D] mt-1">{formatINR(accountingMetrics.totalSalesAmount)}</div>
          <div className="text-[10px] text-[#6B7280]">{sales.length} Invoices Issued</div>
        </div>

        <div className="p-3.5 rounded-xl bg-white border border-[#E5E7EB]">
          <div className="text-[10px] uppercase font-bold text-[#6B7280]">Total Purchases</div>
          <div className="text-xl font-bold text-[#6B7280] mt-1">{formatINR(accountingMetrics.totalPurchaseAmount)}</div>
          <div className="text-[10px] text-[#6B7280]">{purchases.length} Purchase Bills</div>
        </div>

        <div className="p-3.5 rounded-xl bg-white border border-[#E5E7EB]">
          <div className="text-[10px] uppercase font-bold text-[#6B7280]">Total Receivables</div>
          <div className="text-xl font-bold text-[#176B4D] mt-1">{formatINR(accountingMetrics.totalReceivables)}</div>
          <div className="text-[10px] text-[#6B7280]">From Customers</div>
        </div>

        <div className="p-3.5 rounded-xl bg-white border border-[#E5E7EB]">
          <div className="text-[10px] uppercase font-bold text-[#6B7280]">Total Payables</div>
          <div className="text-xl font-bold text-[#C62828] mt-1">{formatINR(accountingMetrics.totalPayables)}</div>
          <div className="text-[10px] text-[#6B7280]">To Suppliers</div>
        </div>

        <div className="p-3.5 rounded-xl bg-white border border-[#E5E7EB]">
          <div className="text-[10px] uppercase font-bold text-[#6B7280]">Stock Valuation</div>
          <div className="text-xl font-bold text-[#B7791F] mt-1">{formatINR(accountingMetrics.totalStockValue)}</div>
          <div className="text-[10px] text-[#6B7280]">{data.inventory.length} Stock SKUs</div>
        </div>

        <div className="p-3.5 rounded-xl bg-white border border-[#E5E7EB]">
          <div className="text-[10px] uppercase font-bold text-[#6B7280]">Total Expenses</div>
          <div className="text-xl font-bold text-purple-300 mt-1">{formatINR(accountingMetrics.totalExpenses)}</div>
          <div className="text-[10px] text-[#6B7280]">{data.expenses.length} Expense Entries</div>
        </div>
      </div>

      {/* Module Navigation Tabs */}
      <div className="flex items-center gap-1.5 border-b border-[#E5E7EB] pb-2 overflow-x-auto text-xs font-semibold">
        {[
          { id: 'sales_invoices', label: `Sales Invoices (${sales.length})`, icon: ArrowUpRight },
          { id: 'purchase_bills', label: `Purchase Bills (${purchases.length})`, icon: ArrowDownLeft },
          { id: 'parties', label: `Parties (${data.parties.length})`, icon: Users },
          { id: 'party_ledger', label: 'Party Ledgers', icon: FileSpreadsheet },
          { id: 'payments', label: `Payments (${data.payments.length})`, icon: Wallet },
          { id: 'expenses', label: `Expenses (${data.expenses.length})`, icon: Receipt },
          { id: 'inventory', label: `Inventory (${data.inventory.length})`, icon: Boxes },
          { id: 'e_invoice_ewb', label: 'E-Invoice & E-Way Bill', icon: QrCode },
          { id: 'reports', label: 'Business Reports', icon: FileText }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as AccountingTab)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg whitespace-nowrap transition ${
                isActive
                  ? 'bg-[#176B4D]/20 text-[#176B4D] border border-[#176B4D]/30 font-bold'
                  : 'text-[#6B7280] hover:text-[#202124] hover:bg-[#F8F9FA]'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: SALES INVOICES */}
      {activeTab === 'sales_invoices' && (
        <div className="bg-white rounded-2xl border border-[#E5E7EB] overflow-hidden shadow-xl">
          <div className="p-4 border-b border-[#E5E7EB] flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-[#202124]">Sales & Outward Tax Invoices</h2>
              <span className="text-xs px-2 py-0.5 rounded-full bg-[#F8F9FA] text-[#6B7280] font-mono">
                {sales.length} Total
              </span>
            </div>

            <button
              onClick={() => setIsSaleModalOpen(true)}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#176B4D] hover:bg-[#176B4D] text-slate-950 font-bold text-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create Invoice</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#FFFFFF]/60 text-[#6B7280] uppercase text-[10px] border-b border-[#E5E7EB]">
                <tr>
                  <th className="py-3 px-4 font-semibold">Invoice No & Date</th>
                  <th className="py-3 px-4 font-semibold">Customer Name & GSTIN</th>
                  <th className="py-3 px-4 font-semibold">Classification</th>
                  <th className="py-3 px-4 font-semibold text-right">Taxable</th>
                  <th className="py-3 px-4 font-semibold text-right">GST Total</th>
                  <th className="py-3 px-4 font-semibold text-right">Total Amount</th>
                  <th className="py-3 px-4 font-semibold text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-[#6B7280]">
                {sales.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-10 text-[#6B7280]">
                      No sales invoices recorded yet. Click "Create Invoice" to add your first sales transaction.
                    </td>
                  </tr>
                ) : (
                  sales.map(inv => (
                    <tr key={inv.id} className="hover:bg-[#F8F9FA] transition">
                      <td className="py-3 px-4 font-mono">
                        <div className="font-bold text-white">{inv.invoiceNumber}</div>
                        <div className="text-[11px] text-[#6B7280] font-sans">{inv.invoiceDate}</div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-[#202124]">{inv.recipientName}</div>
                        <div className="text-[11px] text-[#176B4D] font-mono">{inv.recipientGstin}</div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-[#F8F9FA] text-[#176B4D] font-mono">
                          {inv.classification}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right font-mono">{formatINR(inv.taxableValue)}</td>
                      <td className="py-3 px-4 text-right font-mono text-purple-300">
                        {formatINR(inv.cgst + inv.sgst + inv.igst + inv.cess)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-[#176B4D]">
                        {formatINR(inv.totalAmount)}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => {
                              accountingService.generateEInvoice(currentClient.id, currentGstin, inv);
                              refreshData();
                              setActiveTab('e_invoice_ewb');
                            }}
                            className="px-2 py-1 rounded bg-[#F8F9FA] hover:bg-slate-700 text-[#6B7280] text-[10px] font-semibold"
                            title="Generate E-Invoice / IRN"
                          >
                            E-Invoice
                          </button>
                          <button
                            onClick={() => setReminderModalInvoice(inv)}
                            className="p-1 rounded bg-[#F8F9FA] hover:bg-slate-700 text-[#B7791F]"
                            title="Send Payment Reminder"
                          >
                            <Send className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: PURCHASE BILLS */}
      {activeTab === 'purchase_bills' && (
        <div className="bg-white rounded-2xl border border-[#E5E7EB] overflow-hidden shadow-xl">
          <div className="p-4 border-b border-[#E5E7EB] flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-[#202124]">Purchase Bills & Vendor Register</h2>
              <span className="text-xs px-2 py-0.5 rounded-full bg-[#F8F9FA] text-[#6B7280] font-mono">
                {purchases.length} Total
              </span>
            </div>

            <button
              onClick={() => setIsPurchaseModalOpen(true)}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-600 hover:bg-slate-500 text-slate-950 font-bold text-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Record Purchase Bill</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#FFFFFF]/60 text-[#6B7280] uppercase text-[10px] border-b border-[#E5E7EB]">
                <tr>
                  <th className="py-3 px-4 font-semibold">Bill No & Date</th>
                  <th className="py-3 px-4 font-semibold">Vendor & GSTIN</th>
                  <th className="py-3 px-4 font-semibold">ITC Status</th>
                  <th className="py-3 px-4 font-semibold text-right">Taxable</th>
                  <th className="py-3 px-4 font-semibold text-right">Total Tax</th>
                  <th className="py-3 px-4 font-semibold text-right">Bill Total</th>
                  <th className="py-3 px-4 font-semibold text-center">RCM</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-[#6B7280]">
                {purchases.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-10 text-[#6B7280]">
                      No purchase bills recorded yet. Click "Record Purchase Bill" to add inward supplies.
                    </td>
                  </tr>
                ) : (
                  purchases.map(inv => (
                    <tr key={inv.id} className="hover:bg-[#F8F9FA] transition">
                      <td className="py-3 px-4 font-mono">
                        <div className="font-bold text-white">{inv.invoiceNumber}</div>
                        <div className="text-[11px] text-[#6B7280] font-sans">{inv.invoiceDate}</div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-[#202124]">{inv.supplierName}</div>
                        <div className="text-[11px] text-[#176B4D] font-mono">{inv.supplierGstin}</div>
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`text-[10px] px-1.5 py-0.2 rounded font-semibold ${
                            inv.itcStatus === 'ELIGIBLE'
                              ? 'bg-[#176B4D]/10 text-[#176B4D]'
                              : 'bg-[#FDECEC] text-[#C62828] text-rose-300'
                          }`}
                        >
                          {inv.itcStatus}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right font-mono">{formatINR(inv.taxableValue)}</td>
                      <td className="py-3 px-4 text-right font-mono text-purple-300">
                        {formatINR(inv.cgst + inv.sgst + inv.igst + inv.cess)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-[#202124]">
                        {formatINR(inv.totalAmount)}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className={`text-[10px] px-1.5 py-0.2 rounded ${inv.rcm ? 'bg-[#FFF8E1] text-[#B7791F] text-[#B7791F] font-bold' : 'text-[#6B7280]'}`}>
                          {inv.rcm ? 'YES (Sec 9(3))' : 'NO'}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: PARTIES (Customers & Suppliers) */}
      {activeTab === 'parties' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-xl bg-white border border-[#E5E7EB]">
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-[#202124]">Customers & Suppliers Directory</h2>
              <span className="text-xs px-2 py-0.5 rounded-full bg-[#F8F9FA] text-[#6B7280] font-mono">
                {data.parties.length} Parties
              </span>
            </div>

            <button
              onClick={() => setIsPartyModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#176B4D] hover:bg-[#176B4D] text-white font-bold text-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add New Party</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {data.parties.length === 0 ? (
              <div className="col-span-full text-center py-12 bg-white border border-[#E5E7EB] rounded-xl text-[#6B7280] text-xs">
                No parties added yet. Click "Add New Party" or create a sales invoice to automatically register parties.
              </div>
            ) : (
              data.parties.map(p => (
                <div key={p.id} className="p-4 rounded-xl bg-white border border-[#E5E7EB] space-y-3 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="font-bold text-white text-sm">{p.name}</div>
                        <div className="text-[11px] text-[#6B7280]">{p.tradeName || p.type}</div>
                      </div>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                        p.type === 'CUSTOMER' ? 'bg-[#176B4D]/10 text-[#176B4D]' : 'bg-slate-500/10 text-[#6B7280]'
                      }`}>
                        {p.type}
                      </span>
                    </div>

                    <div className="mt-3 space-y-1 text-xs text-[#6B7280]">
                      {p.gstin && <div className="font-mono text-[#176B4D] text-[11px]">GSTIN: {p.gstin}</div>}
                      <div>State: {p.state}</div>
                      <div>Contact: {p.mobile || p.email || 'N/A'}</div>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-[#E5E7EB] flex items-center justify-between">
                    <div>
                      <div className="text-[10px] text-[#6B7280] uppercase font-semibold">Balance</div>
                      <div className={`font-mono font-bold text-xs ${
                        p.currentBalance > 0 ? 'text-[#176B4D]' : p.currentBalance < 0 ? 'text-[#C62828]' : 'text-[#6B7280]'
                      }`}>
                        {p.currentBalance > 0
                          ? `Receivable: ${formatINR(p.currentBalance)}`
                          : p.currentBalance < 0
                          ? `Payable: ${formatINR(Math.abs(p.currentBalance))}`
                          : 'Settled (₹0)'}
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setSelectedPartyForLedger(p.id);
                        setActiveTab('party_ledger');
                      }}
                      className="px-2.5 py-1 rounded bg-[#F8F9FA] hover:bg-slate-700 text-[#202124] text-xs font-semibold"
                    >
                      View Ledger
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* TAB 4: PARTY LEDGERS */}
      {activeTab === 'party_ledger' && (
        <div className="bg-white rounded-2xl border border-[#E5E7EB] overflow-hidden shadow-xl">
          <div className="p-4 border-b border-[#E5E7EB] flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <h2 className="text-sm font-bold text-[#202124]">Party Account Statement & Ledger</h2>
              <select
                value={selectedPartyForLedger}
                onChange={e => setSelectedPartyForLedger(e.target.value)}
                className="px-2.5 py-1 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-xs text-white"
              >
                <option value="">All Parties</option>
                {data.parties.map(p => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.type})
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={() => {
                const csv = 'Date,Particulars,Voucher Type,Voucher No,Debit,Credit,Balance\n' +
                  selectedLedgerEntries.map(l => `${l.date},"${l.particulars}",${l.voucherType},${l.voucherNumber},${l.debit},${l.credit},${l.balance}`).join('\n');
                const blob = new Blob([csv], { type: 'text/csv' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `party_ledger_${selectedPartyForLedger || 'all'}.csv`;
                a.click();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#F8F9FA] hover:bg-slate-700 text-[#202124] text-xs font-semibold"
            >
              <Download className="w-3.5 h-3.5 text-[#176B4D]" />
              <span>Export Ledger (.CSV)</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#FFFFFF]/60 text-[#6B7280] uppercase text-[10px] border-b border-[#E5E7EB]">
                <tr>
                  <th className="py-3 px-4 font-semibold">Date</th>
                  <th className="py-3 px-4 font-semibold">Particulars</th>
                  <th className="py-3 px-4 font-semibold">Voucher Type & Ref</th>
                  <th className="py-3 px-4 font-semibold text-right">Debit (₹)</th>
                  <th className="py-3 px-4 font-semibold text-right">Credit (₹)</th>
                  <th className="py-3 px-4 font-semibold text-right">Running Balance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-[#6B7280] font-mono">
                {selectedLedgerEntries.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-10 text-[#6B7280] font-sans">
                      No ledger entries recorded yet.
                    </td>
                  </tr>
                ) : (
                  selectedLedgerEntries.map(entry => (
                    <tr key={entry.id} className="hover:bg-[#F8F9FA] transition">
                      <td className="py-2.5 px-4 text-[#6B7280]">{entry.date}</td>
                      <td className="py-2.5 px-4 font-sans text-[#202124] font-medium">{entry.particulars}</td>
                      <td className="py-2.5 px-4 text-[11px] text-[#6B7280]">
                        {entry.voucherType} #{entry.voucherNumber}
                      </td>
                      <td className="py-2.5 px-4 text-right text-[#176B4D]">
                        {entry.debit > 0 ? formatINR(entry.debit) : '—'}
                      </td>
                      <td className="py-2.5 px-4 text-right text-[#C62828]">
                        {entry.credit > 0 ? formatINR(entry.credit) : '—'}
                      </td>
                      <td className={`py-2.5 px-4 text-right font-bold ${
                        entry.balance > 0 ? 'text-[#176B4D]' : entry.balance < 0 ? 'text-[#B7791F]' : 'text-[#6B7280]'
                      }`}>
                        {formatINR(entry.balance)}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 5: PAYMENTS */}
      {activeTab === 'payments' && (
        <div className="bg-white rounded-2xl border border-[#E5E7EB] overflow-hidden shadow-xl">
          <div className="p-4 border-b border-[#E5E7EB] flex items-center justify-between">
            <h2 className="text-sm font-bold text-[#202124]">Payment Collections & Payouts</h2>
            <button
              onClick={() => setIsPaymentModalOpen(true)}
              className="px-3 py-1.5 rounded-lg bg-[#176B4D] hover:bg-[#176B4D] text-white font-bold text-xs"
            >
              Record Payment
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#FFFFFF]/60 text-[#6B7280] uppercase text-[10px] border-b border-[#E5E7EB]">
                <tr>
                  <th className="py-3 px-4 font-semibold">Date & Type</th>
                  <th className="py-3 px-4 font-semibold">Party Name</th>
                  <th className="py-3 px-4 font-semibold">Payment Mode & Ref</th>
                  <th className="py-3 px-4 font-semibold text-right">Amount</th>
                  <th className="py-3 px-4 font-semibold">Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-[#6B7280]">
                {data.payments.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="text-center py-10 text-[#6B7280]">
                      No payments recorded yet.
                    </td>
                  </tr>
                ) : (
                  data.payments.map(pay => (
                    <tr key={pay.id} className="hover:bg-[#F8F9FA] transition">
                      <td className="py-2.5 px-4">
                        <span className={`text-[10px] px-1.5 py-0.2 rounded font-bold ${
                          pay.type === 'PAYMENT_IN' ? 'bg-[#176B4D]/20 text-[#176B4D]' : 'bg-[#FDECEC] text-[#C62828] text-rose-300'
                        }`}>
                          {pay.type === 'PAYMENT_IN' ? 'PAYMENT IN (RECEIPT)' : 'PAYMENT OUT'}
                        </span>
                        <div className="text-[11px] text-[#6B7280] mt-0.5">{pay.date}</div>
                      </td>
                      <td className="py-2.5 px-4 font-semibold text-[#202124]">{pay.partyName}</td>
                      <td className="py-2.5 px-4 text-[#6B7280]">
                        {pay.paymentMode} {pay.referenceNumber && `(${pay.referenceNumber})`}
                      </td>
                      <td className={`py-2.5 px-4 text-right font-mono font-bold ${
                        pay.type === 'PAYMENT_IN' ? 'text-[#176B4D]' : 'text-[#C62828]'
                      }`}>
                        {formatINR(pay.amount)}
                      </td>
                      <td className="py-2.5 px-4 text-[#6B7280] text-[11px]">{pay.notes || '—'}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 6: EXPENSES */}
      {activeTab === 'expenses' && (
        <div className="bg-white rounded-2xl border border-[#E5E7EB] overflow-hidden shadow-xl">
          <div className="p-4 border-b border-[#E5E7EB] flex items-center justify-between">
            <h2 className="text-sm font-bold text-[#202124]">Business Expenses & Operational Overheads</h2>
            <button
              onClick={() => setIsExpenseModalOpen(true)}
              className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-[#FFF8E1] text-[#B7791F] text-slate-950 font-bold text-xs"
            >
              Add Expense
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#FFFFFF]/60 text-[#6B7280] uppercase text-[10px] border-b border-[#E5E7EB]">
                <tr>
                  <th className="py-3 px-4 font-semibold">Date & Category</th>
                  <th className="py-3 px-4 font-semibold">Vendor / Beneficiary</th>
                  <th className="py-3 px-4 font-semibold text-right">Taxable</th>
                  <th className="py-3 px-4 font-semibold text-right">GST (ITC Claimable)</th>
                  <th className="py-3 px-4 font-semibold text-right">Total Amount</th>
                  <th className="py-3 px-4 font-semibold">Mode</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-[#6B7280]">
                {data.expenses.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-10 text-[#6B7280]">
                      No operational expenses logged yet.
                    </td>
                  </tr>
                ) : (
                  data.expenses.map(exp => (
                    <tr key={exp.id} className="hover:bg-[#F8F9FA] transition">
                      <td className="py-2.5 px-4">
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-[#F8F9FA] text-[#B7791F] font-mono">
                          {exp.category}
                        </span>
                        <div className="text-[11px] text-[#6B7280] mt-0.5">{exp.date}</div>
                      </td>
                      <td className="py-2.5 px-4 font-medium text-[#202124]">{exp.partyName || 'Office Vendor'}</td>
                      <td className="py-2.5 px-4 text-right font-mono">{formatINR(exp.taxableAmount)}</td>
                      <td className="py-2.5 px-4 text-right font-mono text-purple-300">
                        {formatINR(exp.cgst + exp.sgst + exp.igst)}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono font-bold text-[#202124]">
                        {formatINR(exp.totalAmount)}
                      </td>
                      <td className="py-2.5 px-4 text-[#6B7280] text-[11px]">{exp.paymentMode}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 7: INVENTORY */}
      {activeTab === 'inventory' && (
        <div className="bg-white rounded-2xl border border-[#E5E7EB] overflow-hidden shadow-xl">
          <div className="p-4 border-b border-[#E5E7EB] flex items-center justify-between">
            <h2 className="text-sm font-bold text-[#202124]">Inventory Stock & Items Directory</h2>
            <button
              onClick={() => setIsItemModalOpen(true)}
              className="px-3 py-1.5 rounded-lg bg-slate-600 hover:bg-slate-500 text-slate-950 font-bold text-xs"
            >
              Add New Product / Service
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#FFFFFF]/60 text-[#6B7280] uppercase text-[10px] border-b border-[#E5E7EB]">
                <tr>
                  <th className="py-3 px-4 font-semibold">Item Name & SKU</th>
                  <th className="py-3 px-4 font-semibold">HSN/SAC</th>
                  <th className="py-3 px-4 font-semibold text-right">Purchase Price</th>
                  <th className="py-3 px-4 font-semibold text-right">Sale Price</th>
                  <th className="py-3 px-4 font-semibold text-center">GST Rate</th>
                  <th className="py-3 px-4 font-semibold text-right">Current Stock</th>
                  <th className="py-3 px-4 font-semibold text-right">Stock Valuation</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-[#6B7280]">
                {data.inventory.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-10 text-[#6B7280]">
                      No inventory items registered. Click "Add New Product" to configure items.
                    </td>
                  </tr>
                ) : (
                  data.inventory.map(item => (
                    <tr key={item.id} className="hover:bg-[#F8F9FA] transition">
                      <td className="py-2.5 px-4">
                        <div className="font-bold text-white">{item.name}</div>
                        <div className="text-[10px] text-[#6B7280] font-mono">SKU: {item.sku}</div>
                      </td>
                      <td className="py-2.5 px-4 font-mono text-[#176B4D]">{item.hsnSac}</td>
                      <td className="py-2.5 px-4 text-right font-mono">{formatINR(item.purchasePrice)}</td>
                      <td className="py-2.5 px-4 text-right font-mono text-[#176B4D] font-bold">
                        {formatINR(item.salePrice)}
                      </td>
                      <td className="py-2.5 px-4 text-center font-mono">{item.gstRate}%</td>
                      <td className="py-2.5 px-4 text-right font-mono">
                        <span className={`px-2 py-0.5 rounded font-bold ${
                          item.currentStock <= item.minStockAlert ? 'bg-[#FDECEC] text-[#C62828] text-rose-300' : 'text-white'
                        }`}>
                          {item.currentStock} {item.unit}
                        </span>
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono font-bold text-[#B7791F]">
                        {formatINR(item.currentStock * item.purchasePrice)}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 8: E-INVOICE & E-WAY BILL */}
      {activeTab === 'e_invoice_ewb' && (
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-white border border-[#E5E7EB] flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-[#202124]">E-Invoicing (IRN) & E-Way Bill Gateway</h2>
              <p className="text-xs text-[#6B7280]">
                Official GSTN NIC authorized API schema • Live IRN & Signed QR generation
              </p>
            </div>
            <span className="text-[10px] px-2 py-1 rounded bg-[#176B4D]/20 text-[#176B4D] font-mono">
              API Sandbox Connected
            </span>
          </div>

          <div className="bg-white rounded-2xl border border-[#E5E7EB] overflow-hidden shadow-xl">
            <div className="p-4 border-b border-[#E5E7EB] text-xs font-bold text-white">
              Generated E-Invoices ({data.eInvoices.length})
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#FFFFFF]/60 text-[#6B7280] uppercase text-[10px] border-b border-[#E5E7EB]">
                  <tr>
                    <th className="py-3 px-4 font-semibold">Invoice No & Date</th>
                    <th className="py-3 px-4 font-semibold">Recipient</th>
                    <th className="py-3 px-4 font-semibold">IRN (Invoice Reference Number)</th>
                    <th className="py-3 px-4 font-semibold">Ack No & Date</th>
                    <th className="py-3 px-4 font-semibold text-right">Amount</th>
                    <th className="py-3 px-4 font-semibold text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-[#6B7280]">
                  {data.eInvoices.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="text-center py-8 text-[#6B7280]">
                        No E-Invoices generated yet. Go to "Sales Invoices" and click "E-Invoice" on any eligible B2B invoice.
                      </td>
                    </tr>
                  ) : (
                    data.eInvoices.map(einv => (
                      <tr key={einv.id} className="hover:bg-[#F8F9FA] transition">
                        <td className="py-2.5 px-4 font-mono font-bold text-[#202124]">{einv.invoiceNumber}</td>
                        <td className="py-2.5 px-4">
                          <div className="text-[#202124]">{einv.recipientName}</div>
                          <div className="text-[11px] text-[#176B4D] font-mono">{einv.recipientGstin}</div>
                        </td>
                        <td className="py-2.5 px-4 font-mono text-[10px] text-[#6B7280] truncate max-w-[200px]">
                          {einv.irn}
                        </td>
                        <td className="py-2.5 px-4 font-mono text-[11px] text-[#6B7280]">
                          {einv.ackNumber} ({einv.ackDate?.split('T')[0]})
                        </td>
                        <td className="py-2.5 px-4 text-right font-mono font-bold text-[#176B4D]">
                          {formatINR(einv.totalAmount)}
                        </td>
                        <td className="py-2.5 px-4 text-center">
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-[#176B4D]/20 text-[#176B4D] font-bold">
                            GENERATED
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 9: BUSINESS REPORTS */}
      {activeTab === 'reports' && (
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-white border border-[#E5E7EB] flex items-center justify-between">
            <h2 className="text-sm font-bold text-[#202124]">Profit & Loss, Cash Flow & GST Return Statements</h2>
            <div className="flex items-center gap-2 text-xs">
              <span className="text-[#6B7280]">Frequency:</span>
              <select
                value={reportPeriod}
                onChange={e => setReportPeriod(e.target.value as any)}
                className="px-2.5 py-1 rounded bg-[#F8F9FA] border border-[#E5E7EB] text-white font-medium"
              >
                <option value="MONTHLY">Monthly (April 2026)</option>
                <option value="QUARTERLY">Quarterly (Q1 FY27)</option>
                <option value="YEARLY">Annual (FY 2026-27)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* P&L Snapshot */}
            <div className="p-5 rounded-2xl bg-white border border-[#E5E7EB] space-y-3">
              <h3 className="font-bold text-[#202124] text-sm pb-2 border-b border-[#E5E7EB]">
                Financial Performance (Trading & P&L)
              </h3>
              <div className="space-y-2 text-xs font-mono">
                <div className="flex justify-between py-1 border-b border-[#E5E7EB]">
                  <span className="text-[#6B7280] font-sans">Gross Sales Turnover</span>
                  <span className="text-[#176B4D] font-bold">{formatINR(accountingMetrics.totalSalesAmount)}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-[#E5E7EB]">
                  <span className="text-[#6B7280] font-sans">Cost of Goods / Purchases</span>
                  <span className="text-[#C62828]">{formatINR(accountingMetrics.totalPurchaseAmount)}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-[#E5E7EB]">
                  <span className="text-[#6B7280] font-sans">Operating Expenses</span>
                  <span className="text-[#B7791F]">{formatINR(accountingMetrics.totalExpenses)}</span>
                </div>
                <div className="flex justify-between py-2 border-t border-[#E5E7EB] text-sm font-bold">
                  <span className="text-white font-sans">Estimated Operating Profit</span>
                  <span className="text-[#176B4D] font-bold">
                    {formatINR(
                      accountingMetrics.totalSalesAmount -
                        accountingMetrics.totalPurchaseAmount -
                        accountingMetrics.totalExpenses
                    )}
                  </span>
                </div>
              </div>
            </div>

            {/* GST Summary */}
            <div className="p-5 rounded-2xl bg-white border border-[#E5E7EB] space-y-3">
              <h3 className="font-bold text-[#202124] text-sm pb-2 border-b border-[#E5E7EB]">
                GST Tax Liability & Cash Settlement
              </h3>
              <div className="space-y-2 text-xs font-mono">
                <div className="flex justify-between py-1 border-b border-[#E5E7EB]">
                  <span className="text-[#6B7280] font-sans">Outward Tax Liability (GSTR-1)</span>
                  <span className="text-[#B7791F] font-bold">
                    {formatINR(sales.reduce((s, inv) => s + (inv.cgst + inv.sgst + inv.igst), 0))}
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-[#E5E7EB]">
                  <span className="text-[#6B7280] font-sans">Eligible Input Tax Credit (ITC)</span>
                  <span className="text-[#176B4D]">
                    {formatINR(
                      purchases
                        .filter(p => p.itcStatus === 'ELIGIBLE')
                        .reduce((s, inv) => s + (inv.cgst + inv.sgst + inv.igst), 0)
                    )}
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-[#E5E7EB]">
                  <span className="text-[#6B7280] font-sans">Inward Reverse Charge (RCM Liability)</span>
                  <span className="text-purple-300">
                    {formatINR(
                      purchases
                        .filter(p => p.rcm)
                        .reduce((s, inv) => s + (inv.cgst + inv.sgst + inv.igst), 0)
                    )}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CREATE NEW SALE INVOICE MODAL */}
      {isSaleModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#FFFFFF]/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border border-[#E5E7EB] rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
              <h3 className="font-bold text-[#202124] text-base">New Sales Tax Invoice</h3>
              <button onClick={() => setIsSaleModalOpen(false)} className="text-[#6B7280] hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveSale} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#6B7280] mb-1 font-semibold">Invoice Number *</label>
                  <input
                    type="text"
                    value={saleForm.invoiceNumber}
                    onChange={e => setSaleForm({ ...saleForm, invoiceNumber: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white font-mono"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[#6B7280] mb-1 font-semibold">Invoice Date *</label>
                  <input
                    type="date"
                    value={saleForm.invoiceDate}
                    onChange={e => setSaleForm({ ...saleForm, invoiceDate: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#6B7280] mb-1 font-semibold">Customer / Party Name *</label>
                  <input
                    type="text"
                    value={saleForm.customerName}
                    onChange={e => setSaleForm({ ...saleForm, customerName: e.target.value })}
                    placeholder="e.g. Godrej Infotech Solutions Ltd"
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[#6B7280] mb-1 font-semibold">Customer GSTIN (Leave blank for B2C)</label>
                  <input
                    type="text"
                    value={saleForm.customerGstin}
                    onChange={e => setSaleForm({ ...saleForm, customerGstin: e.target.value.toUpperCase() })}
                    placeholder="27AAACG0561F1ZK"
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#6B7280] mb-1 font-semibold">Place of Supply (State) *</label>
                  <select
                    value={saleForm.placeOfSupply}
                    onChange={e => setSaleForm({ ...saleForm, placeOfSupply: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white"
                  >
                    {INDIAN_STATES.map(s => (
                      <option key={s.code} value={s.name}>
                        {s.name} ({s.code})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[#6B7280] mb-1 font-semibold">GST Classification</label>
                  <select
                    value={saleForm.classification}
                    onChange={e => setSaleForm({ ...saleForm, classification: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white"
                  >
                    <option value="B2B">B2B (Registered Taxpayer)</option>
                    <option value="B2C_SMALL">B2C Small (Local Consumer)</option>
                    <option value="B2C_LARGE">B2C Large (Inter-State &gt; ₹2.5L)</option>
                    <option value="EXPORT_WITH_PAYMENT">Export (With Tax)</option>
                    <option value="EXPORT_WITHOUT_PAYMENT">Export (LUT - Without Tax)</option>
                    <option value="SEZ_WITH_PAYMENT">SEZ Unit</option>
                  </select>
                </div>
              </div>

              {/* Item Details */}
              <div className="p-3 rounded-xl bg-[#FFFFFF] border border-[#E5E7EB] space-y-3">
                <div className="font-semibold text-white">Item & Service Particulars</div>
                <div>
                  <label className="block text-[#6B7280] mb-1">Description</label>
                  <input
                    type="text"
                    value={saleForm.itemDescription}
                    onChange={e => setSaleForm({ ...saleForm, itemDescription: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-white border border-[#E5E7EB] text-white"
                  />
                </div>

                <div className="grid grid-cols-4 gap-2">
                  <div>
                    <label className="block text-[#6B7280] mb-1">HSN/SAC</label>
                    <input
                      type="text"
                      value={saleForm.hsnSac}
                      onChange={e => setSaleForm({ ...saleForm, hsnSac: e.target.value })}
                      className="w-full px-2 py-1.5 rounded-lg bg-white border border-[#E5E7EB] text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[#6B7280] mb-1">Quantity</label>
                    <input
                      type="number"
                      min={1}
                      value={saleForm.quantity}
                      onChange={e => setSaleForm({ ...saleForm, quantity: Number(e.target.value) })}
                      className="w-full px-2 py-1.5 rounded-lg bg-white border border-[#E5E7EB] text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[#6B7280] mb-1">Unit Rate (₹)</label>
                    <input
                      type="number"
                      min={0}
                      value={saleForm.rate}
                      onChange={e => setSaleForm({ ...saleForm, rate: Number(e.target.value) })}
                      className="w-full px-2 py-1.5 rounded-lg bg-white border border-[#E5E7EB] text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[#6B7280] mb-1">GST Rate (%)</label>
                    <select
                      value={saleForm.gstRate}
                      onChange={e => setSaleForm({ ...saleForm, gstRate: Number(e.target.value) })}
                      className="w-full px-2 py-1.5 rounded-lg bg-white border border-[#E5E7EB] text-white"
                    >
                      <option value={0}>0% (Nil)</option>
                      <option value={5}>5%</option>
                      <option value={12}>12%</option>
                      <option value={18}>18%</option>
                      <option value={28}>28%</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Tax Math Calculation Summary */}
              <div className="p-3 rounded-xl bg-[#FFFFFF] border border-[#E5E7EB] text-xs font-mono space-y-1">
                <div className="flex justify-between text-[#6B7280] font-sans">
                  <span>Supply Nature:</span>
                  <span className="font-bold text-white">
                    {saleCalculations.isInterState ? 'Inter-State (IGST Applicable)' : 'Intra-State (CGST + SGST)'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Base Taxable Amount:</span>
                  <span>{formatINR(saleCalculations.taxable)}</span>
                </div>
                {saleCalculations.isInterState ? (
                  <div className="flex justify-between text-purple-300">
                    <span>IGST ({saleForm.gstRate}%):</span>
                    <span>{formatINR(saleCalculations.igst)}</span>
                  </div>
                ) : (
                  <>
                    <div className="flex justify-between text-[#176B4D]">
                      <span>CGST ({saleForm.gstRate / 2}%):</span>
                      <span>{formatINR(saleCalculations.cgst)}</span>
                    </div>
                    <div className="flex justify-between text-[#176B4D]">
                      <span>SGST ({saleForm.gstRate / 2}%):</span>
                      <span>{formatINR(saleCalculations.sgst)}</span>
                    </div>
                  </>
                )}
                <div className="flex justify-between text-[#176B4D] font-bold border-t border-[#E5E7EB] pt-1 text-sm">
                  <span>Total Invoice Amount:</span>
                  <span>{formatINR(saleCalculations.total)}</span>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-[#E5E7EB]">
                <button
                  type="button"
                  onClick={() => setIsSaleModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-[#F8F9FA] text-[#6B7280] font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-[#176B4D] hover:bg-[#176B4D] text-slate-950 font-bold shadow-md"
                >
                  Generate Invoice
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CREATE NEW PURCHASE BILL MODAL */}
      {isPurchaseModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#FFFFFF]/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border border-[#E5E7EB] rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
              <h3 className="font-bold text-[#202124] text-base">Record Purchase Bill (Inward)</h3>
              <button onClick={() => setIsPurchaseModalOpen(false)} className="text-[#6B7280] hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSavePurchase} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#6B7280] mb-1 font-semibold">Vendor Bill No *</label>
                  <input
                    type="text"
                    value={purchaseForm.invoiceNumber}
                    onChange={e => setPurchaseForm({ ...purchaseForm, invoiceNumber: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white font-mono"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[#6B7280] mb-1 font-semibold">Bill Date *</label>
                  <input
                    type="date"
                    value={purchaseForm.invoiceDate}
                    onChange={e => setPurchaseForm({ ...purchaseForm, invoiceDate: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#6B7280] mb-1 font-semibold">Supplier Name *</label>
                  <input
                    type="text"
                    value={purchaseForm.supplierName}
                    onChange={e => setPurchaseForm({ ...purchaseForm, supplierName: e.target.value })}
                    placeholder="e.g. Siemens Cloud & Infra Ltd"
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[#6B7280] mb-1 font-semibold">Supplier GSTIN *</label>
                  <input
                    type="text"
                    value={purchaseForm.supplierGstin}
                    onChange={e => setPurchaseForm({ ...purchaseForm, supplierGstin: e.target.value.toUpperCase() })}
                    placeholder="27AABCS1429B1Z1"
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white font-mono"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-[#6B7280] mb-1">Item / Description</label>
                <input
                  type="text"
                  value={purchaseForm.itemDescription}
                  onChange={e => setPurchaseForm({ ...purchaseForm, itemDescription: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-[#6B7280] mb-1 font-semibold">Taxable Amount *</label>
                  <input
                    type="number"
                    value={purchaseForm.taxableValue}
                    onChange={e => setPurchaseForm({ ...purchaseForm, taxableValue: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white font-mono"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[#6B7280] mb-1 font-semibold">GST Rate (%)</label>
                  <select
                    value={purchaseForm.gstRate}
                    onChange={e => setPurchaseForm({ ...purchaseForm, gstRate: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white"
                  >
                    <option value={5}>5%</option>
                    <option value={12}>12%</option>
                    <option value={18}>18%</option>
                    <option value={28}>28%</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[#6B7280] mb-1 font-semibold">ITC Eligibility</label>
                  <select
                    value={purchaseForm.itcStatus}
                    onChange={e => setPurchaseForm({ ...purchaseForm, itcStatus: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white"
                  >
                    <option value="ELIGIBLE">Eligible ITC</option>
                    <option value="INELIGIBLE">Ineligible / Blocked (17(5))</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-[#E5E7EB]">
                <button
                  type="button"
                  onClick={() => setIsPurchaseModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-[#F8F9FA] text-[#6B7280]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-slate-600 hover:bg-slate-500 text-slate-950 font-bold"
                >
                  Save Purchase Bill
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD PARTY MODAL */}
      {isPartyModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#FFFFFF]/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border border-[#E5E7EB] rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
              <h3 className="font-bold text-[#202124] text-base">Add Customer / Supplier Party</h3>
              <button onClick={() => setIsPartyModalOpen(false)} className="text-[#6B7280] hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveParty} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#6B7280] mb-1 font-semibold">Party Name *</label>
                  <input
                    type="text"
                    value={partyForm.name}
                    onChange={e => setPartyForm({ ...partyForm, name: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[#6B7280] mb-1 font-semibold">Party Type</label>
                  <select
                    value={partyForm.type}
                    onChange={e => setPartyForm({ ...partyForm, type: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white"
                  >
                    <option value="CUSTOMER">Customer (Receivable)</option>
                    <option value="SUPPLIER">Supplier (Payable)</option>
                    <option value="BOTH">Both</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#6B7280] mb-1">GSTIN</label>
                  <input
                    type="text"
                    value={partyForm.gstin}
                    onChange={e => setPartyForm({ ...partyForm, gstin: e.target.value.toUpperCase() })}
                    placeholder="15-char GSTIN"
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[#6B7280] mb-1">Mobile / Phone</label>
                  <input
                    type="text"
                    value={partyForm.mobile}
                    onChange={e => setPartyForm({ ...partyForm, mobile: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#6B7280] mb-1">Opening Balance (₹)</label>
                  <input
                    type="number"
                    value={partyForm.openingBalance}
                    onChange={e => setPartyForm({ ...partyForm, openingBalance: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[#6B7280] mb-1">Credit Terms (Days)</label>
                  <input
                    type="number"
                    value={partyForm.paymentTermsDays}
                    onChange={e => setPartyForm({ ...partyForm, paymentTermsDays: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white"
                  />
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-[#E5E7EB]">
                <button
                  type="button"
                  onClick={() => setIsPartyModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-[#F8F9FA] text-[#6B7280]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-[#176B4D] hover:bg-[#176B4D] text-white font-bold"
                >
                  Save Party
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* RECORD PAYMENT MODAL */}
      {isPaymentModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#FFFFFF]/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border border-[#E5E7EB] rounded-2xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
              <h3 className="font-bold text-[#202124] text-base">Record Payment Receipt / Payout</h3>
              <button onClick={() => setIsPaymentModalOpen(false)} className="text-[#6B7280] hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSavePayment} className="space-y-3 text-xs">
              <div>
                <label className="block text-[#6B7280] mb-1 font-semibold">Payment Type</label>
                <select
                  value={paymentForm.type}
                  onChange={e => setPaymentForm({ ...paymentForm, type: e.target.value as any })}
                  className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white"
                >
                  <option value="PAYMENT_IN">Payment In (Receipt from Customer)</option>
                  <option value="PAYMENT_OUT">Payment Out (Payout to Vendor)</option>
                </select>
              </div>

              <div>
                <label className="block text-[#6B7280] mb-1 font-semibold">Select Party *</label>
                <select
                  value={paymentForm.partyId}
                  onChange={e => setPaymentForm({ ...paymentForm, partyId: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white"
                  required
                >
                  <option value="">-- Choose Customer / Supplier --</option>
                  {data.parties.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({formatINR(p.currentBalance)})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#6B7280] mb-1 font-semibold">Amount (₹) *</label>
                  <input
                    type="number"
                    value={paymentForm.amount}
                    onChange={e => setPaymentForm({ ...paymentForm, amount: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white font-mono"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[#6B7280] mb-1 font-semibold">Mode</label>
                  <select
                    value={paymentForm.paymentMode}
                    onChange={e => setPaymentForm({ ...paymentForm, paymentMode: e.target.value as PaymentMode })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white"
                  >
                    <option value="BANK_TRANSFER">Bank Transfer (NEFT/RTGS)</option>
                    <option value="UPI">UPI</option>
                    <option value="CASH">Cash</option>
                    <option value="CHEQUE">Cheque</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-[#E5E7EB]">
                <button
                  type="button"
                  onClick={() => setIsPaymentModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-[#F8F9FA] text-[#6B7280]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-[#176B4D] hover:bg-[#176B4D] text-white font-bold"
                >
                  Save Payment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD EXPENSE MODAL */}
      {isExpenseModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#FFFFFF]/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border border-[#E5E7EB] rounded-2xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
              <h3 className="font-bold text-[#202124] text-base">Add Operational Expense</h3>
              <button onClick={() => setIsExpenseModalOpen(false)} className="text-[#6B7280] hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveExpense} className="space-y-3 text-xs">
              <div>
                <label className="block text-[#6B7280] mb-1 font-semibold">Expense Category</label>
                <select
                  value={expenseForm.category}
                  onChange={e => setExpenseForm({ ...expenseForm, category: e.target.value as any })}
                  className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white"
                >
                  <option value="RENT">Rent & Commercial Lease</option>
                  <option value="ELECTRICITY">Electricity & Utility Power</option>
                  <option value="TELEPHONE_INTERNET">Telephone & Internet Leased Lines</option>
                  <option value="OFFICE_STATIONERY">Office Stationery & Supplies</option>
                  <option value="LOGISTICS_TRANSPORT">Freight & Goods Transportation (GTA)</option>
                  <option value="PROFESSIONAL_LEGAL_FEES">Legal & Professional Advisory Fees</option>
                  <option value="SALARIES_WAGES">Salaries & Employee Allowances</option>
                  <option value="OTHER_OVERHEADS">Other Operating Expenses</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#6B7280] mb-1 font-semibold">Taxable Amount *</label>
                  <input
                    type="number"
                    value={expenseForm.taxableAmount}
                    onChange={e => setExpenseForm({ ...expenseForm, taxableAmount: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white font-mono"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[#6B7280] mb-1 font-semibold">GST Rate (%)</label>
                  <select
                    value={expenseForm.gstRate}
                    onChange={e => setExpenseForm({ ...expenseForm, gstRate: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white"
                  >
                    <option value={0}>0%</option>
                    <option value={5}>5%</option>
                    <option value={18}>18%</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="itcElig"
                  checked={expenseForm.isItcEligible}
                  onChange={e => setExpenseForm({ ...expenseForm, isItcEligible: e.target.checked })}
                  className="rounded border-[#E5E7EB] text-emerald-500"
                />
                <label htmlFor="itcElig" className="text-[#6B7280] cursor-pointer">
                  Eligible for GST Input Tax Credit (ITC)
                </label>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-[#E5E7EB]">
                <button
                  type="button"
                  onClick={() => setIsExpenseModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-[#F8F9FA] text-[#6B7280]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-amber-600 hover:bg-[#FFF8E1] text-[#B7791F] text-slate-950 font-bold"
                >
                  Save Expense
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD INVENTORY ITEM MODAL */}
      {isItemModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#FFFFFF]/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border border-[#E5E7EB] rounded-2xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
              <h3 className="font-bold text-[#202124] text-base">Add Product or Service Item</h3>
              <button onClick={() => setIsItemModalOpen(false)} className="text-[#6B7280] hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveItem} className="space-y-3 text-xs">
              <div>
                <label className="block text-[#6B7280] mb-1 font-semibold">Item Name *</label>
                <input
                  type="text"
                  value={itemForm.name}
                  onChange={e => setItemForm({ ...itemForm, name: e.target.value })}
                  placeholder="e.g. Enterprise Router Switch 24-Port"
                  className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#6B7280] mb-1">HSN/SAC Code</label>
                  <input
                    type="text"
                    value={itemForm.hsnSac}
                    onChange={e => setItemForm({ ...itemForm, hsnSac: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[#6B7280] mb-1">Unit</label>
                  <select
                    value={itemForm.unit}
                    onChange={e => setItemForm({ ...itemForm, unit: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white"
                  >
                    <option value="NOS">Numbers (NOS)</option>
                    <option value="PCS">Pieces (PCS)</option>
                    <option value="BOX">Box</option>
                    <option value="SET">Set</option>
                    <option value="MTR">Meters</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#6B7280] mb-1">Purchase Price (₹)</label>
                  <input
                    type="number"
                    value={itemForm.purchasePrice}
                    onChange={e => setItemForm({ ...itemForm, purchasePrice: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[#6B7280] mb-1">Sale Price (₹)</label>
                  <input
                    type="number"
                    value={itemForm.salePrice}
                    onChange={e => setItemForm({ ...itemForm, salePrice: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#6B7280] mb-1">Opening Stock</label>
                  <input
                    type="number"
                    value={itemForm.openingStock}
                    onChange={e => setItemForm({ ...itemForm, openingStock: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[#6B7280] mb-1">GST Rate (%)</label>
                  <select
                    value={itemForm.gstRate}
                    onChange={e => setItemForm({ ...itemForm, gstRate: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white"
                  >
                    <option value={5}>5%</option>
                    <option value={12}>12%</option>
                    <option value={18}>18%</option>
                    <option value={28}>28%</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-[#E5E7EB]">
                <button
                  type="button"
                  onClick={() => setIsItemModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-[#F8F9FA] text-[#6B7280]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-slate-600 hover:bg-slate-500 text-slate-950 font-bold"
                >
                  Save Item
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PAYMENT REMINDER MODAL */}
      {reminderModalInvoice && (
        <div className="fixed inset-0 z-50 bg-[#FFFFFF]/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border border-[#E5E7EB] rounded-2xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
              <h3 className="font-bold text-[#202124] text-base">Dispatch Payment Reminder</h3>
              <button onClick={() => setReminderModalInvoice(null)} className="text-[#6B7280] hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-[#FFFFFF] border border-[#E5E7EB] space-y-1">
                <div className="font-semibold text-white">{reminderModalInvoice.recipientName}</div>
                <div className="font-mono text-[#176B4D]">
                  Invoice #{reminderModalInvoice.invoiceNumber} • Outstanding: {formatINR(reminderModalInvoice.totalAmount)}
                </div>
              </div>

              <div>
                <label className="block text-[#6B7280] mb-1">Reminder Message Template</label>
                <textarea
                  rows={4}
                  readOnly
                  value={`Dear ${reminderModalInvoice.recipientName},\n\nThis is a polite reminder from ${currentClient.name} regarding outstanding Tax Invoice #${reminderModalInvoice.invoiceNumber} for ${formatINR(reminderModalInvoice.totalAmount)} dated ${reminderModalInvoice.invoiceDate}.\n\nKindly release the payment at your earliest convenience.`}
                  className="w-full p-2.5 rounded-lg bg-[#FFFFFF] border border-[#E5E7EB] text-[#6B7280] text-xs"
                />
              </div>

              <div className="pt-2 flex flex-col gap-2">
                <button
                  onClick={() => {
                    alert(`WhatsApp reminder template generated for ${reminderModalInvoice.recipientName}.`);
                    setReminderModalInvoice(null);
                  }}
                  className="w-full flex items-center justify-center gap-2 py-2 rounded-xl bg-[#176B4D] hover:bg-[#176B4D] text-white font-bold"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Send via WhatsApp</span>
                </button>
                <button
                  onClick={() => {
                    alert(`Email reminder queued for ${reminderModalInvoice.recipientName}.`);
                    setReminderModalInvoice(null);
                  }}
                  className="w-full flex items-center justify-center gap-2 py-2 rounded-xl bg-[#F8F9FA] hover:bg-slate-700 text-[#202124] font-semibold"
                >
                  <Mail className="w-4 h-4 text-[#176B4D]" />
                  <span>Send via Email</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
