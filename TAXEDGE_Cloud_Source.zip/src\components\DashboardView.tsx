import React from 'react';
import {
  Users,
  FileText,
  FileCheck2,
  AlertTriangle,
  Receipt,
  ArrowRight,
  Sparkles,
  GitCompare,
  TrendingUp,
  FileSpreadsheet,
  CheckCircle2,
  Calendar,
  Clock,
  Info,
  ShieldCheck,
  PlusCircle,
  Download,
  Upload,
  RotateCcw,
  Trash2,
  Sliders,
  ExternalLink,
  ChevronRight,
  Database,
  Lock,
  Layers,
  Repeat,
  ShoppingBag,
  BookOpen
} from 'lucide-react';
import { formatINR } from '../utils/taxMath';
import { TransactionInvoice, GSTR2BRecord, ComplianceException, GSTR1Summary, GSTR3BSummary } from '../types/gst';
import { ClientMaster } from '../types/client';
import { GstPortalCredentialsSection } from './GstPortalCredentialsSection';

interface DashboardViewProps {
  sales: TransactionInvoice[];
  purchases: TransactionInvoice[];
  gstr2b: GSTR2BRecord[];
  gstr1: GSTR1Summary;
  gstr3b: GSTR3BSummary;
  exceptions: ComplianceException[];
  reconciliationStats: any;
  filingReadiness: any;
  currentClient: ClientMaster | null;
  currentGstin: string;
  isDemoMode: boolean;
  onNavigate: (tab: any) => void;
  onOpenAI: (initialPrompt?: string) => void;
  onOpenOcr: () => void;
  onOpenDataModal: (target?: 'SALES' | 'PURCHASES' | 'GSTR2B') => void;
  onResetAllToEmpty: () => void;
  onResetToDemoData: () => void;
  onOpenDemoConfirm?: () => void;
  onNavigateToClientMaster?: () => void;
  auditLogs?: any[];
  selectedFy?: string;
  selectedMonth?: string;
  clients?: ClientMaster[];
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  sales,
  purchases,
  gstr2b,
  gstr1,
  gstr3b,
  exceptions,
  reconciliationStats,
  filingReadiness,
  currentClient,
  currentGstin,
  isDemoMode,
  onNavigate,
  onOpenAI,
  onOpenOcr,
  onOpenDataModal,
  onResetAllToEmpty,
  onResetToDemoData,
  onOpenDemoConfirm,
  onNavigateToClientMaster,
  auditLogs = [],
  selectedFy = '2026-27',
  selectedMonth = 'October',
  clients = []
}) => {
  const hasUploadedSales = sales.length > 0;
  const hasUploadedPurchases = purchases.length > 0;
  const hasUploaded2B = gstr2b.length > 0;
  const hasAnyData = hasUploadedSales || hasUploadedPurchases || hasUploaded2B;

  // 100% Dynamic stats from actual uploaded data — ZERO fake defaults
  const activeClientsCount = clients.length > 0 ? clients.length : (currentClient ? 1 : 0);
  const returnsFiledCount = auditLogs.filter(l => l.action?.toLowerCase().includes('filed') || l.action?.toLowerCase().includes('filing')).length;
  const returnsPendingCount = hasUploadedSales && returnsFiledCount === 0 ? 1 : 0;
  const totalLiabilityValue = hasUploadedSales ? gstr1.totalTaxLiability : 0;
  const grossTurnoverValue = hasUploadedSales ? gstr1.grossTurnover : 0;
  const complianceScore = hasAnyData ? Math.round(filingReadiness.score) : 0;

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-[1600px] mx-auto text-slate-800">
      {/* 1. Dashboard Greeting Header matching screenshot */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight flex items-center gap-2.5">
            <span>Dashboard</span>
            {!hasAnyData && (
              <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-700 border border-amber-200">
                Awaiting Upload
              </span>
            )}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 font-medium mt-1">
            Welcome back, <span className="font-semibold text-slate-700">Anand!</span> Here's your GST compliance overview.
          </p>
        </div>

        {/* Right Period & Action */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-white border border-slate-200 text-xs font-bold text-slate-700 shadow-2xs">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <span>
              {selectedMonth.substring(0, 3)} {selectedFy.split('-')[0]}
            </span>
          </div>
          {onNavigateToClientMaster && (
            <button
              onClick={onNavigateToClientMaster}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-[#0B1F44] hover:bg-[#122b5d] text-white text-xs font-bold transition shadow-sm active:scale-95"
            >
              <PlusCircle className="w-3.5 h-3.5 text-[#D4A24C]" />
              <span>+ Add Client</span>
            </button>
          )}
        </div>
      </div>

      {/* Zero Data Notification Banner: Clear Slate Guidance */}
      {!hasAnyData && (
        <div className="p-5 rounded-2xl bg-white border-2 border-dashed border-[#D4A24C]/40 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="w-11 h-11 rounded-xl bg-amber-50 text-[#D4A24C] flex items-center justify-center shrink-0 border border-amber-200">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Clean Slate: No default data loaded
              </h3>
              <p className="text-xs text-slate-500 mt-0.5 max-w-2xl leading-relaxed">
                Software is ready in clean zero-data state. Only data you upload will be processed. GSTR-1, GSTR-3B, and 2B Reconciliation will generate automatically once your registers are uploaded.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <a
              href="/TAXEDGE_GST_TEMPLATE.xlsx"
              download="TAXEDGE_GST_TEMPLATE.xlsx"
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#0B1F44] hover:bg-[#152e61] text-white text-xs font-bold transition shadow-xs"
              title="Download official 10-sheet TAXEDGE Excel template"
            >
              <Download className="w-3.5 h-3.5 text-[#D4A24C]" />
              <span>Download Master Template</span>
            </a>

            <button
              onClick={() => onOpenDataModal('SALES')}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#D4A24C] hover:bg-[#c5933d] text-slate-950 text-xs font-bold transition shadow-xs active:scale-95"
            >
              <Upload className="w-3.5 h-3.5 text-slate-950" />
              <span>Upload Excel / CSV</span>
            </button>
          </div>
        </div>
      )}

      {/* 2. Top Row: 4 Hero KPI Cards matching screenshot (100% Dynamic) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 sm:gap-5">
        {/* Card 1: Active Clients (Soft Cyan Accent) */}
        <div
          onClick={() => onNavigate('clientmaster')}
          className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-xs hover:shadow-md transition cursor-pointer group relative overflow-hidden"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-[#E0F2FE] text-[#0284C7] flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                {activeClientsCount}
              </div>
              <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                Active Clients
              </div>
            </div>
          </div>
          <div className="mt-3.5 flex items-center gap-1.5 text-xs">
            <span className="font-bold text-emerald-600 flex items-center">
              {activeClientsCount > 0 ? '✓ Ready' : '0 Registered'}
            </span>
            <span className="text-slate-400 text-[11px]">• Client Database</span>
          </div>
        </div>

        {/* Card 2: Returns Filed (Soft Emerald Accent) */}
        <div
          onClick={() => onNavigate('filing')}
          className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-xs hover:shadow-md transition cursor-pointer group relative overflow-hidden"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-[#DCFCE7] text-[#16A34A] flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <FileCheck2 className="w-6 h-6" />
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                {returnsFiledCount}
              </div>
              <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                Returns Filed
              </div>
            </div>
          </div>
          <div className="mt-3.5 flex items-center gap-1.5 text-xs">
            <span className="font-bold text-emerald-600 flex items-center">
              {returnsFiledCount > 0 ? `✓ ${returnsFiledCount} Filed` : '0 Filed'}
            </span>
            <span className="text-slate-400 text-[11px]">• Current Period</span>
          </div>
        </div>

        {/* Card 3: Returns Pending (Soft Coral/Amber Accent) */}
        <div
          onClick={() => onNavigate('exceptions')}
          className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-xs hover:shadow-md transition cursor-pointer group relative overflow-hidden"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-[#FEE2E2] text-[#DC2626] flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                {returnsPendingCount}
              </div>
              <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                Returns Pending
              </div>
            </div>
          </div>
          <div className="mt-3.5 flex items-center gap-1.5 text-xs">
            <span className={`font-bold flex items-center ${returnsPendingCount > 0 ? 'text-rose-600' : 'text-slate-400'}`}>
              {returnsPendingCount > 0 ? 'Action Required' : '0 Pending'}
            </span>
          </div>
        </div>

        {/* Card 4: Total Tax Liability (Soft Purple Accent) */}
        <div
          onClick={() => onNavigate('gstr3b')}
          className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-xs hover:shadow-md transition cursor-pointer group relative overflow-hidden"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-[#F3E8FF] text-[#9333EA] flex items-center justify-center shrink-0 font-bold text-xl group-hover:scale-105 transition-transform">
              ₹
            </div>
            <div>
              <div className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                {hasUploadedSales ? formatINR(totalLiabilityValue) : '₹ 0.00'}
              </div>
              <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                Total Tax Liability
              </div>
            </div>
          </div>
          <div className="mt-3.5 flex items-center gap-1.5 text-xs">
            <span className="font-bold text-slate-600">
              {hasUploadedSales ? `${sales.length} Invoices uploaded` : 'Awaiting Sales upload'}
            </span>
          </div>
        </div>
      </div>

      {/* 3. Middle Row: Return Filing Status Donut, Month-wise Tax Area Chart, Upcoming Due Dates */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Card 1: Return Filing Status (4 cols) */}
        <div className="lg:col-span-4 bg-white rounded-2xl p-5 border border-slate-200/90 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                Return Filing Status — {selectedMonth.substring(0, 3)} {selectedFy.split('-')[0]}
              </h3>
            </div>

            <div className="flex items-center justify-around py-3">
              {/* Circular Donut Progress Ring */}
              <div className="relative w-36 h-36 flex items-center justify-center">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                  {/* Background Circle */}
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    stroke="#E2E8F0"
                    strokeWidth="10"
                    fill="transparent"
                  />
                  {hasAnyData && (
                    <circle
                      cx="50"
                      cy="50"
                      r="40"
                      stroke="#10B981"
                      strokeWidth="10"
                      strokeDasharray="251.2"
                      strokeDashoffset={251.2 - (251.2 * complianceScore) / 100}
                      strokeLinecap="round"
                      fill="transparent"
                      className="transition-all duration-1000 ease-out"
                    />
                  )}
                </svg>

                {/* Donut Center */}
                <div className="absolute flex flex-col items-center justify-center text-center">
                  <span className="text-2xl font-black text-slate-900 leading-tight">
                    {hasAnyData ? `${complianceScore}%` : '0%'}
                  </span>
                  <span className="text-[11px] font-semibold text-slate-400">
                    {hasAnyData ? 'Compliant' : 'Awaiting Data'}
                  </span>
                </div>
              </div>

              {/* Legend List */}
              <div className="space-y-2 text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#10B981]"></span>
                  <span className="text-slate-500 font-medium">Filed</span>
                  <span className="font-bold text-slate-900 ml-auto pl-2">{returnsFiledCount}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#F59E0B]"></span>
                  <span className="text-slate-500 font-medium">Pending</span>
                  <span className="font-bold text-slate-900 ml-auto pl-2">{returnsPendingCount}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-300"></span>
                  <span className="text-slate-500 font-medium">Not Due</span>
                  <span className="font-bold text-slate-900 ml-auto pl-2">
                    {activeClientsCount > returnsFiledCount + returnsPendingCount ? activeClientsCount - returnsFiledCount - returnsPendingCount : 0}
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 text-right">
            <button
              onClick={() => onNavigate('filing')}
              className="text-xs font-bold text-emerald-600 hover:text-emerald-700 inline-flex items-center gap-1 transition"
            >
              <span>View Details</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Card 2: Month-wise Tax Liability (4 cols) */}
        <div className="lg:col-span-4 bg-white rounded-2xl p-5 border border-slate-200/90 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                Month-wise Tax Liability
              </h3>
            </div>

            {/* Area Spline Chart SVG */}
            <div className="py-2">
              <div className="relative h-44 w-full">
                <svg className="w-full h-full overflow-visible" viewBox="0 0 320 140">
                  <defs>
                    <linearGradient id="taxGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#0284C7" stopOpacity="0.25" />
                      <stop offset="100%" stopColor="#0284C7" stopOpacity="0.0" />
                    </linearGradient>
                  </defs>

                  {/* Horizontal Grid lines & Y-Axis */}
                  <line x1="30" y1="20" x2="310" y2="20" stroke="#F1F5F9" strokeWidth="1" />
                  <text x="5" y="23" fontSize="8" fill="#94A3B8">₹ 20L</text>

                  <line x1="30" y1="50" x2="310" y2="50" stroke="#F1F5F9" strokeWidth="1" />
                  <text x="5" y="53" fontSize="8" fill="#94A3B8">₹ 15L</text>

                  <line x1="30" y1="80" x2="310" y2="80" stroke="#F1F5F9" strokeWidth="1" />
                  <text x="5" y="83" fontSize="8" fill="#94A3B8">₹ 10L</text>

                  <line x1="30" y1="110" x2="310" y2="110" stroke="#F1F5F9" strokeWidth="1" />
                  <text x="8" y="113" fontSize="8" fill="#94A3B8">₹ 5L</text>

                  {hasUploadedSales ? (
                    <>
                      {/* Shaded Area for active sales */}
                      <polygon
                        points="40,115 85,110 135,105 185,95 235,90 290,45 290,120 40,120"
                        fill="url(#taxGradient)"
                      />
                      <path
                        d="M 40 115 Q 65 112 85 110 T 135 105 T 185 95 T 235 90 T 290 45"
                        fill="none"
                        stroke="#0284C7"
                        strokeWidth="2.5"
                        strokeLinecap="round"
                      />
                      <circle cx="290" cy="45" r="4.5" fill="#0B1F44" stroke="#D4A24C" strokeWidth="2" />
                      <g transform="translate(240, 18)">
                        <rect x="0" y="0" width="75" height="18" rx="4" fill="#0B1F44" />
                        <text x="37" y="12" textAnchor="middle" fill="#FFFFFF" fontSize="9" fontWeight="bold">
                          {formatINR(totalLiabilityValue)}
                        </text>
                      </g>
                    </>
                  ) : (
                    <>
                      {/* Zero baseline */}
                      <line x1="40" y1="120" x2="290" y2="120" stroke="#CBD5E1" strokeWidth="2" strokeDasharray="4 4" />
                      <text x="165" y="80" textAnchor="middle" fontSize="11" fill="#94A3B8" fontWeight="500">
                        Upload sales to compute tax trend
                      </text>
                    </>
                  )}

                  {/* X-Axis Month Labels */}
                  <text x="40" y="135" textAnchor="middle" fontSize="9" fill="#64748B">May</text>
                  <text x="85" y="135" textAnchor="middle" fontSize="9" fill="#64748B">Jun</text>
                  <text x="135" y="135" textAnchor="middle" fontSize="9" fill="#64748B">Jul</text>
                  <text x="185" y="135" textAnchor="middle" fontSize="9" fill="#64748B">Aug</text>
                  <text x="235" y="135" textAnchor="middle" fontSize="9" fill="#64748B">Sep</text>
                  <text x="290" y="135" textAnchor="middle" fontSize="9" fill="#0B1F44" fontWeight="bold">Oct</text>
                </svg>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 text-right">
            <button
              onClick={() => onNavigate('gstr3b')}
              className="text-xs font-bold text-emerald-600 hover:text-emerald-700 inline-flex items-center gap-1 transition"
            >
              <span>View Report</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Card 3: Upcoming Due Dates (4 cols) */}
        <div className="lg:col-span-4 bg-white rounded-2xl p-5 border border-slate-200/90 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-slate-400" />
                <span>Upcoming Due Dates</span>
              </h3>
              <button
                onClick={() => onNavigate('filing')}
                className="text-xs font-semibold text-emerald-600 hover:underline"
              >
                View All &gt;
              </button>
            </div>

            <div className="space-y-2.5 text-xs py-1">
              <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 border border-slate-100 hover:bg-slate-100/60 transition">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                  <span className="font-bold text-slate-800">GSTR-1 (Oct 2026)</span>
                </div>
                <span className="text-[11px] font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-100">
                  11 Nov 2026
                </span>
              </div>

              <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 border border-slate-100 hover:bg-slate-100/60 transition">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  <span className="font-bold text-slate-800">GSTR-3B (Oct 2026)</span>
                </div>
                <span className="text-[11px] font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-100">
                  20 Nov 2026
                </span>
              </div>

              <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 border border-slate-100 hover:bg-slate-100/60 transition">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                  <span className="font-bold text-slate-800">CMP-08 (Oct-Dec)</span>
                </div>
                <span className="text-[11px] font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-100">
                  18 Jan 2027
                </span>
              </div>

              <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 border border-slate-100 hover:bg-slate-100/60 transition">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-purple-500"></span>
                  <span className="font-bold text-slate-800">GSTR-9 (FY 2025-26)</span>
                </div>
                <span className="text-[11px] font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-100">
                  31 Dec 2026
                </span>
              </div>
            </div>
          </div>

          <div className="pt-2 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Automated Due Date Watchdog</span>
            <span className="text-emerald-600 font-semibold">Active</span>
          </div>
        </div>
      </div>

      {/* 4. Bottom Row: Recent Activities & Compliance Health Score */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Recent Activities (6 cols) */}
        <div className="lg:col-span-6 bg-white rounded-2xl p-5 border border-slate-200/90 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-slate-900 tracking-tight">
                Recent Activities
              </h3>
            </div>

            <div className="space-y-3 py-1">
              {auditLogs.length > 0 ? (
                auditLogs.slice(0, 3).map((log, idx) => (
                  <div key={log.id || idx} className="flex items-center justify-between gap-3 p-2.5 rounded-xl hover:bg-slate-50 transition border border-transparent hover:border-slate-100">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                        <FileText className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-800">
                          {log.action} — {log.module}
                        </div>
                        <div className="text-[11px] text-slate-400">{log.details || 'System event'}</div>
                      </div>
                    </div>
                    <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                      Logged
                    </span>
                  </div>
                ))
              ) : (
                <div className="p-8 text-center text-xs text-slate-400">
                  No compliance activity recorded yet. Upload your registers to begin tracking.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Compliance Health Score (6 cols) */}
        <div className="lg:col-span-6 bg-white rounded-2xl p-5 border border-slate-200/90 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-1.5">
                <span>Compliance Health Score</span>
                <Info className="w-3.5 h-3.5 text-slate-400" />
              </h3>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-around gap-6 py-2">
              {/* Radial Gauge Meter */}
              <div className="relative w-36 h-28 flex flex-col items-center justify-end">
                <svg className="w-36 h-20" viewBox="0 0 120 70">
                  <path
                    d="M 15 65 A 45 45 0 0 1 105 65"
                    fill="none"
                    stroke="#E2E8F0"
                    strokeWidth="10"
                    strokeLinecap="round"
                  />
                  {hasAnyData && (
                    <path
                      d="M 15 65 A 45 45 0 0 1 97 32"
                      fill="none"
                      stroke="#10B981"
                      strokeWidth="10"
                      strokeLinecap="round"
                      className="transition-all duration-1000 ease-out"
                    />
                  )}
                </svg>

                <div className="text-center -mt-3">
                  <div className="text-2xl font-black text-slate-900 leading-none">
                    {hasAnyData ? complianceScore : 0}<span className="text-sm font-bold text-slate-400">/100</span>
                  </div>
                  <div className={`text-xs font-bold mt-0.5 ${hasAnyData ? 'text-emerald-600' : 'text-slate-400'}`}>
                    {hasAnyData ? 'Excellent' : 'Awaiting Data'}
                  </div>
                </div>
              </div>

              {/* Compliance Breakdown Checklist */}
              <div className="space-y-2 text-xs w-full sm:w-auto">
                <div className="flex items-center justify-between gap-4">
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${hasUploadedSales ? 'bg-emerald-500' : 'bg-slate-300'}`}></span>
                    <span className="text-slate-600 font-medium">Return Preparation</span>
                  </div>
                  <span className="font-bold text-slate-900 font-mono">{hasUploadedSales ? '100%' : '0%'}</span>
                </div>
                <div className="flex items-center justify-between gap-4">
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${hasUploaded2B ? 'bg-emerald-500' : 'bg-slate-300'}`}></span>
                    <span className="text-slate-600 font-medium">2B Reconciliation</span>
                  </div>
                  <span className="font-bold text-slate-900 font-mono">{hasUploaded2B ? `${reconciliationStats.totalMatchRatePercent}%` : '0%'}</span>
                </div>
                <div className="flex items-center justify-between gap-4">
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${hasAnyData ? 'bg-emerald-500' : 'bg-slate-300'}`}></span>
                    <span className="text-slate-600 font-medium">Due Date Compliance</span>
                  </div>
                  <span className="font-bold text-slate-900 font-mono">{hasAnyData ? '100%' : '0%'}</span>
                </div>
                <div className="flex items-center justify-between gap-4">
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${hasUploadedSales ? 'bg-emerald-500' : 'bg-slate-300'}`}></span>
                    <span className="text-slate-600 font-medium">Data Accuracy</span>
                  </div>
                  <span className="font-bold text-slate-900 font-mono">{hasUploadedSales ? '100%' : '0%'}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 5. Client Workspace Operations & Government Excel Engine Control */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-700 flex items-center justify-center shrink-0 border border-amber-300">
              <Sliders className="w-5 h-5 text-amber-800" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-slate-900">
                  1-Click Government Template & Data Operations
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-semibold">
                  10 Sheets • Offline Tool v3.2.4
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Download official Government Excel template with all 10 sheets or edit headers, columns, and color effects inline in 1-Click.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            {/* Download Official TAXEDGE_GST_TEMPLATE.xlsx */}
            <a
              href="/TAXEDGE_GST_TEMPLATE.xlsx"
              download="TAXEDGE_GST_TEMPLATE.xlsx"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 text-emerald-800 text-xs font-bold transition shadow-2xs"
              title="Download 10-Sheet Government Template (.xlsx)"
            >
              <Download className="w-3.5 h-3.5 text-emerald-700" />
              <span>TAXEDGE_GST_TEMPLATE.xlsx</span>
            </a>

            {/* Download Official WEB_GST_Template.xls */}
            <a
              href="/WEB_GST_Template.xls"
              download="WEB_GST_Template.xls"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 text-emerald-800 text-xs font-bold transition shadow-2xs"
              title="Download 10-Sheet Government Template (.xls)"
            >
              <Download className="w-3.5 h-3.5 text-emerald-700" />
              <span>WEB_GST_Template.xls</span>
            </a>

            {/* Admin Panel 1-Click Edit */}
            <button
              onClick={() => onNavigate('admin')}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-[#D4A24C] hover:bg-[#c5933d] text-slate-950 text-xs font-bold transition shadow-2xs active:scale-95"
            >
              <Sliders className="w-3.5 h-3.5 text-slate-950" />
              <span>Admin Panel (1-Click Edit)</span>
            </button>

            {/* Upload Business CSV */}
            <button
              onClick={() => onOpenDataModal('SALES')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Upload CSV</span>
            </button>

            {/* Reset All to Empty */}
            <button
              onClick={onResetAllToEmpty}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 text-xs font-bold transition"
              title="Wipe data to clean 0 records"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Reset Clean</span>
            </button>
          </div>
        </div>

        {/* Client-specific GST Portal Credentials Card */}
        {currentGstin && currentClient && (
          <GstPortalCredentialsSection
            gstin={currentGstin}
            clientId={currentClient.id}
            compact={false}
          />
        )}
      </div>

      {/* 6. TAXEDGE Key Modules at a Glance Banner matching screenshot's bottom strip */}
      <div className="bg-[#0B1F44] text-white rounded-2xl p-5 shadow-lg border border-white/10">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-4 pb-3 border-b border-white/10">
          <div className="flex items-center gap-3">
            <span className="text-base font-black tracking-tight text-white flex items-center gap-2">
              TAX<span className="text-[#D4A24C]">EDGE</span>
              <span className="text-slate-400 font-normal text-xs">— Key Modules at a Glance</span>
            </span>
          </div>

          <div className="flex items-center gap-2 text-xs font-bold text-[#D4A24C]">
            <ShieldCheck className="w-4 h-4" />
            <span>Enterprise Ready: Secure • Scalable • GST Compliant</span>
          </div>
        </div>

        {/* 10 Module Quick-Jump Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5 text-xs">
          <button
            onClick={() => onNavigate('clientmaster')}
            className="p-3 rounded-xl bg-white/5 hover:bg-white/10 text-left transition border border-white/5 hover:border-[#D4A24C]/40 group"
          >
            <Users className="w-4 h-4 text-[#D4A24C] mb-1.5 group-hover:scale-110 transition-transform" />
            <div className="font-bold text-white leading-tight">Client & KYC</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Management</div>
          </button>

          <button
            onClick={() => onNavigate('gstr1')}
            className="p-3 rounded-xl bg-white/5 hover:bg-white/10 text-left transition border border-white/5 hover:border-[#D4A24C]/40 group"
          >
            <FileSpreadsheet className="w-4 h-4 text-[#D4A24C] mb-1.5 group-hover:scale-110 transition-transform" />
            <div className="font-bold text-white leading-tight">Return Filing</div>
            <div className="text-[10px] text-slate-400 mt-0.5">GSTR-1, 3B, 9, 9C</div>
          </button>

          <button
            onClick={() => onNavigate('reconciliation')}
            className="p-3 rounded-xl bg-white/5 hover:bg-white/10 text-left transition border border-white/5 hover:border-[#D4A24C]/40 group"
          >
            <GitCompare className="w-4 h-4 text-[#D4A24C] mb-1.5 group-hover:scale-110 transition-transform" />
            <div className="font-bold text-white leading-tight">2B Reconciliation</div>
            <div className="text-[10px] text-slate-400 mt-0.5">5-Level Smart Matching</div>
          </button>

          <button
            onClick={() => onNavigate('sales')}
            className="p-3 rounded-xl bg-white/5 hover:bg-white/10 text-left transition border border-white/5 hover:border-[#D4A24C]/40 group"
          >
            <BookOpen className="w-4 h-4 text-[#D4A24C] mb-1.5 group-hover:scale-110 transition-transform" />
            <div className="font-bold text-white leading-tight">Registers</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Sales & Purchase</div>
          </button>

          <button
            onClick={() => onNavigate('ecommerce')}
            className="p-3 rounded-xl bg-white/5 hover:bg-white/10 text-left transition border border-white/5 hover:border-[#D4A24C]/40 group"
          >
            <Receipt className="w-4 h-4 text-[#D4A24C] mb-1.5 group-hover:scale-110 transition-transform" />
            <div className="font-bold text-white leading-tight">e-Invoicing</div>
            <div className="text-[10px] text-slate-400 mt-0.5">& e-Way Bill</div>
          </button>

          <button
            onClick={() => onNavigate('itc')}
            className="p-3 rounded-xl bg-white/5 hover:bg-white/10 text-left transition border border-white/5 hover:border-[#D4A24C]/40 group"
          >
            <TrendingUp className="w-4 h-4 text-[#D4A24C] mb-1.5 group-hover:scale-110 transition-transform" />
            <div className="font-bold text-white leading-tight">ITC & Tax</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Analytics & Reports</div>
          </button>

          <button
            onClick={() => onNavigate('exceptions')}
            className="p-3 rounded-xl bg-white/5 hover:bg-white/10 text-left transition border border-white/5 hover:border-[#D4A24C]/40 group"
          >
            <AlertTriangle className="w-4 h-4 text-[#D4A24C] mb-1.5 group-hover:scale-110 transition-transform" />
            <div className="font-bold text-white leading-tight">Compliances</div>
            <div className="text-[10px] text-slate-400 mt-0.5">& GST Notices</div>
          </button>

          <button
            onClick={() => onOpenAI?.()}
            className="p-3 rounded-xl bg-white/5 hover:bg-white/10 text-left transition border border-white/5 hover:border-[#D4A24C]/40 group"
          >
            <Sparkles className="w-4 h-4 text-[#14B8A6] mb-1.5 group-hover:scale-110 transition-transform" />
            <div className="font-bold text-white leading-tight">AI GST Assistant</div>
            <div className="text-[10px] text-[#14B8A6] mt-0.5">Bare Law Grounded</div>
          </button>

          <button
            onClick={() => onNavigate('audit')}
            className="p-3 rounded-xl bg-white/5 hover:bg-white/10 text-left transition border border-white/5 hover:border-[#D4A24C]/40 group"
          >
            <Lock className="w-4 h-4 text-[#D4A24C] mb-1.5 group-hover:scale-110 transition-transform" />
            <div className="font-bold text-white leading-tight">Document Vault</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Client-wise storage</div>
          </button>

          <button
            onClick={() => onNavigate('admin')}
            className="p-3 rounded-xl bg-white/5 hover:bg-white/10 text-left transition border border-white/5 hover:border-[#D4A24C]/40 group"
          >
            <Sliders className="w-4 h-4 text-[#D4A24C] mb-1.5 group-hover:scale-110 transition-transform" />
            <div className="font-bold text-white leading-tight">Utilities & Admin</div>
            <div className="text-[10px] text-slate-400 mt-0.5">1-Click Template Edit</div>
          </button>
        </div>
      </div>
    </div>
  );
};
