import React, { useState } from 'react';
import { Smartphone, Download, Check, Sparkles } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  onOpenApkModal?: () => void;
  className?: string;
  variant?: 'header' | 'mobile' | 'card';
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  onOpenApkModal,
  className = '',
  variant = 'header',
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [justInstalled, setJustInstalled] = useState(false);

  // If already running inside installed standalone app
  if (isInstalled && !justInstalled) {
    return null;
  }

  const handleClick = async () => {
    if (onOpenApkModal) {
      onOpenApkModal();
      return;
    }

    if (isInstallable) {
      const success = await install();
      if (success) {
        setJustInstalled(true);
      }
    } else if (isIOS) {
      setShowIOSGuide(true);
    }
  };

  return (
    <>
      <button
        onClick={handleClick}
        className={
          className ||
          `flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-white hover:bg-[#E8F5EF] text-[#176B4D] border-2 border-[#176B4D] font-bold text-xs shadow-sm transition transform active:scale-95`
        }
        title="Download Android APK file (1.43 MB • V2/V3 Signed) or Install on Mobile"
      >
        <div className="flex items-center gap-1.5">
          <Download className="w-3.5 h-3.5 text-[#176B4D]" />
          <span>Download APK</span>
        </div>
        <span className="hidden sm:inline-block px-1.5 py-0.5 rounded bg-[#E8F5EF] text-[#176B4D] border border-[#176B4D]/30 text-[10px] font-bold uppercase tracking-wider">
          1.43 MB
        </span>
      </button>

      {/* iOS Safari Guide Modal */}
      {showIOSGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-xl bg-white border border-[#E5E7EB] p-6 shadow-2xl text-[#202124]">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-[#176B4D]" />
              <span>Install on iPhone / iPad</span>
            </h3>
            <p className="mt-3 text-xs text-[#6B7280] leading-relaxed">
              1. Safari toolbar me neeche <strong>Share</strong> button tap karein.<br />
              2. List me scroll karke <strong>Add to Home Screen</strong> select karein.<br />
              3. Top right me <strong>Add</strong> tap karein.
            </p>
            <button
              onClick={() => setShowIOSGuide(false)}
              className="mt-5 w-full rounded-lg bg-[#176B4D] hover:bg-emerald-400 py-2 text-xs font-bold text-slate-950 transition"
            >
              Theek Hai (Close)
            </button>
          </div>
        </div>
      )}
    </>
  );
};
