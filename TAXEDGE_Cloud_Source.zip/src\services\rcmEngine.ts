/**
 * Reverse Charge Mechanism (RCM) Engine
 * Legal Basis: Section 9(3) & 9(4) of CGST Act, 2017 & Notification No. 13/2017-Central Tax (Rate)
 */

import { RCMStatus, RCMCategory } from '../types/gst';
import { round2 } from '../utils/taxMath';

export interface RCMCheckResult {
  rcmStatus: RCMStatus;
  rcmCategory: RCMCategory;
  isRcm: boolean;
  legalProvision: string;
  sourceCitation: string;
  taxableValue: number;
  rate: number;
  cgstRcm: number;
  sgstRcm: number;
  igstRcm: number;
  cessRcm: number;
  totalRcmTax: number;
  reason: string;
  cashPaymentMandatory: boolean;
  itcClaimableSubsequent: boolean;
  reviewRequired: boolean;
}

export class RCMEngine {
  /**
   * Evaluates if a transaction falls under Reverse Charge
   */
  public evaluateRCM(tx: {
    supplierGstin: string;
    recipientGstin: string;
    supplierType?: string;
    recipientType?: string;
    hsnSac: string;
    description: string;
    taxableValue: number;
    isInterState: boolean;
    date: string;
  }): RCMCheckResult {
    const hsn = (tx.hsnSac || '').trim();
    const desc = (tx.description || '').toLowerCase();
    const val = round2(tx.taxableValue);

    // 1. Legal Services by Advocate / Firm of Advocates (SAC 998211)
    if (hsn === '998211' || desc.includes('advocate') || desc.includes('legal services') || desc.includes('arbitral tribunal')) {
      const rate = 18;
      const cgst = tx.isInterState ? 0 : round2(val * 0.09);
      const sgst = tx.isInterState ? 0 : round2(val * 0.09);
      const igst = tx.isInterState ? round2(val * 0.18) : 0;
      return {
        rcmStatus: 'YES',
        rcmCategory: 'LEGAL_ADVOCATE_SERVICES',
        isRcm: true,
        legalProvision: 'Section 9(3) CGST Act Read with Notification 13/2017-CT(R) Entry 2',
        sourceCitation: 'ICAI Bare Law (April 2026 Edition), Page 19',
        taxableValue: val,
        rate,
        cgstRcm: cgst,
        sgstRcm: sgst,
        igstRcm: igst,
        cessRcm: 0,
        totalRcmTax: round2(cgst + sgst + igst),
        reason: 'Services supplied by an individual advocate or firm of advocates by way of legal services to any business entity located in the taxable territory.',
        cashPaymentMandatory: true,
        itcClaimableSubsequent: true,
        reviewRequired: false
      };
    }

    // 2. Goods Transport Agency (GTA) Services (SAC 996511)
    if (hsn === '996511' || desc.includes('goods transport') || desc.includes('gta') || desc.includes('freight')) {
      const rate = 5;
      const cgst = tx.isInterState ? 0 : round2(val * 0.025);
      const sgst = tx.isInterState ? 0 : round2(val * 0.025);
      const igst = tx.isInterState ? round2(val * 0.05) : 0;
      return {
        rcmStatus: 'YES',
        rcmCategory: 'GTA_GOODS_TRANSPORT',
        isRcm: true,
        legalProvision: 'Section 9(3) CGST Act Read with Notification 13/2017-CT(R) Entry 1',
        sourceCitation: 'ICAI Bare Law (April 2026 Edition), Page 19',
        taxableValue: val,
        rate,
        cgstRcm: cgst,
        sgstRcm: sgst,
        igstRcm: igst,
        cessRcm: 0,
        totalRcmTax: round2(cgst + sgst + igst),
        reason: 'Supply of services by a Goods Transport Agency (GTA) in respect of transportation of goods by road to a registered person where GTA has not exercised option to pay tax under forward charge at 12%.',
        cashPaymentMandatory: true,
        itcClaimableSubsequent: true,
        reviewRequired: false
      };
    }

    // 3. Security Personnel Supply Services (SAC 998599)
    if (hsn === '998599' || desc.includes('security personnel') || desc.includes('security guard')) {
      const isSupplierCorporate = tx.supplierGstin && tx.supplierGstin.length === 15 && tx.supplierGstin.charAt(5) === 'C';
      if (!isSupplierCorporate) {
        const rate = 18;
        const cgst = tx.isInterState ? 0 : round2(val * 0.09);
        const sgst = tx.isInterState ? 0 : round2(val * 0.09);
        const igst = tx.isInterState ? round2(val * 0.18) : 0;
        return {
          rcmStatus: 'YES',
          rcmCategory: 'SECURITY_SERVICES',
          isRcm: true,
          legalProvision: 'Section 9(3) CGST Act Read with Notification 29/2018-CT(R)',
          sourceCitation: 'ICAI Bare Law (April 2026 Edition), Page 20',
          taxableValue: val,
          rate,
          cgstRcm: cgst,
          sgstRcm: sgst,
          igstRcm: igst,
          cessRcm: 0,
          totalRcmTax: round2(cgst + sgst + igst),
          reason: 'Security personnel services provided by any person other than a body corporate to a registered person.',
          cashPaymentMandatory: true,
          itcClaimableSubsequent: true,
          reviewRequired: false
        };
      }
    }

    // 4. Director Remuneration / Sitting Fees (SAC 9983)
    if (desc.includes('director remuneration') || desc.includes('director sitting fees') || desc.includes('independent director')) {
      const rate = 18;
      const cgst = tx.isInterState ? 0 : round2(val * 0.09);
      const sgst = tx.isInterState ? 0 : round2(val * 0.09);
      const igst = tx.isInterState ? round2(val * 0.18) : 0;
      return {
        rcmStatus: 'YES',
        rcmCategory: 'DIRECTOR_REMUNERATION',
        isRcm: true,
        legalProvision: 'Section 9(3) CGST Act Read with Notification 13/2017-CT(R) Entry 6',
        sourceCitation: 'ICAI Bare Law (April 2026 Edition), Page 20',
        taxableValue: val,
        rate,
        cgstRcm: cgst,
        sgstRcm: sgst,
        igstRcm: igst,
        cessRcm: 0,
        totalRcmTax: round2(cgst + sgst + igst),
        reason: 'Services supplied by a director of a company or a body corporate to the said company or the body corporate.',
        cashPaymentMandatory: true,
        itcClaimableSubsequent: true,
        reviewRequired: false
      };
    }

    // 5. Specified Goods (Cashew nuts, Tobacco, Cotton, Silk Yarn)
    if (hsn === '080131' || hsn === '240110' || desc.includes('cashew nuts in shell') || desc.includes('unmanufactured tobacco')) {
      const rate = hsn === '240110' ? 28 : 5;
      const cgst = tx.isInterState ? 0 : round2(val * (rate / 200));
      const sgst = tx.isInterState ? 0 : round2(val * (rate / 200));
      const igst = tx.isInterState ? round2(val * (rate / 100)) : 0;
      return {
        rcmStatus: 'YES',
        rcmCategory: 'SPECIFIED_GOODS_CASHEW_TOBACCO_COTTON',
        isRcm: true,
        legalProvision: 'Section 9(3) CGST Act Read with Notification 4/2017-CT(R)',
        sourceCitation: 'ICAI Bare Law (April 2026 Edition), Page 21',
        taxableValue: val,
        rate,
        cgstRcm: cgst,
        sgstRcm: sgst,
        igstRcm: igst,
        cessRcm: 0,
        totalRcmTax: round2(cgst + sgst + igst),
        reason: 'Notified goods supplied by an agriculturist to any registered person under reverse charge.',
        cashPaymentMandatory: true,
        itcClaimableSubsequent: true,
        reviewRequired: false
      };
    }

    // Default: Not RCM
    return {
      rcmStatus: 'NO',
      rcmCategory: 'NOT_APPLICABLE',
      isRcm: false,
      legalProvision: 'Section 9(1) CGST Act (Forward Charge)',
      sourceCitation: 'ICAI Bare Law (April 2026 Edition), Page 18',
      taxableValue: val,
      rate: 0,
      cgstRcm: 0,
      sgstRcm: 0,
      igstRcm: 0,
      cessRcm: 0,
      totalRcmTax: 0,
      reason: 'Standard supply subject to forward charge by the registered supplier.',
      cashPaymentMandatory: false,
      itcClaimableSubsequent: false,
      reviewRequired: false
    };
  }
}

export const rcmEngine = new RCMEngine();
