/**
 * E-Commerce & TCS Reconciliation Engine
 * Legal Basis: Section 52 of CGST Act, 2017 & Rule 67 of CGST Rules, 2017
 */

import { ECommerceReport } from '../types/gst';
import { round2 } from '../utils/taxMath';

export interface ECommerceReconciliationSummary {
  totalGrossSales: number;
  totalReturns: number;
  totalNetTaxable: number;
  totalGstCollected: number;
  totalTcsDeducted: number;
  totalCommissionPaid: number;
  totalNetSettlement: number;
  matchedGstr8Count: number;
  unmatchedCount: number;
  auditObservations: string[];
}

export class ECommerceEngine {
  /**
   * Reconciles e-commerce reports across platforms
   */
  public summarizeReports(reports: ECommerceReport[]): ECommerceReconciliationSummary {
    let totalGrossSales = 0;
    let totalReturns = 0;
    let totalNetTaxable = 0;
    let totalGstCollected = 0;
    let totalTcsDeducted = 0;
    let totalCommissionPaid = 0;
    let totalNetSettlement = 0;
    let matchedGstr8Count = 0;
    let unmatchedCount = 0;
    const auditObservations: string[] = [];

    for (const r of reports) {
      totalGrossSales = round2(totalGrossSales + r.grossSales);
      totalReturns = round2(totalReturns + r.salesReturn);
      totalNetTaxable = round2(totalNetTaxable + r.netTaxableSales);
      totalGstCollected = round2(totalGstCollected + r.totalTax);
      totalTcsDeducted = round2(totalTcsDeducted + r.tcsDeductedSection52);
      totalCommissionPaid = round2(totalCommissionPaid + r.commissionDeducted + r.logisticsFeeDeducted);
      totalNetSettlement = round2(totalNetSettlement + r.netSettlementAmount);

      if (r.gstr8Matched) {
        matchedGstr8Count++;
      } else {
        unmatchedCount++;
        auditObservations.push(`Discrepancy on ${r.platform}: TCS reported does not reconcile with Electronic Cash Ledger credit.`);
      }

      // Check Section 52 1% TCS mathematical formula
      const expectedTcs = round2(r.netTaxableSales * 0.01);
      const diffTcs = Math.abs(expectedTcs - r.tcsDeductedSection52);
      if (diffTcs > 5.0) {
        auditObservations.push(
          `${r.platform} TCS calculation variance: Reported ₹${r.tcsDeductedSection52} vs statutory 1% ₹${expectedTcs}.`
        );
      }
    }

    if (auditObservations.length === 0) {
      auditObservations.push('All e-commerce operator TCS reports reconcile 100% with GSTR-8 credits in Electronic Cash Ledger.');
    }

    return {
      totalGrossSales,
      totalReturns,
      totalNetTaxable,
      totalGstCollected,
      totalTcsDeducted,
      totalCommissionPaid,
      totalNetSettlement,
      matchedGstr8Count,
      unmatchedCount,
      auditObservations
    };
  }
}

export const ecommerceEngine = new ECommerceEngine();
