/**
 * Business Accounting Service
 * Manages Parties, Inventory, Payments, Expenses, Ledgers, E-Invoicing and E-Way Bills
 * Fully isolated per Client ID and GSTIN
 */

import {
  Party,
  PartyLedgerEntry,
  PaymentRecord,
  ExpenseRecord,
  InventoryItem,
  EInvoiceRecord,
  EWayBillRecord
} from '../types/accounting';
import { TransactionInvoice } from '../types/gst';

const ACCOUNTING_PREFIX = 'gst_practice_ai_acc_';

export interface AccountingWorkspaceData {
  parties: Party[];
  inventory: InventoryItem[];
  payments: PaymentRecord[];
  expenses: ExpenseRecord[];
  ledgers: PartyLedgerEntry[];
  eInvoices: EInvoiceRecord[];
  eWayBills: EWayBillRecord[];
}

export class AccountingService {
  private cache: Map<string, AccountingWorkspaceData> = new Map();

  private getKey(clientId: string, gstin: string): string {
    return `${ACCOUNTING_PREFIX}${clientId}_${gstin}`;
  }

  public getData(clientId: string, gstin: string): AccountingWorkspaceData {
    if (!clientId || !gstin) {
      return { parties: [], inventory: [], payments: [], expenses: [], ledgers: [], eInvoices: [], eWayBills: [] };
    }
    const key = this.getKey(clientId, gstin);
    if (this.cache.has(key)) {
      return this.cache.get(key)!;
    }

    try {
      const stored = localStorage.getItem(key);
      if (stored) {
        const parsed = JSON.parse(stored);
        this.cache.set(key, parsed);
        return parsed;
      }
    } catch {}

    const emptyData: AccountingWorkspaceData = {
      parties: [],
      inventory: [],
      payments: [],
      expenses: [],
      ledgers: [],
      eInvoices: [],
      eWayBills: []
    };
    this.saveData(clientId, gstin, emptyData);
    return emptyData;
  }

  public saveData(clientId: string, gstin: string, data: AccountingWorkspaceData): void {
    if (!clientId || !gstin) return;
    const key = this.getKey(clientId, gstin);
    this.cache.set(key, data);
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      console.warn('LocalStorage save error:', e);
    }
  }

  public clearData(clientId: string, gstin: string): void {
    const key = this.getKey(clientId, gstin);
    this.cache.delete(key);
    try {
      localStorage.removeItem(key);
    } catch {}
  }

  /**
   * Records a party and sets initial ledger entry if opening balance exists
   */
  public addParty(clientId: string, gstin: string, party: Party): void {
    const data = this.getData(clientId, gstin);
    data.parties.push(party);

    if (party.openingBalance !== 0) {
      const isDebit = party.openingBalance > 0;
      data.ledgers.push({
        id: `LED-${Date.now()}`,
        partyId: party.id,
        clientId,
        gstinReference: gstin,
        date: party.createdAt.split('T')[0],
        particulars: 'Opening Balance',
        voucherType: 'OPENING_BALANCE',
        voucherNumber: 'OB-001',
        debit: isDebit ? Math.abs(party.openingBalance) : 0,
        credit: !isDebit ? Math.abs(party.openingBalance) : 0,
        balance: party.openingBalance
      });
    }

    this.saveData(clientId, gstin, data);
  }

  public updateParty(clientId: string, gstin: string, updated: Party): void {
    const data = this.getData(clientId, gstin);
    const idx = data.parties.findIndex(p => p.id === updated.id);
    if (idx >= 0) {
      data.parties[idx] = updated;
      this.saveData(clientId, gstin, data);
    }
  }

  public deleteParty(clientId: string, gstin: string, partyId: string): void {
    const data = this.getData(clientId, gstin);
    data.parties = data.parties.filter(p => p.id !== partyId);
    data.ledgers = data.ledgers.filter(l => l.partyId !== partyId);
    this.saveData(clientId, gstin, data);
  }

  /**
   * Adds an inventory item
   */
  public addInventoryItem(clientId: string, gstin: string, item: InventoryItem): void {
    const data = this.getData(clientId, gstin);
    data.inventory.push(item);
    this.saveData(clientId, gstin, data);
  }

  public updateInventoryItem(clientId: string, gstin: string, item: InventoryItem): void {
    const data = this.getData(clientId, gstin);
    const idx = data.inventory.findIndex(i => i.id === item.id);
    if (idx >= 0) {
      data.inventory[idx] = item;
      this.saveData(clientId, gstin, data);
    }
  }

  /**
   * Records a payment and updates the party's current balance and ledger
   */
  public recordPayment(clientId: string, gstin: string, payment: PaymentRecord): void {
    const data = this.getData(clientId, gstin);
    data.payments.unshift(payment);

    const party = data.parties.find(p => p.id === payment.partyId);
    if (party) {
      // Payment In reduces receivable balance (credits customer)
      // Payment Out reduces payable balance (debits supplier)
      const isPaymentIn = payment.type === 'PAYMENT_IN';
      const change = isPaymentIn ? -payment.amount : payment.amount;
      party.currentBalance += change;

      data.ledgers.push({
        id: `LED-${Date.now()}`,
        partyId: party.id,
        clientId,
        gstinReference: gstin,
        date: payment.date,
        particulars: `Payment Received / Made via ${payment.paymentMode}${payment.referenceNumber ? ' (' + payment.referenceNumber + ')' : ''}`,
        voucherType: isPaymentIn ? 'PAYMENT_IN' : 'PAYMENT_OUT',
        voucherNumber: payment.id,
        debit: !isPaymentIn ? payment.amount : 0,
        credit: isPaymentIn ? payment.amount : 0,
        balance: party.currentBalance
      });
    }

    this.saveData(clientId, gstin, data);
  }

  /**
   * Records an expense entry
   */
  public recordExpense(clientId: string, gstin: string, expense: ExpenseRecord): void {
    const data = this.getData(clientId, gstin);
    data.expenses.unshift(expense);
    this.saveData(clientId, gstin, data);
  }

  /**
   * Updates inventory stock when an invoice is created or edited
   */
  public processInvoiceInventoryAndLedger(
    clientId: string,
    gstin: string,
    invoice: TransactionInvoice,
    direction: 'SALE' | 'PURCHASE'
  ): void {
    const data = this.getData(clientId, gstin);

    // 1. Find matching party by GSTIN or Name
    const targetGstin = direction === 'SALE' ? invoice.recipientGstin : invoice.supplierGstin;
    const targetName = direction === 'SALE' ? invoice.recipientName : invoice.supplierName;

    let party = data.parties.find(
      p => (targetGstin && p.gstin === targetGstin) || p.name.toLowerCase() === targetName.toLowerCase()
    );

    // Auto-create party if not existing
    if (!party) {
      party = {
        id: `PRT-${Date.now()}`,
        clientId,
        gstinReference: gstin,
        type: direction === 'SALE' ? 'CUSTOMER' : 'SUPPLIER',
        name: targetName,
        gstin: targetGstin.startsWith('URP') ? '' : targetGstin,
        pan: targetGstin.length >= 12 ? targetGstin.substring(2, 12) : '',
        state: direction === 'SALE' ? invoice.recipientState : invoice.supplierState,
        stateCode: direction === 'SALE' ? invoice.recipientStateCode : invoice.supplierStateCode,
        address: `${direction === 'SALE' ? invoice.recipientState : invoice.supplierState} Commercial Address`,
        mobile: '+91 98000 00000',
        email: 'accounts@entity.com',
        openingBalance: 0,
        currentBalance: direction === 'SALE' ? invoice.totalAmount : -invoice.totalAmount,
        creditLimit: 500000,
        paymentTermsDays: 30,
        createdAt: new Date().toISOString()
      };
      data.parties.push(party);
    } else {
      // Update balance
      if (direction === 'SALE') {
        party.currentBalance += invoice.totalAmount;
      } else {
        party.currentBalance -= invoice.totalAmount;
      }
    }

    // Add Ledger Entry
    data.ledgers.push({
      id: `LED-${Date.now()}`,
      partyId: party.id,
      clientId,
      gstinReference: gstin,
      date: invoice.invoiceDate,
      particulars: `${direction === 'SALE' ? 'Tax Invoice' : 'Purchase Bill'} #${invoice.invoiceNumber} - ${invoice.descriptionPrimary}`,
      voucherType: direction === 'SALE' ? 'SALES_INVOICE' : 'PURCHASE_BILL',
      voucherNumber: invoice.invoiceNumber,
      debit: direction === 'SALE' ? invoice.totalAmount : 0,
      credit: direction === 'PURCHASE' ? invoice.totalAmount : 0,
      balance: party.currentBalance
    });

    // 2. Adjust Stock for matched items
    if (invoice.items && invoice.items.length > 0) {
      for (const item of invoice.items) {
        const invMatch = data.inventory.find(
          i => i.hsnSac === item.hsnSac || i.name.toLowerCase() === item.itemDescription.toLowerCase()
        );
        if (invMatch) {
          if (direction === 'SALE') {
            invMatch.currentStock = Math.max(0, invMatch.currentStock - item.quantity);
          } else {
            invMatch.currentStock += item.quantity;
          }
        }
      }
    }

    this.saveData(clientId, gstin, data);
  }

  /**
   * Generates E-Invoice record (simulated authorized government schema without faking government confirmations)
   */
  public generateEInvoice(clientId: string, gstin: string, invoice: TransactionInvoice): EInvoiceRecord {
    const data = this.getData(clientId, gstin);
    const existing = data.eInvoices.find(e => e.invoiceNumber === invoice.invoiceNumber);

    const record: EInvoiceRecord = {
      id: existing?.id || `EINV-${Date.now()}`,
      clientId,
      gstinReference: gstin,
      invoiceNumber: invoice.invoiceNumber,
      invoiceDate: invoice.invoiceDate,
      recipientGstin: invoice.recipientGstin,
      recipientName: invoice.recipientName,
      taxableValue: invoice.taxableValue,
      totalTax: invoice.cgst + invoice.sgst + invoice.igst + invoice.cess,
      totalAmount: invoice.totalAmount,
      irn: `NIC-IRN-2026-${invoice.invoiceNumber.replace(/[^a-zA-Z0-9]/g, '')}-${Date.now().toString(16)}`,
      ackNumber: `102026${Math.floor(10000000 + Math.random() * 90000000)}`,
      ackDate: new Date().toISOString(),
      signedQrPayload: `GSTIN:${gstin}|INV:${invoice.invoiceNumber}|VAL:${invoice.totalAmount}`,
      status: 'TEST_MODE'
    };

    if (existing) {
      const idx = data.eInvoices.findIndex(e => e.id === existing.id);
      data.eInvoices[idx] = record;
    } else {
      data.eInvoices.unshift(record);
    }

    this.saveData(clientId, gstin, data);
    return record;
  }

  /**
   * Generates E-Way Bill record
   */
  public generateEWayBill(
    clientId: string,
    gstin: string,
    invoice: TransactionInvoice,
    transporterId?: string,
    vehicleNumber?: string,
    distanceKm: number = 150
  ): EWayBillRecord {
    const data = this.getData(clientId, gstin);
    const existing = data.eWayBills.find(e => e.invoiceNumber === invoice.invoiceNumber);

    const record: EWayBillRecord = {
      id: existing?.id || `EWB-${Date.now()}`,
      clientId,
      gstinReference: gstin,
      invoiceNumber: invoice.invoiceNumber,
      invoiceDate: invoice.invoiceDate,
      recipientGstin: invoice.recipientGstin,
      recipientName: invoice.recipientName,
      transporterId: transporterId || '27AAACG0914K1ZH',
      transporterName: 'Express Logistics Services',
      vehicleNumber: vehicleNumber || 'MH-04-AB-1234',
      distanceKm,
      ewbNumber: `35${Math.floor(1000000000 + Math.random() * 9000000000)}`,
      validUntil: new Date(Date.now() + 86400000 * 2).toLocaleDateString('en-IN'),
      status: 'TEST_MODE'
    };

    if (existing) {
      const idx = data.eWayBills.findIndex(e => e.id === existing.id);
      data.eWayBills[idx] = record;
    } else {
      data.eWayBills.unshift(record);
    }

    this.saveData(clientId, gstin, data);
    return record;
  }

  /**
   * Populates demo accounting dataset for a client
   */
  public seedDemoAccounting(clientId: string, gstin: string): void {
    const demoData: AccountingWorkspaceData = {
      parties: [
        {
          id: 'PRT-101',
          clientId,
          gstinReference: gstin,
          type: 'CUSTOMER',
          name: 'Godrej Infotech Solutions Ltd',
          tradeName: 'Godrej Infotech',
          gstin: '27AAACG0561F1ZK',
          pan: 'AAACG0561F',
          state: 'Maharashtra',
          stateCode: '27',
          address: 'Pirojshanagar, Vikhroli East, Mumbai 400079',
          mobile: '+91 98201 11223',
          email: 'accounts@godrejinfotech.com',
          openingBalance: 150000.00,
          currentBalance: 740000.00,
          creditLimit: 2500000.00,
          paymentTermsDays: 30,
          notes: 'Key enterprise IT client',
          createdAt: '2026-04-01'
        },
        {
          id: 'PRT-102',
          clientId,
          gstinReference: gstin,
          type: 'CUSTOMER',
          name: 'Wipro Digital Enterprises Ltd',
          tradeName: 'Wipro Digital',
          gstin: '29AABCT1284K1ZR',
          pan: 'AABCT1284K',
          state: 'Karnataka',
          stateCode: '29',
          address: 'Doddakannelli, Sarjapur Road, Bengaluru 560035',
          mobile: '+91 98450 33445',
          email: 'tax@wipro.com',
          openingBalance: 0.00,
          currentBalance: 920400.00,
          creditLimit: 3000000.00,
          paymentTermsDays: 45,
          notes: 'Inter-state software consulting customer',
          createdAt: '2026-04-01'
        },
        {
          id: 'PRT-201',
          clientId,
          gstinReference: gstin,
          type: 'SUPPLIER',
          name: 'Siemens Cloud & Infrastructure India Ltd',
          tradeName: 'Siemens Cloud',
          gstin: '27AABCS1429B1Z1',
          pan: 'AABCS1429B',
          state: 'Maharashtra',
          stateCode: '27',
          address: 'Worli, Mumbai 400018',
          mobile: '+91 98200 77889',
          email: 'billing@siemens.co.in',
          openingBalance: -250000.00,
          currentBalance: -590000.00,
          creditLimit: 5000000.00,
          paymentTermsDays: 30,
          notes: 'Cloud servers & infrastructure vendor',
          createdAt: '2026-04-01'
        },
        {
          id: 'PRT-202',
          clientId,
          gstinReference: gstin,
          type: 'SUPPLIER',
          name: 'Hewlett Packard Enterprise India Pvt Ltd',
          tradeName: 'HPE India',
          gstin: '29AAACH1928F1ZY',
          pan: 'AAACH1928F',
          state: 'Karnataka',
          stateCode: '29',
          address: 'Electronic City, Bengaluru 560100',
          mobile: '+91 98440 99881',
          email: 'ap-india@hpe.com',
          openingBalance: 0.00,
          currentBalance: -413000.00,
          creditLimit: 4000000.00,
          paymentTermsDays: 30,
          notes: 'Hardware & IT equipment vendor',
          createdAt: '2026-04-01'
        }
      ],
      inventory: [
        {
          id: 'INV-001',
          clientId,
          gstinReference: gstin,
          name: 'High-Density Enterprise Server Rack 42U',
          sku: 'SRV-RACK-42U',
          hsnSac: '847141',
          unit: 'NOS',
          purchasePrice: 180000.00,
          salePrice: 240000.00,
          gstRate: 18,
          openingStock: 15,
          minStockAlert: 5,
          currentStock: 12,
          category: 'Hardware',
          createdAt: '2026-04-01'
        },
        {
          id: 'INV-002',
          clientId,
          gstinReference: gstin,
          name: 'Enterprise UltraWide IPS Monitor 34-Inch',
          sku: 'MON-34-IPS',
          hsnSac: '852852',
          unit: 'NOS',
          purchasePrice: 28000.00,
          salePrice: 38000.00,
          gstRate: 18,
          openingStock: 40,
          minStockAlert: 10,
          currentStock: 28,
          category: 'Peripherals',
          createdAt: '2026-04-01'
        },
        {
          id: 'INV-003',
          clientId,
          gstinReference: gstin,
          name: 'Cloud Security Architecture Consultation (Per Hour)',
          sku: 'SRV-SEC-HR',
          hsnSac: '998313',
          unit: 'NOS',
          purchasePrice: 3000.00,
          salePrice: 7500.00,
          gstRate: 18,
          openingStock: 999,
          minStockAlert: 50,
          currentStock: 940,
          category: 'Services',
          createdAt: '2026-04-01'
        }
      ],
      payments: [
        {
          id: 'PAY-101',
          clientId,
          gstinReference: gstin,
          type: 'PAYMENT_IN',
          partyId: 'PRT-101',
          partyName: 'Godrej Infotech Solutions Ltd',
          date: '2026-04-10',
          amount: 250000.00,
          paymentMode: 'BANK_TRANSFER',
          referenceNumber: 'NEFT-HDFC2604100918',
          linkedInvoiceNumber: 'INV/2026-27/001',
          notes: 'Part payment against April consulting invoices',
          createdAt: '2026-04-10'
        },
        {
          id: 'PAY-201',
          clientId,
          gstinReference: gstin,
          type: 'PAYMENT_OUT',
          partyId: 'PRT-201',
          partyName: 'Siemens Cloud & Infrastructure India Ltd',
          date: '2026-04-15',
          amount: 200000.00,
          paymentMode: 'BANK_TRANSFER',
          referenceNumber: 'RTGS-ICICI260415998',
          linkedInvoiceNumber: 'INV/2026/0411',
          notes: 'Monthly infrastructure payment',
          createdAt: '2026-04-15'
        }
      ],
      expenses: [
        {
          id: 'EXP-001',
          clientId,
          gstinReference: gstin,
          date: '2026-04-05',
          category: 'RENT',
          partyName: 'Spectrum Cyber Parks Realty Ltd',
          partyGstin: '27AAACS1122R1Z4',
          taxableAmount: 150000.00,
          gstRate: 18,
          cgst: 13500.00,
          sgst: 13500.00,
          igst: 0.00,
          totalAmount: 177000.00,
          paymentMode: 'BANK_TRANSFER',
          isItcEligible: true,
          notes: 'Office commercial space lease for April 2026',
          createdAt: '2026-04-05'
        },
        {
          id: 'EXP-002',
          clientId,
          gstinReference: gstin,
          date: '2026-04-12',
          category: 'TELEPHONE_INTERNET',
          partyName: 'Tata Communications Ltd',
          partyGstin: '27AAACT2233M1Z8',
          taxableAmount: 40000.00,
          gstRate: 18,
          cgst: 3600.00,
          sgst: 3600.00,
          igst: 0.00,
          totalAmount: 47200.00,
          paymentMode: 'BANK_TRANSFER',
          isItcEligible: true,
          notes: 'Dedicated 1Gbps fiber internet leased line',
          createdAt: '2026-04-12'
        }
      ],
      ledgers: [
        {
          id: 'LED-001',
          partyId: 'PRT-101',
          clientId,
          gstinReference: gstin,
          date: '2026-04-01',
          particulars: 'Opening Balance (Receivable)',
          voucherType: 'OPENING_BALANCE',
          voucherNumber: 'OB-2026',
          debit: 150000.00,
          credit: 0.00,
          balance: 150000.00
        },
        {
          id: 'LED-002',
          partyId: 'PRT-101',
          clientId,
          gstinReference: gstin,
          date: '2026-04-03',
          particulars: 'Tax Invoice #INV/2026-27/001 - Enterprise Cloud Services',
          voucherType: 'SALES_INVOICE',
          voucherNumber: 'INV/2026-27/001',
          debit: 590000.00,
          credit: 0.00,
          balance: 740000.00
        },
        {
          id: 'LED-003',
          partyId: 'PRT-201',
          clientId,
          gstinReference: gstin,
          date: '2026-04-01',
          particulars: 'Opening Balance (Payable)',
          voucherType: 'OPENING_BALANCE',
          voucherNumber: 'OB-2026',
          debit: 0.00,
          credit: 250000.00,
          balance: -250000.00
        },
        {
          id: 'LED-004',
          partyId: 'PRT-201',
          clientId,
          gstinReference: gstin,
          date: '2026-04-05',
          particulars: 'Purchase Bill #INV/2026/0411 - Siemens Cloud Services',
          voucherType: 'PURCHASE_BILL',
          voucherNumber: 'INV/2026/0411',
          debit: 0.00,
          credit: 590000.00,
          balance: -590000.00
        }
      ],
      eInvoices: [],
      eWayBills: []
    };

    this.saveData(clientId, gstin, demoData);
  }
}

export const accountingService = new AccountingService();
