import React, { useState } from 'react';
import { FlaskConical, CheckCircle2, XCircle, Play, ShieldCheck, RefreshCw } from 'lucide-react';
import { gstTestSuite, TestCaseResult } from '../services/testSuite';

export const TestSuiteView: React.FC = () => {
  const [results, setResults] = useState<TestCaseResult[]>(() => gstTestSuite.runAllTests());
  const [isRunning, setIsRunning] = useState(false);

  const handleRunTests = () => {
    setIsRunning(true);
    setTimeout(() => {
      setResults(gstTestSuite.runAllTests());
      setIsRunning(false);
    }, 300);
  };

  const totalPassed = results.filter(r => r.passed).length;
  const passRate = results.length > 0 ? Math.round((totalPassed / results.length) * 100) : 0;

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-black text-[#202124] flex items-center gap-2">
              <FlaskConical className="w-5 h-5 text-[#176B4D]" />
              Automated Statutory Verification Suite (Part 38)
            </h2>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#176B4D]/20 text-[#176B4D] font-bold border border-[#176B4D]/30">
              {passRate}% Passing ({totalPassed}/{results.length})
            </span>
          </div>
          <p className="text-xs text-[#6B7280] mt-1">
            Automated regression tests verifying deterministic math, Bare Law rules, Section 17(5), and Rule 88A set-off.
          </p>
        </div>

        <button
          onClick={handleRunTests}
          disabled={isRunning}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#176B4D] hover:bg-emerald-400 disabled:opacity-50 text-slate-950 font-bold text-xs shadow-md transition"
        >
          <RefreshCw className={`w-4 h-4 ${isRunning ? 'animate-spin' : ''}`} />
          <span>{isRunning ? 'Executing Suite...' : 'Re-Run All Test Cases'}</span>
        </button>
      </div>

      {/* Test Case Cards */}
      <div className="space-y-3">
        {results.map(tc => (
          <div
            key={tc.id}
            className="bg-white border border-[#E5E7EB] rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs"
          >
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                {tc.passed ? (
                  <CheckCircle2 className="w-4 h-4 text-[#176B4D] shrink-0" />
                ) : (
                  <XCircle className="w-4 h-4 text-[#C62828] shrink-0" />
                )}
                <span className="font-mono font-bold text-[#6B7280]">{tc.id}</span>
                <span className="font-bold text-white text-sm">{tc.name}</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-[#F8F9FA] text-[#6B7280] font-mono">
                  {tc.category}
                </span>
              </div>
              <div className="text-[#6B7280] pl-6">
                <strong>Expected:</strong> {tc.expected}
              </div>
              <div className="text-[#6B7280] pl-6">
                <strong>Actual:</strong> <span className={tc.passed ? 'text-[#176B4D] font-mono' : 'text-[#C62828] font-mono'}>{tc.actual}</span>
              </div>
            </div>

            <div className="text-right shrink-0">
              <span className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded font-mono ${
                tc.passed ? 'bg-[#E8F5EF] text-[#176B4D] border border-emerald-800' : 'bg-rose-950 text-[#C62828] border border-rose-800'
              }`}>
                {tc.passed ? 'PASSED' : 'FAILED'} ({tc.durationMs}ms)
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
