/**
 * Compliance Exception Center Engine
 * Analyzes transactions, filings, and reconciliations to raise prioritized compliance exceptions
 */

import { ComplianceException, TransactionInvoice, ReconciliationResultItem } from '../types/gst';
import { validateGstinFormat } from '../data/masterData';
import { verifyInvoiceTotals } from '../utils/taxMath';

export class ExceptionEngine {
  /**
   * Scans all invoices and reconciliation results to produce compliance exceptions
   */
  public scanExceptions(
    sales: TransactionInvoice[],
    purchases: TransactionInvoice[],
    reconciliationResults: ReconciliationResultItem[]
  ): ComplianceException[] {
    const exceptions: ComplianceException[] = [];

    // 1. Scan Sales Invoices
    const salesInvoiceNumbers = new Set<string>();
    for (const inv of sales) {
      // Check duplicate invoice numbers
      if (salesInvoiceNumbers.has(inv.invoiceNumber)) {
        exceptions.push({
          id: `EX-DUP-SL-${inv.id}`,
          code: 'ERR_DUP_INVOICE',
          severity: 'CRITICAL',
          category: 'DUPLICATE',
          title: `Duplicate Sales Invoice Number: ${inv.invoiceNumber}`,
          description: `Invoice number ${inv.invoiceNumber} appears more than once in the outward sales register. GST portal will reject duplicate invoice numbers within the same financial year under Rule 46.`,
          entityType: 'SALES_INVOICE',
          entityId: inv.id,
          invoiceNumber: inv.invoiceNumber,
          suggestedAction: 'Assign unique invoice numbering sequence as mandated by Rule 46(b) of CGST Rules.',
          resolved: false,
          timestamp: new Date().toISOString()
        });
      }
      salesInvoiceNumbers.add(inv.invoiceNumber);

      // Check GSTIN format for B2B
      if (inv.classification === 'B2B' && inv.recipientGstin !== 'URP' && inv.recipientGstin !== 'OVERSEAS') {
        const valRes = validateGstinFormat(inv.recipientGstin);
        if (!valRes.valid) {
          exceptions.push({
            id: `EX-GSTIN-SL-${inv.id}`,
            code: 'ERR_INVALID_GSTIN',
            severity: 'CRITICAL',
            category: 'GSTIN_VALIDATION',
            title: `Invalid Recipient GSTIN: ${inv.recipientGstin}`,
            description: `Recipient GSTIN failed statutory checksum verification: ${valRes.error}. Invoice will be rejected in GSTR-1 Table 4.`,
            entityType: 'SALES_INVOICE',
            entityId: inv.id,
            invoiceNumber: inv.invoiceNumber,
            suggestedAction: 'Verify correct 15-character GSTIN with customer or reclassify as B2C.',
            resolved: false,
            timestamp: new Date().toISOString()
          });
        }
      }

      // Check Tax math integrity
      const mathCheck = verifyInvoiceTotals({
        taxableValue: inv.taxableValue,
        cgst: inv.cgst,
        sgst: inv.sgst,
        igst: inv.igst,
        cess: inv.cess,
        totalAmount: inv.totalAmount
      });
      if (!mathCheck.valid) {
        exceptions.push({
          id: `EX-MATH-SL-${inv.id}`,
          code: 'ERR_TAX_MATH_MISMATCH',
          severity: 'CRITICAL',
          category: 'TAX_CALCULATION',
          title: `Tax Total Arithmetic Error on Invoice ${inv.invoiceNumber}`,
          description: `Line item sum (Taxable + CGST + SGST + IGST + Cess = ₹${mathCheck.calculatedTotal}) does not match reported invoice total (₹${inv.totalAmount}). Difference: ₹${mathCheck.difference}.`,
          entityType: 'SALES_INVOICE',
          entityId: inv.id,
          invoiceNumber: inv.invoiceNumber,
          suggestedAction: 'Recalculate invoice using deterministic math engine to eliminate rounding errors.',
          resolved: false,
          timestamp: new Date().toISOString()
        });
      }

      // Check Place of Supply consistency
      if (inv.supplyType === 'INTRA_STATE' && inv.placeOfSupplyCode !== inv.supplierStateCode) {
        exceptions.push({
          id: `EX-POS-SL-${inv.id}`,
          code: 'ERR_POS_TAX_HEAD_CONFLICT',
          severity: 'HIGH',
          category: 'POS_MISMATCH',
          title: `Intra-State Supply flagged with Outside POS Code: ${inv.placeOfSupplyCode}`,
          description: `Invoice is booked with CGST+SGST, but Place of Supply code is ${inv.placeOfSupplyCode} while supplier state code is ${inv.supplierStateCode}. Section 8 IGST Act mandates IGST when POS is in different state.`,
          entityType: 'SALES_INVOICE',
          entityId: inv.id,
          invoiceNumber: inv.invoiceNumber,
          suggestedAction: 'Amend tax head from CGST+SGST to IGST in GSTR-1 preparation.',
          resolved: false,
          timestamp: new Date().toISOString()
        });
      }
    }

    // 2. Scan Purchase Invoices
    for (const pur of purchases) {
      // Check Section 17(5) Blocked Credit
      if (pur.itcStatus === 'INELIGIBLE' && pur.itcEligibleAmount > 0) {
        exceptions.push({
          id: `EX-ITC-PUR-${pur.id}`,
          code: 'ERR_BLOCKED_ITC_CLAIMED',
          severity: 'HIGH',
          category: 'ITC_BLOCKAGE',
          title: `Blocked ITC claimed on Invoice ${pur.invoiceNumber}`,
          description: `Expense relates to ${pur.descriptionPrimary} (${pur.blockedCreditReason}). Claiming ITC on this invoice violates Section 17(5) and attracts 24% interest and penalty under Section 73/74.`,
          entityType: 'PURCHASE_INVOICE',
          entityId: pur.id,
          invoiceNumber: pur.invoiceNumber,
          suggestedAction: 'Move tax amount to Table 4(D)(1) Ineligible ITC in GSTR-3B.',
          resolved: false,
          timestamp: new Date().toISOString()
        });
      }

      // Check RCM Cash Payment Compliance
      if (pur.rcm && !pur.rcmCashPaid) {
        exceptions.push({
          id: `EX-RCM-PUR-${pur.id}`,
          code: 'ERR_RCM_CASH_COMPLIANCE',
          severity: 'HIGH',
          category: 'RCM_COMPLIANCE',
          title: `Unpaid RCM Liability for ${pur.supplierName}`,
          description: `Under Section 9(3) and Section 49(4) of CGST Act, reverse charge tax must be deposited in CASH via Electronic Cash Ledger. Cannot use existing ITC balance.`,
          entityType: 'PURCHASE_INVOICE',
          entityId: pur.id,
          invoiceNumber: pur.invoiceNumber,
          suggestedAction: 'Include tax amount in GSTR-3B Table 3.1(d) and ensure sufficient Electronic Cash Ledger balance.',
          resolved: false,
          timestamp: new Date().toISOString()
        });
      }
    }

    // 3. Scan Reconciliation Results
    for (const rec of reconciliationResults) {
      if (rec.matchStatus === 'TAX_MISMATCH') {
        exceptions.push({
          id: `EX-REC-TAX-${rec.id}`,
          code: 'ERR_2B_TAX_MISMATCH',
          severity: 'HIGH',
          category: 'TAX_CALCULATION',
          title: `GSTR-2B Tax Variance: ${rec.invoiceNumber} (${rec.supplierName})`,
          description: `Tax in books (₹${rec.bookTax}) differs from GSTR-2B (₹${rec.gstr2bTax}) by ₹${Math.abs(rec.taxDifference)}. Claiming books amount violates Rule 36(4) and triggers Rule 88D DRC-01C notice.`,
          entityType: 'GSTR2B',
          entityId: rec.id,
          invoiceNumber: rec.invoiceNumber,
          suggestedAction: 'Cap ITC claim in GSTR-3B Table 4(A)(5) to GSTR-2B figure until supplier rectifies in next GSTR-1.',
          resolved: false,
          timestamp: new Date().toISOString()
        });
      } else if (rec.matchStatus === 'MISSING_IN_2B' && !rec.rootCause.includes('RCM')) {
        exceptions.push({
          id: `EX-REC-MISSING2B-${rec.id}`,
          code: 'ERR_2B_MISSING_INVOICE',
          severity: 'MEDIUM',
          category: 'ITC_BLOCKAGE',
          title: `Invoice Missing in GSTR-2B: ${rec.invoiceNumber}`,
          description: `Vendor ${rec.supplierName} has not uploaded invoice in GSTR-1. Under Section 16(2)(aa) and Rule 36(4), ITC of ₹${rec.bookTax} cannot be claimed in current tax period.`,
          entityType: 'GSTR2B',
          entityId: rec.id,
          invoiceNumber: rec.invoiceNumber,
          suggestedAction: 'Hold ITC in books and trigger payment withhold alert to accounts payable.',
          resolved: false,
          timestamp: new Date().toISOString()
        });
      }
    }

    return exceptions;
  }
}

export const exceptionEngine = new ExceptionEngine();
