import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, Send, X, Bot, User, BookOpen, AlertTriangle, CheckCircle2, ShieldCheck, Loader2 } from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  structuredDecision?: any;
}

interface AIAssistantDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  initialPrompt?: string;
}

export const AIAssistantDrawer: React.FC<AIAssistantDrawerProps> = ({
  isOpen,
  onClose,
  initialPrompt
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'assistant',
      text: `Hello! I am your **AI GST Expert & Legal Compliance Agent** grounded directly in the revised 12th edition of **"GST Act(s) and Rule(s) - Bare Law (April 2026 Edition)"** published by ICAI.

I analyze your transactions against CGST Act, IGST Act, and CGST Rules to provide structured, explainable legal decisions on:
• **Reverse Charge (RCM)** under Section 9(3) / 9(4)
• **ITC Eligibility & Blocked Credits** under Section 16 & Section 17(5)
• **Place of Supply (POS)** under IGST Sections 10 & 12
• **Statutory Returns & Scrutiny** (Rule 88C DRC-01B & Rule 88D DRC-01C)

How can I assist your compliance today?`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (initialPrompt && isOpen) {
      handleSendMessage(initialPrompt);
    }
  }, [initialPrompt, isOpen]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: textToSend })
      });

      const data = await response.json();
      const assistantMsg: ChatMessage = {
        id: `asst-${Date.now()}`,
        sender: 'assistant',
        text: data.text || 'Analysis completed.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        structuredDecision: data.structuredDecision
      };

      setMessages(prev => [...prev, assistantMsg]);
    } catch (err: any) {
      console.error(err);
      setMessages(prev => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          sender: 'assistant',
          text: 'Encountered communication error with GST Legal Service. Fallback local engine: Please review Section 16 & 17 of CGST Act.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-[520px] bg-white border-l border-[#E5E7EB] shadow-2xl flex flex-col">
      {/* Header */}
      <div className="p-4 bg-[#F8F9FA] border-b border-[#E5E7EB] flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-[#176B4D]/20 text-[#176B4D] flex items-center justify-center border border-[#176B4D]/30">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-[#202124] flex items-center gap-2">
              GST Expert AI
              <span className="text-[10px] px-2 py-0.5 rounded bg-[#176B4D]/20 text-[#176B4D] font-mono">
                ICAI 12th Ed. Grounded
              </span>
            </h3>
            <p className="text-[11px] text-[#6B7280]">Explainable Legal Intelligence • Bare Law RAG</p>
          </div>
        </div>
        <button onClick={onClose} className="text-[#6B7280] hover:text-white transition">
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Suggested Quick Prompts */}
      <div className="p-3 bg-[#FFFFFF]/60 border-b border-[#E5E7EB] overflow-x-auto flex items-center gap-2">
        {[
          'Private Limited company ne partnership firm ko lamps sale kiye. RCM lagega?',
          'Can I claim ITC on motor car repair under Section 17(5)?',
          'Is GTA freight subject to RCM and payable in cash?',
          'What is the order of ITC utilization under Rule 88A?'
        ].map((prompt, idx) => (
          <button
            key={idx}
            onClick={() => handleSendMessage(prompt)}
            className="px-2.5 py-1 rounded-lg bg-[#F8F9FA] hover:bg-slate-700 text-[#6B7280] text-[11px] whitespace-nowrap transition border border-[#E5E7EB] shrink-0"
          >
            {prompt.length > 35 ? prompt.substring(0, 35) + '...' : prompt}
          </button>
        ))}
      </div>

      {/* Chat Messages */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4 text-xs">
        {messages.map(msg => (
          <div
            key={msg.id}
            className={`flex items-start gap-2.5 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            {msg.sender === 'assistant' && (
              <div className="w-7 h-7 rounded-lg bg-[#176B4D]/20 text-[#176B4D] flex items-center justify-center shrink-0 mt-0.5 border border-[#176B4D]/30">
                <Bot className="w-4 h-4" />
              </div>
            )}

            <div
              className={`rounded-2xl p-4 max-w-[85%] leading-relaxed ${
                msg.sender === 'user'
                  ? 'bg-[#176B4D] text-white rounded-tr-none'
                  : 'bg-[#F8F9FA] text-[#202124] border border-[#E5E7EB] rounded-tl-none space-y-2'
              }`}
            >
              <div className="whitespace-pre-wrap">{msg.text}</div>
              <div className={`text-[10px] mt-1 ${msg.sender === 'user' ? 'text-emerald-200' : 'text-[#6B7280]'}`}>
                {msg.timestamp}
              </div>
            </div>

            {msg.sender === 'user' && (
              <div className="w-7 h-7 rounded-lg bg-slate-700 text-[#6B7280] flex items-center justify-center shrink-0 mt-0.5">
                <User className="w-4 h-4" />
              </div>
            )}
          </div>
        ))}

        {isLoading && (
          <div className="flex items-center gap-2 text-[#6B7280] text-xs p-3 rounded-xl bg-[#F8F9FA] border border-[#E5E7EB] w-fit">
            <Loader2 className="w-4 h-4 animate-spin text-[#176B4D]" />
            <span>Consulting Bare Law index & retrieving provisions...</span>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Field */}
      <div className="p-4 bg-[#F8F9FA] border-t border-[#E5E7EB]">
        <form
          onSubmit={e => {
            e.preventDefault();
            handleSendMessage(input);
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={e => setInput(e.target.value)}
            placeholder="Ask GST question or paste transaction details..."
            className="flex-1 bg-white border border-[#E5E7EB] rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#176B4D]/30"
          />
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="p-2.5 rounded-xl bg-[#176B4D] hover:bg-emerald-400 disabled:opacity-40 text-slate-950 font-bold transition shrink-0"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
