import React, { useState } from 'react';
import {
  LayoutDashboard,
  Users,
  FileText,
  GitCompare,
  BookOpen,
  Receipt,
  BarChart3,
  AlertTriangle,
  FolderLock,
  Sparkles,
  Sliders,
  Settings,
  ChevronDown,
  ChevronRight,
  ShieldCheck,
  CheckCircle2,
  FileSpreadsheet,
  Send,
  ArrowUpRight,
  ArrowDownLeft,
  Layers,
  Repeat,
  FlaskConical,
  History,
  X
} from 'lucide-react';

export type NavTab =
  | 'admin'
  | 'practice'
  | 'clientmaster'
  | 'dashboard'
  | 'sales'
  | 'purchases'
  | 'reconciliation'
  | 'gstr1'
  | 'gstr3b'
  | 'itc'
  | 'rcm'
  | 'ecommerce'
  | 'barelaw'
  | 'exceptions'
  | 'filing'
  | 'testsuite'
  | 'audit'
  | 'vault';

interface SidebarProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  onOpenDataModal?: () => void;
  onOpenCredentialVault?: () => void;
  exceptionsCount: number;
  matchRate: number;
  salesCount: number;
  purchaseCount: number;
  clientCount?: number;
  isMobileOpen?: boolean;
  onCloseMobile?: () => void;
  onOpenAI?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onTabChange,
  onOpenDataModal,
  onOpenCredentialVault,
  exceptionsCount,
  matchRate,
  salesCount,
  purchaseCount,
  clientCount = 0,
  isMobileOpen = false,
  onCloseMobile,
  onOpenAI
}) => {
  // Collapsible sub-navigation for groups
  const [openGstReturns, setOpenGstReturns] = useState(
    ['gstr1', 'gstr3b', 'filing'].includes(activeTab)
  );
  const [openRegisters, setOpenRegisters] = useState(
    ['sales', 'purchases'].includes(activeTab)
  );
  const [openReports, setOpenReports] = useState(
    ['itc', 'rcm', 'testsuite'].includes(activeTab)
  );

  const handleItemClick = (tabId: NavTab) => {
    onTabChange(tabId);
    if (onCloseMobile) {
      onCloseMobile();
    }
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 bg-slate-950/70 z-40 lg:hidden backdrop-blur-sm transition-opacity"
          onClick={onCloseMobile}
        />
      )}

      <aside
        className={`
        fixed inset-y-0 left-0 z-50 w-64 bg-[#0B1F44] text-slate-300 flex flex-col justify-between h-full overflow-y-auto transition-transform duration-300 ease-in-out shadow-2xl border-r border-[#1E293B]/60
        lg:static lg:z-auto lg:h-screen lg:translate-x-0 shrink-0
        ${isMobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}
      >
        <div className="flex flex-col h-full">
          {/* Brand Header */}
          <div className="p-5 pb-4 border-b border-white/10 flex items-center justify-between">
            <div
              onClick={() => handleItemClick('dashboard')}
              className="flex items-center gap-3 cursor-pointer group select-none"
            >
              {/* Gold Bar-Chart Logo Icon matching design */}
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#D4A24C] via-[#C59239] to-[#996B1E] flex items-center justify-center shadow-lg shadow-[#D4A24C]/20 text-slate-950 group-hover:scale-105 transition-transform">
                <svg
                  className="w-6 h-6 text-slate-950"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M4 20v-4" />
                  <path d="M9 20v-8" />
                  <path d="M14 20v-12" />
                  <path d="M19 20v-16" />
                  <polyline points="4 15 9 10 14 6 19 3" strokeWidth="2" />
                </svg>
              </div>

              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xl font-black tracking-tight text-white font-sans">
                    TAX<span className="text-[#D4A24C]">EDGE</span>
                  </span>
                </div>
                <p className="text-[10px] text-slate-400 font-medium tracking-wide">
                  GST Compliance & Automation
                </p>
              </div>
            </div>

            {/* Mobile close button */}
            {onCloseMobile && (
              <button
                onClick={onCloseMobile}
                className="lg:hidden p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>

          {/* Navigation Items matching the Design Board */}
          <nav className="flex-1 p-3 space-y-1.5 overflow-y-auto text-xs font-medium">
            {/* 1. Dashboard (Active state shown with gold pill #D4A24C) */}
            <button
              onClick={() => handleItemClick('dashboard')}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-bold transition select-none ${
                activeTab === 'dashboard'
                  ? 'bg-[#D4A24C] text-slate-950 shadow-md shadow-[#D4A24C]/25'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <div className="flex items-center gap-3">
                <LayoutDashboard
                  className={`w-4 h-4 ${
                    activeTab === 'dashboard' ? 'text-slate-950' : 'text-slate-400'
                  }`}
                />
                <span>Dashboard</span>
              </div>
            </button>

            {/* 2. Clients */}
            <button
              onClick={() => handleItemClick('clientmaster')}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-semibold transition select-none ${
                activeTab === 'clientmaster' || activeTab === 'practice'
                  ? 'bg-[#D4A24C] text-slate-950 shadow-md shadow-[#D4A24C]/25'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <div className="flex items-center gap-3">
                <Users
                  className={`w-4 h-4 ${
                    activeTab === 'clientmaster' || activeTab === 'practice'
                      ? 'text-slate-950'
                      : 'text-slate-400'
                  }`}
                />
                <span>Clients</span>
              </div>
              <span
                className={`text-[10px] px-1.5 py-0.5 rounded font-bold font-mono ${
                  activeTab === 'clientmaster' || activeTab === 'practice'
                    ? 'bg-slate-950/20 text-slate-950'
                    : 'bg-white/10 text-slate-300'
                }`}
              >
                {clientCount}
              </span>
            </button>

            {/* 3. GST Returns (with Sub-items: GSTR-1, 3B, Filing) */}
            <div>
              <button
                onClick={() => setOpenGstReturns(!openGstReturns)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-semibold transition select-none ${
                  ['gstr1', 'gstr3b', 'filing'].includes(activeTab)
                    ? 'text-white bg-white/10'
                    : 'text-slate-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <div className="flex items-center gap-3">
                  <FileText className="w-4 h-4 text-slate-400" />
                  <span>GST Returns</span>
                </div>
                {openGstReturns ? (
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                ) : (
                  <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                )}
              </button>

              {openGstReturns && (
                <div className="ml-5 pl-3 border-l border-white/10 space-y-1 mt-1">
                  <button
                    onClick={() => handleItemClick('gstr1')}
                    className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-xs transition ${
                      activeTab === 'gstr1'
                        ? 'bg-[#D4A24C] text-slate-950 font-bold'
                        : 'text-slate-300 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <span>GSTR-1 Outward</span>
                    <span className="text-[10px] opacity-75">11th</span>
                  </button>
                  <button
                    onClick={() => handleItemClick('gstr3b')}
                    className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-xs transition ${
                      activeTab === 'gstr3b'
                        ? 'bg-[#D4A24C] text-slate-950 font-bold'
                        : 'text-slate-300 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <span>GSTR-3B Summary</span>
                    <span className="text-[10px] opacity-75">20th</span>
                  </button>
                  <button
                    onClick={() => handleItemClick('filing')}
                    className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-xs transition ${
                      activeTab === 'filing'
                        ? 'bg-[#D4A24C] text-slate-950 font-bold'
                        : 'text-slate-300 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <span>Filing & Approval</span>
                    <span className="text-[10px] px-1 py-0.2 rounded bg-emerald-500/20 text-emerald-400">
                      Sign
                    </span>
                  </button>
                </div>
              )}
            </div>

            {/* 4. 2B Reconciliation */}
            <button
              onClick={() => handleItemClick('reconciliation')}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-semibold transition select-none ${
                activeTab === 'reconciliation'
                  ? 'bg-[#D4A24C] text-slate-950 shadow-md shadow-[#D4A24C]/25'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <div className="flex items-center gap-3">
                <GitCompare
                  className={`w-4 h-4 ${
                    activeTab === 'reconciliation' ? 'text-slate-950' : 'text-slate-400'
                  }`}
                />
                <span>2B Reconciliation</span>
              </div>
              <span
                className={`text-[10px] px-1.5 py-0.5 rounded font-bold font-mono ${
                  activeTab === 'reconciliation'
                    ? 'bg-slate-950/20 text-slate-950'
                    : 'bg-emerald-500/20 text-emerald-400'
                }`}
              >
                {matchRate}%
              </span>
            </button>

            {/* 5. Registers (Sales & Purchase) */}
            <div>
              <button
                onClick={() => setOpenRegisters(!openRegisters)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-semibold transition select-none ${
                  ['sales', 'purchases'].includes(activeTab)
                    ? 'text-white bg-white/10'
                    : 'text-slate-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <div className="flex items-center gap-3">
                  <BookOpen className="w-4 h-4 text-slate-400" />
                  <span>Registers</span>
                </div>
                {openRegisters ? (
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                ) : (
                  <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                )}
              </button>

              {openRegisters && (
                <div className="ml-5 pl-3 border-l border-white/10 space-y-1 mt-1">
                  <button
                    onClick={() => handleItemClick('sales')}
                    className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-xs transition ${
                      activeTab === 'sales'
                        ? 'bg-[#D4A24C] text-slate-950 font-bold'
                        : 'text-slate-300 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <ArrowUpRight className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Sales Register</span>
                    </div>
                    {salesCount > 0 && (
                      <span className="text-[10px] font-mono opacity-80">{salesCount}</span>
                    )}
                  </button>
                  <button
                    onClick={() => handleItemClick('purchases')}
                    className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-xs transition ${
                      activeTab === 'purchases'
                        ? 'bg-[#D4A24C] text-slate-950 font-bold'
                        : 'text-slate-300 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <ArrowDownLeft className="w-3.5 h-3.5 text-blue-400" />
                      <span>Purchase Register</span>
                    </div>
                    {purchaseCount > 0 && (
                      <span className="text-[10px] font-mono opacity-80">{purchaseCount}</span>
                    )}
                  </button>
                </div>
              )}
            </div>

            {/* 6. Invoices & e-Invoicing */}
            <button
              onClick={() => handleItemClick('ecommerce')}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-semibold transition select-none ${
                activeTab === 'ecommerce'
                  ? 'bg-[#D4A24C] text-slate-950 shadow-md shadow-[#D4A24C]/25'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <div className="flex items-center gap-3">
                <Receipt
                  className={`w-4 h-4 ${
                    activeTab === 'ecommerce' ? 'text-slate-950' : 'text-slate-400'
                  }`}
                />
                <span>Invoices & e-Invoicing</span>
              </div>
            </button>

            {/* 7. Reports & Analytics */}
            <div>
              <button
                onClick={() => setOpenReports(!openReports)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-semibold transition select-none ${
                  ['itc', 'rcm', 'testsuite'].includes(activeTab)
                    ? 'text-white bg-white/10'
                    : 'text-slate-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <div className="flex items-center gap-3">
                  <BarChart3 className="w-4 h-4 text-slate-400" />
                  <span>Reports & Analytics</span>
                </div>
                {openReports ? (
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                ) : (
                  <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                )}
              </button>

              {openReports && (
                <div className="ml-5 pl-3 border-l border-white/10 space-y-1 mt-1">
                  <button
                    onClick={() => handleItemClick('itc')}
                    className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-xs transition ${
                      activeTab === 'itc'
                        ? 'bg-[#D4A24C] text-slate-950 font-bold'
                        : 'text-slate-300 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <span>ITC Engine 16/17</span>
                  </button>
                  <button
                    onClick={() => handleItemClick('rcm')}
                    className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-xs transition ${
                      activeTab === 'rcm'
                        ? 'bg-[#D4A24C] text-slate-950 font-bold'
                        : 'text-slate-300 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <span>RCM Engine 9(3)/9(4)</span>
                  </button>
                  <button
                    onClick={() => handleItemClick('testsuite')}
                    className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-xs transition ${
                      activeTab === 'testsuite'
                        ? 'bg-[#D4A24C] text-slate-950 font-bold'
                        : 'text-slate-300 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <span>Statutory Audit Suite</span>
                  </button>
                </div>
              )}
            </div>

            {/* 8. Compliances & Notices */}
            <button
              onClick={() => handleItemClick('exceptions')}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-semibold transition select-none ${
                activeTab === 'exceptions'
                  ? 'bg-[#D4A24C] text-slate-950 shadow-md shadow-[#D4A24C]/25'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <div className="flex items-center gap-3">
                <AlertTriangle
                  className={`w-4 h-4 ${
                    activeTab === 'exceptions' ? 'text-slate-950' : 'text-amber-400'
                  }`}
                />
                <span>Compliances & Notices</span>
              </div>
              {exceptionsCount > 0 && (
                <span
                  className={`text-[10px] px-1.5 py-0.5 rounded font-bold font-mono ${
                    activeTab === 'exceptions'
                      ? 'bg-slate-950/20 text-slate-950'
                      : 'bg-[#EF4444] text-white'
                  }`}
                >
                  {exceptionsCount}
                </span>
              )}
            </button>

            {/* 9. Document Vault */}
            <button
              onClick={() => {
                if (onOpenCredentialVault) {
                  onOpenCredentialVault();
                } else {
                  handleItemClick('audit');
                }
              }}
              className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-semibold text-slate-300 hover:text-white hover:bg-white/5 transition select-none"
            >
              <div className="flex items-center gap-3">
                <FolderLock className="w-4 h-4 text-slate-400" />
                <span>Document Vault</span>
              </div>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-white/10 text-slate-300 font-mono">
                AES-256
              </span>
            </button>

            {/* 10. AI GST Assistant (with AI pill badge matching design) */}
            <button
              onClick={() => {
                if (onOpenAI) {
                  onOpenAI();
                } else {
                  handleItemClick('barelaw');
                }
              }}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-semibold transition select-none ${
                activeTab === 'barelaw'
                  ? 'bg-[#D4A24C] text-slate-950 shadow-md shadow-[#D4A24C]/25'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <div className="flex items-center gap-3">
                <Sparkles
                  className={`w-4 h-4 ${
                    activeTab === 'barelaw' ? 'text-slate-950' : 'text-[#14B8A6]'
                  }`}
                />
                <span>AI GST Assistant</span>
              </div>
              <span className="text-[10px] px-1.5 py-0.5 rounded font-extrabold bg-[#14B8A6]/20 text-[#14B8A6] border border-[#14B8A6]/30">
                AI
              </span>
            </button>

            {/* 11. Utilities (Admin Panel / 1-Click Template Editor & Masters) */}
            <button
              onClick={() => handleItemClick('admin')}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-semibold transition select-none ${
                activeTab === 'admin'
                  ? 'bg-[#D4A24C] text-slate-950 shadow-md shadow-[#D4A24C]/25'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <div className="flex items-center gap-3">
                <Sliders
                  className={`w-4 h-4 ${
                    activeTab === 'admin' ? 'text-slate-950' : 'text-slate-400'
                  }`}
                />
                <span>Utilities</span>
              </div>
              <span
                className={`text-[9px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider ${
                  activeTab === 'admin'
                    ? 'bg-slate-950/20 text-slate-950'
                    : 'bg-[#D4A24C]/20 text-[#D4A24C]'
                }`}
              >
                1-Click Edit
              </span>
            </button>

            {/* 12. User & Settings */}
            <button
              onClick={() => handleItemClick('audit')}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl font-semibold transition select-none ${
                activeTab === 'audit'
                  ? 'bg-[#D4A24C] text-slate-950 shadow-md shadow-[#D4A24C]/25'
                  : 'text-slate-300 hover:text-white hover:bg-white/5'
              }`}
            >
              <div className="flex items-center gap-3">
                <Settings
                  className={`w-4 h-4 ${
                    activeTab === 'audit' ? 'text-slate-950' : 'text-slate-400'
                  }`}
                />
                <span>User & Settings</span>
              </div>
            </button>
          </nav>

          {/* Bottom Enterprise Badge */}
          <div className="p-3 border-t border-white/10 bg-slate-950/40 text-[11px] text-slate-400">
            <div className="flex items-center justify-between mb-1">
              <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-[#14B8A6]" />
                <span>Enterprise Ready</span>
              </span>
              <span className="inline-block w-2 h-2 rounded-full bg-[#14B8A6] animate-pulse"></span>
            </div>
            <div className="text-[10px] text-slate-500 leading-tight">
              Secure • Scalable • GST Compliant
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};
