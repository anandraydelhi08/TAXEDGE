import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  Bell,
  HelpCircle,
  Plus,
  Calendar,
  Sliders,
  Menu,
  ChevronDown,
  Building2,
  CheckCircle2,
  Sparkles,
  Command,
  Smartphone
} from 'lucide-react';
import { ClientMaster } from '../types/client';
import { NavTab } from './Sidebar';

interface HeaderProps {
  activeTab: string;
  onTabChange?: (tab: NavTab) => void;
  clients: ClientMaster[];
  currentClient: ClientMaster | null;
  currentGstin: string;
  customFirmName?: string;
  onSelectClientAndGstin: (clientId: string, gstin: string) => void;
  onNavigateToClientMaster: () => void;
  onOpenAI: () => void;
  onOpenOcr: () => void;
  onOpenDataModal: () => void;
  onOpenDemoConfirm: () => void;
  onResetAllToEmpty: () => void;
  onOpenApkModal?: () => void;
  onToggleMobileMenu?: () => void;
  isDemoMode: boolean;
  filingScore: number;
  criticalExceptionsCount: number;
  testMode: boolean;
  salesCount: number;
  purchaseCount: number;
  gstr2bCount: number;
  selectedFy: string;
  selectedMonth: string;
  onSelectFy: (fy: string) => void;
  onSelectMonth: (month: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onTabChange,
  clients,
  currentClient,
  currentGstin,
  customFirmName,
  onSelectClientAndGstin,
  onNavigateToClientMaster,
  onOpenAI,
  onOpenApkModal,
  isDemoMode,
  selectedFy,
  selectedMonth,
  onSelectFy,
  onSelectMonth,
  onToggleMobileMenu
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isPeriodOpen, setIsPeriodOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  const searchInputRef = useRef<HTMLInputElement>(null);
  const searchDropdownRef = useRef<HTMLDivElement>(null);
  const periodDropdownRef = useRef<HTMLDivElement>(null);

  // Global Ctrl+K keyboard shortcut handler
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        searchInputRef.current?.focus();
        setIsSearchOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Close dropdowns on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (
        searchDropdownRef.current &&
        !searchDropdownRef.current.contains(e.target as Node)
      ) {
        setIsSearchOpen(false);
      }
      if (
        periodDropdownRef.current &&
        !periodDropdownRef.current.contains(e.target as Node)
      ) {
        setIsPeriodOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Filter clients by search query (name, GSTIN, PAN)
  const filteredClients = clients.filter(c => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      c.name.toLowerCase().includes(q) ||
      (c.tradeName && c.tradeName.toLowerCase().includes(q)) ||
      c.primaryGstin.toLowerCase().includes(q) ||
      (c.pan && c.pan.toLowerCase().includes(q))
    );
  });

  const MONTHS = [
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
    'January',
    'February',
    'March'
  ];

  const FINANCIAL_YEARS = ['2026-27', '2025-26', '2024-25'];

  return (
    <header className="h-16 bg-white border-b border-slate-200/90 px-4 lg:px-6 flex items-center justify-between gap-4 sticky top-0 z-30 shadow-xs">
      {/* Left: Mobile Toggle & Global Search Box matching screenshot */}
      <div className="flex items-center gap-3 flex-1 max-w-xl">
        {onToggleMobileMenu && (
          <button
            onClick={onToggleMobileMenu}
            className="lg:hidden p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition"
            aria-label="Open Navigation Menu"
          >
            <Menu className="w-5 h-5" />
          </button>
        )}

        {/* Global Search Box matching: "Search client by name, GSTIN or PAN...   Ctrl+K" */}
        <div ref={searchDropdownRef} className="relative flex-1">
          <div className="relative flex items-center">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
            <input
              ref={searchInputRef}
              type="text"
              value={searchQuery}
              onChange={e => {
                setSearchQuery(e.target.value);
                setIsSearchOpen(true);
              }}
              onFocus={() => setIsSearchOpen(true)}
              placeholder="Search client by name, GSTIN or PAN..."
              className="w-full pl-9 pr-16 py-2 bg-slate-50 hover:bg-slate-100/80 focus:bg-white text-xs text-slate-800 placeholder-slate-400 rounded-xl border border-slate-200 focus:border-[#D4A24C] focus:ring-2 focus:ring-[#D4A24C]/20 transition outline-none"
            />
            <div className="absolute right-2.5 flex items-center gap-1 pointer-events-none">
              <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-mono font-semibold text-slate-400 bg-white border border-slate-200 rounded shadow-2xs">
                Ctrl + K
              </kbd>
            </div>
          </div>

          {/* Search Dropdown Results */}
          {isSearchOpen && (
            <div className="absolute top-full left-0 right-0 mt-1.5 bg-white border border-slate-200 rounded-xl shadow-xl z-50 max-h-72 overflow-y-auto">
              <div className="p-2 border-b border-slate-100 text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
                <span>Matching Clients ({filteredClients.length})</span>
                <span className="text-[10px] lowercase font-normal">click to switch</span>
              </div>
              {filteredClients.length > 0 ? (
                filteredClients.map(c => {
                  const isSelected = currentClient?.id === c.id;
                  return (
                    <button
                      key={c.id}
                      onClick={() => {
                        onSelectClientAndGstin(c.id, c.primaryGstin);
                        setIsSearchOpen(false);
                      }}
                      className={`w-full text-left p-2.5 hover:bg-slate-50 flex items-center justify-between border-b border-slate-50 transition ${
                        isSelected ? 'bg-amber-50/60' : ''
                      }`}
                    >
                      <div className="flex items-center gap-2.5 truncate">
                        <div
                          className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs ${
                            isSelected
                              ? 'bg-[#D4A24C] text-slate-950'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {c.name.substring(0, 2).toUpperCase()}
                        </div>
                        <div className="truncate">
                          <div className="font-semibold text-xs text-slate-800 truncate">
                            {c.name}
                          </div>
                          <div className="font-mono text-[10px] text-slate-400">
                            {c.primaryGstin} • {c.state}
                          </div>
                        </div>
                      </div>
                      {isSelected && (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      )}
                    </button>
                  );
                })
              ) : (
                <div className="p-4 text-center text-xs text-slate-400">
                  No client found matching "{searchQuery}"
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Right Controls: Notification, Help, Profile, Period, Add Client */}
      <div className="flex items-center gap-2.5 sm:gap-3">
        {/* 1-Click Utilities / Admin Panel Shortcut Pill */}
        {onTabChange && (
          <button
            onClick={() => onTabChange('admin')}
            className="hidden xl:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-900 text-xs font-bold transition shadow-2xs"
            title="Open 1-Click Template Editor & Government Masters"
          >
            <Sliders className="w-3.5 h-3.5 text-amber-700" />
            <span>Admin Panel</span>
          </button>
        )}

        {/* Notifications Icon with unread red badge */}
        <div className="relative">
          <button
            onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
            className="p-2 rounded-xl text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition relative"
            title="Notifications"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#EF4444] ring-2 ring-white"></span>
          </button>

          {isNotificationsOpen && (
            <div className="absolute right-0 mt-2 w-72 bg-white border border-slate-200 rounded-xl shadow-xl z-50 p-3 space-y-2">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 text-xs font-bold text-slate-800">
                <span>Compliance Alerts</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-rose-50 text-rose-600 font-bold">
                  1 New
                </span>
              </div>
              <div className="text-xs space-y-1.5">
                <div className="p-2 rounded-lg bg-slate-50 border border-slate-100">
                  <p className="font-semibold text-slate-800">GSTR-1 Due in 5 Days</p>
                  <p className="text-[11px] text-slate-500">
                    October 2026 return due date is 11 Nov 2026. 8 client returns pending.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Help / Bare Law FAQ Icon */}
        <button
          onClick={onOpenAI}
          className="p-2 rounded-xl text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition"
          title="GST Bare Law Assistant & Help"
        >
          <HelpCircle className="w-4 h-4" />
        </button>

        {/* User Profile Chip matching screenshot: [AR] Anand Rai (Admin) */}
        <div className="relative">
          <div
            onClick={() => setIsProfileOpen(!isProfileOpen)}
            className="flex items-center gap-2 px-2 py-1 rounded-xl hover:bg-slate-100 cursor-pointer transition select-none"
          >
            <div className="w-8 h-8 rounded-full bg-[#0B1F44] text-[#D4A24C] font-bold text-xs flex items-center justify-center ring-2 ring-[#D4A24C]/30 shadow-xs">
              AR
            </div>
            <div className="hidden md:block text-left">
              <div className="text-xs font-bold text-slate-900 leading-tight">
                Anand Rai
              </div>
              <div className="text-[10px] text-slate-400 font-medium">Admin</div>
            </div>
          </div>

          {isProfileOpen && (
            <div className="absolute right-0 mt-2 w-52 bg-white border border-slate-200 rounded-xl shadow-xl z-50 p-2 space-y-1 text-xs">
              <div className="p-2 border-b border-slate-100">
                <div className="font-bold text-slate-800">Anand Rai</div>
                <div className="text-[11px] text-slate-500">anand.rai@taxedge.in</div>
              </div>
              <button
                onClick={() => {
                  onTabChange?.('admin');
                  setIsProfileOpen(false);
                }}
                className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-slate-50 text-slate-700 flex items-center gap-2"
              >
                <Sliders className="w-3.5 h-3.5 text-slate-400" />
                <span>Admin Settings</span>
              </button>
              <button
                onClick={() => {
                  onTabChange?.('audit');
                  setIsProfileOpen(false);
                }}
                className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-slate-50 text-slate-700 flex items-center gap-2"
              >
                <Building2 className="w-3.5 h-3.5 text-slate-400" />
                <span>Firm Master</span>
              </button>
            </div>
          )}
        </div>

        {/* Return Period Selector Dropdown Pill matching screenshot: 📅 Oct 2026 ▾ */}
        <div ref={periodDropdownRef} className="relative">
          <button
            onClick={() => setIsPeriodOpen(!isPeriodOpen)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-700 rounded-xl border border-slate-200 text-xs font-bold transition shadow-2xs"
          >
            <Calendar className="w-3.5 h-3.5 text-slate-500" />
            <span>
              {selectedMonth.substring(0, 3)} {selectedFy.split('-')[0]}
            </span>
            <ChevronDown className="w-3 h-3 text-slate-400 ml-0.5" />
          </button>

          {isPeriodOpen && (
            <div className="absolute right-0 mt-2 w-64 bg-white border border-slate-200 rounded-xl shadow-xl z-50 p-3 space-y-3">
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Financial Year
                </label>
                <div className="grid grid-cols-3 gap-1">
                  {FINANCIAL_YEARS.map(fy => (
                    <button
                      key={fy}
                      onClick={() => onSelectFy(fy)}
                      className={`py-1 text-xs rounded-lg font-mono font-semibold transition ${
                        selectedFy === fy
                          ? 'bg-[#0B1F44] text-white'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {fy}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Return Month
                </label>
                <div className="grid grid-cols-3 gap-1 max-h-40 overflow-y-auto">
                  {MONTHS.map(m => (
                    <button
                      key={m}
                      onClick={() => {
                        onSelectMonth(m);
                        setIsPeriodOpen(false);
                      }}
                      className={`py-1 text-xs rounded-lg font-semibold transition ${
                        selectedMonth.toLowerCase() === m.toLowerCase()
                          ? 'bg-[#D4A24C] text-slate-950 font-bold'
                          : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {m.substring(0, 3)}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Primary Action Button matching screenshot: + Add Client */}
        <button
          onClick={onNavigateToClientMaster}
          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-[#0B1F44] hover:bg-[#132c5e] text-white text-xs font-bold transition shadow-sm active:scale-95 shrink-0"
        >
          <Plus className="w-3.5 h-3.5 text-[#D4A24C]" />
          <span>Add Client</span>
        </button>
      </div>
    </header>
  );
};
