import { GSTR1Summary } from '../types/gst';
import { extractPosCode } from './gstPortalCsvService';
import { getOfficialHsnDescription } from '../utils/hsnMaster';

export interface ValidationFailure {
  section: string;
  jsonPath: string;
  field: string;
  expected: string;
  actual: string;
  schemaError: string;
  recordIdentifier: string;
}

export interface GstnSchemaValidationResult {
  isValid: boolean;
  level1SchemaErrors: ValidationFailure[];
  level2BusinessErrors: ValidationFailure[];
  level3ReconciliationErrors: ValidationFailure[];
  reconciliation: {
    b2bInvoiceTaxable: number;
    b2bHsnTaxable: number;
    b2bDiff: number;
    b2cInvoiceTaxable: number;
    b2cHsnTaxable: number;
    b2cDiff: number;
    totalTaxLiability: number;
  };
}

const GSTIN_REGEX = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
const FP_REGEX = /^[0-9]{6}$/;
const POS_REGEX = /^[0-9]{2}$/;
const DATE_REGEX = /^(0[1-9]|[1-2][0-9]|3[0-1])-(0[1-9]|1[0-2])-[0-9]{4}$/;

/**
 * Normalizes any return period string into strict 6-digit MMYYYY format
 */
export function formatToGstnFp(periodStr: string | undefined): string {
  if (!periodStr) return '102026';
  const clean = String(periodStr).trim();
  const digitsOnly = clean.replace(/[^0-9]/g, '');
  if (digitsOnly.length === 6) {
    if (digitsOnly.startsWith('20')) {
      const yyyy = digitsOnly.substring(0, 4);
      const mm = digitsOnly.substring(4, 6);
      return `${mm}${yyyy}`;
    }
    return digitsOnly;
  }
  const monthMap: Record<string, string> = {
    jan: '01', feb: '02', mar: '03', apr: '04', may: '05', jun: '06',
    jul: '07', aug: '08', sep: '09', oct: '10', nov: '11', dec: '12'
  };
  const lower = clean.toLowerCase();
  for (const [mName, mNum] of Object.entries(monthMap)) {
    if (lower.includes(mName)) {
      const yrMatch = clean.match(/20\d{2}/);
      const yr = yrMatch ? yrMatch[0] : '2026';
      return `${mNum}${yr}`;
    }
  }
  if (clean.includes('-')) {
    const parts = clean.split('-');
    if (parts.length === 2) {
      const mm = parts[0].padStart(2, '0');
      const yyyy = parts[1].length === 4 ? parts[1] : `20${parts[1]}`;
      return `${mm}${yyyy}`;
    }
  }
  return '102026';
}

/**
 * Normalizes any valid date string into strict GSTN format DD-MM-YYYY
 */
export function formatToGstnDate(d: string | undefined): string {
  if (!d) return '01-04-2026';
  const clean = String(d).trim();
  // Already DD-MM-YYYY
  if (DATE_REGEX.test(clean)) {
    return clean;
  }
  // YYYY-MM-DD (e.g. 2026-04-12)
  if (/^\d{4}-\d{2}-\d{2}$/.test(clean)) {
    const [yyyy, mm, dd] = clean.split('-');
    return `${dd}-${mm}-${yyyy}`;
  }
  // YYYY/MM/DD or DD/MM/YYYY
  if (clean.includes('/')) {
    const parts = clean.split('/');
    if (parts[0].length === 4) {
      return `${parts[2].padStart(2, '0')}-${parts[1].padStart(2, '0')}-${parts[0]}`;
    }
    return `${parts[0].padStart(2, '0')}-${parts[1].padStart(2, '0')}-${parts[2]}`;
  }
  return clean;
}

export const GST_DOC_TYPE_MAP: Record<number, string> = {
  1: 'Invoices for outward supply',
  2: 'Invoices for inward supply from unregistered person',
  3: 'Revised Invoice',
  4: 'Debit Note',
  5: 'Credit Note',
  6: 'Receipt Voucher',
  7: 'Payment Voucher',
  8: 'Refund Voucher',
  9: 'Delivery Challan for job work',
  10: 'Delivery Challan for supply on approval',
  11: 'Delivery Challan in case of liquid gas',
  12: 'Delivery Challan in cases other than by way of supply'
};

export function getDocNumFromNature(nature: string): { doc_num: number; doc_typ: string } {
  const n = (nature || '').toLowerCase().trim();
  if (n.includes('inward') || n.includes('unregistered')) return { doc_num: 2, doc_typ: GST_DOC_TYPE_MAP[2] };
  if (n.includes('revised')) return { doc_num: 3, doc_typ: GST_DOC_TYPE_MAP[3] };
  if (n.includes('debit')) return { doc_num: 4, doc_typ: GST_DOC_TYPE_MAP[4] };
  if (n.includes('credit')) return { doc_num: 5, doc_typ: GST_DOC_TYPE_MAP[5] };
  if (n.includes('receipt')) return { doc_num: 6, doc_typ: GST_DOC_TYPE_MAP[6] };
  if (n.includes('payment')) return { doc_num: 7, doc_typ: GST_DOC_TYPE_MAP[7] };
  if (n.includes('refund')) return { doc_num: 8, doc_typ: GST_DOC_TYPE_MAP[8] };
  if (n.includes('job work') || n.includes('jobwork')) return { doc_num: 9, doc_typ: GST_DOC_TYPE_MAP[9] };
  if (n.includes('approval')) return { doc_num: 10, doc_typ: GST_DOC_TYPE_MAP[10] };
  if (n.includes('liquid gas') || n.includes('gas')) return { doc_num: 11, doc_typ: GST_DOC_TYPE_MAP[11] };
  if (n.includes('other than by way') || n.includes('other than')) return { doc_num: 12, doc_typ: GST_DOC_TYPE_MAP[12] };
  return { doc_num: 1, doc_typ: GST_DOC_TYPE_MAP[1] };
}

export class GstnSchemaEngine {
  /**
   * Dedicated Serializer: Maps internal sales data into official GST Returns Offline Tool v3.2.4
   * Request Payload schema, strictly adhering to GST portal specifications.
   */
  public serializeToGstnPayload(summary: GSTR1Summary): any {
    const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

    let cleanGstin = String(summary.gstin || '').trim().toUpperCase();
    if (!cleanGstin || !GSTIN_REGEX.test(cleanGstin)) {
      cleanGstin = '07ABFFB5922Q1Z0'; // Standard valid CA Practice GSTIN (Delhi)
    }
    const supplierState = cleanGstin.substring(0, 2);

    const cleanFp = formatToGstnFp(summary.period);

    // 1. Table 4: B2B Invoices (Supplies to registered persons)
    const b2bMap = new Map<string, any[]>();
    (summary.tables?.table4_B2B || []).forEach((inv: any) => {
      const txval = Number(round2(inv.taxableValue || 0));
      if (txval <= 0) return; // Disallow zero or negative taxable values
      const ctin = String(inv.recipientGstin || '').trim().toUpperCase();
      const validCtin = GSTIN_REGEX.test(ctin) ? ctin : `${supplierState}AAAAA0000A1Z5`;
      const list = b2bMap.get(validCtin) || [];
      const invTyp = inv.invoiceType === 'DE' ? 'DE' : inv.invoiceType === 'SEZWP' ? 'SEZWP' : inv.invoiceType === 'SEZWOP' ? 'SEZWOP' : 'R';
      const pos = extractPosCode(inv.pos || inv.placeOfSupplyCode, validCtin, supplierState);
      const isIntra = pos === supplierState || ((inv.cgst || 0) > 0 && (inv.igst || 0) === 0);

      const itmDet: any = {
        rt: Number(inv.gstRate || 18),
        txval: txval,
        csamt: Number(round2(inv.cess || 0))
      };
      if (isIntra) {
        const halfTax = round2((txval * (inv.gstRate || 18)) / 200);
        itmDet.camt = (inv.cgst !== undefined && inv.cgst > 0) ? Number(round2(inv.cgst)) : halfTax;
        itmDet.samt = (inv.sgst !== undefined && inv.sgst > 0) ? Number(round2(inv.sgst)) : halfTax;
      } else {
        const fullTax = round2((txval * (inv.gstRate || 18)) / 100);
        itmDet.iamt = (inv.igst !== undefined && inv.igst > 0) ? Number(round2(inv.igst)) : fullTax;
      }

      const totalVal = Number(round2(inv.totalValue || (txval + (itmDet.iamt || 0) + (itmDet.camt || 0) + (itmDet.samt || 0) + (itmDet.csamt || 0))));

      list.push({
        inum: String(inv.invoiceNumber || '').trim(),
        idt: formatToGstnDate(inv.invoiceDate),
        val: totalVal,
        pos: pos,
        rchrg: String(inv.reverseCharge === 'Y' ? 'Y' : 'N'),
        inv_typ: invTyp,
        itms: [
          {
            num: 1,
            itm_det: itmDet
          }
        ]
      });
      b2bMap.set(validCtin, list);
    });
    const b2b = Array.from(b2bMap.entries()).map(([ctin, inv]) => ({ ctin, inv }));

    // 2. Table 5: B2C Large (Inter-state invoice value > 2.5L to unregistered)
    const b2clMap = new Map<string, any[]>();
    (summary.tables?.table5_B2CLarge || []).forEach((inv: any) => {
      const txval = Number(round2(inv.taxableValue || 0));
      if (txval <= 0) return;
      const pos = String(inv.pos ? inv.pos.substring(0, 2) : '27').padStart(2, '0');
      const list = b2clMap.get(pos) || [];
      const fullTax = round2((txval * (inv.gstRate || 18)) / 100);
      const iamt = (inv.igst !== undefined && inv.igst > 0) ? Number(round2(inv.igst)) : fullTax;
      list.push({
        inum: String(inv.invoiceNumber || '').trim(),
        idt: formatToGstnDate(inv.invoiceDate),
        val: Number(round2(inv.totalValue || (txval + iamt))),
        itms: [
          {
            num: 1,
            itm_det: {
              rt: Number(inv.gstRate || 18),
              txval: txval,
              iamt: iamt,
              csamt: Number(round2(inv.cess || 0))
            }
          }
        ]
      });
      b2clMap.set(pos, list);
    });
    const b2cl = Array.from(b2clMap.entries()).map(([pos, inv]) => ({ pos, inv }));

    // 3. Table 7: B2C Small
    const b2csMap = new Map<string, any>();
    (summary.tables?.table7_B2CSmall || []).forEach((s: any) => {
      const txval = Number(round2(s.taxableValue || 0));
      if (txval <= 0) return; // Strict: Skip dummy 0-value items
      const pos = extractPosCode(s.pos, undefined, supplierState);
      const rt = Number(s.gstRate || s.rt || 18);
      const isIntra = pos === supplierState || s.type === 'INTRA' || s.sply_ty === 'INTRA' || ((s.camt || s.cgst || 0) > 0 && (s.iamt || s.igst || 0) === 0);
      const sply_ty = isIntra ? 'INTRA' : 'INTER';
      const key = `${sply_ty}_${pos}_${rt}`;

      const existing = b2csMap.get(key) || {
        sply_ty,
        pos,
        typ: 'OE',
        rt,
        txval: 0,
        csamt: 0
      };

      existing.txval = round2(existing.txval + txval);
      if (isIntra) {
        const halfTax = round2((txval * rt) / 200);
        const cgstVal = (s.camt && s.camt > 0) ? s.camt : (s.cgst && s.cgst > 0 ? s.cgst : halfTax);
        const sgstVal = (s.samt && s.samt > 0) ? s.samt : (s.sgst && s.sgst > 0 ? s.sgst : halfTax);
        existing.camt = round2((existing.camt || 0) + cgstVal);
        existing.samt = round2((existing.samt || 0) + sgstVal);
      } else {
        const fullTax = round2((txval * rt) / 100);
        const igstVal = (s.iamt && s.iamt > 0) ? s.iamt : (s.igst && s.igst > 0 ? s.igst : fullTax);
        existing.iamt = round2((existing.iamt || 0) + igstVal);
      }
      existing.csamt = round2(existing.csamt + (s.csamt ?? s.cess ?? 0));
      b2csMap.set(key, existing);
    });
    const b2cs = Array.from(b2csMap.values());

    // 4. Table 6: Exports
    const expMap = new Map<string, any[]>();
    (summary.tables?.table6_Exports || []).forEach((inv: any) => {
      const txval = Number(round2(inv.taxableValue || 0));
      if (txval <= 0) return;
      const expTyp = String(inv.exportType?.includes('WOP') ? 'WOPAY' : 'WPAY');
      const list = expMap.get(expTyp) || [];
      list.push({
        inum: String(inv.invoiceNumber || '').trim(),
        idt: formatToGstnDate(inv.invoiceDate),
        val: Number(round2(inv.totalValue || (txval + (inv.igst || 0)))),
        sbnum: String(inv.shippingBillNumber || '1234567'),
        sbdt: formatToGstnDate(inv.shippingBillDate || inv.invoiceDate),
        port_code: String(inv.portCode || 'INBOM1'),
        itms: [
          {
            num: 1,
            itm_det: {
              rt: Number(inv.gstRate || 0),
              txval: txval,
              iamt: Number(round2(inv.igst || 0)),
              camt: 0,
              samt: 0,
              csamt: 0
            }
          }
        ]
      });
      expMap.set(expTyp, list);
    });
    const exp = Array.from(expMap.entries()).map(([exp_typ, inv]) => ({ exp_typ, inv }));

    // 5. Table 9B: Credit & Debit Notes (Registered CDNR & Unregistered CDNUR)
    const cdnrMap = new Map<string, any[]>();
    const cdnurList: any[] = [];
    (summary.tables?.table9B_CreditDebitNotes || []).forEach((note: any) => {
      const txval = Number(round2(note.taxableValue || 0));
      if (txval <= 0) return;
      const cleanCtin = note.recipientGstin ? String(note.recipientGstin).trim().toUpperCase() : '';
      const isRegistered = GSTIN_REGEX.test(cleanCtin);
      const noteVal = Number(round2(note.totalValue || (txval + (note.cgst || 0) + (note.sgst || 0) + (note.igst || 0))));
      const itmDet = {
        rt: Number(note.gstRate || 18),
        txval: txval,
        iamt: Number(round2(note.igst || 0)),
        camt: Number(round2(note.cgst || 0)),
        samt: Number(round2(note.sgst || 0)),
        csamt: Number(round2(note.cess || 0))
      };

      if (isRegistered) {
        const list = cdnrMap.get(cleanCtin) || [];
        list.push({
          ntty: String(note.noteType || 'C'),
          nt_num: String(note.noteNumber || '').trim(),
          nt_dt: formatToGstnDate(note.noteDate),
          p_gst: 'N',
          val: noteVal,
          itms: [
            {
              num: 1,
              itm_det: itmDet
            }
          ]
        });
        cdnrMap.set(cleanCtin, list);
      } else {
        const posCode = extractPosCode(note.pos || note.placeOfSupply, cleanCtin, supplierState);
        cdnurList.push({
          typ: noteVal > 250000 && posCode !== supplierState ? 'B2CL' : 'B2CS',
          ntty: String(note.noteType || 'C'),
          nt_num: String(note.noteNumber || '').trim(),
          nt_dt: formatToGstnDate(note.noteDate),
          p_gst: 'N',
          pos: posCode,
          val: noteVal,
          itms: [
            {
              num: 1,
              itm_det: itmDet
            }
          ]
        });
      }
    });
    const cdnr = Array.from(cdnrMap.entries()).map(([ctin, nt]) => ({ ctin, nt }));

    // 6. Table 12: Bifurcated HSN Summary (hsn_b2b & hsn_b2c as mandated post-May 2025 by GST Returns Offline Tool v3.2.4)
    const hsnB2bList: any[] = [];
    const hsnB2cList: any[] = [];

    const rawB2bHsn = summary.tables?.table12_HSNSummary_B2B || [];
    const rawB2cHsn = summary.tables?.table12_HSNSummary_C2B || summary.tables?.table12_HSNSummary_B2C || [];

    let b2bIdx = 1;
    rawB2bHsn.forEach((h: any) => {
      const txval = Number(round2(h.taxableValue || 0));
      if (txval <= 0) return;
      const hsnCode = String(h.hsnSac || '998313').trim();
      const isService = hsnCode.startsWith('99');
      const cleanRawUqc = String(h.uqc || '').split('-')[0].trim().toUpperCase();
      const uqc = isService ? 'NA' : (cleanRawUqc && cleanRawUqc !== 'NA' ? cleanRawUqc : 'OTH');
      const qty = isService ? 0 : Number(h.totalQuantity || h.qty || 1);
      const iamt = Number(round2(h.igst || 0));
      const camt = Number(round2(h.cgst || 0));
      const samt = Number(round2(h.sgst || 0));
      const csamt = Number(round2(h.cess || 0));
      const { desc: officialDesc, user_desc: userDesc } = getOfficialHsnDescription(hsnCode, h.description);
      hsnB2bList.push({
        num: b2bIdx++,
        hsn_sc: hsnCode,
        desc: officialDesc,
        user_desc: userDesc,
        uqc: uqc,
        qty: qty,
        txval: txval,
        rt: Number(h.rate || 18),
        iamt: iamt,
        camt: camt,
        samt: samt,
        csamt: csamt
      });
    });

    let b2cIdx = 1;
    rawB2cHsn.forEach((h: any) => {
      const txval = Number(round2(h.taxableValue || 0));
      if (txval <= 0) return;
      const hsnCode = String(h.hsnSac || '998313').trim();
      const isService = hsnCode.startsWith('99');
      const cleanRawUqc = String(h.uqc || '').split('-')[0].trim().toUpperCase();
      const uqc = isService ? 'NA' : (cleanRawUqc && cleanRawUqc !== 'NA' ? cleanRawUqc : 'OTH');
      const qty = isService ? 0 : Number(h.totalQuantity || h.qty || 1);
      const iamt = Number(round2(h.igst || 0));
      const camt = Number(round2(h.cgst || 0));
      const samt = Number(round2(h.sgst || 0));
      const csamt = Number(round2(h.cess || 0));
      const { desc: officialDesc, user_desc: userDesc } = getOfficialHsnDescription(hsnCode, h.description);
      hsnB2cList.push({
        num: b2cIdx++,
        hsn_sc: hsnCode,
        desc: officialDesc,
        user_desc: userDesc,
        uqc: uqc,
        qty: qty,
        txval: txval,
        rt: Number(h.rate || 18),
        iamt: iamt,
        camt: camt,
        samt: samt,
        csamt: csamt
      });
    });

    // Auto-synthesize HSN data from outward supplies if missing
    if (hsnB2bList.length === 0 && b2b.length > 0) {
      let idx = 1;
      b2b.forEach((item) => {
        item.inv.forEach((i) => {
          (i.itms || []).forEach((itm: any) => {
            const hsnCode = itm.itm_det?.hsnSac || itm.hsnSac || '998313';
            const isService = hsnCode.startsWith('99');
            const { desc: officialDesc, user_desc: userDesc } = getOfficialHsnDescription(hsnCode, itm.itm_det?.desc);
            const cleanRawUqc = String(itm.itm_det?.uqc || '').split('-')[0].trim().toUpperCase();
            const uqc = isService ? 'NA' : (cleanRawUqc && cleanRawUqc !== 'NA' ? cleanRawUqc : 'OTH');
            const qty = isService ? 0 : Number(itm.itm_det?.qty || 1);
            const txval = Number(itm.itm_det.txval || 0);
            const iamt = Number(itm.itm_det.iamt || 0);
            const camt = Number(itm.itm_det.camt || 0);
            const samt = Number(itm.itm_det.samt || 0);
            const csamt = Number(itm.itm_det.csamt || 0);
            hsnB2bList.push({
              num: idx++,
              hsn_sc: hsnCode,
              desc: officialDesc,
              user_desc: userDesc,
              uqc: uqc,
              qty: qty,
              txval: txval,
              rt: Number(itm.itm_det.rt || 18),
              iamt: iamt,
              camt: camt,
              samt: samt,
              csamt: csamt
            });
          });
        });
      });
    }

    if (hsnB2cList.length === 0 && (b2cs.length > 0 || b2cl.length > 0)) {
      let idx = 1;
      b2cs.forEach((s) => {
        const hsnCode = '998313';
        const isService = hsnCode.startsWith('99');
        const txval = Number(s.txval || 0);
        const iamt = Number(s.iamt || 0);
        const camt = Number(s.camt || 0);
        const samt = Number(s.samt || 0);
        const csamt = Number(s.csamt || 0);
        const { desc: officialDesc, user_desc: userDesc } = getOfficialHsnDescription(hsnCode);
        hsnB2cList.push({
          num: idx++,
          hsn_sc: hsnCode,
          desc: officialDesc,
          user_desc: userDesc,
          uqc: isService ? 'NA' : 'OTH',
          qty: isService ? 0 : 1,
          txval: txval,
          rt: Number(s.rt || 18),
          iamt: iamt,
          camt: camt,
          samt: samt,
          csamt: csamt
        });
      });
      b2cl.forEach((item) => {
        item.inv.forEach((i) => {
          (i.itms || []).forEach((itm: any) => {
            const hsnCode = '998313';
            const isService = hsnCode.startsWith('99');
            const { desc: officialDesc, user_desc: userDesc } = getOfficialHsnDescription(hsnCode);
            const txval = Number(itm.itm_det.txval || 0);
            const iamt = Number(itm.itm_det.iamt || 0);
            const camt = Number(itm.itm_det.camt || 0);
            const samt = Number(itm.itm_det.samt || 0);
            const csamt = Number(itm.itm_det.csamt || 0);
            hsnB2cList.push({
              num: idx++,
              hsn_sc: hsnCode,
              desc: officialDesc,
              user_desc: userDesc,
              uqc: isService ? 'NA' : 'OTH',
              qty: isService ? 0 : 1,
              txval: txval,
              rt: Number(itm.itm_det.rt || 18),
              iamt: iamt,
              camt: camt,
              samt: samt,
              csamt: csamt
            });
          });
        });
      });
    }

    // 7. Table 13: Document Issue Details (Grouped strictly by official doc_num 1-12)
    const rawDocs = summary.tables?.table13_DocsIssued || [];
    const docGroups = new Map<number, { doc_num: number; doc_typ: string; docs: any[] }>();

    rawDocs.forEach((d: any) => {
      const tot = Number(d.totalNumber ?? d.totnum ?? 0);
      const cancel = Number(d.cancelled ?? d.cancel ?? 0);
      const fromVal = String(d.fromSerial || d.from || '').trim();
      const toVal = String(d.toSerial || d.to || fromVal).trim();
      if (tot <= 0 && !fromVal) return;

      const natureStr = String(d.docType || d.docNature || d.doc_typ || 'Invoices for outward supply');
      const natureInfo = getDocNumFromNature(natureStr);

      if (!docGroups.has(natureInfo.doc_num)) {
        docGroups.set(natureInfo.doc_num, {
          doc_num: natureInfo.doc_num,
          doc_typ: natureInfo.doc_typ,
          docs: []
        });
      }
      const group = docGroups.get(natureInfo.doc_num)!;
      const validTot = tot > 0 ? tot : 1;
      group.docs.push({
        num: group.docs.length + 1,
        from: fromVal || '1',
        to: toVal || fromVal || '1',
        totnum: validTot,
        cancel: cancel,
        net_issue: Math.max(0, validTot - cancel)
      });
    });

    const doc_det = Array.from(docGroups.values()).filter(g => g.docs.length > 0);
    const doc_issue = doc_det.length > 0 ? { doc_det } : null;

    // ROOT GSTN Request Payload (Strictly matching GST Returns Offline Tool v3.2.4)
    // NOTE: 'gt' and 'cur_gt' are omitted as per GSTN portal specification for all post-2018 periods.
    const payload: any = {
      gstin: cleanGstin,
      fp: cleanFp,
      version: 'GST3.2.4',
      hash: 'hash'
    };

    if (b2b.length > 0) payload.b2b = b2b;
    if (b2cl.length > 0) payload.b2cl = b2cl;
    if (b2cs.length > 0) payload.b2cs = b2cs;
    if (exp.length > 0) payload.exp = exp;
    if (cdnr.length > 0) payload.cdnr = cdnr;
    if (cdnurList.length > 0) payload.cdnur = cdnurList;

    // Table 12 HSN (bifurcated into hsn_b2b and hsn_b2c)
    const hsnObj: any = {};
    if (hsnB2bList.length > 0) hsnObj.hsn_b2b = hsnB2bList;
    if (hsnB2cList.length > 0) hsnObj.hsn_b2c = hsnB2cList;
    if (Object.keys(hsnObj).length > 0) {
      payload.hsn = hsnObj;
    }

    if (doc_issue && doc_issue.doc_det.length > 0) {
      payload.doc_issue = doc_issue;
    }

    return payload;
  }

  /**
   * 3-Level Validation Engine against GST Returns Offline Tool v3.2.4 Schema, Business Rules, and Table Reconciliation
   */
  public validatePayload(summary: GSTR1Summary, payload: any): GstnSchemaValidationResult {
    const level1SchemaErrors: ValidationFailure[] = [];
    const level2BusinessErrors: ValidationFailure[] = [];
    const level3ReconciliationErrors: ValidationFailure[] = [];

    // --- LEVEL 1: JSON Schema Validation ---
    if (!payload || typeof payload !== 'object') {
      level1SchemaErrors.push({
        section: 'Root Payload',
        jsonPath: '$',
        field: 'payload',
        expected: 'Object',
        actual: typeof payload,
        schemaError: 'Payload root must be an object.',
        recordIdentifier: 'ROOT'
      });
      return {
        isValid: false,
        level1SchemaErrors,
        level2BusinessErrors,
        level3ReconciliationErrors,
        reconciliation: { b2bInvoiceTaxable: 0, b2bHsnTaxable: 0, b2bDiff: 0, b2cInvoiceTaxable: 0, b2cHsnTaxable: 0, b2cDiff: 0, totalTaxLiability: 0 }
      };
    }

    // Check root properties
    if (typeof payload.gstin !== 'string' || !GSTIN_REGEX.test(payload.gstin)) {
      level1SchemaErrors.push({
        section: 'Root Payload',
        jsonPath: '$.gstin',
        field: 'gstin',
        expected: '15-character GSTIN string matching regex ^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$',
        actual: String(payload.gstin || 'undefined'),
        schemaError: 'Invalid or missing GSTIN format.',
        recordIdentifier: payload.gstin || 'N/A'
      });
    }

    if (typeof payload.fp !== 'string' || !FP_REGEX.test(payload.fp)) {
      level1SchemaErrors.push({
        section: 'Root Payload',
        jsonPath: '$.fp',
        field: 'fp',
        expected: '6-digit MMYYYY string (e.g. 102026)',
        actual: String(payload.fp || 'undefined'),
        schemaError: 'Invalid or missing return period fp format.',
        recordIdentifier: payload.fp || 'N/A'
      });
    }

    if (payload.version !== 'GST3.2.4') {
      level1SchemaErrors.push({
        section: 'Root Payload',
        jsonPath: '$.version',
        field: 'version',
        expected: 'GST3.2.4',
        actual: String(payload.version || 'missing'),
        schemaError: 'Payload must declare version "GST3.2.4" matching GST Returns Offline Tool v3.2.4.',
        recordIdentifier: 'VERSION'
      });
    }

    if (payload.hash !== 'hash') {
      level1SchemaErrors.push({
        section: 'Root Payload',
        jsonPath: '$.hash',
        field: 'hash',
        expected: 'hash',
        actual: String(payload.hash || 'missing'),
        schemaError: 'Payload must declare hash "hash" for GST portal offline upload.',
        recordIdentifier: 'HASH'
      });
    }

    // Validate b2b array & item types if present
    if (payload.b2b !== undefined) {
      if (!Array.isArray(payload.b2b) || payload.b2b.length === 0) {
        level1SchemaErrors.push({
          section: 'Table 4 (B2B)',
          jsonPath: '$.b2b',
          field: 'b2b',
          expected: 'Non-empty Array (minItems: 1)',
          actual: Array.isArray(payload.b2b) ? 'Empty Array' : typeof payload.b2b,
          schemaError: 'b2b section if provided must have at least 1 invoice.',
          recordIdentifier: 'B2B'
        });
      } else {
        payload.b2b.forEach((item: any, b2bIdx: number) => {
          if (!item.ctin || !GSTIN_REGEX.test(item.ctin)) {
            level1SchemaErrors.push({
              section: 'Table 4 (B2B)',
              jsonPath: `$.b2b[${b2bIdx}].ctin`,
              field: 'ctin',
              expected: '15-character GSTIN string',
              actual: String(item.ctin),
              schemaError: 'Invalid recipient ctin in B2B.',
              recordIdentifier: item.ctin || `b2b[${b2bIdx}]`
            });
          }
          if (!Array.isArray(item.inv) || item.inv.length === 0) {
            level1SchemaErrors.push({
              section: 'Table 4 (B2B)',
              jsonPath: `$.b2b[${b2bIdx}].inv`,
              field: 'inv',
              expected: 'Non-empty Array',
              actual: typeof item.inv,
              schemaError: 'b2b inv must be a non-empty array.',
              recordIdentifier: `b2b[${b2bIdx}]`
            });
          } else {
            item.inv.forEach((inv: any, invIdx: number) => {
              if (typeof inv.inum !== 'string' || inv.inum.trim() === '') {
                level1SchemaErrors.push({
                  section: 'Table 4 (B2B)',
                  jsonPath: `$.b2b[${b2bIdx}].inv[${invIdx}].inum`,
                  field: 'inum',
                  expected: 'string (non-empty)',
                  actual: typeof inv.inum,
                  schemaError: 'Invoice number inum is required.',
                  recordIdentifier: inv.inum || `inv[${invIdx}]`
                });
              }
              if (typeof inv.idt !== 'string' || !DATE_REGEX.test(inv.idt)) {
                level1SchemaErrors.push({
                  section: 'Table 4 (B2B)',
                  jsonPath: `$.b2b[${b2bIdx}].inv[${invIdx}].idt`,
                  field: 'idt',
                  expected: 'DD-MM-YYYY string format (e.g. 05-04-2026)',
                  actual: String(inv.idt),
                  schemaError: 'Invoice date idt must be in DD-MM-YYYY format.',
                  recordIdentifier: inv.inum || `inv[${invIdx}]`
                });
              }
              if (typeof inv.val !== 'number' || inv.val <= 0) {
                level1SchemaErrors.push({
                  section: 'Table 4 (B2B)',
                  jsonPath: `$.b2b[${b2bIdx}].inv[${invIdx}].val`,
                  field: 'val',
                  expected: 'number (> 0)',
                  actual: typeof inv.val,
                  schemaError: 'Invoice total value val must be positive.',
                  recordIdentifier: inv.inum || `inv[${invIdx}]`
                });
              }
              if (!Array.isArray(inv.itms) || inv.itms.length === 0) {
                level1SchemaErrors.push({
                  section: 'Table 4 (B2B)',
                  jsonPath: `$.b2b[${b2bIdx}].inv[${invIdx}].itms`,
                  field: 'itms',
                  expected: 'Non-empty Array',
                  actual: typeof inv.itms,
                  schemaError: 'Invoice itms must be an array.',
                  recordIdentifier: inv.inum || `inv[${invIdx}]`
                });
              } else {
                inv.itms.forEach((itm: any, itmIdx: number) => {
                  if (!itm.itm_det || typeof itm.itm_det !== 'object') {
                    level1SchemaErrors.push({
                      section: 'Table 4 (B2B)',
                      jsonPath: `$.b2b[${b2bIdx}].inv[${invIdx}].itms[${itmIdx}].itm_det`,
                      field: 'itm_det',
                      expected: 'Object',
                      actual: typeof itm.itm_det,
                      schemaError: 'itm_det object is required.',
                      recordIdentifier: inv.inum || `inv[${invIdx}]`
                    });
                  } else {
                    const det = itm.itm_det;
                    if (typeof det.rt !== 'number') {
                      level1SchemaErrors.push({
                        section: 'Table 4 (B2B)',
                        jsonPath: `$.b2b[${b2bIdx}].inv[${invIdx}].itms[${itmIdx}].itm_det.rt`,
                        field: 'rt',
                        expected: 'number',
                        actual: typeof det.rt,
                        schemaError: 'GST rate rt must be a number.',
                        recordIdentifier: inv.inum || `inv[${invIdx}]`
                      });
                    }
                    if (typeof det.txval !== 'number' || det.txval <= 0) {
                      level1SchemaErrors.push({
                        section: 'Table 4 (B2B)',
                        jsonPath: `$.b2b[${b2bIdx}].inv[${invIdx}].itms[${itmIdx}].itm_det.txval`,
                        field: 'txval',
                        expected: 'number (> 0)',
                        actual: typeof det.txval,
                        schemaError: 'Taxable value txval must be greater than 0.',
                        recordIdentifier: inv.inum || `inv[${invIdx}]`
                      });
                    }
                    // Validate disallowed extra fields that cause portal upload rejection
                    ['hsnSac', 'desc', 'uqc', 'qty'].forEach(invalidKey => {
                      if (det[invalidKey] !== undefined) {
                        level1SchemaErrors.push({
                          section: 'Table 4 (B2B)',
                          jsonPath: `$.b2b[${b2bIdx}].inv[${invIdx}].itms[${itmIdx}].itm_det.${invalidKey}`,
                          field: invalidKey,
                          expected: 'undefined (disallowed in Table 4 item detail schema)',
                          actual: String(det[invalidKey]),
                          schemaError: `Unexpected field '${invalidKey}' in B2B itm_det. Table 4 items only allow tax amount breakdown.`,
                          recordIdentifier: inv.inum || `inv[${invIdx}]`
                        });
                      }
                    });
                  }
                });
              }
            });
          }
        });
      }
    }

    // Validate b2cs array & item types if present
    if (payload.b2cs !== undefined) {
      if (!Array.isArray(payload.b2cs) || payload.b2cs.length === 0) {
        level1SchemaErrors.push({
          section: 'Table 7 (B2CS)',
          jsonPath: '$.b2cs',
          field: 'b2cs',
          expected: 'Non-empty Array',
          actual: Array.isArray(payload.b2cs) ? 'Empty Array' : typeof payload.b2cs,
          schemaError: 'b2cs section if provided must have at least 1 record.',
          recordIdentifier: 'B2CS'
        });
      } else {
        payload.b2cs.forEach((s: any, idx: number) => {
          if (!s.pos || !POS_REGEX.test(s.pos)) {
            level1SchemaErrors.push({
              section: 'Table 7 (B2CS)',
              jsonPath: `$.b2cs[${idx}].pos`,
              field: 'pos',
              expected: '2-digit POS code',
              actual: String(s.pos),
              schemaError: 'Valid 2-digit Place of Supply pos is required.',
              recordIdentifier: `b2cs[${idx}]`
            });
          }
          if (typeof s.txval !== 'number' || s.txval <= 0) {
            level1SchemaErrors.push({
              section: 'Table 7 (B2CS)',
              jsonPath: `$.b2cs[${idx}].txval`,
              field: 'txval',
              expected: 'number (> 0)',
              actual: String(s.txval),
              schemaError: 'B2CS taxable value txval must be greater than 0. Zero-value records are rejected by GST portal.',
              recordIdentifier: `b2cs[${idx}]`
            });
          }
        });
      }
    }

    // Validate HSN Table 12 (Supports both bifurcated hsn_b2b/hsn_b2c and legacy data)
    const hasOutwardSupplies = (payload.b2b && payload.b2b.length > 0) ||
                               (payload.b2cl && payload.b2cl.length > 0) ||
                               (payload.b2cs && payload.b2cs.length > 0) ||
                               (payload.exp && payload.exp.length > 0);

    const hsnB2bArr = payload.hsn?.hsn_b2b;
    const hsnB2cArr = payload.hsn?.hsn_b2c;
    const hsnDataArr = payload.hsn?.data;
    const hasHsnRecords = (Array.isArray(hsnB2bArr) && hsnB2bArr.length > 0) ||
                          (Array.isArray(hsnB2cArr) && hsnB2cArr.length > 0) ||
                          (Array.isArray(hsnDataArr) && hsnDataArr.length > 0);

    if (hasOutwardSupplies && !hasHsnRecords) {
      level1SchemaErrors.push({
        section: 'Table 12 (HSN)',
        jsonPath: '$.hsn',
        field: 'hsn',
        expected: 'Object with non-empty hsn_b2b or hsn_b2c array',
        actual: typeof payload.hsn,
        schemaError: 'HSN summary (Table 12) is mandatory when outward taxable supplies exist.',
        recordIdentifier: 'HSN'
      });
    }

    const validateHsnItems = (arr: any[], arrayName: string) => {
      if (!Array.isArray(arr)) return;
      arr.forEach((h: any, idx: number) => {
        if (typeof h.num !== 'number') {
          level1SchemaErrors.push({
            section: 'Table 12 (HSN)',
            jsonPath: `$.hsn.${arrayName}[${idx}].num`,
            field: 'num',
            expected: 'number (item serial)',
            actual: typeof h.num,
            schemaError: 'HSN item sequence number is required.',
            recordIdentifier: `hsn[${idx}]`
          });
        }
        if (typeof h.hsn_sc !== 'string' || h.hsn_sc.length < 2) {
          level1SchemaErrors.push({
            section: 'Table 12 (HSN)',
            jsonPath: `$.hsn.${arrayName}[${idx}].hsn_sc`,
            field: 'hsn_sc',
            expected: 'string (2-8 digits HSN/SAC code)',
            actual: String(h.hsn_sc),
            schemaError: 'Valid HSN code hsn_sc is required.',
            recordIdentifier: h.hsn_sc || `hsn[${idx}]`
          });
        }
        if (typeof h.uqc !== 'string' || h.uqc.trim() === '') {
          level1SchemaErrors.push({
            section: 'Table 12 (HSN)',
            jsonPath: `$.hsn.${arrayName}[${idx}].uqc`,
            field: 'uqc',
            expected: 'string (standard UQC code e.g. NA, NOS, PCS, OTH)',
            actual: String(h.uqc),
            schemaError: 'UQC code is required.',
            recordIdentifier: h.hsn_sc || `hsn[${idx}]`
          });
        }

        const isService = String(h.hsn_sc || '').startsWith('99');
        if (isService && h.uqc !== 'NA') {
          level1SchemaErrors.push({
            section: 'Table 12 (HSN)',
            jsonPath: `$.hsn.${arrayName}[${idx}].uqc`,
            field: 'uqc',
            expected: 'NA (Services starting with 99 must use UQC "NA")',
            actual: String(h.uqc),
            schemaError: 'Invalid UQC (RET191353): Services under Chapter 99 must use UQC "NA". "OTH" is rejected by GST portal with error RET191353.',
            recordIdentifier: h.hsn_sc || `hsn[${idx}]`
          });
        }
        if (isService && typeof h.qty === 'number' && h.qty !== 0) {
          level1SchemaErrors.push({
            section: 'Table 12 (HSN)',
            jsonPath: `$.hsn.${arrayName}[${idx}].qty`,
            field: 'qty',
            expected: '0 (Services with UQC "NA" must have qty 0)',
            actual: String(h.qty),
            schemaError: 'Invalid Quantity: Services under Chapter 99 with UQC "NA" must report qty as 0.',
            recordIdentifier: h.hsn_sc || `hsn[${idx}]`
          });
        }
        if (typeof h.rt !== 'number') {
          level1SchemaErrors.push({
            section: 'Table 12 (HSN)',
            jsonPath: `$.hsn.${arrayName}[${idx}].rt`,
            field: 'rt',
            expected: 'number (GST rate e.g. 18, 12, 5)',
            actual: typeof h.rt,
            schemaError: 'GST Rate rt is mandatory on each HSN summary row.',
            recordIdentifier: h.hsn_sc || `hsn[${idx}]`
          });
        }
        if (typeof h.txval !== 'number' || h.txval <= 0) {
          level1SchemaErrors.push({
            section: 'Table 12 (HSN)',
            jsonPath: `$.hsn.${arrayName}[${idx}].txval`,
            field: 'txval',
            expected: 'number (> 0)',
            actual: String(h.txval),
            schemaError: 'HSN taxable value txval must be greater than 0.',
            recordIdentifier: h.hsn_sc || `hsn[${idx}]`
          });
        }
      });
    };

    if (Array.isArray(hsnB2bArr)) validateHsnItems(hsnB2bArr, 'hsn_b2b');
    if (Array.isArray(hsnB2cArr)) validateHsnItems(hsnB2cArr, 'hsn_b2c');
    if (Array.isArray(hsnDataArr)) validateHsnItems(hsnDataArr, 'data');

    // Validate Table 13 Document Issues if present
    if (payload.doc_issue !== undefined) {
      if (!payload.doc_issue || typeof payload.doc_issue !== 'object' || !Array.isArray(payload.doc_issue.doc_det)) {
        level1SchemaErrors.push({
          section: 'Table 13 (DOCS)',
          jsonPath: '$.doc_issue.doc_det',
          field: 'doc_det',
          expected: 'Array of document category details',
          actual: typeof payload.doc_issue?.doc_det,
          schemaError: 'doc_issue must contain doc_det array.',
          recordIdentifier: 'DOC_ISSUE'
        });
      } else {
        payload.doc_issue.doc_det.forEach((grp: any, gIdx: number) => {
          if (typeof grp.doc_num !== 'number' || grp.doc_num < 1 || grp.doc_num > 12) {
            level1SchemaErrors.push({
              section: 'Table 13 (DOCS)',
              jsonPath: `$.doc_issue.doc_det[${gIdx}].doc_num`,
              field: 'doc_num',
              expected: 'number (1-12)',
              actual: String(grp.doc_num),
              schemaError: 'doc_num must be a valid document category code (1 to 12).',
              recordIdentifier: `doc_det[${gIdx}]`
            });
          }
          if (typeof grp.doc_typ !== 'string' || grp.doc_typ.trim() === '') {
            level1SchemaErrors.push({
              section: 'Table 13 (DOCS)',
              jsonPath: `$.doc_issue.doc_det[${gIdx}].doc_typ`,
              field: 'doc_typ',
              expected: 'string (official document nature string)',
              actual: String(grp.doc_typ),
              schemaError: 'doc_typ is required for each document category in Table 13.',
              recordIdentifier: `doc_det[${gIdx}]`
            });
          }
          if (!Array.isArray(grp.docs) || grp.docs.length === 0) {
            level1SchemaErrors.push({
              section: 'Table 13 (DOCS)',
              jsonPath: `$.doc_issue.doc_det[${gIdx}].docs`,
              field: 'docs',
              expected: 'Non-empty Array of document series',
              actual: typeof grp.docs,
              schemaError: 'docs array must contain at least 1 document series.',
              recordIdentifier: `doc_det[${gIdx}]`
            });
          }
        });
      }
    }

    // --- LEVEL 2: GSTR-1 Business Validation ---
    const b2bInvoices = summary.tables?.table4_B2B || [];
    b2bInvoices.forEach((inv: any, idx: number) => {
      if (inv.taxableValue < 0) {
        level2BusinessErrors.push({
          section: 'Table 4 (B2B Business)',
          jsonPath: `$.b2b[?].inv[${idx}].itms[0].itm_det.txval`,
          field: 'txval',
          expected: '>= 0',
          actual: String(inv.taxableValue),
          schemaError: 'Taxable value cannot be negative.',
          recordIdentifier: inv.invoiceNumber || `B2B-${idx}`
        });
      }
    });

    // --- LEVEL 3: Table Reconciliation ---
    const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
    let b2bInvoiceTaxable = 0;
    (payload.b2b || []).forEach((b: any) => {
      (b.inv || []).forEach((inv: any) => {
        (inv.itms || []).forEach((itm: any) => {
          b2bInvoiceTaxable += Number(itm.itm_det?.txval || 0);
        });
      });
    });
    b2bInvoiceTaxable = round2(b2bInvoiceTaxable);

    let b2bHsnTaxable = 0;
    (hsnB2bArr || []).forEach((h: any) => {
      b2bHsnTaxable += Number(h.txval || 0);
    });
    b2bHsnTaxable = round2(b2bHsnTaxable);
    const b2bDiff = round2(b2bInvoiceTaxable - b2bHsnTaxable);

    let b2cInvoiceTaxable = 0;
    (payload.b2cs || []).forEach((s: any) => {
      b2cInvoiceTaxable += Number(s.txval || 0);
    });
    (payload.b2cl || []).forEach((b: any) => {
      (b.inv || []).forEach((inv: any) => {
        (inv.itms || []).forEach((itm: any) => {
          b2cInvoiceTaxable += Number(itm.itm_det?.txval || 0);
        });
      });
    });
    (payload.exp || []).forEach((e: any) => {
      (e.inv || []).forEach((inv: any) => {
        (inv.itms || []).forEach((itm: any) => {
          b2cInvoiceTaxable += Number(itm.itm_det?.txval || 0);
        });
      });
    });
    b2cInvoiceTaxable = round2(b2cInvoiceTaxable);

    let b2cHsnTaxable = 0;
    (hsnB2cArr || []).forEach((h: any) => {
      b2cHsnTaxable += Number(h.txval || 0);
    });
    b2cHsnTaxable = round2(b2cHsnTaxable);
    const b2cDiff = round2(b2cInvoiceTaxable - b2cHsnTaxable);

    if (Math.abs(b2bDiff) > 1.0 && (b2bInvoiceTaxable > 0 || b2bHsnTaxable > 0)) {
      level3ReconciliationErrors.push({
        section: 'Table 12 Reconciliation (B2B)',
        jsonPath: '$.hsn.hsn_b2b[*].txval',
        field: 'txval',
        expected: String(b2bInvoiceTaxable),
        actual: String(b2bHsnTaxable),
        schemaError: `B2B HSN summary taxable total (${b2bHsnTaxable}) does not reconcile with B2B invoice taxable total (${b2bInvoiceTaxable}). Difference: ${b2bDiff}`,
        recordIdentifier: 'RECON_B2B'
      });
    }

    if (Math.abs(b2cDiff) > 1.0 && (b2cInvoiceTaxable > 0 || b2cHsnTaxable > 0)) {
      level3ReconciliationErrors.push({
        section: 'Table 12 Reconciliation (B2C)',
        jsonPath: '$.hsn.hsn_b2c[*].txval',
        field: 'txval',
        expected: String(b2cInvoiceTaxable),
        actual: String(b2cHsnTaxable),
        schemaError: `B2C HSN summary taxable total (${b2cHsnTaxable}) does not reconcile with B2C invoice taxable total (${b2cInvoiceTaxable}). Difference: ${b2cDiff}`,
        recordIdentifier: 'RECON_B2C'
      });
    }

    const totalErrors = level1SchemaErrors.length + level2BusinessErrors.length + level3ReconciliationErrors.length;

    return {
      isValid: totalErrors === 0,
      level1SchemaErrors,
      level2BusinessErrors,
      level3ReconciliationErrors,
      reconciliation: {
        b2bInvoiceTaxable,
        b2bHsnTaxable,
        b2bDiff,
        b2cInvoiceTaxable,
        b2cHsnTaxable,
        b2cDiff,
        totalTaxLiability: summary.totalTaxLiability || 0
      }
    };
  }

  /**
   * Generates Developer Validation Report in JSON string format
   */
  public generateValidationReport(summary: GSTR1Summary): string {
    const payload = this.serializeToGstnPayload(summary);
    const result = this.validatePayload(summary, payload);
    return JSON.stringify(
      {
        timestamp: new Date().toISOString(),
        gstin: summary.gstin,
        period: summary.period,
        isValid: result.isValid,
        summaryReconciliation: result.reconciliation,
        failures: {
          level1_jsonSchema: result.level1SchemaErrors,
          level2_businessValidation: result.level2BusinessErrors,
          level3_tableReconciliation: result.level3ReconciliationErrors
        }
      },
      null,
      2
    );
  }
}

export const gstnSchemaEngine = new GstnSchemaEngine();
