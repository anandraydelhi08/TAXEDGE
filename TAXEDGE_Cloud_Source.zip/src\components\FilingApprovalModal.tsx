import React, { useState } from 'react';
import { ShieldCheck, AlertTriangle, Send, X, Lock, FileCheck2, CheckCircle2 } from 'lucide-react';
import { GSTR1Summary, GSTR3BSummary } from '../types/gst';
import { formatINR } from '../utils/taxMath';
import { ClientMaster } from '../types/client';

interface FilingApprovalModalProps {
  isOpen: boolean;
  onClose: () => void;
  gstr1: GSTR1Summary;
  gstr3b: GSTR3BSummary;
  criticalExceptionsCount: number;
  currentClient?: ClientMaster | null;
  currentGstin?: string;
  onConfirmFiling: (authData: { signatory: string; method: 'EVC_OTP' | 'DSC'; otp?: string }) => void;
  isFilingInProgress: boolean;
}

export const FilingApprovalModal: React.FC<FilingApprovalModalProps> = ({
  isOpen,
  onClose,
  gstr1,
  gstr3b,
  criticalExceptionsCount,
  currentClient,
  currentGstin,
  onConfirmFiling,
  isFilingInProgress
}) => {
  const [signatory, setSignatory] = useState('Anand Ray (Director & Authorized Signatory)');
  const [authMethod, setAuthMethod] = useState<'EVC_OTP' | 'DSC'>('EVC_OTP');
  const [evcOtp, setEvcOtp] = useState('892041');
  const [declarationAccepted, setDeclarationAccepted] = useState(false);

  if (!isOpen) return null;

  const totalCash = gstr3b.table6_1_PaymentOfTax.totalCashPayable;

  const handleApprove = (e: React.FormEvent) => {
    e.preventDefault();
    if (!declarationAccepted) return;
    onConfirmFiling({
      signatory,
      method: authMethod,
      otp: evcOtp
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-white border border-[#E5E7EB] rounded-3xl w-full max-w-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-slate-900 to-slate-800 border-b border-[#E5E7EB] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#176B4D]/20 text-[#176B4D] flex items-center justify-center border border-[#176B4D]/30">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Mandatory Human Review & Return Filing Approval
              </h2>
              <p className="text-xs text-[#6B7280]">
                Statutory verification required under GST Rules • AI cannot file independently
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-[#6B7280] hover:text-white transition">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs">
          {/* Prominent Sandbox Notice */}
          <div className="bg-[#FFF8E1] text-[#B7791F] border border-amber-500/30 rounded-xl p-3.5 text-[#B7791F] flex items-start gap-2.5">
            <AlertTriangle className="w-4 h-4 text-[#B7791F] shrink-0 mt-0.5" />
            <div>
              <strong className="block text-amber-200">
                TEST MODE — NO ACTUAL GST RETURN HAS BEEN FILED.
              </strong>
              This action will transmit the validated return payload to the authorized GST Sandbox Gateway and issue a simulated ARN acknowledgement.
            </div>
          </div>

          {/* Critical Exception Warning */}
          {criticalExceptionsCount > 0 && (
            <div className="bg-rose-950/40 border border-rose-800 rounded-xl p-3.5 text-rose-300 flex items-center gap-2.5">
              <AlertTriangle className="w-5 h-5 text-[#C62828] shrink-0" />
              <div>
                <strong>Cannot File: {criticalExceptionsCount} Critical Exception(s) Pending.</strong>
                <p className="text-[11px] text-[#C62828] mt-0.5">Please resolve arithmetic or GSTIN errors in Exception Center before filing.</p>
              </div>
            </div>
          )}

          {/* Entity & Period Details */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 bg-[#FFFFFF] rounded-xl border border-[#E5E7EB]">
            <div>
              <div className="text-[10px] text-[#6B7280] uppercase font-semibold">Entity Legal Name</div>
              <div className="font-semibold text-white truncate">{currentClient?.legalName || currentClient?.name || 'Registered Client'}</div>
            </div>
            <div>
              <div className="text-[10px] text-[#6B7280] uppercase font-semibold">GSTIN</div>
              <div className="font-mono text-[#176B4D] font-semibold">{currentGstin || currentClient?.primaryGstin || '—'}</div>
            </div>
            <div>
              <div className="text-[10px] text-[#6B7280] uppercase font-semibold">Return Period</div>
              <div className="font-semibold text-white">April 2026</div>
            </div>
            <div>
              <div className="text-[10px] text-[#6B7280] uppercase font-semibold">Jurisdiction</div>
              <div className="text-[#6B7280]">{currentClient?.state || 'Maharashtra'}</div>
            </div>
          </div>

          {/* Summary Figures Comparison */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* GSTR-1 Outward Summary */}
            <div className="p-4 rounded-2xl bg-[#F8F9FA] border border-[#E5E7EB] space-y-2">
              <div className="flex items-center justify-between border-b border-[#E5E7EB] pb-2">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <FileCheck2 className="w-4 h-4 text-[#176B4D]" /> GSTR-1 Statement
                </span>
                <span className="text-[10px] text-[#176B4D] bg-[#E8F5EF] px-2 py-0.5 rounded font-mono">
                  {gstr1.period}
                </span>
              </div>
              <div className="flex justify-between text-[#6B7280]">
                <span>Gross Outward Turnover:</span>
                <span className="font-mono font-bold text-white">{formatINR(gstr1.grossTurnover)}</span>
              </div>
              <div className="flex justify-between text-[#6B7280]">
                <span>Total Tax Liability:</span>
                <span className="font-mono font-bold text-[#176B4D]">{formatINR(gstr1.totalTaxLiability)}</span>
              </div>
              <div className="flex justify-between text-[#6B7280] text-[11px]">
                <span>Invoices Count:</span>
                <span>{gstr1.b2bCount} B2B • {gstr1.exportsCount} Export • {gstr1.b2csCount} B2C</span>
              </div>
            </div>

            {/* GSTR-3B Tax Summary */}
            <div className="p-4 rounded-2xl bg-[#F8F9FA] border border-[#E5E7EB] space-y-2">
              <div className="flex items-center justify-between border-b border-[#E5E7EB] pb-2">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <FileCheck2 className="w-4 h-4 text-[#176B4D]" /> GSTR-3B Return
                </span>
                <span className="text-[10px] text-[#176B4D] bg-[#E8F5EF] px-2 py-0.5 rounded font-mono">
                  {gstr3b.period}
                </span>
              </div>
              <div className="flex justify-between text-[#6B7280]">
                <span>Eligible ITC Utilised:</span>
                <span className="font-mono font-bold text-[#6B7280]">
                  {formatINR(
                    gstr3b.table4_ITC.netITCAvailable.igst +
                    gstr3b.table4_ITC.netITCAvailable.cgst +
                    gstr3b.table4_ITC.netITCAvailable.sgst
                  )}
                </span>
              </div>
              <div className="flex justify-between text-[#6B7280]">
                <span>Inward RCM Cash Liability:</span>
                <span className="font-mono font-bold text-purple-300">
                  {formatINR(gstr3b.table3_1.inwardRCM.igst + gstr3b.table3_1.inwardRCM.cgst + gstr3b.table3_1.inwardRCM.sgst)}
                </span>
              </div>
              <div className="flex justify-between text-[#B7791F] font-bold border-t border-[#E5E7EB] pt-1">
                <span>Total Cash Payable:</span>
                <span className="font-mono text-sm">{formatINR(totalCash)}</span>
              </div>
            </div>
          </div>

          {/* Form and Verification Oath */}
          <form onSubmit={handleApprove} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-[#6B7280] block mb-1">Authorized Signatory Name</label>
                <input
                  type="text"
                  required
                  value={signatory}
                  onChange={e => setSignatory(e.target.value)}
                  className="w-full bg-[#F8F9FA] border border-[#E5E7EB] rounded-lg px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="text-[#6B7280] block mb-1">Authentication Method</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setAuthMethod('EVC_OTP')}
                    className={`py-2 px-3 rounded-lg border text-center font-medium transition ${
                      authMethod === 'EVC_OTP' ? 'bg-[#176B4D]/20 border-[#176B4D]/30 text-[#176B4D]' : 'bg-[#F8F9FA] border-[#E5E7EB] text-[#6B7280]'
                    }`}
                  >
                    EVC (OTP)
                  </button>
                  <button
                    type="button"
                    onClick={() => setAuthMethod('DSC')}
                    className={`py-2 px-3 rounded-lg border text-center font-medium transition ${
                      authMethod === 'DSC' ? 'bg-[#176B4D]/20 border-[#176B4D]/30 text-[#176B4D]' : 'bg-[#F8F9FA] border-[#E5E7EB] text-[#6B7280]'
                    }`}
                  >
                    DSC Token
                  </button>
                </div>
              </div>
            </div>

            {authMethod === 'EVC_OTP' && (
              <div>
                <label className="text-[#6B7280] block mb-1">Simulated EVC One-Time Password (OTP)</label>
                <input
                  type="text"
                  required
                  value={evcOtp}
                  onChange={e => setEvcOtp(e.target.value)}
                  placeholder="Enter 6-digit EVC OTP"
                  className="w-full bg-[#F8F9FA] border border-[#E5E7EB] rounded-lg px-3 py-2 text-white font-mono tracking-widest text-center text-sm"
                />
              </div>
            )}

            {/* Legal Oath Checkbox */}
            <div className="p-4 rounded-xl bg-[#FFFFFF] border border-[#E5E7EB] flex items-start gap-3">
              <input
                type="checkbox"
                id="declaration"
                checked={declarationAccepted}
                onChange={e => setDeclarationAccepted(e.target.checked)}
                className="mt-0.5 rounded border-[#E5E7EB] text-emerald-500 focus:ring-emerald-500"
              />
              <label htmlFor="declaration" className="text-[#6B7280] text-[11px] leading-relaxed cursor-pointer select-none">
                <strong>Statutory Declaration:</strong> I hereby solemnly affirm and declare that the information given herein above in Form GSTR-1 and Form GSTR-3B for the tax period April 2026 is true and correct to the best of my knowledge and belief, and that nothing has been concealed therefrom.
              </label>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-[#F8F9FA] hover:bg-slate-700 text-[#6B7280] font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!declarationAccepted || criticalExceptionsCount > 0 || isFilingInProgress}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-slate-400 hover:from-emerald-400 hover:to-slate-300 disabled:opacity-40 disabled:cursor-not-allowed text-slate-950 font-bold shadow-lg shadow-emerald-950/40 transition flex items-center gap-2"
              >
                <Lock className="w-4 h-4" />
                <span>{isFilingInProgress ? 'Transmitting to GSTN...' : 'Approve & Submit to GST Portal'}</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
