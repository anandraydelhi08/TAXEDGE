import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Suppress harmless Vite HMR WebSocket errors in preview environment
window.addEventListener('error', (event) => {
  if (event.message && (event.message.includes("reading 'send'") || event.message.includes("send was called before connect"))) {
    event.preventDefault();
    event.stopPropagation();
  }
});

window.addEventListener('unhandledrejection', (event) => {
  if (event.reason && (String(event.reason).includes("reading 'send'") || String(event.reason).includes("send was called before connect"))) {
    event.preventDefault();
  }
});

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
