/**
 * Production Full-Stack Server
 * Hosts API endpoints for Gemini AI and serves static frontend build
 */

import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { handleGeminiChat } from './server/geminiHandler';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// Health check endpoint for Cloud Run
app.get('/health', (req, res) => {
  res.status(200).send('OK');
});

// API route for AI GST Expert Assistant
app.post('/api/gemini/chat', async (req, res) => {
  try {
    const result = await handleGeminiChat(req.body);
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Internal error processing GST legal query.' });
  }
});

// APK Download Endpoints for Android
app.get(['/api/download/gst-practice-ai.apk', '/GST-Practice-AI.apk', '/download/apk'], (req, res) => {
  const publicApk = path.resolve(__dirname, 'public', 'GST-Practice-AI.apk');
  const distApk = path.resolve(__dirname, 'dist', 'GST-Practice-AI.apk');
  const apkPath = fs.existsSync(publicApk) ? publicApk : fs.existsSync(distApk) ? distApk : null;

  if (apkPath) {
    res.setHeader('Content-Type', 'application/vnd.android.package-archive');
    res.setHeader('Content-Disposition', 'attachment; filename="GST-Practice-AI.apk"');
    return res.sendFile(apkPath);
  }
  res.status(404).send('APK file is compiling. Please refresh in a moment.');
});

// ZIP Download Endpoints for Project Source & Offline Setup
app.get(['/api/download/gst-practice-ai.zip', '/GST-Practice-AI.zip', '/download-zip', '/download/zip'], (req, res) => {
  const rootZip = path.resolve(__dirname, 'GST_Practice_AI.zip');
  const distZip = path.resolve(__dirname, 'dist', 'GST_Practice_AI.zip');
  const publicZip = path.resolve(__dirname, 'public', 'GST_Practice_AI.zip');
  const zipPath = fs.existsSync(rootZip) ? rootZip : fs.existsSync(distZip) ? distZip : fs.existsSync(publicZip) ? publicZip : null;

  if (zipPath) {
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="GST_Practice_AI.zip"');
    return res.sendFile(zipPath);
  }
  res.status(404).send('ZIP file is being prepared. Please refresh in a moment.');
});

// Official Government WEB_GST_Template & TAXEDGE Template Download Endpoints (.xls and .xlsx)
app.get(['/api/download/template', '/WEB_GST_Template.xls', '/WEB_GST_Template.xlsx', '/TAXEDGE_GST_TEMPLATE.xlsx', '/TAXEDGE_GST_Template.xlsx'], (req, res) => {
  const isXlsx = req.path.toLowerCase().endsWith('.xlsx');
  const filename = req.path.toLowerCase().includes('taxedge') ? 'TAXEDGE_GST_TEMPLATE.xlsx' : (isXlsx ? 'WEB_GST_Template.xlsx' : 'WEB_GST_Template.xls');
  const pubPath = path.resolve(__dirname, 'public', filename);
  const dstPath = path.resolve(__dirname, 'dist', filename);
  const fallback = path.resolve(__dirname, 'public', 'WEB_GST_Template.xls');
  const target = fs.existsSync(pubPath) ? pubPath : fs.existsSync(dstPath) ? dstPath : fallback;

  if (fs.existsSync(target)) {
    res.setHeader('Content-Type', isXlsx ? 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' : 'application/vnd.ms-excel');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    return res.sendFile(target);
  }
  res.status(404).send('Template file not found.');
});

// Dedicated APK Download Portal Page
app.get(['/apk', '/download', '/download-apk'], (req, res) => {
  const apkHtml = path.resolve(__dirname, 'public', 'apk.html');
  if (fs.existsSync(apkHtml)) {
    return res.sendFile(apkHtml);
  }
  res.redirect('/GST-Practice-AI.apk');
});

const publicPath = path.resolve(__dirname, 'public');
if (fs.existsSync(publicPath)) {
  app.use(express.static(publicPath));
}

// Serve frontend assets
const distPath = path.resolve(__dirname, 'dist');
if (fs.existsSync(distPath)) {
  app.use(express.static(distPath, {
    setHeaders: (res, filePath) => {
      if (filePath.endsWith('index.html') || filePath.endsWith('sw.js') || filePath.endsWith('registerSW.js')) {
        res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      }
    }
  }));
}

app.get('*', (req, res) => {
  const indexPath = path.join(distPath, 'index.html');
  if (fs.existsSync(indexPath)) {
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.sendFile(indexPath);
  } else {
    res.status(200).send('GST Practice AI is initializing. Please refresh in a moment.');
  }
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`GST Expert AI Platform running on port ${PORT} (0.0.0.0)`);
});
