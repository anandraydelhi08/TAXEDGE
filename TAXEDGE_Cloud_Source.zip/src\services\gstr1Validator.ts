import { GSTR1Summary } from '../types/gst';
import { gstnSchemaEngine, ValidationFailure } from './gstnSchemaEngine';

export interface Gstr1ValidationError {
  section: string;
  invoiceNumber: string;
  field: string;
  error: string;
  requiredFormat: string;
  suggestedFix: string;
  jsonPath?: string;
  expected?: string;
  actual?: string;
}

export interface Gstr1ValidationResult {
  isValid: boolean;
  errors: Gstr1ValidationError[];
  warningCount: number;
  reconciliation: {
    b2bInvoiceTaxable: number;
    b2bHsnTaxable: number;
    b2bDiff: number;
    b2cInvoiceTaxable: number;
    b2cHsnTaxable: number;
    b2cDiff: number;
  };
}

export class Gstr1Validator {
  public validate(summary: GSTR1Summary): Gstr1ValidationResult {
    const payload = gstnSchemaEngine.serializeToGstnPayload(summary);
    const engineResult = gstnSchemaEngine.validatePayload(summary, payload);

    const allFailures: ValidationFailure[] = [
      ...engineResult.level1SchemaErrors,
      ...engineResult.level2BusinessErrors,
      ...engineResult.level3ReconciliationErrors
    ];

    const errors: Gstr1ValidationError[] = allFailures.map((f) => ({
      section: f.section,
      invoiceNumber: f.recordIdentifier,
      field: f.field,
      error: f.schemaError,
      requiredFormat: f.expected,
      suggestedFix: `Actual: ${f.actual} (Path: ${f.jsonPath})`,
      jsonPath: f.jsonPath,
      expected: f.expected,
      actual: f.actual
    }));

    return {
      isValid: engineResult.isValid,
      errors,
      warningCount: 0,
      reconciliation: {
        b2bInvoiceTaxable: engineResult.reconciliation.b2bInvoiceTaxable,
        b2bHsnTaxable: engineResult.reconciliation.b2bHsnTaxable,
        b2bDiff: engineResult.reconciliation.b2bDiff,
        b2cInvoiceTaxable: engineResult.reconciliation.b2cInvoiceTaxable,
        b2cHsnTaxable: engineResult.reconciliation.b2cHsnTaxable,
        b2cDiff: engineResult.reconciliation.b2cDiff
      }
    };
  }
}

export const gstr1Validator = new Gstr1Validator();
