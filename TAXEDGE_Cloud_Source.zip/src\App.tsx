/**
 * GST Practice AI — Multi-Client CA Practice Platform
 * Architecture: CA Firm Hub + Multi-Client Database + Secure Vault + 5-Level 2B Auto-Reconciliation
 * Grounded in ICAI "GST Act(s) and Rule(s) - Bare Law (April 2026 Edition)"
 */

import React, { useState, useMemo, useEffect, useCallback, useRef } from 'react';
import { Header } from './components/Header';
import { Sidebar, NavTab } from './components/Sidebar';
import { AdminPanelView } from './components/AdminPanelView';
import { ClientPracticeDashboard } from './components/ClientPracticeDashboard';
import { ClientMasterView } from './components/ClientMasterView';
import { CredentialVaultModal } from './components/CredentialVaultModal';
import { JobQueueModal } from './components/JobQueueModal';
import { DemoConfirmationModal } from './components/DemoConfirmationModal';

import { DashboardView } from './components/DashboardView';
import { SalesRegisterView } from './components/SalesRegisterView';
import { PurchaseRegisterView } from './components/PurchaseRegisterView';
import { ReconciliationView } from './components/ReconciliationView';
import { ITCEngineView } from './components/ITCEngineView';
import { RCMEngineView } from './components/RCMEngineView';
import { GSTR1View } from './components/GSTR1View';
import { GSTR3BView } from './components/GSTR3BView';
import { ECommerceView } from './components/ECommerceView';
import { BareLawBrowserView } from './components/BareLawBrowserView';
import { ExceptionCenterView } from './components/ExceptionCenterView';
import { FilingView } from './components/FilingView';
import { TestSuiteView } from './components/TestSuiteView';
import { AuditTrailView } from './components/AuditTrailView';
import { FilingApprovalModal } from './components/FilingApprovalModal';
import { AIAssistantDrawer } from './components/AIAssistantDrawer';
import { OcrUploadModal } from './components/OcrUploadModal';
import { DataManagementModal } from './components/DataManagementModal';
import { SalesImportSuccessBanner } from './components/SalesImportSuccessBanner';
import { Gstr1UploadModal } from './components/Gstr1UploadModal';
import { AndroidApkModal } from './components/AndroidApkModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import {
  Smartphone,
  Download,
  X as CloseIcon,
  ExternalLink,
  ArrowUpRight,
  ArrowDownLeft,
  GitCompare,
  FileCheck2,
  FileSpreadsheet,
  Sliders
} from 'lucide-react';

import { TransactionInvoice, GSTR2BRecord, AuditLog, ComplianceException } from './types/gst';
import { ClientMaster, GSTINMasterEntry } from './types/client';
import { clientStorageService } from './services/clientStorageService';
import { credentialVaultService } from './services/credentialVaultService';
import { gstProvider } from './services/gstProvider';
import { jobQueueService } from './services/jobQueueService';
import { gstr1Engine } from './services/gstr1Engine';
import { gstr3bEngine } from './services/gstr3bEngine';
import { reconciliationEngine } from './services/reconciliationEngine';
import { exceptionEngine } from './services/exceptionEngine';
import { calculateFilingReadiness } from './services/filingService';
import { computeReturnPeriod } from './services/returnPeriodService';
import { INITIAL_ECOMMERCE_REPORTS } from './data/masterData';
import { adminSettingsService, PracticeSettings } from './services/adminSettingsService';

export default function App() {
  // Navigation: Default to CA Practice Hub
  const [activeTab, setActiveTab] = useState<NavTab>('practice');
  const [firmSettings, setFirmSettings] = useState<PracticeSettings>(() => adminSettingsService.getSettings());

  // Multi-Client Practice Database
  const [clients, setClients] = useState<ClientMaster[]>(() => clientStorageService.getClients());
  const [gstins, setGstins] = useState<GSTINMasterEntry[]>(() => clientStorageService.getAllGstins());
  const [isDemoMode, setIsDemoMode] = useState<boolean>(() => clientStorageService.isDemoModeActive());

  // Prevent reactive loadClientWorkspace from wiping newly imported sales during import
  const isImportingRef = useRef(false);

  // Currently Selected Client & Active GSTIN (clean empty defaults if zero clients)
  const [selectedClientId, setSelectedClientId] = useState<string>(() => {
    const initClients = clientStorageService.getClients();
    return initClients.length > 0 ? initClients[0].id : '';
  });
  const [selectedGstin, setSelectedGstin] = useState<string>(() => {
    const initClients = clientStorageService.getClients();
    return initClients.length > 0 && initClients[0].primaryGstin ? initClients[0].primaryGstin : '';
  });

  // Client-isolated state
  const [sales, setSales] = useState<TransactionInvoice[]>([]);
  const [purchases, setPurchases] = useState<TransactionInvoice[]>([]);
  const [gstr2b, setGstr2b] = useState<GSTR2BRecord[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [filingResult, setFilingResult] = useState<any>(null);
  const [resolvedExceptionIds, setResolvedExceptionIds] = useState<Set<string>>(new Set());
  const [ecommerceReports] = useState(INITIAL_ECOMMERCE_REPORTS);

  // Modals & Drawers
  const [isAiOpen, setIsAiOpen] = useState(false);
  const [aiPrompt, setAiPrompt] = useState<string | undefined>(undefined);
  const [isOcrOpen, setIsOcrOpen] = useState(false);
  const [isApprovalModalOpen, setIsApprovalModalOpen] = useState(false);
  const [isFilingInProgress, setIsFilingInProgress] = useState(false);
  const [isDataModalOpen, setIsDataModalOpen] = useState(false);
  const [dataModalTarget, setDataModalTarget] = useState<'SALES' | 'PURCHASES' | 'GSTR2B'>('SALES');
  const [isDemoConfirmOpen, setIsDemoConfirmOpen] = useState(false);

  // GST Return Period Selection (FY & Month)
  const [selectedFy, setSelectedFy] = useState<string>('2026-27');
  const [selectedMonth, setSelectedMonth] = useState<string>('October');

  // Mobile Navigation Menu State
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Android APK & PWA Modal State
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);
  const [isApkBannerDismissed, setIsApkBannerDismissed] = useState(false);

  // GSTR-1 Direct Upload Modal & Imported Sales Feedback State
  const [isGstr1UploadModalOpen, setIsGstr1UploadModalOpen] = useState(false);
  const [lastImportedSalesSummary, setLastImportedSalesSummary] = useState<{
    financialYear: string;
    month: string;
    totalInvoices: number;
    totalTaxableValue: number;
    totalGst: number;
  } | null>(null);

  // CA Specific Modals
  const [isVaultModalOpen, setIsVaultModalOpen] = useState(false);
  const [vaultTargetGstin, setVaultTargetGstin] = useState<string | undefined>(undefined);
  const [isJobQueueModalOpen, setIsJobQueueModalOpen] = useState(false);

  // Direct 2B Sync State
  const [isFetchingDirect2B, setIsFetchingDirect2B] = useState(false);
  const [direct2bMeta, setDirect2bMeta] = useState<{
    generationDate: string;
    source: string;
    lastSynced: string;
    totalInvoices: number;
    totalTaxable: number;
    totalTax: number;
  } | undefined>(undefined);

  // Current client object (null if no clients)
  const currentClient = useMemo<ClientMaster | null>(() => {
    if (clients.length === 0) return null;
    return clients.find(c => c.id === selectedClientId) || clients[0] || null;
  }, [clients, selectedClientId]);

  // Keep selectedGstin in sync if client changes
  useEffect(() => {
    if (currentClient && (!selectedGstin || !clients.some(c => c.primaryGstin === selectedGstin || c.additionalGstins.includes(selectedGstin)))) {
      setSelectedGstin(currentClient.primaryGstin);
    }
  }, [currentClient, selectedGstin, clients]);

  // GST Return Period details for currently active FY & Month
  const currentReturnPeriod = useMemo(() => {
    return computeReturnPeriod(selectedFy, selectedMonth);
  }, [selectedFy, selectedMonth]);

  const activePeriodKey = useMemo(() => {
    return currentReturnPeriod ? `${currentReturnPeriod.monthNumber}-${currentReturnPeriod.year}` : '10-2026';
  }, [currentReturnPeriod]);

  // Load client-isolated data when selected client, GSTIN, or return period changes
  const loadClientWorkspace = useCallback((cId: string, gstin: string, periodKey: string = activePeriodKey) => {
    if (!cId || !gstin) {
      setSales([]);
      setPurchases([]);
      setGstr2b([]);
      setAuditLogs([]);
      setFilingResult(null);
      setResolvedExceptionIds(new Set());
      setDirect2bMeta(undefined);
      return;
    }

    const data = clientStorageService.getClientData(cId, gstin, periodKey);
    setSales(data.sales || []);
    setPurchases(data.purchases || []);
    setGstr2b(data.gstr2b || []);
    setAuditLogs(data.auditLogs || []);
    setFilingResult(data.filingResult || null);
    setResolvedExceptionIds(new Set());
    setDirect2bMeta(
      data.gstr2b && data.gstr2b.length > 0
        ? {
            generationDate: '14-10-2026 06:00 IST',
            source: 'Authorized GSP Gateway (Adaequare) via GSTN',
            lastSynced: new Date().toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata' }),
            totalInvoices: data.gstr2b.length,
            totalTaxable: data.gstr2b.reduce((s, r) => s + r.taxableValue, 0),
            totalTax: data.gstr2b.reduce((s, r) => s + (r.igst + r.cgst + r.sgst + r.cess), 0)
          }
        : undefined
    );
  }, [activePeriodKey]);

  // Save current client data
  const persistCurrentWorkspace = useCallback(() => {
    if (!selectedClientId || !selectedGstin) return;
    clientStorageService.saveClientData(selectedClientId, selectedGstin, activePeriodKey, {
      sales,
      purchases,
      gstr2b,
      auditLogs,
      filingResult
    });
  }, [selectedClientId, selectedGstin, activePeriodKey, sales, purchases, gstr2b, auditLogs, filingResult]);

  // Initial and reactive load on client, GSTIN, or return period change
  useEffect(() => {
    if (isImportingRef.current) {
      isImportingRef.current = false;
      return;
    }
    if (selectedClientId && selectedGstin) {
      loadClientWorkspace(selectedClientId, selectedGstin, activePeriodKey);
    }
  }, [selectedClientId, selectedGstin, activePeriodKey, loadClientWorkspace]);

  // Check hash or URL query for direct tab navigation like #admin or ?tab=admin
  useEffect(() => {
    const handleUrlTab = () => {
      const hash = window.location.hash.replace('#', '').toLowerCase();
      const params = new URLSearchParams(window.location.search);
      const tabParam = params.get('tab')?.toLowerCase();
      const target = hash || tabParam;
      if (target === 'admin') {
        setActiveTab('admin');
      }
    };
    handleUrlTab();
    window.addEventListener('hashchange', handleUrlTab);
    return () => window.removeEventListener('hashchange', handleUrlTab);
  }, []);

  // Save changes on data edits
  useEffect(() => {
    if (selectedClientId && selectedGstin) {
      persistCurrentWorkspace();
    }
  }, [sales, purchases, gstr2b, auditLogs, filingResult, persistCurrentWorkspace]);

  // Client & GSTIN Switcher
  const handleSelectClientAndGstin = (clientId: string, gstin: string) => {
    persistCurrentWorkspace();
    setSelectedClientId(clientId);
    setSelectedGstin(gstin);
    loadClientWorkspace(clientId, gstin, activePeriodKey);
    setActiveTab('dashboard');
  };

  // Selected Month Sales for GSTR-1 Upload & Statutory calculations
  const selectedMonthSales = useMemo(() => {
    const periodCode = currentReturnPeriod.periodCode;
    const matching = sales.filter(inv => {
      // Table 13 Document summaries always accompany the return for the active return period
      if ((inv as any).isDocSummary || inv.id?.startsWith('PORTAL-DOC')) {
        return !inv.financialYear || inv.financialYear === selectedFy;
      }
      // Table 12 HSN summaries accompany the return for the active return period
      if ((inv as any).isHsnSummary || inv.id?.startsWith('PORTAL-HSN')) {
        if (inv.financialYear && inv.returnMonth) {
          return (
            inv.financialYear === selectedFy &&
            inv.returnMonth.toLowerCase() === selectedMonth.toLowerCase()
          );
        }
        return !inv.financialYear || inv.financialYear === selectedFy;
      }
      // Table 7 B2CS summaries accompany the return for the active return period
      if ((inv as any).isB2csSummary || inv.id?.startsWith('PORTAL-B2CS')) {
        if (inv.financialYear && inv.returnMonth) {
          return (
            inv.financialYear === selectedFy &&
            inv.returnMonth.toLowerCase() === selectedMonth.toLowerCase()
          );
        }
        return !inv.financialYear || inv.financialYear === selectedFy;
      }
      if (inv.financialYear && inv.returnMonth) {
        return (
          inv.financialYear === selectedFy &&
          inv.returnMonth.toLowerCase() === selectedMonth.toLowerCase()
        );
      }
      if (inv.period) {
        return inv.period === periodCode;
      }
      if (inv.invoiceDate) {
        const parts = inv.invoiceDate.split('-');
        if (parts.length === 3) {
          const invYear = parseInt(parts[0], 10);
          const invMonth = parts[1];
          return invYear === currentReturnPeriod.year && invMonth === currentReturnPeriod.monthNumber;
        }
      }
      return false;
    });

    // Fallback: If strict period matching yielded 0, but user has sales, retain them
    if (matching.length === 0 && sales.length > 0) {
      return sales;
    }

    return matching;
  }, [sales, selectedFy, selectedMonth, currentReturnPeriod]);

  // Statutory Engines Recomputations for Active Client
  const effectiveGstin = useMemo(() => {
    if (selectedGstin && selectedGstin.trim().length === 15) return selectedGstin.trim();
    if (currentClient?.primaryGstin && currentClient.primaryGstin.trim().length === 15) return currentClient.primaryGstin.trim();
    const detectedInSales = sales.find(s => s.supplierGstin && s.supplierGstin.trim().length === 15)?.supplierGstin;
    if (detectedInSales) return detectedInSales.trim();
    if (clients.length > 0 && clients[0]?.primaryGstin && clients[0].primaryGstin.trim().length === 15) return clients[0].primaryGstin.trim();
    return '07ABFFB5922Q1Z0';
  }, [selectedGstin, currentClient, clients, sales]);

  const gstr1 = useMemo(() => {
    const invoicesToUse = selectedMonthSales.length > 0 ? selectedMonthSales : sales;
    return gstr1Engine.prepareGSTR1(
      invoicesToUse,
      currentReturnPeriod.periodCode,
      effectiveGstin,
      currentClient?.legalName ? currentClient.legalName.trim() : 'Practice Taxpayer Entity'
    );
  }, [selectedMonthSales, sales, currentReturnPeriod, effectiveGstin, currentClient]);

  const gstr3b = useMemo(() => {
    return gstr3bEngine.prepareGSTR3B(sales, purchases, gstr2b, currentReturnPeriod.periodCode, effectiveGstin);
  }, [sales, purchases, gstr2b, currentReturnPeriod, effectiveGstin]);

  // 5-Level Automatic Reconciliation
  const reconciliation = useMemo(() => {
    return reconciliationEngine.reconcilePurchaseVs2B(purchases, gstr2b);
  }, [purchases, gstr2b]);

  // Raw Exceptions & Resolved Exceptions
  const rawExceptions = useMemo(() => {
    return exceptionEngine.scanExceptions(sales, purchases, reconciliation.results);
  }, [sales, purchases, reconciliation.results]);

  const exceptions: ComplianceException[] = useMemo(() => {
    return rawExceptions.map(ex => ({
      ...ex,
      resolved: ex.resolved || resolvedExceptionIds.has(ex.id)
    }));
  }, [rawExceptions, resolvedExceptionIds]);

  const criticalExceptionsCount = exceptions.filter(e => e.severity === 'CRITICAL' && !e.resolved).length;

  const filingReadiness = useMemo(() => {
    return calculateFilingReadiness(
      sales.length,
      purchases.length,
      reconciliation.stats.totalMatchRatePercent,
      criticalExceptionsCount,
      true,
      true,
      filingResult !== null,
      gstr2b.length
    );
  }, [sales.length, purchases.length, reconciliation.stats.totalMatchRatePercent, criticalExceptionsCount, filingResult, gstr2b.length]);

  /**
   * DIRECT GSTR-2B IMPORT
   * Retrieves GSTR-2B directly through authorized GSTProvider and AUTOMATICALLY starts reconciliation
   */
  const handleFetchDirect2B = async () => {
    if (!selectedGstin) {
      alert('No active GSTIN selected. Please add or select a client.');
      return;
    }
    setIsFetchingDirect2B(true);
    try {
      const response = await gstProvider.getGSTR2B(selectedGstin, '04-2026');

      setGstr2b(response.records);
      setDirect2bMeta({
        generationDate: response.generationDate,
        source: response.source,
        lastSynced: response.lastSynced,
        totalInvoices: response.totalInvoices,
        totalTaxable: response.totalTaxableValue,
        totalTax: response.igst + response.cgst + response.sgst + response.cess
      });

      // Update in GSTIN Master summary
      const allGstins = clientStorageService.getAllGstins();
      const gEntry = allGstins.find(g => g.gstin === selectedGstin);
      if (gEntry) {
        gEntry.last2bSync = response.lastSynced;
        gEntry.status2B = 'RECONCILED';
        clientStorageService.updateGstin(gEntry);
        setGstins([...clientStorageService.getAllGstins()]);
      }

      // Add audit log
      setAuditLogs(prev => [
        {
          id: `log-${Date.now()}`,
          timestamp: new Date().toISOString(),
          actor: 'GST Portal Sync Agent',
          actorRole: 'GST_PROVIDER',
          businessGstin: selectedGstin,
          module: 'RECONCILIATION',
          action: 'Direct GSTR-2B Fetch & Auto-Reconciliation',
          details: `Retrieved ${response.totalInvoices} auto-drafted invoices via ${response.source}. Automatic 5-level reconciliation initiated immediately.`,
          payloadHash: `SHA256:${Date.now().toString(16)}`
        },
        ...prev
      ]);
    } catch (err: any) {
      alert(`GST Portal Error: ${err.message || 'Failed to retrieve GSTR-2B'}`);
    } finally {
      setIsFetchingDirect2B(false);
    }
  };

  /**
   * Bulk Sync for a specific client row on the Practice Dashboard
   */
  const handleSyncClientDirect2B = async (clientId: string, gstin: string) => {
    setIsFetchingDirect2B(true);
    try {
      const clientData = clientStorageService.getClientData(clientId, gstin, '04-2026');
      const response = await gstProvider.getGSTR2B(gstin, '04-2026');

      clientData.gstr2b = response.records;
      const recon = reconciliationEngine.reconcilePurchaseVs2B(clientData.purchases, response.records);
      clientStorageService.saveClientData(clientId, gstin, '04-2026', clientData);

      const allGstins = clientStorageService.getAllGstins();
      const gEntry = allGstins.find(g => g.gstin === gstin);
      if (gEntry) {
        gEntry.last2bSync = response.lastSynced;
        gEntry.eligibleItc = recon.financialSummary.eligibleItc;
        gEntry.status2B = recon.stats.reviewRequiredCount > 0 ? 'REVIEW_REQUIRED' : 'RECONCILED';
        clientStorageService.updateGstin(gEntry);
        setGstins([...clientStorageService.getAllGstins()]);
      }

      if (clientId === selectedClientId && gstin === selectedGstin) {
        loadClientWorkspace(clientId, gstin);
      }
    } catch (err: any) {
      alert(`Sync Error for ${gstin}: ${err.message}`);
    } finally {
      setIsFetchingDirect2B(false);
    }
  };

  /**
   * DEMO MODE SEPARATE LOADER (Part 2)
   * Triggered upon user confirmation in DemoConfirmationModal
   */
  const handleConfirmLoadDemo = () => {
    clientStorageService.loadDemoDataset();
    const loadedClients = clientStorageService.getClients();
    const loadedGstins = clientStorageService.getAllGstins();
    setClients([...loadedClients]);
    setGstins([...loadedGstins]);
    setIsDemoMode(true);

    if (loadedClients.length > 0) {
      setSelectedClientId(loadedClients[0].id);
      setSelectedGstin(loadedClients[0].primaryGstin);
      loadClientWorkspace(loadedClients[0].id, loadedClients[0].primaryGstin);
    }
  };

  /**
   * RESET TO EMPTY SLATE (Part 2)
   * 0 Clients, 0 GSTINs, 0 Sales, 0 Purchases, 0 GSTR-2B, 0 Reconciliation Records
   */
  const handleResetAllToEmpty = () => {
    clientStorageService.resetAllToEmpty();
    setClients([]);
    setGstins([]);
    setSelectedClientId('');
    setSelectedGstin('');
    setSales([]);
    setPurchases([]);
    setGstr2b([]);
    setAuditLogs([]);
    setResolvedExceptionIds(new Set());
    setFilingResult(null);
    setDirect2bMeta(undefined);
    setIsDemoMode(false);
    setIsDataModalOpen(false);
  };

  // Client Master CRUD Handlers
  const handleAddClient = (client: ClientMaster) => {
    clientStorageService.addClient(client);
    const updatedClients = clientStorageService.getClients();
    const updatedGstins = clientStorageService.getAllGstins();
    setClients([...updatedClients]);
    setGstins([...updatedGstins]);

    // If first client added, activate workspace immediately
    if (clients.length === 0 || !selectedClientId) {
      setSelectedClientId(client.id);
      setSelectedGstin(client.primaryGstin);
      loadClientWorkspace(client.id, client.primaryGstin);
      setActiveTab('dashboard');
    }
  };

  const handleUpdateClient = (client: ClientMaster) => {
    clientStorageService.updateClient(client);
    setClients([...clientStorageService.getClients()]);
  };

  const handleDeleteClient = (clientId: string) => {
    clientStorageService.deleteClient(clientId);
    const updated = clientStorageService.getClients();
    const updatedGstins = clientStorageService.getAllGstins();
    setClients([...updated]);
    setGstins([...updatedGstins]);
    if (selectedClientId === clientId) {
      if (updated.length > 0) {
        handleSelectClientAndGstin(updated[0].id, updated[0].primaryGstin);
      } else {
        setSelectedClientId('');
        setSelectedGstin('');
        setSales([]);
        setPurchases([]);
        setGstr2b([]);
        setDirect2bMeta(undefined);
        setAuditLogs([]);
        setFilingResult(null);
      }
    }
  };

  // Register Level Deletes with Immediate Persistence
  const handleDeleteSale = (invoiceId: string) => {
    setSales(prev => {
      const updated = prev.filter(inv => inv.id !== invoiceId);
      if (selectedClientId && selectedGstin) {
        clientStorageService.saveClientData(selectedClientId, selectedGstin, '04-2026', {
          sales: updated,
          purchases,
          gstr2b,
          auditLogs: [
            {
              id: `log-${Date.now()}`,
              timestamp: new Date().toISOString(),
              actor: 'Finance Executive',
              actorRole: 'USER',
              businessGstin: selectedGstin,
              module: 'SALES_REGISTER',
              action: 'Deleted Sales Invoice',
              details: `Deleted invoice record #${invoiceId}`,
              payloadHash: `SHA256:${Date.now().toString(16)}`
            },
            ...auditLogs
          ],
          filingResult: null
        });
      }
      return updated;
    });
    setFilingResult(null);
  };

  const handleDeletePurchase = (invoiceId: string) => {
    setPurchases(prev => {
      const updated = prev.filter(inv => inv.id !== invoiceId);
      if (selectedClientId && selectedGstin) {
        clientStorageService.saveClientData(selectedClientId, selectedGstin, '04-2026', {
          sales,
          purchases: updated,
          gstr2b,
          auditLogs: [
            {
              id: `log-${Date.now()}`,
              timestamp: new Date().toISOString(),
              actor: 'Accounts Payable',
              actorRole: 'USER',
              businessGstin: selectedGstin,
              module: 'PURCHASE_REGISTER',
              action: 'Deleted Purchase Invoice',
              details: `Deleted purchase record #${invoiceId}`,
              payloadHash: `SHA256:${Date.now().toString(16)}`
            },
            ...auditLogs
          ],
          filingResult: null
        });
      }
      return updated;
    });
    setFilingResult(null);
  };

  const handleResetToDemoData = () => {
    if (selectedClientId && selectedGstin) {
      const demo = clientStorageService.restoreDemoData(selectedClientId, selectedGstin, '04-2026');
      setSales(demo.sales);
      setPurchases(demo.purchases);
      setGstr2b(demo.gstr2b);
      setAuditLogs(demo.auditLogs);
      setResolvedExceptionIds(new Set());
      setFilingResult(null);
      setDirect2bMeta({
        generationDate: '14-04-2026 06:00 IST',
        source: 'Authorized GSP Gateway (Adaequare) via GSTN',
        lastSynced: new Date().toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata' }),
        totalInvoices: demo.gstr2b.length,
        totalTaxable: demo.gstr2b.reduce((s, r) => s + r.taxableValue, 0),
        totalTax: demo.gstr2b.reduce((s, r) => s + (r.igst + r.cgst + r.sgst + r.cess), 0)
      });
    }
  };

  const handleClearSales = () => {
    if (!selectedClientId || !selectedGstin) return;
    const updated = clientStorageService.clearSales(selectedClientId, selectedGstin, activePeriodKey);
    setSales([]);
    setFilingResult(null);
    setAuditLogs(updated.auditLogs);

    const allGstins = clientStorageService.getAllGstins();
    const gEntry = allGstins.find(g => g.gstin === selectedGstin);
    if (gEntry) {
      gEntry.taxLiability = 0;
      clientStorageService.updateGstin(gEntry);
      setGstins([...clientStorageService.getAllGstins()]);
    }
  };

  const handleClearPurchases = () => {
    if (!selectedClientId || !selectedGstin) return;
    const updated = clientStorageService.clearPurchases(selectedClientId, selectedGstin, activePeriodKey);
    setPurchases([]);
    setFilingResult(null);
    setAuditLogs(updated.auditLogs);

    const allGstins = clientStorageService.getAllGstins();
    const gEntry = allGstins.find(g => g.gstin === selectedGstin);
    if (gEntry) {
      gEntry.eligibleItc = 0;
      clientStorageService.updateGstin(gEntry);
      setGstins([...clientStorageService.getAllGstins()]);
    }
  };

  const handleClearGstr2b = () => {
    if (!selectedClientId || !selectedGstin) return;
    const updated = clientStorageService.clearGstr2b(selectedClientId, selectedGstin, activePeriodKey);
    setGstr2b([]);
    setDirect2bMeta(undefined);
    setFilingResult(null);
    setAuditLogs(updated.auditLogs);

    const allGstins = clientStorageService.getAllGstins();
    const gEntry = allGstins.find(g => g.gstin === selectedGstin);
    if (gEntry) {
      gEntry.status2B = 'NOT_IMPORTED';
      gEntry.eligibleItc = 0;
      clientStorageService.updateGstin(gEntry);
      setGstins([...clientStorageService.getAllGstins()]);
    }
  };

  // Import Handlers with Immediate Persistence
  const handleImportSales = (items: TransactionInvoice[], mode: 'REPLACE' | 'APPEND' = 'REPLACE') => {
    const periodCode = currentReturnPeriod.periodCode;

    // Detect supplier GSTIN from imported items or fallback to effectiveGstin
    const detectedGstin = items.find(i => i.supplierGstin && i.supplierGstin.trim().length === 15)?.supplierGstin;
    const targetGstin = detectedGstin || effectiveGstin || '07ABFFB5922Q1Z0';

    // Automatically tag the imported sales with the selected Financial Year + Month + Period + Supplier GSTIN
    const taggedItems = items.map(inv => ({
      ...inv,
      financialYear: selectedFy,
      returnMonth: selectedMonth,
      period: periodCode,
      supplierGstin: inv.supplierGstin && inv.supplierGstin.length === 15 ? inv.supplierGstin : targetGstin
    }));

    const cleanExistingSales = sales;

    const isDocSummaryImport = taggedItems.some((s: any) => s.isDocSummary || s.id?.startsWith('PORTAL-DOC'));
    const isHsnSummaryImport = taggedItems.some((s: any) => s.isHsnSummary || s.id?.startsWith('PORTAL-HSN') || (s.notes && s.notes.includes('HSN Template')));
    const isB2csSummaryImport = taggedItems.some((s: any) => s.isB2csSummary || s.id?.startsWith('PORTAL-B2CS'));
    let newSales: TransactionInvoice[];

    if (isDocSummaryImport) {
      // Keep real sales (B2B, B2C, HSN), replace existing doc summaries
      const nonDocSales = cleanExistingSales.filter((s: any) => !s.isDocSummary && !s.id?.startsWith('PORTAL-DOC'));
      newSales = [...nonDocSales, ...taggedItems];
    } else if (isHsnSummaryImport) {
      // Keep B2B/B2C invoices & doc summaries, replace or add HSN summaries
      const nonHsnSales = mode === 'REPLACE'
        ? cleanExistingSales.filter((s: any) => !s.isHsnSummary && !s.id?.startsWith('PORTAL-HSN') && !(s.notes && s.notes.includes('HSN Template')))
        : cleanExistingSales;
      newSales = [...nonHsnSales, ...taggedItems];
    } else if (isB2csSummaryImport) {
      // Keep B2B/HSN/doc summaries, replace or add B2CS summaries
      const nonB2csSales = mode === 'REPLACE'
        ? cleanExistingSales.filter((s: any) => !s.isB2csSummary && !s.id?.startsWith('PORTAL-B2CS'))
        : cleanExistingSales;
      newSales = [...nonB2csSales, ...taggedItems];
    } else {
      // Normal bills/invoices import (B2B, B2C, etc.): Keep any previously imported doc summaries, HSN summaries, and B2CS summaries
      const existingDocs = cleanExistingSales.filter((s: any) => s.isDocSummary || s.id?.startsWith('PORTAL-DOC'));
      const existingHsn = cleanExistingSales.filter((s: any) => s.isHsnSummary || s.id?.startsWith('PORTAL-HSN') || (s.notes && s.notes.includes('HSN Template')));
      const existingB2cs = cleanExistingSales.filter((s: any) => s.isB2csSummary || s.id?.startsWith('PORTAL-B2CS'));
      newSales = mode === 'REPLACE'
        ? [...taggedItems, ...existingDocs, ...existingHsn, ...existingB2cs]
        : [...taggedItems, ...cleanExistingSales];
    }

    // Set flag so reactive loadClientWorkspace doesn't wipe sales
    isImportingRef.current = true;

    const totalTaxable = taggedItems.reduce((acc, inv) => acc + (inv.taxableValue || 0), 0);
    const totalGst = taggedItems.reduce(
      (acc, inv) => acc + (inv.igst || 0) + (inv.cgst || 0) + (inv.sgst || 0) + (inv.cess || 0),
      0
    );

    setLastImportedSalesSummary({
      financialYear: selectedFy,
      month: selectedMonth,
      totalInvoices: taggedItems.length,
      totalTaxableValue: totalTaxable,
      totalGst: totalGst
    });

    // Save directly to storage first to ensure cache has the latest data
    if (selectedClientId && targetGstin) {
      clientStorageService.saveClientData(selectedClientId, targetGstin, activePeriodKey, {
        sales: newSales,
        purchases,
        gstr2b,
        auditLogs: [
          {
            id: `log-${Date.now()}`,
            timestamp: new Date().toISOString(),
            actor: currentClient?.assignedStaff || 'CA Rahul Sharma',
            actorRole: 'USER',
            businessGstin: targetGstin,
            module: 'SALES_REGISTER',
            action: `Imported Sales Data (${selectedMonth} ${selectedFy})`,
            details: `Imported ${taggedItems.length} records. Taxable: ₹${totalTaxable.toFixed(2)}, GST: ₹${totalGst.toFixed(2)}. Return Period: ${selectedMonth} (${selectedFy}).`,
            payloadHash: `SHA256:${Date.now().toString(16)}`
          },
          ...auditLogs
        ],
        filingResult: null
      });
    }

    if (targetGstin && targetGstin !== selectedGstin) {
      setSelectedGstin(targetGstin);
    }

    setSales(newSales);
    setFilingResult(null);
  };

  const handleImportPurchases = (items: TransactionInvoice[], mode: 'REPLACE' | 'APPEND') => {
    const newPurchases = mode === 'REPLACE' ? items : [...items, ...purchases];
    setPurchases(newPurchases);
    setFilingResult(null);
    if (selectedClientId && selectedGstin) {
      clientStorageService.saveClientData(selectedClientId, selectedGstin, activePeriodKey, {
        sales,
        purchases: newPurchases,
        gstr2b,
        auditLogs,
        filingResult: null
      });
    }
  };

  const handleImportGstr2b = (items: GSTR2BRecord[], mode: 'REPLACE' | 'APPEND') => {
    const new2b = mode === 'REPLACE' ? items : [...items, ...gstr2b];
    setGstr2b(new2b);
    setFilingResult(null);
    if (selectedClientId && selectedGstin) {
      clientStorageService.saveClientData(selectedClientId, selectedGstin, activePeriodKey, {
        sales,
        purchases,
        gstr2b: new2b,
        auditLogs,
        filingResult: null
      });
    }
  };

  // Adding single invoice records
  const handleAddSaleInvoice = (newInv: TransactionInvoice) => {
    setSales(prev => [newInv, ...prev]);
  };

  const handleAddPurchaseInvoice = (newInv: TransactionInvoice) => {
    setPurchases(prev => [newInv, ...prev]);
  };

  const handleResolveException = (id: string) => {
    setResolvedExceptionIds(prev => new Set([...prev, id]));
  };

  const handleResolveReconciliationItem = (id: string, note: string) => {
    setAuditLogs(prev => [
      {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        actor: currentClient?.assignedStaff || 'CA Rahul Sharma',
        actorRole: 'USER',
        businessGstin: selectedGstin,
        module: 'RECONCILIATION',
        action: `Reconciliation Override for ${id}`,
        details: note,
        payloadHash: `SHA256:${Date.now().toString(16)}`
      },
      ...prev
    ]);
  };

  // Final Statutory Return Submission
  const handleConfirmFiling = async (authData: { signatory: string; method: 'EVC_OTP' | 'DSC'; otp?: string }) => {
    setIsFilingInProgress(true);
    try {
      const gstr1Payload = JSON.parse(gstr1Engine.generateGSTNJsonPayload(gstr1));
      const res = await gstProvider.submitReturn({
        gstin: selectedGstin,
        period: '04-2026',
        returnType: 'GSTR3B',
        payload: { gstr1: gstr1Payload, gstr3b },
        authorizedSignatory: authData.signatory,
        authMethod: authData.method,
        evcOtp: authData.otp
      });

      setFilingResult(res);
      setIsApprovalModalOpen(false);

      // Update GSTIN Master status
      const allGstins = clientStorageService.getAllGstins();
      const gEntry = allGstins.find(g => g.gstin === selectedGstin);
      if (gEntry) {
        gEntry.status2B = 'FILED';
        clientStorageService.updateGstin(gEntry);
        setGstins([...clientStorageService.getAllGstins()]);
      }

      setAuditLogs(prev => [
        {
          id: `log-${Date.now()}`,
          timestamp: new Date().toISOString(),
          actor: authData.signatory,
          actorRole: 'USER',
          businessGstin: selectedGstin,
          module: 'FILING_GATEWAY',
          action: 'GSTR-3B & GSTR-1 Submitted to GSTN (Sandbox)',
          details: `Filed with ${authData.method}. Issued ARN: ${res.arn}`,
          payloadHash: res.hash
        },
        ...prev
      ]);
    } catch (err: any) {
      alert(`Filing error: ${err.message}`);
    } finally {
      setIsFilingInProgress(false);
    }
  };

  const handleOpenAi = (prompt?: string) => {
    setAiPrompt(prompt);
    setIsAiOpen(true);
  };

  const handleOpenDataModal = (target: 'SALES' | 'PURCHASES' | 'GSTR2B' = 'SALES') => {
    setDataModalTarget(target);
    setIsDataModalOpen(true);
  };

  const handleOpenCredentialVault = (gstin?: string) => {
    setVaultTargetGstin(gstin || selectedGstin);
    setIsVaultModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#F4F7FB] text-slate-800 flex overflow-hidden font-sans selection:bg-[#D4A24C] selection:text-slate-950">
      {/* Full-Height Dark Navy Sidebar (#0B1F44) matching Design Board */}
      <Sidebar
        activeTab={activeTab}
        onTabChange={tab => setActiveTab(tab)}
        onOpenDataModal={() => handleOpenDataModal('SALES')}
        onOpenCredentialVault={() => handleOpenCredentialVault(selectedGstin)}
        exceptionsCount={exceptions.filter(e => !e.resolved).length}
        matchRate={(reconciliation.stats.totalPurchases > 0 || reconciliation.stats.total2B > 0) ? reconciliation.stats.totalMatchRatePercent : 0}
        salesCount={sales.length}
        purchaseCount={purchases.length}
        clientCount={clients.length}
        isMobileOpen={isMobileMenuOpen}
        onCloseMobile={() => setIsMobileMenuOpen(false)}
        onOpenAI={() => handleOpenAi()}
      />

      {/* Main Right Column Container */}
      <div className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        {/* Top Header matching screenshot */}
        <Header
          activeTab={activeTab}
          onTabChange={tab => setActiveTab(tab)}
          clients={clients}
          currentClient={currentClient}
          customFirmName={firmSettings.firmName}
          onSelectClientAndGstin={handleSelectClientAndGstin}
          onNavigateToClientMaster={() => setActiveTab('clientmaster')}
          onOpenAI={() => handleOpenAi()}
          onOpenOcr={() => setIsOcrOpen(true)}
          onOpenDataModal={() => handleOpenDataModal('SALES')}
          onOpenDemoConfirm={() => setIsDemoConfirmOpen(true)}
          onResetAllToEmpty={handleResetAllToEmpty}
          isDemoMode={isDemoMode}
          filingScore={filingReadiness.score}
          criticalExceptionsCount={criticalExceptionsCount}
          testMode={true}
          salesCount={sales.length}
          purchaseCount={purchases.length}
          gstr2bCount={gstr2b.length}
          selectedFy={selectedFy}
          selectedMonth={selectedMonth}
          currentGstin={effectiveGstin}
          onSelectFy={setSelectedFy}
          onSelectMonth={setSelectedMonth}
          onOpenApkModal={() => setIsApkModalOpen(true)}
          onToggleMobileMenu={() => setIsMobileMenuOpen(true)}
        />

        {/* Dynamic Workspace View */}
        <main className="flex-1 overflow-y-auto bg-[#F4F7FB] text-slate-800">

          {/* Sales Data Imported Successfully Banner (Requirement 3 & 4) */}
          {lastImportedSalesSummary && (
            <div className="p-4 pb-0 max-w-7xl mx-auto">
              <SalesImportSuccessBanner
                financialYear={lastImportedSalesSummary.financialYear}
                month={lastImportedSalesSummary.month}
                totalInvoices={lastImportedSalesSummary.totalInvoices}
                totalTaxableValue={lastImportedSalesSummary.totalTaxableValue}
                totalGst={lastImportedSalesSummary.totalGst}
                onUploadToGstPortal={() => setIsGstr1UploadModalOpen(true)}
                onDismiss={() => setLastImportedSalesSummary(null)}
              />
            </div>
          )}



          {/* ADMIN CONTROL PANEL (1-CLICK MASTER EDITOR) */}
          {activeTab === 'admin' && (
            <AdminPanelView
              clients={clients}
              gstins={gstins}
              selectedClientId={selectedClientId}
              selectedGstin={selectedGstin}
              sales={sales}
              purchases={purchases}
              onSelectClientAndGstin={handleSelectClientAndGstin}
              onAddClient={handleAddClient}
              onUpdateClient={handleUpdateClient}
              onDeleteClient={handleDeleteClient}
              onUpdateSales={setSales}
              onUpdatePurchases={setPurchases}
              onLoadDemo={handleConfirmLoadDemo}
              onResetAll={handleResetAllToEmpty}
              isDemoMode={isDemoMode}
              onFirmSettingsChange={setFirmSettings}
            />
          )}

          {/* CA PRACTICE HUB */}
          {activeTab === 'practice' && (
            <ClientPracticeDashboard
              clients={clients}
              gstins={gstins}
              selectedClientId={selectedClientId}
              selectedGstin={selectedGstin}
              onSelectClientAndGstin={handleSelectClientAndGstin}
              onNavigateToClientMaster={() => setActiveTab('clientmaster')}
              onNavigateToAdmin={() => setActiveTab('admin')}
              onOpenCredentialVault={handleOpenCredentialVault}
              onOpenJobQueueModal={() => setIsJobQueueModalOpen(true)}
              onSyncDirect2B={handleSyncClientDirect2B}
              isSyncing={isFetchingDirect2B}
              isDemoMode={isDemoMode}
              onOpenDemoConfirm={() => setIsDemoConfirmOpen(true)}
            />
          )}

          {/* CLIENT MASTER DATABASE */}
          {activeTab === 'clientmaster' && (
            <ClientMasterView
              clients={clients}
              onAddClient={handleAddClient}
              onUpdateClient={handleUpdateClient}
              onDeleteClient={handleDeleteClient}
              onSelectClient={clientId => {
                const target = clients.find(c => c.id === clientId);
                if (target) {
                  handleSelectClientAndGstin(target.id, target.primaryGstin);
                }
              }}
              onOpenDemoConfirm={() => setIsDemoConfirmOpen(true)}
              isDemoMode={isDemoMode}
            />
          )}

          {/* CLIENT DASHBOARD */}
          {activeTab === 'dashboard' && (
            <DashboardView
              sales={sales}
              purchases={purchases}
              gstr2b={gstr2b}
              gstr1={gstr1}
              gstr3b={gstr3b}
              exceptions={exceptions}
              reconciliationStats={reconciliation.stats}
              filingReadiness={filingReadiness}
              currentClient={currentClient}
              currentGstin={effectiveGstin}
              isDemoMode={isDemoMode}
              onNavigate={tab => setActiveTab(tab)}
              onOpenAI={handleOpenAi}
              onOpenOcr={() => setIsOcrOpen(true)}
              onOpenDataModal={handleOpenDataModal}
              onResetAllToEmpty={handleResetAllToEmpty}
              onResetToDemoData={handleResetToDemoData}
              onOpenDemoConfirm={() => setIsDemoConfirmOpen(true)}
              onNavigateToClientMaster={() => setActiveTab('clientmaster')}
              auditLogs={auditLogs}
              selectedFy={selectedFy}
              selectedMonth={selectedMonth}
              clients={clients}
            />
          )}

          {/* SALES REGISTER */}
          {activeTab === 'sales' && (
            <SalesRegisterView
              sales={sales}
              currentClient={currentClient}
              currentGstin={effectiveGstin}
              onAddInvoice={handleAddSaleInvoice}
              onOpenDataModal={handleOpenDataModal}
              onClearSales={handleClearSales}
              onDeleteSale={handleDeleteSale}
              onUploadToGstPortal={() => setIsGstr1UploadModalOpen(true)}
              selectedFy={selectedFy}
              selectedMonth={selectedMonth}
              onImportSales={handleImportSales}
            />
          )}

          {/* PURCHASE REGISTER */}
          {activeTab === 'purchases' && (
            <PurchaseRegisterView
              purchases={purchases}
              currentClient={currentClient}
              currentGstin={effectiveGstin}
              onAddPurchase={handleAddPurchaseInvoice}
              onOpenDataModal={handleOpenDataModal}
              onClearPurchases={handleClearPurchases}
              onDeletePurchase={handleDeletePurchase}
            />
          )}

          {/* GSTR-2B 5-LEVEL RECONCILIATION */}
          {activeTab === 'reconciliation' && (
            <ReconciliationView
              results={reconciliation.results}
              stats={reconciliation.stats}
              financialSummary={reconciliation.financialSummary}
              clientName={currentClient?.name || ''}
              currentGstin={effectiveGstin}
              period="April 2026"
              onResolveItem={handleResolveReconciliationItem}
              onRefreshRecon={() => {
                setPurchases([...purchases]);
              }}
              onOpenDataModal={handleOpenDataModal}
              onClearGstr2b={handleClearGstr2b}
              onFetchDirect2B={handleFetchDirect2B}
              isFetching2B={isFetchingDirect2B}
              direct2bMeta={direct2bMeta}
            />
          )}

          {/* ITC ENGINE */}
          {activeTab === 'itc' && (
            <ITCEngineView
              purchases={purchases}
              onOpenAI={handleOpenAi}
            />
          )}

          {/* RCM ENGINE */}
          {activeTab === 'rcm' && (
            <RCMEngineView
              purchases={purchases}
              sales={sales}
              onOpenAI={handleOpenAi}
            />
          )}

          {/* GSTR-1 WORKBENCH */}
          {activeTab === 'gstr1' && (
            <GSTR1View
              gstr1={gstr1}
              sales={selectedMonthSales.length > 0 ? selectedMonthSales : sales}
              onOpenAI={handleOpenAi}
              onUploadToGstPortal={() => setIsGstr1UploadModalOpen(true)}
              onImportSales={handleImportSales}
            />
          )}

          {/* GSTR-3B WORKBENCH */}
          {activeTab === 'gstr3b' && (
            <GSTR3BView
              gstr3b={gstr3b}
              gstr1={gstr1}
              sales={sales}
              purchases={purchases}
              gstr2b={gstr2b}
            />
          )}

          {/* E-COMMERCE & TCS */}
          {activeTab === 'ecommerce' && (
            <ECommerceView
              reports={ecommerceReports}
              onOpenAI={handleOpenAi}
            />
          )}

          {/* BARE LAW RAG (2026) */}
          {activeTab === 'barelaw' && (
            <BareLawBrowserView
              onOpenAI={handleOpenAi}
            />
          )}

          {/* EXCEPTION CENTER */}
          {activeTab === 'exceptions' && (
            <ExceptionCenterView
              exceptions={exceptions}
              onResolveException={handleResolveException}
            />
          )}

          {/* FILING & HUMAN APPROVAL */}
          {activeTab === 'filing' && (
            <FilingView
              gstr1={gstr1}
              gstr3b={gstr3b}
              readiness={filingReadiness}
              criticalExceptionsCount={criticalExceptionsCount}
              onOpenApprovalModal={() => setIsApprovalModalOpen(true)}
              filingSuccessResult={filingResult}
              currentClient={currentClient}
              currentGstin={effectiveGstin}
              onOpenDataModal={() => handleOpenDataModal('SALES')}
              onResetAllToEmpty={handleResetAllToEmpty}
              onResetToDemoData={handleResetToDemoData}
            />
          )}

          {/* AUTOMATED TEST SUITE */}
          {activeTab === 'testsuite' && (
            <TestSuiteView />
          )}

          {/* AUDIT TRAIL */}
          {activeTab === 'audit' && (
            <AuditTrailView
              logs={auditLogs}
            />
          )}
        </main>
      </div>

      {/* Human Approval Modal */}
      <FilingApprovalModal
        isOpen={isApprovalModalOpen}
        onClose={() => setIsApprovalModalOpen(false)}
        gstr1={gstr1}
        gstr3b={gstr3b}
        criticalExceptionsCount={criticalExceptionsCount}
        currentClient={currentClient}
        currentGstin={selectedGstin}
        onConfirmFiling={handleConfirmFiling}
        isFilingInProgress={isFilingInProgress}
      />

      {/* AI GST Expert Drawer (Never sends passwords) */}
      <AIAssistantDrawer
        isOpen={isAiOpen}
        onClose={() => setIsAiOpen(false)}
        initialPrompt={aiPrompt}
      />

      {/* OCR Document Import Modal */}
      <OcrUploadModal
        isOpen={isOcrOpen}
        onClose={() => setIsOcrOpen(false)}
        onImportInvoice={(inv, target) => {
          if (target === 'SALES') {
            handleAddSaleInvoice(inv);
            setActiveTab('sales');
          } else {
            handleAddPurchaseInvoice(inv);
            setActiveTab('purchases');
          }
        }}
      />

      {/* Data Management & Upload Center Modal */}
      <DataManagementModal
        isOpen={isDataModalOpen}
        onClose={() => setIsDataModalOpen(false)}
        initialTarget={dataModalTarget}
        salesCount={sales.length}
        purchaseCount={purchases.length}
        gstr2bCount={gstr2b.length}
        onResetAllToEmpty={handleResetAllToEmpty}
        onResetToDemoData={handleResetToDemoData}
        onClearSales={handleClearSales}
        onClearPurchases={handleClearPurchases}
        onClearGstr2b={handleClearGstr2b}
        onImportSales={handleImportSales}
        onImportPurchases={handleImportPurchases}
        onImportGstr2b={handleImportGstr2b}
        onNavigateTo={tab => {
          setActiveTab(tab as NavTab);
          setIsDataModalOpen(false);
        }}
        selectedFy={selectedFy}
        selectedMonth={selectedMonth}
        currentGstin={effectiveGstin}
        onSelectFy={setSelectedFy}
        onSelectMonth={setSelectedMonth}
        onTriggerGstr1Upload={() => {
          setIsDataModalOpen(false);
          setIsGstr1UploadModalOpen(true);
        }}
      />

      {/* Direct GSTR-1 Portal Upload Modal (Requirements 5, 6, 7) */}
      <Gstr1UploadModal
        isOpen={isGstr1UploadModalOpen}
        onClose={() => setIsGstr1UploadModalOpen(false)}
        gstin={effectiveGstin}
        financialYear={selectedFy}
        month={selectedMonth}
        period={currentReturnPeriod.periodCode}
        invoices={selectedMonthSales}
        onOpenCredentialVault={handleOpenCredentialVault}
        onUploadSuccess={res => {
          setSales(prev =>
            prev.map(inv => {
              if (selectedMonthSales.some(s => s.id === inv.id)) {
                return {
                  ...inv,
                  gstr1UploadStatus: 'UPLOADED',
                  gstr1UploadRef: res.referenceId
                };
              }
              return inv;
            })
          );
          setAuditLogs(prev => [
            {
              id: `log-${Date.now()}`,
              timestamp: new Date().toISOString(),
              actor: 'Authorized GSP Direct Gateway',
              actorRole: 'GST_PROVIDER',
              businessGstin: selectedGstin,
              module: 'FILING_GATEWAY',
              action: `GSTR-1 Outward Supplies Uploaded (${selectedMonth} ${selectedFy})`,
              details: `Transmitted ${res.totalInvoices} invoices to GST Portal. Ref ID: ${res.referenceId}, Ack: ${res.acknowledgementNumber}. Status: ${res.status}.`,
              payloadHash: `SHA256:${Date.now().toString(16)}`
            },
            ...prev
          ]);
        }}
      />

      {/* GST Portal Credential Vault Modal */}
      <CredentialVaultModal
        isOpen={isVaultModalOpen}
        onClose={() => setIsVaultModalOpen(false)}
        gstins={gstins}
        initialGstin={vaultTargetGstin || selectedGstin}
        onCredentialUpdated={() => {
          setGstins([...clientStorageService.getAllGstins()]);
        }}
      />

      {/* Asynchronous Background Job Queue Modal */}
      <JobQueueModal
        isOpen={isJobQueueModalOpen}
        onClose={() => setIsJobQueueModalOpen(false)}
        onSelectClientAndGstin={handleSelectClientAndGstin}
      />

      {/* Separate Demo Mode Confirmation Modal (Part 2) */}
      <DemoConfirmationModal
        isOpen={isDemoConfirmOpen}
        onClose={() => setIsDemoConfirmOpen(false)}
        onConfirm={handleConfirmLoadDemo}
      />

      {/* Android APK & PWA Direct Installation Modal */}
      <AndroidApkModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />

      {/* Offline Connectivity Status Notification */}
      <OfflineIndicator />

      {/* Floating 1-Click Admin Panel Quick Launcher (Always Visible) */}
      <button
        onClick={() => setActiveTab('admin')}
        className={`fixed bottom-6 right-6 z-40 px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-2.5 border-2 border-white/60 cursor-pointer transition-all duration-200 hover:scale-105 active:scale-95 ${
          activeTab === 'admin'
            ? 'bg-[#0B1F44] text-white shadow-slate-900/50'
            : 'bg-[#0B1F44] text-white shadow-[#0B1F44]/40 ring-4 ring-[#D4A24C]/25'
        }`}
        title="Open Admin Control Panel (1-Click Edit)"
      >
        <div className="w-7 h-7 rounded-xl bg-white/10 flex items-center justify-center shrink-0">
          <Sliders className="w-4 h-4 text-[#D4A24C]" />
        </div>
        <div className="text-left">
          <div className="text-[10px] uppercase font-black tracking-wider text-[#D4A24C] leading-tight">Master Control</div>
          <div className="text-xs font-black text-white leading-tight">⚙️ Admin Panel</div>
        </div>
      </button>
    </div>
  );
}
