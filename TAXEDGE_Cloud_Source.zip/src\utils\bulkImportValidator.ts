/**
 * Bulk Dataset Validation & Template Center
 * Validates bulk CSV/Excel records for Client Master, GSTINs, Registers, and Returns.
 * Never silently rejects rows; returns row-level error diagnosis.
 */

import { validateGstinFormat } from '../data/masterData';
import { BulkImportResult, ClientMaster, GSTINMasterEntry } from '../types/client';

export interface TemplateDefinition {
  id: string;
  name: string;
  filename: string;
  description: string;
  headers: string[];
  sampleRows: string[][];
}

export const BULK_TEMPLATES: Record<string, TemplateDefinition> = {
  CLIENT_MASTER: {
    id: 'CLIENT_MASTER',
    name: 'Client Master Import Template',
    filename: 'client_master_template.csv',
    description: 'Bulk onboard hundreds of clients with PAN, contact details, assigned CA staff, and return frequencies.',
    headers: [
      'Client ID',
      'Client Name',
      'Legal Name',
      'PAN',
      'Primary GSTIN',
      'State',
      'Business Type',
      'Return Frequency',
      'Assigned Staff',
      'Contact Person',
      'Mobile',
      'Email',
      'Status'
    ],
    sampleRows: [
      [
        'CLI-101',
        'Sunrise Engineering Works',
        'Sunrise Engineering Private Limited',
        'AAACS8910M',
        '27AAACS8910M1Z2',
        'Maharashtra',
        'Company',
        'Monthly',
        'CA Rahul Sharma',
        'Rajesh Kulkarni',
        '+91 98200 12345',
        'finance@sunriseeng.com',
        'Active'
      ],
      [
        'CLI-102',
        'Kaveri Textiles',
        'Kaveri Textiles LLP',
        'AAACK4411Q',
        '33AAACK4411Q1ZN',
        'Tamil Nadu',
        'LLP',
        'Monthly',
        'Pooja Verma',
        'S. Meenakshi',
        '+91 94440 67890',
        'accounts@kaveritextiles.com',
        'Active'
      ],
      [
        'CLI-103',
        'Gupta Traders',
        'Ramesh Kumar Gupta (HUF)',
        'AABHG1234R',
        '07AABHG1234R1ZP',
        'Delhi',
        'Proprietorship',
        'QRMP',
        'Vikram Patel',
        'Ramesh Gupta',
        '+91 98101 99887',
        'guptatraders.delhi@gmail.com',
        'Active'
      ]
    ]
  },
  GSTIN_MASTER: {
    id: 'GSTIN_MASTER',
    name: 'Multi-GSTIN Registration Template',
    filename: 'gstin_master_template.csv',
    description: 'Upload state-wise GSTIN registrations mapped to Client IDs with portal credentials and return types.',
    headers: [
      'GSTIN',
      'Client ID',
      'Legal Name',
      'Trade Name',
      'State',
      'Return Type',
      'Business Type',
      'Portal Username',
      'Credential Status'
    ],
    sampleRows: [
      [
        '27AAACS8910M1Z2',
        'CLI-101',
        'Sunrise Engineering Private Limited',
        'Sunrise Eng MH Unit',
        'Maharashtra',
        'Regular',
        'Company',
        'sunrise_mh_portal',
        'CONNECTED'
      ],
      [
        '29AAACS8910M1Z4',
        'CLI-101',
        'Sunrise Engineering Private Limited',
        'Sunrise Eng KA Branch',
        'Karnataka',
        'Regular',
        'Company',
        'sunrise_ka_portal',
        'CONNECTED'
      ]
    ]
  },
  PURCHASE_REGISTER: {
    id: 'PURCHASE_REGISTER',
    name: 'Purchase Register Template',
    filename: 'purchase_register_template.csv',
    description: 'B2B inward invoices, supplier GSTIN, tax values, HSN codes, and 17(5) ITC eligibility tags.',
    headers: [
      'Invoice Number',
      'Invoice Date (YYYY-MM-DD)',
      'Supplier GSTIN',
      'Supplier Name',
      'Place of Supply',
      'Taxable Value',
      'GST Rate (%)',
      'IGST',
      'CGST',
      'SGST',
      'Cess',
      'Total Amount',
      'Is RCM (YES/NO)',
      'ITC Status (ELIGIBLE/INELIGIBLE)',
      'Blocked Reason'
    ],
    sampleRows: [
      ['INV/2026/0411', '2026-04-05', '27AABCS1429B1Z1', 'Siemens Cloud & Infrastructure India Ltd', '27-Maharashtra', '500000.00', '18', '0.00', '45000.00', '45000.00', '0.00', '590000.00', 'NO', 'ELIGIBLE', 'NONE'],
      ['HPE-BLR-44910', '2026-04-12', '29AAACH1928F1ZY', 'Hewlett Packard Enterprise India Pvt Ltd', '27-Maharashtra', '350000.00', '18', '63000.00', '0.00', '0.00', '0.00', '413000.00', 'NO', 'ELIGIBLE', 'NONE'],
      ['SWG-CAT/2026-44', '2026-04-19', '27AAGCS9012R1ZU', 'Royal Gourmet Caterers & Event Managers', '27-Maharashtra', '85000.00', '5', '0.00', '2125.00', '2125.00', '0.00', '89250.00', 'NO', 'INELIGIBLE', 'SEC_17_5_B_FOOD_BEVERAGE_CATERING_HEALTH']
    ]
  },
  SALES_REGISTER: {
    id: 'SALES_REGISTER',
    name: 'Sales Register (Outward Supplies) Template',
    filename: 'sales_register_template.csv',
    description: 'Outward supplies for GSTR-1 preparation across B2B, B2C Large, B2C Small, and Exports.',
    headers: [
      'Invoice Number',
      'Invoice Date (YYYY-MM-DD)',
      'Document Type',
      'Recipient GSTIN',
      'Recipient Name',
      'Place of Supply',
      'Classification',
      'Taxable Value',
      'GST Rate (%)',
      'IGST',
      'CGST',
      'SGST',
      'Cess',
      'Total Amount'
    ],
    sampleRows: [
      ['EXP-2026-001', '2026-04-02', 'INVOICE', '27AAACI1904K1ZR', 'Infosys BPM Solutions Ltd', '27-Maharashtra', 'B2B', '450000.00', '18', '0.00', '40500.00', '40500.00', '0.00', '531000.00'],
      ['EXP-2026-002', '2026-04-05', 'INVOICE', '29AAACT9812M1Z5', 'Tata Consultancy Services Ltd', '29-Karnataka', 'B2B', '620000.00', '18', '111600.00', '0.00', '0.00', '0.00', '731600.00'],
      ['EXP-2026-005', '2026-04-18', 'INVOICE', 'URP-RETAIL-MH', 'Mumbai Walk-in Clients', '27-Maharashtra', 'B2C_SMALL', '180000.00', '18', '0.00', '16200.00', '16200.00', '0.00', '212400.00']
    ]
  },
  GSTR2B: {
    id: 'GSTR2B',
    name: 'GSTR-2B Statement Template (CSV / Excel)',
    filename: 'gstr2b_template.csv',
    description: 'Standardized auto-drafted ITC statement from GSTN for offline purchase reconciliation.',
    headers: [
      'Supplier GSTIN',
      'Supplier Name',
      'Invoice Number',
      'Invoice Type',
      'Invoice Date',
      'Invoice Value',
      'Place of Supply',
      'Reverse Charge (Y/N)',
      'Taxable Value',
      'IGST',
      'CGST',
      'SGST',
      'Cess',
      'ITC Available (Y/N)',
      'Filing Date'
    ],
    sampleRows: [
      ['27AABCS1429B1Z1', 'Siemens Cloud & Infrastructure India Ltd', 'INV/2026/0411', 'B2B', '2026-04-05', '590000.00', '27-Maharashtra', 'N', '500000.00', '0.00', '45000.00', '45000.00', '0.00', 'Y', '2026-05-11'],
      ['29AAACH1928F1ZY', 'Hewlett Packard Enterprise India Pvt Ltd', 'HPE-BLR-44910', 'B2B', '2026-04-12', '413000.00', '27-Maharashtra', 'N', '350000.00', '63000.00', '0.00', '0.00', '0.00', 'Y', '2026-05-10'],
      ['27AAACB2100P1Z0', 'Vodafone Idea Telecommunications Ltd', 'VODAFONE-2026-99', 'B2B', '2026-04-16', '134400.00', '27-Maharashtra', 'N', '120000.00', '0.00', '7200.00', '7200.00', '0.00', 'Y', '2026-05-11']
    ]
  },
  ECOMMERCE_REPORTS: {
    id: 'ECOMMERCE_REPORTS',
    name: 'E-Commerce Marketplace Settlement Template',
    filename: 'ecommerce_settlement_template.csv',
    description: 'Amazon, Flipkart, Meesho, Swiggy sales reports with Section 52 TCS reconciliation.',
    headers: [
      'Platform',
      'Operator GSTIN',
      'Period',
      'Gross Sales',
      'Sales Return',
      'Net Taxable Sales',
      'IGST Collected',
      'CGST Collected',
      'SGST Collected',
      'TCS Deducted (Sec 52)',
      'Commission Deducted',
      'Net Settlement'
    ],
    sampleRows: [
      ['AMAZON', '27AAACA9290L1ZR', 'April 2026', '640000.00', '42000.00', '598000.00', '0.00', '53820.00', '53820.00', '5980.00', '71760.00', '603400.00'],
      ['FLIPKART', '29AABCF9823M1Z2', 'April 2026', '380000.00', '18000.00', '362000.00', '65160.00', '0.00', '0.00', '3620.00', '43440.00', '363900.00']
    ]
  }
};

/**
 * Validates bulk CSV rows for Client Master
 */
export function validateBulkClients(
  csvText: string,
  existingClients: ClientMaster[]
): {
  result: BulkImportResult;
  validClients: ClientMaster[];
} {
  const lines = csvText.split(/\r\n|\r|\n/).map(l => l.trim()).filter(Boolean);
  if (lines.length <= 1) {
    return {
      result: {
        totalRows: 0,
        imported: 0,
        failed: 0,
        duplicates: 0,
        invalidGstin: 0,
        missingFields: 0,
        errors: [{ row: 1, identifier: 'FILE', reason: 'CSV file is empty or only contains header.' }]
      },
      validClients: []
    };
  }

  // Parse header
  const header = lines[0].split(',').map(h => h.trim().toLowerCase().replace(/[^a-z0-9]/g, ''));
  const idIdx = header.findIndex(h => h.includes('clientid') || h === 'id');
  const nameIdx = header.findIndex(h => h.includes('clientname') || h === 'name');
  const legalIdx = header.findIndex(h => h.includes('legalname'));
  const panIdx = header.findIndex(h => h.includes('pan'));
  const gstinIdx = header.findIndex(h => h.includes('gstin'));
  const stateIdx = header.findIndex(h => h.includes('state'));
  const typeIdx = header.findIndex(h => h.includes('business') || h.includes('type'));
  const freqIdx = header.findIndex(h => h.includes('frequency') || h.includes('return'));
  const staffIdx = header.findIndex(h => h.includes('staff') || h.includes('assigned') || h.includes('ca'));
  const contactIdx = header.findIndex(h => h.includes('contact'));
  const emailIdx = header.findIndex(h => h.includes('email'));
  const statusIdx = header.findIndex(h => h.includes('status'));

  const validClients: ClientMaster[] = [];
  const errors: { row: number; identifier: string; reason: string }[] = [];
  let duplicates = 0;
  let invalidGstin = 0;
  let missingFields = 0;

  const existingIds = new Set(existingClients.map(c => c.id.toUpperCase()));
  const existingGstins = new Set(existingClients.map(c => c.primaryGstin.toUpperCase()));

  for (let i = 1; i < lines.length; i++) {
    const rowNum = i + 1;
    // Simple CSV parser respecting potential quotes
    const row = lines[i].split(',').map(c => c.replace(/^["']|["']$/g, '').trim());
    if (row.length < 3 || row.every(c => !c)) continue;

    const clientId = (idIdx >= 0 ? row[idIdx] : `CLI-${100 + i}`).trim().toUpperCase();
    const clientName = (nameIdx >= 0 ? row[nameIdx] : row[0]).trim();
    const legalName = (legalIdx >= 0 ? row[legalIdx] : clientName).trim();
    const pan = (panIdx >= 0 ? row[panIdx] : '').trim().toUpperCase();
    const primaryGstin = (gstinIdx >= 0 ? row[gstinIdx] : '').trim().toUpperCase();
    const state = (stateIdx >= 0 ? row[stateIdx] : 'Maharashtra').trim();
    const rawType = (typeIdx >= 0 ? row[typeIdx] : 'Company').trim();
    const rawFreq = (freqIdx >= 0 ? row[freqIdx] : 'Monthly').trim();
    const staff = (staffIdx >= 0 ? row[staffIdx] : 'CA Rahul Sharma').trim();
    const contact = (contactIdx >= 0 ? row[contactIdx] : 'Finance Manager').trim();
    const email = (emailIdx >= 0 ? row[emailIdx] : 'accounts@taxclient.in').trim();
    const rawStatus = (statusIdx >= 0 ? row[statusIdx] : 'Active').trim();

    // 1. Missing Required Fields
    if (!clientName || !primaryGstin) {
      missingFields++;
      errors.push({
        row: rowNum,
        identifier: clientId || `Row ${rowNum}`,
        reason: 'Missing required field: Client Name and Primary GSTIN are mandatory.'
      });
      continue;
    }

    // 2. Validate GSTIN
    const gVal = validateGstinFormat(primaryGstin);
    if (!gVal.valid) {
      invalidGstin++;
      errors.push({
        row: rowNum,
        identifier: primaryGstin,
        reason: `Invalid GSTIN format: ${gVal.error}`
      });
      continue;
    }

    // 3. Duplicate checks
    if (existingIds.has(clientId)) {
      duplicates++;
      errors.push({
        row: rowNum,
        identifier: clientId,
        reason: `Duplicate Client ID: "${clientId}" already exists in Client Master database.`
      });
      continue;
    }

    if (existingGstins.has(primaryGstin)) {
      duplicates++;
      errors.push({
        row: rowNum,
        identifier: primaryGstin,
        reason: `Duplicate GSTIN: "${primaryGstin}" is already registered under another client.`
      });
      continue;
    }

    // Sanitize business type & frequency
    const businessType = ['Company', 'Partnership', 'Proprietorship', 'LLP', 'Other'].includes(rawType)
      ? (rawType as any)
      : 'Company';

    const returnFrequency = rawFreq.toUpperCase().includes('QRMP') || rawFreq.toUpperCase().includes('QUARTER')
      ? 'QRMP'
      : 'Monthly';

    const client: ClientMaster = {
      id: clientId,
      name: clientName,
      tradeName: clientName,
      legalName: legalName || clientName,
      pan: pan || primaryGstin.substring(2, 12),
      primaryGstin,
      additionalGstins: [],
      businessType,
      state: state || gVal.stateName || 'Maharashtra',
      registeredAddress: `${state} Registered Office`,
      contactPerson: contact,
      mobile: '+91 98000 00000',
      email,
      assignedStaff: staff,
      returnFrequency,
      financialYear: '2026-27',
      status: rawStatus === 'Archived' ? 'Archived' : 'Active',
      createdDate: new Date().toISOString().split('T')[0]
    };

    validClients.push(client);
    existingIds.add(clientId);
    existingGstins.add(primaryGstin);
  }

  const total = lines.length - 1;
  const failed = errors.length;
  const imported = validClients.length;

  return {
    result: {
      totalRows: total,
      imported,
      failed,
      duplicates,
      invalidGstin,
      missingFields,
      errors
    },
    validClients
  };
}

/**
 * Triggers instant browser download of standardized CSV template
 */
export function downloadBulkTemplate(templateKey: keyof typeof BULK_TEMPLATES) {
  const def = BULK_TEMPLATES[templateKey];
  if (!def) return;

  const headerLine = def.headers.join(',');
  const rowLines = def.sampleRows.map(r =>
    r.map(cell => (cell.includes(',') || cell.includes('"') ? `"${cell.replace(/"/g, '""')}"` : cell)).join(',')
  );

  const csvContent = '\uFEFF' + [headerLine, ...rowLines].join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = def.filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
