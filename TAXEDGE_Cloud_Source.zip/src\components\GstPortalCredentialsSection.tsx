import React, { useState, useEffect } from 'react';
import { KeyRound, Lock, Eye, EyeOff, ShieldCheck, Check, Edit2, AlertCircle, RefreshCw } from 'lucide-react';
import { credentialVaultService, VaultCredentialRecord } from '../services/credentialVaultService';
import { clientStorageService } from '../services/clientStorageService';

interface GstPortalCredentialsSectionProps {
  gstin: string;
  clientId?: string;
  onSaved?: () => void;
  compact?: boolean;
}

export const GstPortalCredentialsSection: React.FC<GstPortalCredentialsSectionProps> = ({
  gstin,
  clientId,
  onSaved,
  compact = false
}) => {
  const [cred, setCred] = useState<VaultCredentialRecord | null>(() => {
    return gstin ? credentialVaultService.getCredential(gstin) : null;
  });

  const [isEditing, setIsEditing] = useState<boolean>(() => {
    const existing = gstin ? credentialVaultService.getCredential(gstin) : null;
    return !existing || !existing.portalUsername;
  });

  const [username, setUsername] = useState<string>(() => {
    const existing = gstin ? credentialVaultService.getCredential(gstin) : null;
    return existing?.portalUsername || '';
  });

  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Sync state whenever gstin prop changes
  useEffect(() => {
    if (!gstin) {
      setCred(null);
      setUsername('');
      setPassword('');
      setIsEditing(true);
      return;
    }
    const existing = credentialVaultService.getCredential(gstin);
    setCred(existing);
    setUsername(existing?.portalUsername || '');
    setPassword('');
    setShowPassword(false);
    setIsEditing(!existing || !existing.portalUsername);
    setSaveSuccess(false);
    setErrorMessage(null);
  }, [gstin]);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!gstin) {
      setErrorMessage('GSTIN is required');
      return;
    }
    if (!username.trim()) {
      setErrorMessage('GST Portal Username is required');
      return;
    }
    if (!cred?.portalUsername && !password.trim()) {
      setErrorMessage('GST Portal Password is required');
      return;
    }

    try {
      const savedRecord = credentialVaultService.saveCredential({
        gstin,
        clientId: clientId || cred?.clientId || 'CLI-001',
        portalUsername: username.trim(),
        plainPassword: password.trim() ? password.trim() : undefined
      });

      // Synchronize in GSTIN Master entry
      const allGstins = clientStorageService.getAllGstins();
      const gIndex = allGstins.findIndex(g => g.gstin.trim().toUpperCase() === gstin.trim().toUpperCase());
      if (gIndex >= 0) {
        allGstins[gIndex].portalUsername = savedRecord.portalUsername;
        allGstins[gIndex].encryptedPasswordMask = savedRecord.maskedPassword;
        allGstins[gIndex].credentialStatus = savedRecord.credentialStatus;
        allGstins[gIndex].lastVerified = savedRecord.lastVerified;
        clientStorageService.updateGstin(allGstins[gIndex]);
      }

      setCred(savedRecord);
      setPassword('');
      setShowPassword(false);
      setIsEditing(false);
      setErrorMessage(null);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);

      if (onSaved) {
        onSaved();
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to save credentials');
    }
  };

  const handleCancelEdit = () => {
    if (cred && cred.portalUsername) {
      setUsername(cred.portalUsername);
      setPassword('');
      setShowPassword(false);
      setIsEditing(false);
      setErrorMessage(null);
    }
  };

  if (!gstin) {
    return (
      <div className="p-3.5 rounded-xl bg-white border border-[#E5E7EB] text-xs text-[#6B7280] italic">
        Select a GSTIN to configure GST Portal Credentials.
      </div>
    );
  }

  return (
    <div className={`rounded-xl border ${compact ? 'p-3 bg-[#FFFFFF]/70 border-[#E5E7EB]' : 'p-4 bg-white border-[#E5E7EB] shadow-md'} space-y-3`}>
      {/* Header */}
      <div className="flex items-center justify-between gap-2 border-b border-[#E5E7EB] pb-2">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-[#FFF8E1] text-[#B7791F] border border-amber-500/20 text-[#B7791F]">
            <KeyRound className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
              <span>GST Portal Credentials</span>
              <span className="font-mono text-[11px] text-[#176B4D] font-semibold">({gstin})</span>
            </h4>
            <p className="text-[10px] text-[#6B7280]">
              Encrypted credentials vault for automated 2B retrieval & return filing
            </p>
          </div>
        </div>

        {/* Status Badge */}
        {cred && cred.portalUsername && !isEditing ? (
          <div className="flex items-center gap-1.5">
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-[#176B4D]/10 text-[#176B4D] border border-[#176B4D]/30">
              <ShieldCheck className="w-3 h-3 text-[#176B4D]" />
              Connected
            </span>
            <button
              type="button"
              onClick={() => setIsEditing(true)}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white hover:bg-[#E8F5EF] text-[#176B4D] border border-[#176B4D]/40 font-bold shadow-sm text-[11px] font-semibold transition"
              title="Change GST Portal Username or Password"
            >
              <Edit2 className="w-3 h-3 text-[#6B7280]" />
              <span>Edit / Change Credentials</span>
            </button>
          </div>
        ) : (
          <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-[#F8F9FA] text-[#6B7280] border border-[#E5E7EB]">
            {isEditing && cred ? 'Editing' : 'Not Configured'}
          </span>
        )}
      </div>

      {/* Save Success Alert */}
      {saveSuccess && (
        <div className="p-2.5 rounded-lg bg-[#176B4D]/10 border border-[#176B4D]/30 text-[#176B4D] text-xs flex items-center gap-2">
          <Check className="w-4 h-4 text-[#176B4D] shrink-0" />
          <span>GST portal credentials saved securely. Password is encrypted and masked.</span>
        </div>
      )}

      {/* Error Alert */}
      {errorMessage && (
        <div className="p-2.5 rounded-lg bg-[#FDECEC] text-[#C62828] border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-[#C62828] shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* VIEW MODE: Saved & Masked */}
      {!isEditing && cred && cred.portalUsername ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 text-xs">
          <div className="p-2.5 rounded-lg bg-white border border-[#E5E7EB]">
            <span className="block text-[10px] uppercase font-semibold text-[#6B7280] mb-0.5">
              GST Portal Username
            </span>
            <span className="font-mono font-medium text-white select-all">
              {cred.portalUsername}
            </span>
          </div>

          <div className="p-2.5 rounded-lg bg-white border border-[#E5E7EB]">
            <span className="block text-[10px] uppercase font-semibold text-[#6B7280] mb-0.5">
              GST Portal Password
            </span>
            <div className="flex items-center justify-between">
              <span className="font-mono text-[#6B7280] tracking-wider font-bold">
                {cred.maskedPassword || '••••••••••••'}
              </span>
              <span className="text-[10px] font-semibold text-[#176B4D] flex items-center gap-1">
                <Lock className="w-3 h-3" />
                Encrypted at rest
              </span>
            </div>
          </div>
        </div>
      ) : (
        /* EDIT / ENTRY FORM */
        <form onSubmit={handleSave} className="space-y-3 pt-1 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Username Input */}
            <div>
              <label className="block text-[11px] font-semibold text-[#6B7280] mb-1">
                GST Portal Username <span className="text-[#C62828]">*</span>
              </label>
              <input
                type="text"
                value={username}
                onChange={e => setUsername(e.target.value)}
                placeholder="e.g. taxpayer_portal_id"
                className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white font-mono placeholder-slate-500 focus:outline-none focus:border-[#176B4D]/30 text-xs"
                required
              />
            </div>

            {/* Password Input with Eye Toggle */}
            <div>
              <label className="block text-[11px] font-semibold text-[#6B7280] mb-1">
                GST Portal Password {cred?.portalUsername && <span className="text-[#6B7280] text-[10px]">(Leave blank to keep existing)</span>}
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder={cred?.portalUsername ? '•••••••••••• (Unchanged)' : 'Enter GST portal password'}
                  className="w-full pl-3 pr-9 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-white font-mono placeholder-slate-500 focus:outline-none focus:border-[#176B4D]/30 text-xs"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#6B7280] hover:text-white transition p-0.5"
                  title={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4 text-[#176B4D]" />}
                </button>
              </div>
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex items-center justify-end gap-2 pt-1">
            {cred && cred.portalUsername && (
              <button
                type="button"
                onClick={handleCancelEdit}
                className="px-3 py-1.5 rounded-lg bg-[#F8F9FA] hover:bg-slate-700 text-[#6B7280] text-xs font-bold border border-[#E5E7EB] transition"
              >
                Cancel
              </button>
            )}
            <button
              type="submit"
              className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-emerald-600 to-slate-500 hover:from-emerald-500 hover:to-slate-400 text-slate-950 font-bold text-xs shadow-md shadow-emerald-950/40 flex items-center gap-1.5 transition active:scale-95"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Save Credentials</span>
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
