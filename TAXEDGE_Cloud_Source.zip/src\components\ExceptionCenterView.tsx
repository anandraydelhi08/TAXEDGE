import React, { useState } from 'react';
import { AlertOctagon, CheckCircle2, AlertTriangle, ArrowRight, ShieldCheck, Filter, Wrench } from 'lucide-react';
import { ComplianceException, ExceptionSeverity } from '../types/gst';

interface ExceptionCenterViewProps {
  exceptions: ComplianceException[];
  onResolveException: (id: string, note?: string) => void;
}

export const ExceptionCenterView: React.FC<ExceptionCenterViewProps> = ({
  exceptions,
  onResolveException
}) => {
  const [severityFilter, setSeverityFilter] = useState<string>('ALL');

  const filtered = exceptions.filter(e => {
    if (severityFilter === 'ALL') return true;
    return e.severity === severityFilter;
  });

  const criticalCount = exceptions.filter(e => e.severity === 'CRITICAL' && !e.resolved).length;
  const highCount = exceptions.filter(e => e.severity === 'HIGH' && !e.resolved).length;
  const mediumCount = exceptions.filter(e => e.severity === 'MEDIUM' && !e.resolved).length;

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-black text-[#202124] flex items-center gap-2">
              <AlertOctagon className="w-5 h-5 text-[#C62828]" />
              Compliance Exception Center
            </h2>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#FDECEC] text-[#C62828] text-rose-300 font-bold border border-rose-500/30">
              Audit Risk Scanner Active
            </span>
          </div>
          <p className="text-xs text-[#6B7280] mt-1">
            Automated scrutiny for math discrepancies, GSTIN failures, Section 17(5) blocked credits, and Rule 88C risks.
          </p>
        </div>
      </div>

      {/* Severity Counters */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <button
          onClick={() => setSeverityFilter('ALL')}
          className={`p-4 rounded-xl border text-left transition ${
            severityFilter === 'ALL' ? 'bg-[#F8F9FA] border-[#E5E7EB]' : 'bg-white border-[#E5E7EB]'
          }`}
        >
          <div className="text-[11px] text-[#6B7280] font-medium">Total Exceptions</div>
          <div className="text-2xl font-black text-[#202124] mt-1">{exceptions.length}</div>
          <div className="text-[10px] text-[#6B7280]">Across registers & returns</div>
        </button>

        <button
          onClick={() => setSeverityFilter('CRITICAL')}
          className={`p-4 rounded-xl border text-left transition ${
            severityFilter === 'CRITICAL' ? 'bg-rose-950/40 border-rose-500' : 'bg-white border-[#E5E7EB]'
          }`}
        >
          <div className="text-[11px] text-[#C62828] font-medium flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#FDECEC] text-[#C62828] animate-pulse"></span>
            Critical Severity
          </div>
          <div className="text-2xl font-black text-rose-300 mt-1">{criticalCount}</div>
          <div className="text-[10px] text-[#C62828]/80">Blocks return filing</div>
        </button>

        <button
          onClick={() => setSeverityFilter('HIGH')}
          className={`p-4 rounded-xl border text-left transition ${
            severityFilter === 'HIGH' ? 'bg-amber-950/40 border-amber-500' : 'bg-white border-[#E5E7EB]'
          }`}
        >
          <div className="text-[11px] text-[#B7791F] font-medium">High Severity</div>
          <div className="text-2xl font-black text-[#B7791F] mt-1">{highCount}</div>
          <div className="text-[10px] text-[#B7791F]/80">Audit penalty risk</div>
        </button>

        <button
          onClick={() => setSeverityFilter('MEDIUM')}
          className={`p-4 rounded-xl border text-left transition ${
            severityFilter === 'MEDIUM' ? 'bg-[#E8F5EF]/40 border-[#176B4D]/30' : 'bg-white border-[#E5E7EB]'
          }`}
        >
          <div className="text-[11px] text-[#176B4D] font-medium">Medium Severity</div>
          <div className="text-2xl font-black text-[#176B4D] mt-1">{mediumCount}</div>
          <div className="text-[10px] text-[#6B7280]">Informational / timing</div>
        </button>
      </div>

      {/* Exception List */}
      <div className="space-y-4">
        {filtered.map(ex => (
          <div
            key={ex.id}
            className={`bg-white border rounded-2xl p-5 transition shadow-lg ${
              ex.resolved
                ? 'border-[#E5E7EB] opacity-60'
                : ex.severity === 'CRITICAL'
                ? 'border-rose-500/50 bg-rose-950/10'
                : ex.severity === 'HIGH'
                ? 'border-amber-500/50 bg-amber-950/10'
                : 'border-[#E5E7EB]'
            }`}
          >
            <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4">
              <div className="space-y-2">
                <div className="flex items-center gap-2.5">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    ex.severity === 'CRITICAL'
                      ? 'bg-[#FDECEC] text-[#C62828] text-white'
                      : ex.severity === 'HIGH'
                      ? 'bg-[#FFF8E1] text-[#B7791F] text-slate-950'
                      : 'bg-[#176B4D]/20 text-[#176B4D]'
                  }`}>
                    {ex.severity}
                  </span>
                  <span className="font-mono text-xs text-[#6B7280] font-semibold">{ex.code}</span>
                  <span className="text-[11px] text-[#6B7280] px-2 py-0.5 rounded bg-[#F8F9FA] font-mono">
                    {ex.entityType} {ex.invoiceNumber ? `(${ex.invoiceNumber})` : ''}
                  </span>
                  {ex.resolved && (
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold text-[#176B4D] bg-[#E8F5EF] px-2 py-0.5 rounded">
                      <CheckCircle2 className="w-3 h-3" /> RESOLVED
                    </span>
                  )}
                </div>

                <h3 className="text-base font-bold text-[#202124] tracking-tight">{ex.title}</h3>
                <p className="text-xs text-[#6B7280] leading-relaxed max-w-4xl">{ex.description}</p>

                <div className="p-3 rounded-xl bg-[#FFFFFF] border border-[#E5E7EB] text-xs text-[#176B4D] flex items-start gap-2">
                  <Wrench className="w-4 h-4 shrink-0 mt-0.5 text-[#176B4D]" />
                  <div>
                    <strong className="text-[#202124]">Recommended Action:</strong> {ex.suggestedAction}
                  </div>
                </div>
              </div>

              {/* Action Resolution Button */}
              {!ex.resolved && (
                <div className="shrink-0 flex lg:flex-col gap-2">
                  <button
                    onClick={() => onResolveException(ex.id, 'One-click compliance fix applied')}
                    className="px-4 py-2 rounded-xl bg-[#176B4D] hover:bg-emerald-400 text-slate-950 text-xs font-bold transition shadow-md shadow-emerald-950/40"
                  >
                    Apply Statutory Resolution
                  </button>
                  <button
                    onClick={() => onResolveException(ex.id, 'Reviewed and verified against manual audit voucher')}
                    className="px-4 py-2 rounded-xl bg-[#F8F9FA] hover:bg-slate-700 text-[#6B7280] text-xs font-medium border border-[#E5E7EB] transition"
                  >
                    Accept with Note
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
