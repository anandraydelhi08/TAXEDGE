/**
 * GSTR-3B Preparation and Tax Liability Settlement Engine
 * Legal Basis: Section 39 of CGST Act, 2017 & Rule 61, 88A of CGST Rules, 2017
 */

import { TransactionInvoice, GSTR2BRecord, GSTR3BSummary, GSTR1Summary } from '../types/gst';
import { round2, calculateRule88ASetOff } from '../utils/taxMath';

export class GSTR3BEngine {
  /**
   * Prepares complete statutory GSTR-3B return summary
   */
  public prepareGSTR3B(
    sales: TransactionInvoice[],
    purchases: TransactionInvoice[],
    gstr2bRecords: GSTR2BRecord[],
    period: string = '04-2026',
    gstin: string = ''
  ): GSTR3BSummary {
    // 1. Table 3.1: Details of Outward Supplies and Inward Supplies Liable to Reverse Charge
    let outwardTaxableVal = 0;
    let outwardIgst = 0;
    let outwardCgst = 0;
    let outwardSgst = 0;
    let outwardCess = 0;

    let zeroRatedVal = 0;
    let zeroRatedIgst = 0;
    let zeroRatedCess = 0;

    let nilExemptVal = 0;
    let nonGstVal = 0;

    for (const s of sales) {
      const taxable = round2(s.taxableValue);
      const cgst = round2(s.cgst);
      const sgst = round2(s.sgst);
      const igst = round2(s.igst);
      const cess = round2(s.cess);
      const sign = s.documentType === 'CREDIT_NOTE' ? -1 : 1;

      if (s.classification.startsWith('EXPORT') || s.classification.startsWith('SEZ')) {
        zeroRatedVal = round2(zeroRatedVal + (sign * taxable));
        zeroRatedIgst = round2(zeroRatedIgst + (sign * igst));
        zeroRatedCess = round2(zeroRatedCess + (sign * cess));
      } else if (s.classification === 'NIL_RATED' || s.classification === 'EXEMPT') {
        nilExemptVal = round2(nilExemptVal + (sign * taxable));
      } else if (s.classification === 'NON_GST') {
        nonGstVal = round2(nonGstVal + (sign * taxable));
      } else {
        // Standard taxable supply (B2B, B2C, Debit Notes, Credit Notes)
        outwardTaxableVal = round2(outwardTaxableVal + (sign * taxable));
        outwardIgst = round2(outwardIgst + (sign * igst));
        outwardCgst = round2(outwardCgst + (sign * cgst));
        outwardSgst = round2(outwardSgst + (sign * sgst));
        outwardCess = round2(outwardCess + (sign * cess));
      }
    }

    // Inward RCM Supplies: from Purchase Register where rcm === true
    let rcmTaxableVal = 0;
    let rcmIgst = 0;
    let rcmCgst = 0;
    let rcmSgst = 0;
    let rcmCess = 0;

    for (const p of purchases) {
      if (p.rcm) {
        const sign = p.documentType === 'CREDIT_NOTE' ? -1 : 1;
        rcmTaxableVal = round2(rcmTaxableVal + (sign * p.taxableValue));
        rcmIgst = round2(rcmIgst + (sign * p.igst));
        rcmCgst = round2(rcmCgst + (sign * p.cgst));
        rcmSgst = round2(rcmSgst + (sign * p.sgst));
        rcmCess = round2(rcmCess + (sign * p.cess));
      }
    }

    // 2. Table 4: Eligible Input Tax Credit (ITC)
    let itcAllOtherIgst = 0;
    let itcAllOtherCgst = 0;
    let itcAllOtherSgst = 0;
    let itcAllOtherCess = 0;

    let itcBlockedIgst = 0;
    let itcBlockedCgst = 0;
    let itcBlockedSgst = 0;
    let itcBlockedCess = 0;

    for (const p of purchases) {
      if (p.rcm) continue; // Handled under Table 4(A)(3)
      const cgst = round2(p.cgst);
      const sgst = round2(p.sgst);
      const igst = round2(p.igst);
      const cess = round2(p.cess);
      const sign = p.documentType === 'CREDIT_NOTE' ? -1 : 1;

      if (p.itcStatus === 'ELIGIBLE') {
        itcAllOtherIgst = round2(itcAllOtherIgst + (sign * igst));
        itcAllOtherCgst = round2(itcAllOtherCgst + (sign * cgst));
        itcAllOtherSgst = round2(itcAllOtherSgst + (sign * sgst));
        itcAllOtherCess = round2(itcAllOtherCess + (sign * cess));
      } else if (p.itcStatus === 'INELIGIBLE') {
        itcBlockedIgst = round2(itcBlockedIgst + (sign * igst));
        itcBlockedCgst = round2(itcBlockedCgst + (sign * cgst));
        itcBlockedSgst = round2(itcBlockedSgst + (sign * sgst));
        itcBlockedCess = round2(itcBlockedCess + (sign * cess));
      }
    }

    // Gross ITC available under Table 4(A)(5) (includes both eligible and blocked u/s 17(5) as per CBIC Circular 170)
    const grossOtherIgst = round2(itcAllOtherIgst + itcBlockedIgst);
    const grossOtherCgst = round2(itcAllOtherCgst + itcBlockedCgst);
    const grossOtherSgst = round2(itcAllOtherSgst + itcBlockedSgst);
    const grossOtherCess = round2(itcAllOtherCess + itcBlockedCess);

    // Net ITC Available Table 4(C)
    // Table 4(A)(3) RCM Inward ITC (claimed after cash payment under Sec 16)
    const netItcIgst = round2(itcAllOtherIgst + rcmIgst);
    const netItcCgst = round2(itcAllOtherCgst + rcmCgst);
    const netItcSgst = round2(itcAllOtherSgst + rcmSgst);
    const netItcCess = round2(itcAllOtherCess + rcmCess);

    // 3. Table 6.1: Payment of Tax (Rule 88A ITC Set-Off and Cash Liability)
    // Gross Forward Liability
    const grossLiability = {
      igst: outwardIgst + zeroRatedIgst,
      cgst: outwardCgst,
      sgst: outwardSgst,
      cess: outwardCess + zeroRatedCess
    };

    // Available ITC in Credit Ledger
    const availableITC = {
      igst: netItcIgst,
      cgst: netItcCgst,
      sgst: netItcSgst,
      cess: netItcCess
    };

    const setOff = calculateRule88ASetOff(grossLiability, availableITC);

    // IMPORTANT: Section 49(4) mandates RCM liability CANNOT be paid through ITC; must be paid 100% in CASH!
    const finalCashPayable = {
      igst: round2(setOff.cashPayable.igst + rcmIgst),
      cgst: round2(setOff.cashPayable.cgst + rcmCgst),
      sgst: round2(setOff.cashPayable.sgst + rcmSgst),
      cess: round2(setOff.cashPayable.cess + rcmCess)
    };

    const totalCash = round2(
      finalCashPayable.igst + finalCashPayable.cgst + finalCashPayable.sgst + finalCashPayable.cess
    );

    return {
      period,
      gstin,
      table3_1: {
        outwardTaxable: {
          taxable: outwardTaxableVal,
          igst: outwardIgst,
          cgst: outwardCgst,
          sgst: outwardSgst,
          cess: outwardCess
        },
        outwardZeroRated: {
          taxable: zeroRatedVal,
          igst: zeroRatedIgst,
          cess: zeroRatedCess
        },
        otherOutwardNilExempt: {
          taxable: nilExemptVal
        },
        inwardRCM: {
          taxable: rcmTaxableVal,
          igst: rcmIgst,
          cgst: rcmCgst,
          sgst: rcmSgst,
          cess: rcmCess
        },
        nonGstOutward: {
          taxable: nonGstVal
        }
      },
      table4_ITC: {
        itcAvailable: {
          importGoods: { igst: 0, cess: 0 },
          importServices: { igst: 0, cess: 0 },
          inwardRCM: { igst: rcmIgst, cgst: rcmCgst, sgst: rcmSgst, cess: rcmCess },
          isdCredit: { igst: 0, cgst: 0, sgst: 0, cess: 0 },
          allOtherITC: { igst: grossOtherIgst, cgst: grossOtherCgst, sgst: grossOtherSgst, cess: grossOtherCess }
        },
        itcReversed: {
          asPerRules38_42_43_and_17_5: { igst: itcBlockedIgst, cgst: itcBlockedCgst, sgst: itcBlockedSgst, cess: itcBlockedCess },
          others: { igst: 0, cgst: 0, sgst: 0, cess: 0 }
        },
        netITCAvailable: {
          igst: netItcIgst,
          cgst: netItcCgst,
          sgst: netItcSgst,
          cess: netItcCess
        },
        ineligibleITC: {
          asPerSection16_4: { igst: 0, cgst: 0, sgst: 0, cess: 0 },
          others: { igst: itcBlockedIgst, cgst: itcBlockedCgst, sgst: itcBlockedSgst, cess: itcBlockedCess }
        }
      },
      table5_InwardExempt: {
        fromInterState: 0,
        fromIntraState: 0
      },
      table6_1_PaymentOfTax: {
        taxPayable: {
          igst: round2(grossLiability.igst + rcmIgst),
          cgst: round2(grossLiability.cgst + rcmCgst),
          sgst: round2(grossLiability.sgst + rcmSgst),
          cess: round2(grossLiability.cess + rcmCess)
        },
        paidThroughITC: {
          igstPaidFromIgst: setOff.itcUtilised.igstFromIgst,
          igstPaidFromCgst: setOff.itcUtilised.igstFromCgst,
          igstPaidFromSgst: setOff.itcUtilised.igstFromSgst,
          cgstPaidFromIgst: setOff.itcUtilised.cgstFromIgst,
          cgstPaidFromCgst: setOff.itcUtilised.cgstFromCgst,
          sgstPaidFromIgst: setOff.itcUtilised.sgstFromIgst,
          sgstPaidFromSgst: setOff.itcUtilised.sgstFromSgst,
          cessPaidFromCess: setOff.itcUtilised.cessFromCess
        },
        taxPaidInCash: finalCashPayable,
        interestPaidInCash: { igst: 0, cgst: 0, sgst: 0, cess: 0 },
        lateFeePaidInCash: { cgst: 0, sgst: 0 },
        totalCashPayable: totalCash
      }
    };
  }

  /**
   * 4-Way Reconciliation: BOOKS vs GSTR-1 vs GSTR-2B vs GSTR-3B
   */
  public generate4WayReconciliation(
    sales: TransactionInvoice[],
    purchases: TransactionInvoice[],
    gstr1: GSTR1Summary,
    gstr2b: GSTR2BRecord[],
    gstr3b: GSTR3BSummary
  ) {
    const bookOutwardTaxable = round2(
      sales.reduce((sum, s) => sum + (s.documentType === 'CREDIT_NOTE' ? -s.taxableValue : s.taxableValue), 0)
    );
    const bookOutwardTax = round2(
      sales.reduce((sum, s) => {
        const lineTax = (s.cgst || 0) + (s.sgst || 0) + (s.igst || 0) + (s.cess || 0);
        return sum + (s.documentType === 'CREDIT_NOTE' ? -lineTax : lineTax);
      }, 0)
    );

    const bookInwardTaxable = round2(
      purchases.reduce((sum, p) => sum + (p.documentType === 'CREDIT_NOTE' ? -p.taxableValue : p.taxableValue), 0)
    );
    const bookInwardTax = round2(
      purchases.reduce((sum, p) => {
        const lineTax = (p.cgst || 0) + (p.sgst || 0) + (p.igst || 0) + (p.cess || 0);
        return sum + (p.documentType === 'CREDIT_NOTE' ? -lineTax : lineTax);
      }, 0)
    );

    const gstr1Taxable = round2(gstr1.grossTurnover);
    const gstr1Tax = round2(gstr1.totalTaxLiability);

    const gstr2bTaxable = round2(gstr2b.reduce((sum, r) => sum + r.taxableValue, 0));
    const gstr2bTax = round2(gstr2b.reduce((sum, r) => sum + (r.cgst + r.sgst + r.igst + r.cess), 0));

    const gstr3bOutwardTaxable = round2(
      gstr3b.table3_1.outwardTaxable.taxable + gstr3b.table3_1.outwardZeroRated.taxable
    );
    const gstr3bOutwardTax = round2(
      gstr3b.table3_1.outwardTaxable.igst + gstr3b.table3_1.outwardTaxable.cgst + gstr3b.table3_1.outwardTaxable.sgst +
      gstr3b.table3_1.outwardZeroRated.igst
    );
    const gstr3bNetItc = round2(
      gstr3b.table4_ITC.netITCAvailable.igst + gstr3b.table4_ITC.netITCAvailable.cgst + gstr3b.table4_ITC.netITCAvailable.sgst
    );

    return [
      {
        stream: 'Outward Supplies (Turnover)',
        books: bookOutwardTaxable,
        gstr1: gstr1Taxable,
        gstr2b: null,
        gstr3b: gstr3bOutwardTaxable,
        status: Math.abs(bookOutwardTaxable - gstr1Taxable) <= 1 ? 'MATCHED' : 'MISMATCH',
        variance: round2(gstr1Taxable - bookOutwardTaxable),
        note: 'Sales Books reconciled against GSTR-1 turnover'
      },
      {
        stream: 'Output Tax Liability',
        books: bookOutwardTax,
        gstr1: gstr1Tax,
        gstr2b: null,
        gstr3b: gstr3bOutwardTax,
        status: Math.abs(gstr1Tax - gstr3bOutwardTax) <= 1 ? 'MATCHED' : 'MISMATCH',
        variance: round2(gstr1Tax - gstr3bOutwardTax),
        note: 'Rule 88C scrutiny check between GSTR-1 and GSTR-3B tax'
      },
      {
        stream: 'Input Tax Credit (ITC)',
        books: bookInwardTax,
        gstr1: null,
        gstr2b: gstr2bTax,
        gstr3b: gstr3bNetItc,
        status: Math.abs(gstr2bTax - gstr3bNetItc) <= 1 ? 'MATCHED' : 'REVIEW',
        variance: round2(gstr3bNetItc - gstr2bTax),
        note: 'Rule 88D scrutiny: GSTR-3B claim vs GSTR-2B available credit'
      }
    ];
  }
}

export const gstr3bEngine = new GSTR3BEngine();
