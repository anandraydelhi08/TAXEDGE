import React, { useState, useMemo } from 'react';
import {
  Building2,
  Users,
  GitCompare,
  Send,
  RefreshCw,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ArrowRight,
  ShieldCheck,
  Briefcase,
  KeyRound,
  Download,
  PlusCircle,
  FileSpreadsheet,
  Layers,
  Sparkles,
  ChevronDown,
  Sliders
} from 'lucide-react';
import { ClientMaster, GSTINMasterEntry } from '../types/client';
import { jobQueueService } from '../services/jobQueueService';
import { GstPortalCredentialsSection } from './GstPortalCredentialsSection';

interface ClientPracticeDashboardProps {
  clients: ClientMaster[];
  gstins: GSTINMasterEntry[];
  selectedClientId: string;
  selectedGstin: string;
  onSelectClientAndGstin: (clientId: string, gstin: string) => void;
  onNavigateToClientMaster: () => void;
  onNavigateToAdmin?: () => void;
  onOpenCredentialVault: (gstin?: string) => void;
  onOpenJobQueueModal: () => void;
  onSyncDirect2B: (clientId: string, gstin: string) => Promise<void>;
  isSyncing: boolean;
  isDemoMode?: boolean;
  onOpenDemoConfirm?: () => void;
}

export const ClientPracticeDashboard: React.FC<ClientPracticeDashboardProps> = ({
  clients,
  gstins,
  selectedClientId,
  selectedGstin,
  onSelectClientAndGstin,
  onNavigateToClientMaster,
  onNavigateToAdmin,
  onOpenCredentialVault,
  onOpenJobQueueModal,
  onSyncDirect2B,
  isSyncing,
  isDemoMode = false,
  onOpenDemoConfirm
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStaff, setFilterStaff] = useState<string>('ALL');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [filterFrequency, setFilterFrequency] = useState<string>('ALL');
  const [expandedCredentialsGstin, setExpandedCredentialsGstin] = useState<string | null>(null);

  // Distinct staff members
  const staffList = useMemo(() => {
    const s = new Set<string>();
    clients.forEach(c => s.add(c.assignedStaff));
    return Array.from(s);
  }, [clients]);

  // Combined Rows: each GSTIN entry mapped to its client
  const clientRows = useMemo(() => {
    return gstins.map(g => {
      const parentClient = clients.find(c => c.id === g.clientId) || {
        id: g.clientId,
        name: g.legalName,
        tradeName: g.tradeName,
        legalName: g.legalName,
        pan: g.gstin.substring(2, 12),
        primaryGstin: g.gstin,
        additionalGstins: [],
        businessType: g.businessType,
        state: g.state,
        registeredAddress: '',
        contactPerson: 'Director',
        mobile: '',
        email: '',
        assignedStaff: 'CA Rahul Sharma',
        returnFrequency: 'Monthly',
        financialYear: '2026-27',
        status: 'Active',
        createdDate: '2026-04-01'
      };

      return {
        gstinEntry: g,
        client: parentClient
      };
    });
  }, [gstins, clients]);

  // Filtered rows
  const filteredRows = useMemo(() => {
    return clientRows.filter(({ gstinEntry, client }) => {
      const q = searchQuery.toLowerCase();
      const matchesSearch =
        !q ||
        client.name.toLowerCase().includes(q) ||
        client.tradeName.toLowerCase().includes(q) ||
        gstinEntry.gstin.toLowerCase().includes(q) ||
        gstinEntry.state.toLowerCase().includes(q) ||
        client.assignedStaff.toLowerCase().includes(q);

      const matchesStaff = filterStaff === 'ALL' || client.assignedStaff === filterStaff;
      const matchesStatus = filterStatus === 'ALL' || gstinEntry.status2B === filterStatus;
      const matchesFreq = filterFrequency === 'ALL' || client.returnFrequency === filterFrequency;

      return matchesSearch && matchesStaff && matchesStatus && matchesFreq;
    });
  }, [clientRows, searchQuery, filterStaff, filterStatus, filterFrequency]);

  // Aggregate Firm Metrics
  const metrics = useMemo(() => {
    const totalClients = clients.length;
    const totalGstins = gstins.length;
    const reconciledCount = gstins.filter(g => g.status2B === 'RECONCILED' || g.status2B === 'READY_FOR_FILING').length;
    const reviewNeededCount = gstins.filter(g => g.status2B === 'REVIEW_REQUIRED').length;
    const pendingSyncCount = gstins.filter(g => g.status2B === 'NOT_IMPORTED').length;
    const totalTaxManaged = gstins.reduce((acc, g) => acc + (g.taxLiability || 0), 0);
    const totalEligibleItc = gstins.reduce((acc, g) => acc + (g.eligibleItc || 0), 0);
    const reconcilePercent = totalGstins > 0 ? Math.round((reconciledCount / totalGstins) * 100) : 0;

    return {
      totalClients,
      totalGstins,
      reconciledCount,
      reviewNeededCount,
      pendingSyncCount,
      totalTaxManaged,
      totalEligibleItc,
      reconcilePercent
    };
  }, [clients, gstins]);

  // Trigger Bulk 2B Sync for all GSTINs
  const handleSyncAllClients = () => {
    const list = gstins.map(g => {
      const c = clients.find(cl => cl.id === g.clientId);
      return {
        clientId: g.clientId,
        clientName: c?.name || g.legalName,
        gstin: g.gstin
      };
    });
    jobQueueService.enqueueBulk2BSync(list, '04-2026');
    onOpenJobQueueModal();
  };

  const getStatusBadge = (status: GSTINMasterEntry['status2B']) => {
    switch (status) {
      case 'RECONCILED':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-[#176B4D]/10 text-[#176B4D] border border-[#176B4D]/30">
            <CheckCircle2 className="w-3 h-3" /> Reconciled
          </span>
        );
      case 'READY_FOR_FILING':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-slate-500/10 text-[#6B7280] border border-slate-500/30">
            <Send className="w-3 h-3" /> Ready for Filing
          </span>
        );
      case 'REVIEW_REQUIRED':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-[#FFF8E1] text-[#B7791F] text-[#B7791F] border border-amber-500/30">
            <AlertTriangle className="w-3 h-3" /> Review Required
          </span>
        );
      case 'IMPORTING':
      case 'RECONCILING':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-[#176B4D]/10 text-[#176B4D] border border-[#176B4D]/30 animate-pulse">
            <RefreshCw className="w-3 h-3 animate-spin" /> In Progress
          </span>
        );
      case 'FILED':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-purple-500/10 text-purple-300 border border-purple-500/30">
            <ShieldCheck className="w-3 h-3" /> Filed (ARN Verified)
          </span>
        );
      case 'NOT_IMPORTED':
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-[#F8F9FA] text-[#6B7280] border border-[#E5E7EB]">
            <Clock className="w-3 h-3" /> Not Imported
          </span>
        );
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Prominent Admin Panel 1-Click Editor Launcher Banner */}
      {onNavigateToAdmin && (
        <div className="bg-gradient-to-r from-emerald-800 via-teal-800 to-slate-900 rounded-2xl p-4 sm:p-5 text-white shadow-lg border border-emerald-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center shrink-0">
              <Sliders className="w-6 h-6 text-emerald-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black tracking-tight text-white">
                  Admin Control Panel
                </h2>
                <span className="bg-emerald-400 text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                  1-Click Editor
                </span>
              </div>
              <p className="text-xs text-emerald-200 mt-0.5">
                Clients, GSTINs, Invoices, Firm Profile aur HSN Rates ko 1-Click me edit karne ke liye open karein.
              </p>
            </div>
          </div>
          <button
            onClick={onNavigateToAdmin}
            className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-black text-xs shadow-md transition shrink-0 flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Open Admin Panel</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Demo Mode Alert Banner */}
      {isDemoMode && (
        <div className="p-3 bg-[#FFF8E1] border border-[#B7791F]/30 rounded-xl flex items-center justify-between text-xs text-[#B7791F]">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-purple-400 animate-ping" />
            <span><strong>DEMO MODE ACTIVE:</strong> Sample CA firm dataset loaded for demonstration.</span>
          </div>
          <span className="text-[11px] text-purple-300">Use "Reset to Empty" in Header to clear all records.</span>
        </div>
      )}

      {/* Practice Header & Primary Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-[#E5E7EB] shadow-sm">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-[#176B4D]/10 border border-[#176B4D]/30 text-[#176B4D]">
              <Briefcase className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold text-[#202124] tracking-tight">CA Practice Multi-Client Hub</h1>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-[#176B4D]/20 text-[#176B4D] border border-[#176B4D]/30">
                  Firm Edition
                </span>
                {isDemoMode && (
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                    DEMO MODE
                  </span>
                )}
              </div>
              <p className="text-xs text-[#6B7280]">
                {clients.length > 0
                  ? `Centralized automation for ${clients.length} corporate clients and ${gstins.length} GSTIN registrations • Tax Period April 2026`
                  : 'Centralized multi-client management for Chartered Accountants • 0 Clients registered'}
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={onOpenJobQueueModal}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-[#E8F5EF] border border-[#176B4D]/40 text-[#176B4D] font-bold shadow-sm text-xs font-bold shadow-sm transition"
          >
            <Clock className="w-4 h-4 text-[#176B4D]" />
            <span>Job Queue Tray</span>
          </button>

          <button
            onClick={() => onOpenCredentialVault()}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-[#E8F5EF] border border-[#176B4D]/40 text-[#176B4D] font-bold shadow-sm text-xs font-semibold shadow-sm transition"
          >
            <KeyRound className="w-4 h-4 text-[#B7791F]" />
            <span>Credentials Vault</span>
          </button>

          <button
            onClick={onNavigateToClientMaster}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white hover:bg-[#E8F5EF] border border-[#176B4D]/40 text-[#176B4D] font-bold shadow-sm text-xs font-bold shadow-sm transition"
          >
            <Users className="w-4 h-4 text-[#176B4D]" />
            <span>Client Master</span>
          </button>

          <button
            onClick={handleSyncAllClients}
            disabled={isSyncing}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#176B4D] hover:bg-[#12543B] text-white font-bold text-xs shadow-sm transition transform active:scale-95 disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>Sync All Clients (GSTR-2B)</span>
          </button>
        </div>
      </div>

      {/* High-Level Practice Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-white border border-[#E5E7EB] flex items-center justify-between">
          <div>
            <div className="text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider">Clients / GSTINs</div>
            <div className="text-2xl font-bold text-[#202124] mt-1">
              {metrics.totalClients} <span className="text-sm font-normal text-[#6B7280]">/ {metrics.totalGstins} GSTINs</span>
            </div>
            <div className="text-[11px] text-[#176B4D] mt-1 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" /> All active & isolated
            </div>
          </div>
          <div className="p-3 rounded-xl bg-[#F8F9FA] text-[#176B4D]">
            <Building2 className="w-6 h-6" />
          </div>
        </div>

        <div className="p-4 rounded-xl bg-white border border-[#E5E7EB] flex items-center justify-between">
          <div>
            <div className="text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider">2B Reconciled</div>
            <div className="text-2xl font-bold text-[#202124] mt-1">
              {metrics.reconcilePercent}% <span className="text-xs font-medium text-[#176B4D]">({metrics.reconciledCount}/{metrics.totalGstins})</span>
            </div>
            <div className="text-[11px] text-[#6B7280] mt-1">
              {metrics.reviewNeededCount} need staff review
            </div>
          </div>
          <div className="p-3 rounded-xl bg-[#F8F9FA] text-[#6B7280]">
            <GitCompare className="w-6 h-6" />
          </div>
        </div>

        <div className="p-4 rounded-xl bg-white border border-[#E5E7EB] flex items-center justify-between">
          <div>
            <div className="text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider">Total Output Tax</div>
            <div className="text-2xl font-bold text-[#B7791F] mt-1">
              ₹{(metrics.totalTaxManaged / 100000).toFixed(2)}L
            </div>
            <div className="text-[11px] text-[#6B7280] mt-1">
              Liability across managed entities
            </div>
          </div>
          <div className="p-3 rounded-xl bg-[#F8F9FA] text-[#B7791F]">
            <FileSpreadsheet className="w-6 h-6" />
          </div>
        </div>

        <div className="p-4 rounded-xl bg-white border border-[#E5E7EB] flex items-center justify-between">
          <div>
            <div className="text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider">Eligible ITC Verified</div>
            <div className="text-2xl font-bold text-[#176B4D] mt-1">
              ₹{(metrics.totalEligibleItc / 100000).toFixed(2)}L
            </div>
            <div className="text-[11px] text-[#6B7280] mt-1">
              Auto-verified under Sec 16(2)
            </div>
          </div>
          <div className="p-3 rounded-xl bg-[#F8F9FA] text-[#176B4D]">
            <Layers className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-xl bg-white border border-[#E5E7EB] flex flex-wrap items-center justify-between gap-3">
        <div className="flex-1 min-w-[260px] relative">
          <Search className="w-4 h-4 text-[#176B4D] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search by Client Name, Trade Name, GSTIN, State or Staff..."
            className="w-full pl-9 pr-4 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#176B4D]/30"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Staff Filter */}
          <div className="flex items-center gap-1.5 text-xs text-[#6B7280] bg-[#F8F9FA] px-2.5 py-1.5 rounded-lg border border-[#E5E7EB]">
            <Users className="w-3.5 h-3.5 text-[#176B4D]" />
            <select
              value={filterStaff}
              onChange={e => setFilterStaff(e.target.value)}
              className="bg-transparent text-[#202124] text-xs focus:outline-none cursor-pointer"
            >
              <option value="ALL" className="bg-white text-[#202124]">All CA Staff</option>
              {staffList.map(s => (
                <option key={s} value={s} className="bg-white text-[#202124]">{s}</option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-1.5 text-xs text-[#6B7280] bg-[#F8F9FA] px-2.5 py-1.5 rounded-lg border border-[#E5E7EB]">
            <Filter className="w-3.5 h-3.5 text-[#176B4D]" />
            <select
              value={filterStatus}
              onChange={e => setFilterStatus(e.target.value)}
              className="bg-transparent text-[#202124] text-xs focus:outline-none cursor-pointer"
            >
              <option value="ALL" className="bg-white text-[#202124]">All 2B Statuses</option>
              <option value="RECONCILED" className="bg-white text-[#202124]">Reconciled</option>
              <option value="REVIEW_REQUIRED" className="bg-white text-[#202124]">Review Required</option>
              <option value="NOT_IMPORTED" className="bg-white text-[#202124]">Not Imported</option>
              <option value="READY_FOR_FILING" className="bg-white text-[#202124]">Ready for Filing</option>
              <option value="FILED" className="bg-white text-[#202124]">Filed</option>
            </select>
          </div>

          {/* Frequency Filter */}
          <div className="flex items-center gap-1.5 text-xs text-[#6B7280] bg-[#F8F9FA] px-2.5 py-1.5 rounded-lg border border-[#E5E7EB]">
            <select
              value={filterFrequency}
              onChange={e => setFilterFrequency(e.target.value)}
              className="bg-transparent text-[#202124] text-xs focus:outline-none cursor-pointer"
            >
              <option value="ALL" className="bg-white text-[#202124]">All Frequencies</option>
              <option value="Monthly" className="bg-white text-[#202124]">Monthly</option>
              <option value="QRMP" className="bg-white text-[#202124]">QRMP (Quarterly)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Multi-Client Table */}
      <div className="bg-white rounded-2xl border border-[#E5E7EB] overflow-hidden shadow-xl">
        <div className="px-5 py-3.5 border-b border-[#E5E7EB] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-bold text-[#202124]">Client Portfolio & GSTIN Directory</h2>
            <span className="text-xs px-2 py-0.5 rounded-full bg-[#F8F9FA] text-[#6B7280] font-mono">
              {filteredRows.length} GST Registrations
            </span>
          </div>
          <span className="text-xs text-[#6B7280]">
            Click any client to switch active workspace
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#FFFFFF]/60 text-[#6B7280] uppercase tracking-wider text-[10px] border-b border-[#E5E7EB]">
              <tr>
                <th className="py-3 px-4 font-semibold">Client / Trade Name</th>
                <th className="py-3 px-4 font-semibold">GSTIN / State</th>
                <th className="py-3 px-4 font-semibold">Period & Freq</th>
                <th className="py-3 px-4 font-semibold">Assigned Staff</th>
                <th className="py-3 px-4 font-semibold">2B Sync Status</th>
                <th className="py-3 px-4 font-semibold text-right">Tax Liability</th>
                <th className="py-3 px-4 font-semibold text-right">Eligible ITC</th>
                <th className="py-3 px-4 font-semibold text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-[#6B7280]">
              {filteredRows.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-16 text-center">
                    <div className="flex flex-col items-center justify-center space-y-3">
                      <div className="w-12 h-12 rounded-2xl bg-[#F8F9FA] border border-[#E5E7EB] text-[#6B7280] flex items-center justify-center">
                        <Users className="w-6 h-6" />
                      </div>
                      <div>
                        <div className="text-sm font-bold text-[#202124]">No clients added yet</div>
                        <p className="text-xs text-[#6B7280] mt-1 max-w-sm mx-auto">
                          Add your first client in Client Master or load sample demo data to test automated workflows.
                        </p>
                      </div>
                      <div className="flex items-center gap-2 pt-1">
                        <button
                          onClick={onNavigateToClientMaster}
                          className="px-3 py-1.5 rounded-lg bg-[#176B4D] hover:bg-[#176B4D] text-slate-950 font-bold text-xs shadow-md transition"
                        >
                          Add Your First Client
                        </button>
                        {onOpenDemoConfirm && (
                          <button
                            onClick={onOpenDemoConfirm}
                            className="px-3 py-1.5 rounded-lg bg-[#F8F9FA] hover:bg-slate-700 text-[#B7791F] font-bold text-xs border border-[#E5E7EB] transition"
                          >
                            Load Demo Data
                          </button>
                        )}
                      </div>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredRows.map(({ gstinEntry, client }) => {
                  const isCurrentActive =
                    client.id === selectedClientId && gstinEntry.gstin === selectedGstin;

                return (
                  <React.Fragment key={gstinEntry.gstin}>
                    <tr
                      className={`hover:bg-[#F8F9FA] transition cursor-pointer ${
                      isCurrentActive ? 'bg-[#E8F5EF]/20 border-l-2 border-[#176B4D]/30' : ''
                    }`}
                    onClick={() => onSelectClientAndGstin(client.id, gstinEntry.gstin)}
                  >
                    {/* Client Name */}
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-lg bg-[#F8F9FA] flex items-center justify-center text-[#6B7280] font-bold font-mono text-xs">
                          {client.id.split('-')[1] || '01'}
                        </div>
                        <div>
                          <div className="font-semibold text-[#202124] flex items-center gap-1.5">
                            {client.name}
                            {isCurrentActive && (
                              <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#176B4D]/20 text-[#176B4D] font-bold uppercase">
                                Active
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-[#6B7280]">
                            {client.tradeName || client.legalName} • {client.businessType}
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* GSTIN / State */}
                    <td className="py-3.5 px-4 font-mono">
                      <div className="font-semibold text-[#176B4D]">{gstinEntry.gstin}</div>
                      <div className="text-[11px] text-[#6B7280] font-sans">
                        {gstinEntry.state} ({gstinEntry.stateCode})
                      </div>
                    </td>

                    {/* Period & Frequency */}
                    <td className="py-3.5 px-4">
                      <div className="text-[#202124] font-medium">April 2026</div>
                      <span className={`inline-block text-[10px] px-1.5 py-0.2 rounded font-mono ${
                        client.returnFrequency === 'Monthly' ? 'bg-[#176B4D]/20 text-[#176B4D]' : 'bg-purple-500/20 text-purple-300'
                      }`}>
                        {client.returnFrequency}
                      </span>
                    </td>

                    {/* Assigned Staff */}
                    <td className="py-3.5 px-4">
                      <div className="text-[#202124] font-medium">{client.assignedStaff}</div>
                      <div className="text-[11px] text-[#6B7280]">{client.email}</div>
                    </td>

                    {/* 2B Sync Status */}
                    <td className="py-3.5 px-4">
                      <div>{getStatusBadge(gstinEntry.status2B)}</div>
                      {gstinEntry.last2bSync && (
                        <div className="text-[10px] text-[#6B7280] mt-1 font-mono">
                          Synced: {gstinEntry.last2bSync.split(' ')[0]}
                        </div>
                      )}
                    </td>

                    {/* Tax Liability */}
                    <td className="py-3.5 px-4 text-right font-mono font-medium text-[#B7791F]">
                      ₹{gstinEntry.taxLiability.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                    </td>

                    {/* Eligible ITC */}
                    <td className="py-3.5 px-4 text-right font-mono font-medium text-[#176B4D]">
                      ₹{gstinEntry.eligibleItc.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                    </td>

                    {/* Actions */}
                    <td className="py-3.5 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5" onClick={e => e.stopPropagation()}>
                        <button
                          onClick={() => onSelectClientAndGstin(client.id, gstinEntry.gstin)}
                          className="px-2.5 py-1 rounded bg-[#F8F9FA] hover:bg-slate-700 text-[#202124] text-xs font-semibold transition flex items-center gap-1"
                          title="Open workspace for this client and GSTIN"
                        >
                          <span>Open</span>
                          <ArrowRight className="w-3 h-3 text-[#176B4D]" />
                        </button>

                        <button
                          onClick={() => onSyncDirect2B(client.id, gstinEntry.gstin)}
                          disabled={isSyncing}
                          className="p-1 rounded bg-[#F8F9FA] hover:bg-slate-700 text-[#6B7280] transition"
                          title="Direct GSTR-2B Fetch via GSP"
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setExpandedCredentialsGstin(
                              expandedCredentialsGstin === gstinEntry.gstin ? null : gstinEntry.gstin
                            );
                          }}
                          className={`p-1 rounded transition flex items-center gap-0.5 ${
                            expandedCredentialsGstin === gstinEntry.gstin
                              ? 'bg-[#FFF8E1] text-[#B7791F] text-[#B7791F] border border-amber-500/40'
                              : 'bg-[#F8F9FA] hover:bg-slate-700 text-[#B7791F]'
                          }`}
                          title="Configure / View GST Portal Credentials for this GSTIN"
                        >
                          <KeyRound className="w-3.5 h-3.5" />
                          <ChevronDown
                            className={`w-3 h-3 transition-transform ${
                              expandedCredentialsGstin === gstinEntry.gstin ? 'rotate-180 text-[#B7791F]' : 'text-[#6B7280]'
                            }`}
                          />
                        </button>
                      </div>
                    </td>
                  </tr>
                  {/* Inside each GSTIN: GST Portal Credentials Section */}
                  {expandedCredentialsGstin === gstinEntry.gstin && (
                    <tr key={`${gstinEntry.gstin}-credentials`} className="bg-[#FFFFFF]/90 border-b border-[#E5E7EB]">
                      <td colSpan={8} className="p-4 bg-[#FFFFFF]/60" onClick={e => e.stopPropagation()}>
                        <div className="max-w-2xl mx-auto">
                          <GstPortalCredentialsSection
                            gstin={gstinEntry.gstin}
                            clientId={client.id}
                            compact={true}
                          />
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
                );
              }))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
