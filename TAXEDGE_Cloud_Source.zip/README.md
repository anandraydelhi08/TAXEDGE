# TAXEDGE - Enterprise GST Compliance Platform

TAXEDGE is a modern, full-stack GST compliance and automation platform built with React, TypeScript, Bun, and Express.

## Features
- **GSTR-1 & GSTR-3B Generation**: Direct government schema compliance.
- **Smart 2B Reconciliation**: Automated 5-level invoice matching.
- **10-Sheet Government Template CSV Hub**: Direct processing of multi-sheet Excel/CSV templates.
- **AI GST Legal Assistant**: Integrated GST advisory powered by Google Gemini.

## Deploying to Render.com (24/7 Free)
1. Fork or push this repository to your GitHub account.
2. In [Render.com](https://render.com), click **New +** -> **Web Service**.
3. Select this repository.
4. Render will automatically read ender.yaml and configure:
   - **Environment**: Node / Bun or Docker
   - **Build Command**: un install && bun run build
   - **Start Command**: un ./server.ts
5. Click **Create Web Service**. Your app is live 24/7 at your custom Render URL!
