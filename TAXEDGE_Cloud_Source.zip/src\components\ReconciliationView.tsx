import React, { useState } from 'react';
import {
  GitCompare,
  CheckCircle2,
  AlertTriangle,
  HelpCircle,
  ArrowRight,
  ShieldCheck,
  Download,
  RefreshCw,
  Layers,
  Upload,
  Trash2,
  Database,
  FileSpreadsheet,
  Calendar,
  Building2,
  Check,
  Search,
  Sparkles,
  Info
} from 'lucide-react';
import { ReconciliationResultItem, MatchStatus } from '../types/gst';
import { formatINR } from '../utils/taxMath';
import { DetailedFinancialSummary, ReconciliationSummaryStats } from '../services/reconciliationEngine';

interface ReconciliationViewProps {
  results: ReconciliationResultItem[];
  stats: ReconciliationSummaryStats;
  financialSummary?: DetailedFinancialSummary;
  clientName: string;
  currentGstin: string;
  period: string;
  onResolveItem: (id: string, actionNote: string) => void;
  onRefreshRecon: () => void;
  onOpenDataModal?: (target?: 'SALES' | 'PURCHASES' | 'GSTR2B') => void;
  onClearGstr2b?: () => void;
  onFetchDirect2B: () => Promise<void>;
  isFetching2B: boolean;
  direct2bMeta?: {
    generationDate: string;
    source: string;
    lastSynced: string;
    totalInvoices: number;
    totalTaxable: number;
    totalTax: number;
  };
}

export const ReconciliationView: React.FC<ReconciliationViewProps> = ({
  results,
  stats,
  financialSummary,
  clientName,
  currentGstin,
  period,
  onResolveItem,
  onRefreshRecon,
  onOpenDataModal,
  onClearGstr2b,
  onFetchDirect2B,
  isFetching2B,
  direct2bMeta
}) => {
  const [filter, setFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = results.filter(r => {
    const q = searchQuery.toLowerCase();
    const matchSearch =
      !q ||
      r.invoiceNumber.toLowerCase().includes(q) ||
      r.supplierName.toLowerCase().includes(q) ||
      r.supplierGstin.toLowerCase().includes(q);

    if (!matchSearch) return false;

    if (filter === 'ALL') return true;
    if (filter === 'EXACT') return r.matchStatus === 'EXACT_MATCH';
    if (filter === 'TAX_MISMATCH') return r.matchStatus === 'TAX_MISMATCH';
    if (filter === 'VALUE_MISMATCH') return r.matchStatus === 'VALUE_MISMATCH';
    if (filter === 'POSSIBLE_MATCH') return r.matchStatus === 'POSSIBLE_MATCH';
    if (filter === 'MISSING_2B') return r.matchStatus === 'MISSING_IN_2B';
    if (filter === 'MISSING_BOOKS') return r.matchStatus === 'MISSING_IN_BOOKS';
    if (filter === 'DUPLICATE') return r.matchStatus === 'DUPLICATE';
    if (filter === 'REVIEW_REQUIRED') return !r.resolved && r.matchStatus !== 'EXACT_MATCH';
    return true;
  });

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner & Direct 2B Fetch Action Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-[#E5E7EB] shadow-sm">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-[#E8F5EF] border border-[#176B4D]/30 text-[#176B4D]">
              <GitCompare className="w-5 h-5 text-[#176B4D]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-[#202124] tracking-tight">
                  GSTR-2B Automatic Reconciliation
                </h2>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-[#E8F5EF] text-[#176B4D] border border-[#176B4D]/30">
                  5-Level Match Hierarchy
                </span>
              </div>
              <p className="text-xs text-[#6B7280] mt-0.5">
                Client: <strong className="text-[#202124]">{clientName || 'No client selected'}</strong> • GSTIN:{' '}
                <span className="font-mono text-[#176B4D] font-bold">{currentGstin || 'No GSTINs available'}</span> • Period:{' '}
                <span className="font-mono text-[#202124] font-bold">{period}</span>
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* DIRECT GSTR-2B IMPORT (Core Requirement) */}
          <button
            onClick={onFetchDirect2B}
            disabled={isFetching2B}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#176B4D] hover:bg-[#12543B] text-white font-bold text-xs shadow-sm transition transform active:scale-95 disabled:opacity-50"
            title="Retrieve official GSTR-2B statement directly through authorized GSP API"
          >
            <RefreshCw className={`w-4 h-4 text-white ${isFetching2B ? 'animate-spin' : ''}`} />
            <span>{isFetching2B ? 'Retrieving 2B via GSP...' : 'FETCH GSTR-2B (Direct Portal)'}</span>
          </button>

          {/* Upload Fallback */}
          {onOpenDataModal && (
            <button
              onClick={() => onOpenDataModal('GSTR2B')}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white hover:bg-[#E8F5EF] text-[#176B4D] border border-[#176B4D]/40 font-bold text-xs shadow-sm transition"
              title="Upload GSTR-2B JSON or CSV fallback"
            >
              <Upload className="w-3.5 h-3.5 text-[#176B4D]" />
              <span>Upload 2B (Fallback)</span>
            </button>
          )}

          {onOpenDataModal && (
            <button
              onClick={() => onOpenDataModal('PURCHASES')}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white hover:bg-[#E8F5EF] text-[#176B4D] border border-[#176B4D]/40 font-bold text-xs shadow-sm transition"
              title="Upload purchase register from books"
            >
              <Upload className="w-3.5 h-3.5 text-[#176B4D]" />
              <span>Upload Purchases</span>
            </button>
          )}

          {onClearGstr2b && stats.total2B > 0 && (
            <button
              onClick={onClearGstr2b}
              className="flex items-center gap-1 px-3 py-2 rounded-xl bg-[#FDECEC] text-[#C62828] hover:bg-rose-100 border border-rose-200 text-xs font-bold transition shadow-sm"
              title="Clear all 2B records"
            >
              <Trash2 className="w-3.5 h-3.5 text-[#C62828]" />
              <span>Clear 2B</span>
            </button>
          )}

          <button
            onClick={onRefreshRecon}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white hover:bg-[#E8F5EF] text-[#176B4D] border border-[#176B4D]/40 font-bold text-xs shadow-sm transition"
          >
            <RefreshCw className="w-3.5 h-3.5 text-[#176B4D]" />
            <span>Re-Reconcile</span>
          </button>
        </div>
      </div>

      {/* Direct GSTR-2B Portal Metadata Card */}
      {direct2bMeta && (
        <div className="p-4 rounded-xl bg-white border border-[#E5E7EB] shadow-sm flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-[#E8F5EF] text-[#176B4D]">
              <ShieldCheck className="w-4 h-4 text-[#176B4D]" />
            </div>
            <div>
              <div className="text-[#202124] font-bold flex items-center gap-2">
                <span>Official Auto-Drafted GSTR-2B Statement</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#E8F5EF] text-[#176B4D] font-mono font-bold border border-[#176B4D]/30">
                  Active
                </span>
              </div>
              <div className="text-[#6B7280] text-[11px] mt-0.5">
                Source: <span className="text-[#202124] font-semibold">{direct2bMeta.source}</span> • Generated:{' '}
                <span className="text-[#6B7280]">{direct2bMeta.generationDate}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-5 font-mono text-[11px]">
            <div>
              <span className="text-[#6B7280] block uppercase text-[9px] font-bold">Total Invoices</span>
              <span className="text-[#202124] font-bold text-xs">{direct2bMeta.totalInvoices}</span>
            </div>
            <div>
              <span className="text-[#6B7280] block uppercase text-[9px] font-bold">Taxable Base</span>
              <span className="text-[#202124] font-bold text-xs">{formatINR(direct2bMeta.totalTaxable)}</span>
            </div>
            <div>
              <span className="text-[#6B7280] block uppercase text-[9px] font-bold">2B Tax Total</span>
              <span className="text-[#176B4D] font-bold text-xs">{formatINR(direct2bMeta.totalTax)}</span>
            </div>
            <div>
              <span className="text-[#6B7280] block uppercase text-[9px] font-bold">Last Synced</span>
              <span className="text-[#6B7280] font-semibold">{direct2bMeta.lastSynced.split(' ')[0]}</span>
            </div>
          </div>
        </div>
      )}

      {/* 5-Level Matching KPI Highlights */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
        <div className="p-3.5 rounded-xl bg-white border border-slate-200/90 shadow-2xs">
          <div className="text-[10px] uppercase font-bold text-slate-500">Match Rate</div>
          <div className="text-2xl font-black text-emerald-600 mt-0.5">
            {(stats.totalPurchases > 0 || stats.total2B > 0) ? `${stats.totalMatchRatePercent}%` : '0%'}
          </div>
          <div className="text-[10px] text-slate-400">Auto-reconciled</div>
        </div>

        <div className="p-3.5 rounded-xl bg-white border border-slate-200/90 shadow-2xs">
          <div className="text-[10px] uppercase font-bold text-slate-500">Exact Matches</div>
          <div className="text-xl font-bold text-slate-900 mt-0.5">{stats.exactMatches}</div>
          <div className="text-[10px] text-emerald-600">Level 1 & 2</div>
        </div>

        <div className="p-3.5 rounded-xl bg-white border border-slate-200/90 shadow-2xs">
          <div className="text-[10px] uppercase font-bold text-slate-500">Fuzzy Matches</div>
          <div className="text-xl font-bold text-emerald-600 mt-0.5">{stats.fuzzyMatches || 0}</div>
          <div className="text-[10px] text-slate-400">Level 5 (Preserved)</div>
        </div>

        <div className="p-3.5 rounded-xl bg-white border border-slate-200/90 shadow-2xs">
          <div className="text-[10px] uppercase font-bold text-slate-500">Tax Mismatch</div>
          <div className="text-xl font-bold text-amber-600 mt-0.5">{stats.taxMismatches}</div>
          <div className="text-[10px] text-slate-400">Level 4 Rate variance</div>
        </div>

        <div className="p-3.5 rounded-xl bg-white border border-slate-200/90 shadow-2xs">
          <div className="text-[10px] uppercase font-bold text-slate-500">Missing in 2B</div>
          <div className="text-xl font-bold text-rose-600 mt-0.5">{stats.missingIn2B}</div>
          <div className="text-[10px] text-rose-500/80">Sec 16(2)(aa) Block</div>
        </div>

        <div className="p-3.5 rounded-xl bg-white border border-slate-200/90 shadow-2xs">
          <div className="text-[10px] uppercase font-bold text-slate-500">Missing in Books</div>
          <div className="text-xl font-bold text-slate-600 mt-0.5">{stats.missingInBooks}</div>
          <div className="text-[10px] text-slate-400">Unclaimed ITC</div>
        </div>

        <div className="p-3.5 rounded-xl bg-white border border-slate-200/90 shadow-2xs">
          <div className="text-[10px] uppercase font-bold text-slate-500">Duplicates</div>
          <div className="text-xl font-bold text-amber-600 mt-0.5">{stats.duplicateCount || 0}</div>
          <div className="text-[10px] text-slate-400">Double booking check</div>
        </div>
      </div>

      {/* Requirement 10: Automatic Reconciliation Financial Summary (Comprehensive) */}
      {financialSummary && (
        <div className="p-5 rounded-2xl bg-white border border-[#E5E7EB] space-y-4 shadow-xl">
          <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
            <div className="flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5 text-[#176B4D]" />
              <h3 className="text-sm font-bold text-[#202124]">
                Statutory Financial Reconciliation & ITC Variance Summary
              </h3>
            </div>
            <span className="text-[11px] text-[#6B7280] font-mono">
              Net Tax Difference: {formatINR(financialSummary.netTaxVariance)}
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono">
              <thead className="text-[10px] uppercase text-[#6B7280] bg-[#FFFFFF]/60 border-b border-[#E5E7EB]">
                <tr>
                  <th className="py-2.5 px-3 text-left">Statutory Head</th>
                  <th className="py-2.5 px-3 text-right">As per Books (Purchase Register)</th>
                  <th className="py-2.5 px-3 text-right">As per GSTR-2B (Portal)</th>
                  <th className="py-2.5 px-3 text-right">Difference (2B - Books)</th>
                  <th className="py-2.5 px-3 text-left">Compliance Interpretation</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-[#6B7280]">
                {/* Taxable Value */}
                <tr>
                  <td className="py-2 px-3 font-semibold text-[#202124]">Base Taxable Value</td>
                  <td className="py-2 px-3 text-right">{formatINR(financialSummary.bookTaxable)}</td>
                  <td className="py-2 px-3 text-right">{formatINR(financialSummary.gstr2bTaxable)}</td>
                  <td className={`py-2 px-3 text-right font-bold ${financialSummary.diffTaxable === 0 ? 'text-[#6B7280]' : 'text-[#B7791F]'}`}>
                    {formatINR(financialSummary.diffTaxable)}
                  </td>
                  <td className="py-2 px-3 text-[#6B7280] font-sans text-[11px]">
                    {financialSummary.diffTaxable === 0
                      ? 'Base turnover reconciled.'
                      : 'Base mismatch due to supplier discounts/omissions.'}
                  </td>
                </tr>

                {/* IGST */}
                <tr>
                  <td className="py-2 px-3 font-semibold text-[#202124]">Integrated Tax (IGST)</td>
                  <td className="py-2 px-3 text-right">{formatINR(financialSummary.bookIgst)}</td>
                  <td className="py-2 px-3 text-right">{formatINR(financialSummary.gstr2bIgst)}</td>
                  <td className={`py-2 px-3 text-right font-bold ${financialSummary.diffIgst === 0 ? 'text-[#6B7280]' : 'text-[#B7791F]'}`}>
                    {formatINR(financialSummary.diffIgst)}
                  </td>
                  <td className="py-2 px-3 text-[#6B7280] font-sans text-[11px]">
                    Inter-state inward supply ITC
                  </td>
                </tr>

                {/* CGST */}
                <tr>
                  <td className="py-2 px-3 font-semibold text-[#202124]">Central Tax (CGST)</td>
                  <td className="py-2 px-3 text-right">{formatINR(financialSummary.bookCgst)}</td>
                  <td className="py-2 px-3 text-right">{formatINR(financialSummary.gstr2bCgst)}</td>
                  <td className={`py-2 px-3 text-right font-bold ${financialSummary.diffCgst === 0 ? 'text-[#6B7280]' : 'text-[#B7791F]'}`}>
                    {formatINR(financialSummary.diffCgst)}
                  </td>
                  <td className="py-2 px-3 text-[#6B7280] font-sans text-[11px]">
                    Intra-state central credit
                  </td>
                </tr>

                {/* SGST */}
                <tr>
                  <td className="py-2 px-3 font-semibold text-[#202124]">State Tax (SGST)</td>
                  <td className="py-2 px-3 text-right">{formatINR(financialSummary.bookSgst)}</td>
                  <td className="py-2 px-3 text-right">{formatINR(financialSummary.gstr2bSgst)}</td>
                  <td className={`py-2 px-3 text-right font-bold ${financialSummary.diffSgst === 0 ? 'text-[#6B7280]' : 'text-[#B7791F]'}`}>
                    {formatINR(financialSummary.diffSgst)}
                  </td>
                  <td className="py-2 px-3 text-[#6B7280] font-sans text-[11px]">
                    Intra-state state credit
                  </td>
                </tr>

                {/* CESS */}
                <tr>
                  <td className="py-2 px-3 font-semibold text-[#202124]">Compensation Cess</td>
                  <td className="py-2 px-3 text-right">{formatINR(financialSummary.bookCess)}</td>
                  <td className="py-2 px-3 text-right">{formatINR(financialSummary.gstr2bCess)}</td>
                  <td className={`py-2 px-3 text-right font-bold ${financialSummary.diffCess === 0 ? 'text-[#6B7280]' : 'text-[#B7791F]'}`}>
                    {formatINR(financialSummary.diffCess)}
                  </td>
                  <td className="py-2 px-3 text-[#6B7280] font-sans text-[11px]">
                    Specified luxury / sin goods cess
                  </td>
                </tr>

                {/* Total ITC Row */}
                <tr className="bg-[#FFFFFF]/80 font-bold border-t border-[#E5E7EB]">
                  <td className="py-2.5 px-3 text-[#176B4D]">Total Inward Tax (ITC)</td>
                  <td className="py-2.5 px-3 text-right text-[#202124]">{formatINR(financialSummary.totalBookTax)}</td>
                  <td className="py-2.5 px-3 text-right text-[#202124]">{formatINR(financialSummary.total2BTax)}</td>
                  <td className={`py-2.5 px-3 text-right ${financialSummary.netTaxVariance === 0 ? 'text-[#176B4D]' : 'text-[#B7791F]'}`}>
                    {formatINR(financialSummary.netTaxVariance)}
                  </td>
                  <td className="py-2.5 px-3 text-[#6B7280] font-sans text-[11px]">
                    {financialSummary.netTaxVariance >= 0
                      ? 'No ITC blockage under Rule 36(4).'
                      : 'Variance must be resolved prior to 3B filing.'}
                  </td>
                </tr>

                {/* Statutory ITC Breakdown */}
                <tr className="bg-[#E8F5EF]/20 text-[#176B4D]">
                  <td className="py-2 px-3 font-semibold">Eligible ITC Claimable in GSTR-3B Table 4(A)(5)</td>
                  <td className="py-2 px-3 text-right">—</td>
                  <td className="py-2 px-3 text-right font-bold text-[#176B4D]">{formatINR(financialSummary.eligibleItc)}</td>
                  <td className="py-2 px-3 text-right">—</td>
                  <td className="py-2 px-3 font-sans text-[11px] text-[#176B4D]">
                    Net eligible credit verified against Sec 17(5) and Rule 36(4)
                  </td>
                </tr>

                <tr className="bg-rose-950/20 text-rose-300">
                  <td className="py-2 px-3 font-semibold">Ineligible / Blocked ITC (Sec 17(5) + Rule 36(4))</td>
                  <td className="py-2 px-3 text-right">—</td>
                  <td className="py-2 px-3 text-right font-bold text-[#C62828]">{formatINR(financialSummary.ineligibleItc)}</td>
                  <td className="py-2 px-3 text-right">—</td>
                  <td className="py-2 px-3 font-sans text-[11px] text-rose-300">
                    Auto-reversed in Table 4(B)(1) or 4(B)(2)
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Search & Filter Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-xl bg-white border border-[#E5E7EB] shadow-sm">
        <div className="flex-1 min-w-[240px] relative">
          <Search className="w-4 h-4 text-[#176B4D] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search invoice number, vendor name, or vendor GSTIN..."
            className="w-full pl-9 pr-4 py-1.5 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-xs text-[#202124] placeholder-[#6B7280] focus:outline-none focus:border-[#176B4D]"
          />
        </div>

        {/* Filter Badges */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          {[
            { id: 'ALL', label: `All (${results.length})` },
            { id: 'EXACT', label: `Exact (${stats.exactMatches})` },
            { id: 'POSSIBLE_MATCH', label: `Fuzzy / Possible (${stats.fuzzyMatches || 0})` },
            { id: 'TAX_MISMATCH', label: `Tax Mismatch (${stats.taxMismatches})` },
            { id: 'VALUE_MISMATCH', label: `Value Mismatch (${stats.valueMismatches || 0})` },
            { id: 'MISSING_2B', label: `Missing in 2B (${stats.missingIn2B})` },
            { id: 'MISSING_BOOKS', label: `Missing in Books (${stats.missingInBooks})` },
            { id: 'REVIEW_REQUIRED', label: `Review Needed (${stats.reviewRequiredCount || 0})` }
          ].map(t => (
            <button
              key={t.id}
              onClick={() => setFilter(t.id)}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold whitespace-nowrap transition ${
                filter === t.id
                  ? 'bg-[#E8F5EF] text-[#176B4D] border border-[#176B4D]'
                  : 'bg-white hover:bg-[#E8F5EF] text-[#176B4D] border border-[#176B4D]/30'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Discrepancy Card List */}
      <div className="space-y-3">
        {results.length === 0 ? (
          <div className="p-8 sm:p-12 text-center bg-white border border-slate-200/90 rounded-3xl space-y-4 max-w-2xl mx-auto shadow-sm my-6">
            <div className="w-16 h-16 rounded-2xl bg-amber-50 text-[#D4A24C] border border-amber-200 flex items-center justify-center mx-auto shadow-2xs">
              <GitCompare className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-lg font-black text-slate-900 tracking-tight">No Reconciliation Records Available</h3>
              <p className="text-xs text-slate-500 mt-1.5 max-w-md mx-auto leading-relaxed">
                5-Level Smart Reconciliation requires your Books Purchase Register and official GSTR-2B. Upload both registers or fetch directly from the GST Portal to run matching.
              </p>
            </div>
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                onClick={onFetchDirect2B}
                disabled={isFetching2B}
                className="px-4 py-2.5 rounded-xl bg-[#0B1F44] hover:bg-[#152e61] text-white font-bold text-xs transition shadow-sm active:scale-95 cursor-pointer disabled:opacity-40"
              >
                Fetch GSTR-2B via GSP
              </button>
              {onOpenDataModal && (
                <button
                  onClick={() => onOpenDataModal('PURCHASES')}
                  className="px-4 py-2.5 rounded-xl bg-[#D4A24C] hover:bg-[#c5933d] text-slate-950 font-bold text-xs transition shadow-sm cursor-pointer active:scale-95"
                >
                  Upload Purchase / 2B CSV
                </button>
              )}
              <a
                href="/TAXEDGE_GST_TEMPLATE.xlsx"
                download="TAXEDGE_GST_TEMPLATE.xlsx"
                className="px-4 py-2.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 font-bold text-xs transition"
              >
                Download Master Template (.xlsx)
              </a>
            </div>
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-8 text-center bg-white border border-[#E5E7EB] rounded-xl text-xs text-[#6B7280]">
            No reconciliation items matching the current filter.
          </div>
        ) : (
          filtered.map(item => (
            <div
              key={item.id}
              className={`bg-white border rounded-xl p-4 transition shadow-md ${
                item.matchStatus === 'EXACT_MATCH'
                  ? 'border-[#E5E7EB]'
                  : item.matchStatus === 'POSSIBLE_MATCH'
                  ? 'border-[#176B4D]/30 bg-[#E8F5EF]/10'
                  : item.matchStatus === 'TAX_MISMATCH'
                  ? 'border-amber-500/40 bg-amber-950/10'
                  : item.matchStatus === 'VALUE_MISMATCH'
                  ? 'border-amber-500/30 bg-amber-950/10'
                  : item.matchStatus === 'MISSING_IN_2B'
                  ? 'border-rose-500/40 bg-rose-950/10'
                  : item.matchStatus === 'DUPLICATE'
                  ? 'border-purple-500/40 bg-purple-950/10'
                  : 'border-[#176B4D]/30 bg-[#E8F5EF]/10'
              }`}
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        item.matchStatus === 'EXACT_MATCH'
                          ? 'bg-[#176B4D]/20 text-[#176B4D] border border-[#176B4D]/30'
                          : item.matchStatus === 'POSSIBLE_MATCH'
                          ? 'bg-[#176B4D]/20 text-[#176B4D] border border-[#176B4D]/30'
                          : item.matchStatus === 'TAX_MISMATCH'
                          ? 'bg-[#FFF8E1] text-[#B7791F] text-[#B7791F] border border-amber-500/30'
                          : item.matchStatus === 'VALUE_MISMATCH'
                          ? 'bg-[#FFF8E1] text-[#B7791F] text-[#B7791F] border border-amber-500/30'
                          : item.matchStatus === 'MISSING_IN_2B'
                          ? 'bg-[#FDECEC] text-[#C62828] text-rose-300 border border-rose-500/30'
                          : item.matchStatus === 'DUPLICATE'
                          ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                          : 'bg-[#176B4D]/20 text-[#176B4D] border border-[#176B4D]/30'
                      }`}
                    >
                      {item.matchStatus.replace(/_/g, ' ')}
                    </span>
                    <span className="font-mono text-xs font-bold text-[#202124]">{item.invoiceNumber}</span>
                    <span className="text-xs text-[#6B7280] font-medium">• {item.supplierName}</span>
                    <span className="text-[10px] font-mono text-[#6B7280]">({item.supplierGstin})</span>
                  </div>
                  <div className="text-xs text-[#6B7280]">
                    <strong>Root Cause:</strong> {item.rootCause}
                  </div>
                  <div className="text-xs text-[#176B4D]/90 font-medium">
                    <strong>ITC Impact:</strong> {item.itcImpact}
                  </div>
                </div>

                {/* Side-by-side values */}
                <div className="flex items-center gap-6 text-xs shrink-0 bg-[#FFFFFF]/60 p-3 rounded-lg border border-[#E5E7EB]">
                  <div>
                    <div className="text-[10px] text-[#6B7280] uppercase font-semibold">In Books</div>
                    <div className="font-mono text-[#6B7280] font-medium">Taxable: {formatINR(item.bookTaxable)}</div>
                    <div className="font-mono text-[#202124] font-bold">Tax: {formatINR(item.bookTax)}</div>
                  </div>

                  <div className="border-l border-[#E5E7EB] pl-4">
                    <div className="text-[10px] text-[#6B7280] uppercase font-semibold">In GSTR-2B</div>
                    <div className="font-mono text-[#6B7280] font-medium">Taxable: {formatINR(item.gstr2bTaxable)}</div>
                    <div className="font-mono text-[#202124] font-bold">Tax: {formatINR(item.gstr2bTax)}</div>
                  </div>

                  <div className="border-l border-[#E5E7EB] pl-4 text-right">
                    <div className="text-[10px] text-[#6B7280] uppercase font-semibold">Difference</div>
                    <div
                      className={`font-mono font-bold ${
                        item.taxDifference === 0 ? 'text-[#6B7280]' : 'text-[#B7791F]'
                      }`}
                    >
                      {formatINR(item.taxDifference)}
                    </div>
                  </div>
                </div>
              </div>

              {/* Recommended Action & 1-Click Resolution */}
              {item.matchStatus !== 'EXACT_MATCH' && (
                <div className="mt-3 pt-3 border-t border-[#E5E7EB] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                  <div className="text-[#6B7280] flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 text-[#B7791F] shrink-0" />
                    <span>
                      <strong>Recommended:</strong> {item.recommendedAction}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() =>
                        onResolveItem(item.id, 'Capped ITC in GSTR-3B to GSTR-2B figure under Rule 36(4)')
                      }
                      className="px-3 py-1 rounded bg-[#F8F9FA] hover:bg-slate-700 text-[#202124] text-xs font-medium border border-[#E5E7EB] transition"
                    >
                      Accept 2B Cap
                    </button>
                    <button
                      onClick={() =>
                        onResolveItem(item.id, 'Sent automated GSTR-1 amendment notice to vendor')
                      }
                      className="px-3 py-1 rounded bg-[#176B4D] hover:bg-emerald-400 text-slate-950 text-xs font-bold transition"
                    >
                      Dispatch Vendor Notice
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};
