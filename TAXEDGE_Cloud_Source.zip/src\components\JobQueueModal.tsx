import React, { useState, useEffect } from 'react';
import {
  Clock,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Trash2,
  X,
  Server,
  Layers,
  ArrowRight
} from 'lucide-react';
import { jobQueueService } from '../services/jobQueueService';
import { BackgroundJob } from '../types/client';

interface JobQueueModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectClientAndGstin?: (clientId: string, gstin: string) => void;
}

export const JobQueueModal: React.FC<JobQueueModalProps> = ({
  isOpen,
  onClose,
  onSelectClientAndGstin
}) => {
  const [jobs, setJobs] = useState<BackgroundJob[]>([]);

  useEffect(() => {
    const unsub = jobQueueService.subscribe(updatedJobs => {
      setJobs(updatedJobs);
    });
    return unsub;
  }, []);

  if (!isOpen) return null;

  const total = jobs.length;
  const completed = jobs.filter(j => j.status === 'Completed').length;
  const processing = jobs.filter(j => j.status === 'Processing').length;
  const queued = jobs.filter(j => j.status === 'Queued').length;
  const failed = jobs.filter(j => j.status === 'Failed').length;

  return (
    <div className="fixed inset-0 z-50 bg-[#FFFFFF]/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white border border-[#E5E7EB] rounded-2xl max-w-3xl w-full max-h-[85vh] overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-5 border-b border-[#E5E7EB] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-slate-500/10 border border-slate-500/20 text-[#6B7280]">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Asynchronous Job Queue Manager
                {processing > 0 && (
                  <span className="text-[10px] px-2 py-0.5 rounded bg-[#176B4D]/20 text-[#176B4D] font-mono animate-pulse">
                    Processing {processing} Active
                  </span>
                )}
              </h2>
              <p className="text-xs text-[#6B7280]">
                Non-blocking background sync for hundreds of client GSTINs across India
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-[#6B7280] hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Aggregate Stats */}
        <div className="p-4 bg-[#FFFFFF] border-b border-[#E5E7EB] grid grid-cols-5 gap-2 text-center text-xs">
          <div className="p-2 rounded-lg bg-white border border-[#E5E7EB]">
            <div className="text-[10px] uppercase text-[#6B7280] font-semibold">Total</div>
            <div className="text-base font-bold text-white">{total}</div>
          </div>
          <div className="p-2 rounded-lg bg-[#176B4D]/10 border border-[#176B4D]/30">
            <div className="text-[10px] uppercase text-[#176B4D] font-semibold">Processing</div>
            <div className="text-base font-bold text-[#176B4D]">{processing}</div>
          </div>
          <div className="p-2 rounded-lg bg-white border border-[#E5E7EB]">
            <div className="text-[10px] uppercase text-[#6B7280] font-semibold">Queued</div>
            <div className="text-base font-bold text-[#6B7280]">{queued}</div>
          </div>
          <div className="p-2 rounded-lg bg-[#176B4D]/10 border border-[#176B4D]/30">
            <div className="text-[10px] uppercase text-[#176B4D] font-semibold">Completed</div>
            <div className="text-base font-bold text-[#176B4D]">{completed}</div>
          </div>
          <div className="p-2 rounded-lg bg-[#FDECEC] text-[#C62828] border border-rose-500/20">
            <div className="text-[10px] uppercase text-[#C62828] font-semibold">Failed</div>
            <div className="text-base font-bold text-rose-300">{failed}</div>
          </div>
        </div>

        {/* Toolbar */}
        <div className="px-5 py-2.5 bg-white border-b border-[#E5E7EB] flex items-center justify-between text-xs">
          <span className="text-[#6B7280]">
            {jobs.length === 0 ? 'No background tasks running' : `${jobs.length} jobs in queue`}
          </span>

          <div className="flex items-center gap-2">
            {failed > 0 && (
              <button
                onClick={() => jobQueueService.retryAllFailed()}
                className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#FDECEC] text-[#C62828] text-rose-300 hover:bg-[#FDECEC] text-[#C62828] border border-rose-500/30 text-[11px] font-semibold"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Retry Failed ({failed})</span>
              </button>
            )}

            <button
              onClick={() => jobQueueService.clearCompleted()}
              className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#F8F9FA] text-[#6B7280] hover:bg-slate-700 text-[11px]"
            >
              <Trash2 className="w-3 h-3" />
              <span>Clear Finished</span>
            </button>
          </div>
        </div>

        {/* Job List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5 max-h-[50vh]">
          {jobs.length === 0 ? (
            <div className="text-center py-12 text-[#6B7280] text-xs">
              <Clock className="w-8 h-8 mx-auto text-slate-600 mb-2" />
              All background tasks completed. Trigger "Sync All Clients" to run bulk 2B reconciliation.
            </div>
          ) : (
            jobs.map(job => (
              <div
                key={job.id}
                className="p-3.5 rounded-xl bg-[#FFFFFF] border border-[#E5E7EB] flex flex-col gap-2"
              >
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    {job.status === 'Processing' ? (
                      <RefreshCw className="w-4 h-4 text-[#176B4D] animate-spin" />
                    ) : job.status === 'Completed' ? (
                      <CheckCircle2 className="w-4 h-4 text-[#176B4D]" />
                    ) : job.status === 'Failed' ? (
                      <AlertTriangle className="w-4 h-4 text-[#C62828]" />
                    ) : (
                      <Clock className="w-4 h-4 text-[#176B4D]" />
                    )}

                    <div>
                      <div className="font-semibold text-white text-xs flex items-center gap-2">
                        <span>{job.clientName}</span>
                        <span className="font-mono text-[#176B4D] text-[11px] bg-white px-1.5 py-0.2 rounded">
                          {job.gstin}
                        </span>
                      </div>
                      <div className="text-[10px] text-[#6B7280]">
                        {job.type} • Period: {job.period} • Started: {job.startTime}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded font-semibold uppercase ${
                        job.status === 'Completed'
                          ? 'bg-[#176B4D]/10 text-[#176B4D]'
                          : job.status === 'Processing'
                          ? 'bg-[#176B4D]/10 text-[#176B4D]'
                          : job.status === 'Failed'
                          ? 'bg-[#FDECEC] text-[#C62828] text-rose-300'
                          : 'bg-[#F8F9FA] text-[#6B7280]'
                      }`}
                    >
                      {job.status}
                    </span>

                    {job.status === 'Failed' && (
                      <button
                        onClick={() => jobQueueService.retryJob(job.id)}
                        className="p-1 rounded bg-[#F8F9FA] hover:bg-slate-700 text-rose-300"
                        title="Retry Job"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                      </button>
                    )}

                    {onSelectClientAndGstin && job.status === 'Completed' && (
                      <button
                        onClick={() => {
                          onSelectClientAndGstin(job.clientId, job.gstin);
                          onClose();
                        }}
                        className="px-2 py-1 rounded bg-[#F8F9FA] hover:bg-slate-700 text-[#6B7280] text-[11px] flex items-center gap-1"
                        title="Open this client workspace"
                      >
                        <span>Open</span>
                        <ArrowRight className="w-3 h-3 text-[#176B4D]" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Progress Bar for Active Jobs */}
                {job.status === 'Processing' && (
                  <div className="w-full bg-[#F8F9FA] h-1.5 rounded-full overflow-hidden">
                    <div
                      className="bg-[#176B4D] h-full transition-all duration-300"
                      style={{ width: `${job.progressPercent}%` }}
                    />
                  </div>
                )}

                {/* Result or Error message */}
                {job.resultSummary && (
                  <div className="text-[11px] text-[#176B4D]/90 font-mono bg-[#E8F5EF]/20 px-2 py-1 rounded border border-emerald-900/30">
                    ✓ {job.resultSummary}
                  </div>
                )}

                {job.errorMessage && (
                  <div className="text-[11px] text-rose-300/90 font-mono bg-rose-950/20 px-2 py-1 rounded border border-rose-900/30">
                    ✕ {job.errorMessage}
                  </div>
                )}
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#FFFFFF] border-t border-[#E5E7EB] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-[#F8F9FA] hover:bg-slate-700 text-[#202124] text-xs font-bold"
          >
            Close Tray
          </button>
        </div>
      </div>
    </div>
  );
};
