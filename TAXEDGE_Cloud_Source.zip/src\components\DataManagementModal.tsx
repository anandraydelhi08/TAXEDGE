import React, { useState } from 'react';
import {
  Database,
  Trash2,
  RotateCcw,
  Upload,
  Download,
  FileSpreadsheet,
  AlertTriangle,
  CheckCircle2,
  X,
  FileText,
  Layers,
  ArrowRight,
  Sparkles,
  GitCompare,
  Plus,
  BookOpen,
  Info,
  Check,
  FileCode
} from 'lucide-react';
import {
  getSampleSalesCsv,
  getSamplePurchaseCsv,
  getSampleGstr2bCsv,
  getSampleGstr2bJson,
  triggerFileDownload,
  downloadSalesTemplate,
  downloadPurchaseTemplate,
  downloadGstr2bCsvTemplate,
  downloadGstr2bJsonTemplate,
  downloadAllStandardTemplates,
  STANDARDIZED_SCHEMAS,
  parseSalesCsv,
  parsePurchaseCsv,
  parseGstr2bCsv,
  parseExcelWorkbook,
  getOfficialGstPortalB2bSample,
  getOfficialGstPortalHsnSample,
  getOfficialGstPortalHsnB2bSample,
  getOfficialGstPortalHsnB2cSample,
  getOfficialGstPortalB2csSample,
  getOfficialGstPortalDocsSample,
  downloadGstPortalZipBundle
} from '../utils/csvParser';
import { TransactionInvoice, GSTR2BRecord } from '../types/gst';
import { formatINR } from '../utils/taxMath';
import { SalesImportSuccessBanner } from './SalesImportSuccessBanner';
import { ReturnPeriodSelector } from './ReturnPeriodSelector';

interface DataManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: TabType;
  initialTarget?: UploadTarget;
  salesCount: number;
  purchaseCount: number;
  gstr2bCount: number;
  onResetAllToEmpty: () => void;
  onResetToDemoData: () => void;
  onClearSales: () => void;
  onClearPurchases: () => void;
  onClearGstr2b: () => void;
  onImportSales: (items: TransactionInvoice[], mode: 'REPLACE' | 'APPEND') => void;
  onImportPurchases: (items: TransactionInvoice[], mode: 'REPLACE' | 'APPEND') => void;
  onImportGstr2b: (items: GSTR2BRecord[], mode: 'REPLACE' | 'APPEND') => void;
  onNavigateTo: (tab: string) => void;
  selectedFy?: string;
  selectedMonth?: string;
  onSelectFy?: (fy: string) => void;
  onSelectMonth?: (month: string) => void;
  onTriggerGstr1Upload?: () => void;
  currentGstin?: string;
}

export type TabType = 'UPLOAD' | 'TEMPLATES' | 'RESET';
export type UploadTarget = 'SALES' | 'PURCHASES' | 'GSTR2B';

export const DataManagementModal: React.FC<DataManagementModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'UPLOAD',
  initialTarget = 'SALES',
  salesCount,
  purchaseCount,
  gstr2bCount,
  onResetAllToEmpty,
  onResetToDemoData,
  onClearSales,
  onClearPurchases,
  onClearGstr2b,
  onImportSales,
  onImportPurchases,
  onImportGstr2b,
  onNavigateTo,
  selectedFy = '2026-27',
  selectedMonth = 'April',
  onSelectFy,
  onSelectMonth,
  onTriggerGstr1Upload,
  currentGstin = '07ABFFB5922Q1Z0'
}) => {
  const [activeTab, setActiveTab] = useState<TabType>(initialTab);
  const [uploadTarget, setUploadTarget] = useState<UploadTarget>(initialTarget);
  const [schemaTarget, setSchemaTarget] = useState<UploadTarget>('SALES');
  const [importMode, setImportMode] = useState<'REPLACE' | 'APPEND'>('REPLACE');
  const [csvContent, setCsvContent] = useState('');
  const [confirmingWipe, setConfirmingWipe] = useState<'ALL' | 'SALES' | 'PURCHASES' | 'GSTR2B' | null>(null);
  const [parseResult, setParseResult] = useState<{
    success: boolean;
    count: number;
    totalTaxable: number;
    preview: any[];
    errors: string[];
    formatName?: string;
  } | null>(null);
  const [statusMessage, setStatusMessage] = useState<{ type: 'SUCCESS' | 'ERROR' | 'INFO'; text: string } | null>(null);
  const [salesImportSuccess, setSalesImportSuccess] = useState<{
    financialYear: string;
    month: string;
    totalInvoices: number;
    totalTaxableValue: number;
    totalGst: number;
  } | null>(null);
  const [excelParsedInvoices, setExcelParsedInvoices] = useState<TransactionInvoice[] | null>(null);

  // Sync with initial props whenever modal opens or props change
  React.useEffect(() => {
    if (isOpen) {
      if (initialTab) setActiveTab(initialTab);
      if (initialTarget) {
        setUploadTarget(initialTarget);
        validateAndPreviewCsv(csvContent, initialTarget);
      }
      setConfirmingWipe(null);
    }
  }, [isOpen, initialTab, initialTarget]);

  if (!isOpen) return null;

  // File drop/selection handler supporting CSV, TSV, TXT, JSON, and Excel (.xlsx, .xls)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const fileName = file.name;
    const fileSizeKb = (file.size / 1024).toFixed(1);
    const isExcel = fileName.toLowerCase().endsWith('.xlsx') || fileName.toLowerCase().endsWith('.xls');

    if (isExcel) {
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const buffer = event.target?.result as ArrayBuffer;
          const excelRes = parseExcelWorkbook(buffer, {
            financialYear: selectedFy,
            month: selectedMonth,
            defaultEntity: {
              gstin: currentGstin || '07ABFFB5922Q1Z0',
              legalName: 'Practice Taxpayer Entity',
              state: 'Delhi',
              stateCode: (currentGstin || '07').substring(0, 2)
            }
          });

          if (excelRes.success && excelRes.invoices.length > 0) {
            setExcelParsedInvoices(excelRes.invoices);
            setParseResult({
              success: true,
              count: excelRes.invoices.length,
              totalTaxable: excelRes.summary.totalTaxable,
              preview: excelRes.invoices.slice(0, 5),
              errors: excelRes.errors,
              formatName: excelRes.detectedFormat
            });
            setCsvContent(`[Excel File: ${fileName} - ${excelRes.invoices.length} Invoices detected in worksheets: ${excelRes.sheetsFound.join(', ')}]`);
            setStatusMessage({
              type: 'SUCCESS',
              text: `Loaded Excel file "${fileName}"! Parsed ${excelRes.invoices.length} invoices across worksheets (${excelRes.sheetsFound.join(', ')}). Click "Confirm & Import Data Now" to load.`
            });
          } else {
            setExcelParsedInvoices(null);
            setParseResult({
              success: false,
              count: 0,
              totalTaxable: 0,
              preview: [],
              errors: excelRes.errors.length > 0 ? excelRes.errors : ['Could not find valid invoice rows in Excel workbook.']
            });
            setStatusMessage({
              type: 'ERROR',
              text: `Failed to parse Excel file: ${excelRes.errors.join(', ')}`
            });
          }
        } catch (err: any) {
          setStatusMessage({
            type: 'ERROR',
            text: `Error reading Excel workbook: ${err.message}`
          });
        }
      };
      reader.readAsArrayBuffer(file);
      e.target.value = '';
      return;
    }

    // CSV, TSV, TXT, JSON (Auto-detects comma, tab, semicolon, pipe)
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      setExcelParsedInvoices(null);
      setCsvContent(text);
      validateAndPreviewCsv(text, uploadTarget);
      setStatusMessage({
        type: 'INFO',
        text: `Loaded file "${fileName}" (${fileSizeKb} KB). Click "Confirm & Import Data Now" to save.`
      });
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleTextChange = (text: string) => {
    setCsvContent(text);
    validateAndPreviewCsv(text, uploadTarget);
  };

  const handleLoadSampleIntoBox = (target: UploadTarget = uploadTarget) => {
    let sample = '';
    if (target === 'SALES') sample = getSampleSalesCsv();
    else if (target === 'PURCHASES') sample = getSamplePurchaseCsv();
    else sample = getSampleGstr2bCsv();
    setUploadTarget(target);
    setCsvContent(sample);
    validateAndPreviewCsv(sample, target);
    setActiveTab('UPLOAD');
    setStatusMessage({
      type: 'INFO',
      text: `Loaded standardized ${target} sample data into the editor box. Click "Confirm & Import Data" to load it into the engine.`
    });
  };

  const validateAndPreviewCsv = (text: string, target: UploadTarget) => {
    if (!text.trim()) {
      setParseResult(null);
      return;
    }

    if (target === 'SALES') {
      const res = parseSalesCsv(text, {
        financialYear: selectedFy,
        month: selectedMonth,
        defaultEntity: {
          gstin: currentGstin || '07ABFFB5922Q1Z0',
          legalName: 'Practice Taxpayer Entity',
          state: 'Delhi',
          stateCode: (currentGstin || '07').substring(0, 2)
        }
      });
      if (res.success && res.data.length > 0) {
        const total = res.data.reduce((acc, curr) => acc + curr.taxableValue, 0);
        setParseResult({
          success: true,
          count: res.data.length,
          totalTaxable: total,
          preview: res.data.slice(0, 5),
          errors: res.errors,
          formatName: res.detectedFormat || 'Standard Sales Register'
        });
      } else {
        setParseResult({
          success: false,
          count: 0,
          totalTaxable: 0,
          preview: [],
          errors: res.errors.length ? res.errors : ['Invalid format or no rows detected']
        });
      }
    } else if (target === 'PURCHASES') {
      const res = parsePurchaseCsv(text);
      if (res.success && res.data.length > 0) {
        const total = res.data.reduce((acc, curr) => acc + curr.taxableValue, 0);
        setParseResult({
          success: true,
          count: res.data.length,
          totalTaxable: total,
          preview: res.data.slice(0, 3),
          errors: res.errors
        });
      } else {
        setParseResult({
          success: false,
          count: 0,
          totalTaxable: 0,
          preview: [],
          errors: res.errors.length ? res.errors : ['Invalid format or no rows detected']
        });
      }
    } else if (target === 'GSTR2B') {
      const res = parseGstr2bCsv(text);
      if (res.success && res.data.length > 0) {
        const total = res.data.reduce((acc, curr) => acc + curr.taxableValue, 0);
        setParseResult({
          success: true,
          count: res.data.length,
          totalTaxable: total,
          preview: res.data.slice(0, 3),
          errors: res.errors
        });
      } else {
        setParseResult({
          success: false,
          count: 0,
          totalTaxable: 0,
          preview: [],
          errors: res.errors.length ? res.errors : ['Invalid format or no rows detected']
        });
      }
    }
  };

  const handleDownloadTemplate = () => {
    if (uploadTarget === 'SALES') {
      downloadSalesTemplate();
    } else if (uploadTarget === 'PURCHASES') {
      downloadPurchaseTemplate();
    } else {
      downloadGstr2bCsvTemplate();
    }
    setStatusMessage({
      type: 'SUCCESS',
      text: `Downloaded standardized ${uploadTarget} CSV template! Open in Excel or text editor to prepare your local data.`
    });
  };

  const handleExecuteImport = () => {
    // 1. If direct Excel workbook was parsed:
    if (excelParsedInvoices && excelParsedInvoices.length > 0) {
      if (uploadTarget === 'SALES') {
        onImportSales(excelParsedInvoices, importMode);
        const totalTaxable = excelParsedInvoices.reduce((acc, inv) => acc + (inv.taxableValue || 0), 0);
        const totalGst = excelParsedInvoices.reduce((acc, inv) => acc + (inv.igst || 0) + (inv.cgst || 0) + (inv.sgst || 0) + (inv.cess || 0), 0);
        setSalesImportSuccess({
          financialYear: selectedFy,
          month: selectedMonth,
          totalInvoices: excelParsedInvoices.length,
          totalTaxableValue: totalTaxable,
          totalGst: totalGst
        });
        setStatusMessage({
          type: 'SUCCESS',
          text: `Successfully imported ${excelParsedInvoices.length} records from Excel Workbook (${importMode === 'REPLACE' ? 'Replaced' : 'Appended'})! Tagged with ${selectedMonth} ${selectedFy}.`
        });
        setCsvContent('');
        setExcelParsedInvoices(null);
        setParseResult(null);
        return;
      }
    }

    if (!csvContent.trim()) return;

    if (uploadTarget === 'SALES') {
      const res = parseSalesCsv(csvContent, {
        financialYear: selectedFy,
        month: selectedMonth,
        defaultEntity: {
          gstin: currentGstin || '07ABFFB5922Q1Z0',
          legalName: 'Practice Taxpayer Entity',
          state: 'Delhi',
          stateCode: (currentGstin || '07').substring(0, 2)
        }
      });
      if (res.success) {
        onImportSales(res.data, importMode);
        const isDocSummary = res.data.some((inv: any) => inv.isDocSummary || inv.fromSerial);
        const totalTaxable = res.data.reduce((acc, inv) => acc + (inv.taxableValue || 0), 0);
        const totalGst = res.data.reduce((acc, inv) => acc + (inv.igst || 0) + (inv.cgst || 0) + (inv.sgst || 0) + (inv.cess || 0), 0);
        const totalDocsCount = res.data.reduce((acc, inv: any) => acc + (inv.totalNumber || 0), 0);

        setSalesImportSuccess({
          financialYear: selectedFy,
          month: selectedMonth,
          totalInvoices: res.data.length,
          totalTaxableValue: totalTaxable,
          totalGst: totalGst
        });
        setStatusMessage({
          type: 'SUCCESS',
          text: isDocSummary
            ? `Successfully imported Table 13 Document Issue Summary (${res.data.length} Series, ${totalDocsCount.toLocaleString('en-IN')} Documents Issued)! Tagged with ${selectedMonth} ${selectedFy}.`
            : `Successfully imported ${res.data.length} sales invoices (${importMode === 'REPLACE' ? 'Replaced' : 'Appended'})! Tagged with ${selectedMonth} ${selectedFy}.`
        });
        setCsvContent('');
        setParseResult(null);
      }
    } else if (uploadTarget === 'PURCHASES') {
      const res = parsePurchaseCsv(csvContent);
      if (res.success) {
        onImportPurchases(res.data, importMode);
        setStatusMessage({
          type: 'SUCCESS',
          text: `Successfully imported ${res.data.length} purchase invoices (${importMode === 'REPLACE' ? 'Replaced' : 'Appended'})! ITC, RCM & 2B Recon ready.`
        });
        setCsvContent('');
        setParseResult(null);
      }
    } else if (uploadTarget === 'GSTR2B') {
      const res = parseGstr2bCsv(csvContent);
      if (res.success) {
        onImportGstr2b(res.data, importMode);
        setStatusMessage({
          type: 'SUCCESS',
          text: `Successfully imported ${res.data.length} GSTR-2B records (${importMode === 'REPLACE' ? 'Replaced' : 'Appended'})! Run reconciliation now.`
        });
        setCsvContent('');
        setParseResult(null);
      }
    }
  };

  // Safe Non-blocking Reset Executions (No window.confirm)
  const executeResetAll = () => {
    onResetAllToEmpty();
    setConfirmingWipe(null);
    setStatusMessage({
      type: 'INFO',
      text: 'System Reset Complete: All Sales, Purchases, and GSTR-2B records have been cleared to 0. Ready for fresh data!'
    });
  };

  const executeClearSales = () => {
    onClearSales();
    setConfirmingWipe(null);
    setStatusMessage({
      type: 'INFO',
      text: 'Sales Register cleared to 0 invoices.'
    });
  };

  const executeClearPurchases = () => {
    onClearPurchases();
    setConfirmingWipe(null);
    setStatusMessage({
      type: 'INFO',
      text: 'Purchase Register cleared to 0 invoices.'
    });
  };

  const executeClearGstr2b = () => {
    onClearGstr2b();
    setConfirmingWipe(null);
    setStatusMessage({
      type: 'INFO',
      text: 'GSTR-2B Statement records cleared to 0.'
    });
  };

  const executeReloadDemo = () => {
    onResetToDemoData();
    setConfirmingWipe(null);
    setStatusMessage({
      type: 'SUCCESS',
      text: 'April 2026 enterprise reference demo dataset restored (7 sales, 6 purchases, 6 GSTR-2B).'
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#FFFFFF]/85 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white border border-[#E5E7EB] rounded-2xl w-full max-w-4xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="px-6 py-4 bg-[#F8F9FA] border-b border-[#E5E7EB] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-slate-500 flex items-center justify-center shadow-lg shadow-emerald-950/50">
              <Database className="w-5 h-5 text-slate-950" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                Data Manager & Upload Center
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-[#176B4D]/20 text-[#176B4D] border border-[#176B4D]/30">
                  Standardized CSV & Engine
                </span>
              </h3>
              <p className="text-xs text-[#6B7280]">
                Download standardized CSV/Excel templates, upload custom business datasets, or reset data to a clean slate.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#6B7280] hover:text-white hover:bg-slate-700/50 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current State Status Bar */}
        <div className="bg-[#FFFFFF]/70 px-6 py-2.5 border-b border-[#E5E7EB] flex flex-wrap items-center justify-between text-xs text-[#6B7280] gap-2">
          <div className="flex items-center gap-3 flex-wrap">
            <span className="text-[#6B7280] font-medium">In-Memory Data:</span>
            <span className="px-2 py-0.5 rounded bg-[#F8F9FA] border border-[#E5E7EB] font-mono">
              Sales: <strong className="text-[#176B4D]">{salesCount}</strong>
            </span>
            <span className="px-2 py-0.5 rounded bg-[#F8F9FA] border border-[#E5E7EB] font-mono">
              Purchases: <strong className="text-[#176B4D]">{purchaseCount}</strong>
            </span>
            <span className="px-2 py-0.5 rounded bg-[#F8F9FA] border border-[#E5E7EB] font-mono">
              GSTR-2B: <strong className="text-purple-400">{gstr2bCount}</strong>
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('TEMPLATES')}
              className="px-2.5 py-1 rounded bg-slate-500/15 hover:bg-slate-500/25 text-[#6B7280] border border-slate-500/30 text-xs font-semibold flex items-center gap-1 transition"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Get Templates</span>
            </button>
            <button
              onClick={executeResetAll}
              className="px-2.5 py-1 rounded bg-[#FDECEC] text-[#C62828] hover:bg-[#FDECEC] text-[#C62828] text-rose-300 border border-rose-500/40 text-xs font-bold flex items-center gap-1 transition active:scale-95"
              title="Immediately wipe all registers to 0 records"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Reset to Empty</span>
            </button>
            <button
              onClick={executeReloadDemo}
              className="px-2.5 py-1 rounded bg-white hover:bg-[#E8F5EF] text-[#176B4D] border border-[#176B4D]/40 font-bold shadow-sm text-xs font-bold flex items-center gap-1 transition"
            >
              <RotateCcw className="w-3.5 h-3.5 text-[#6B7280]" />
              <span>Reload Demo</span>
            </button>
          </div>
        </div>

        {/* Tab Selection */}
        <div className="flex border-b border-[#E5E7EB] px-6 bg-white">
          <button
            onClick={() => setActiveTab('UPLOAD')}
            className={`py-3 px-4 font-semibold text-xs border-b-2 transition flex items-center gap-2 ${
              activeTab === 'UPLOAD'
                ? 'border-emerald-400 text-[#176B4D] bg-[#176B4D]/5'
                : 'border-transparent text-[#6B7280] hover:text-[#202124]'
            }`}
          >
            <Upload className="w-4 h-4" />
            <span>Upload Business Data (CSV / JSON)</span>
          </button>
          <button
            onClick={() => setActiveTab('TEMPLATES')}
            className={`py-3 px-4 font-semibold text-xs border-b-2 transition flex items-center gap-2 ${
              activeTab === 'TEMPLATES'
                ? 'border-slate-400 text-[#6B7280] bg-slate-500/5'
                : 'border-transparent text-[#6B7280] hover:text-[#202124]'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Download Standardized Templates (CSV/Excel)</span>
          </button>
          <button
            onClick={() => setActiveTab('RESET')}
            className={`py-3 px-4 font-semibold text-xs border-b-2 transition flex items-center gap-2 ${
              activeTab === 'RESET'
                ? 'border-rose-400 text-rose-300 bg-[#FDECEC] text-[#C62828]'
                : 'border-transparent text-[#6B7280] hover:text-[#202124]'
            }`}
          >
            <Trash2 className="w-4 h-4" />
            <span>Data Reset & Clean Slate</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-5">
          {/* Status Alert Banner */}
          {statusMessage && (
            <div
              className={`p-3.5 rounded-xl border text-xs flex items-center justify-between animate-fadeIn ${
                statusMessage.type === 'SUCCESS'
                  ? 'bg-[#176B4D]/15 border-[#176B4D]/30 text-emerald-200'
                  : statusMessage.type === 'ERROR'
                  ? 'bg-[#FDECEC] text-[#C62828] border-rose-500/40 text-rose-200'
                  : 'bg-[#176B4D]/15 border-[#176B4D]/30 text-emerald-200'
              }`}
            >
              <div className="flex items-center gap-2 font-medium">
                {statusMessage.type === 'SUCCESS' ? (
                  <CheckCircle2 className="w-4 h-4 text-[#176B4D] shrink-0" />
                ) : statusMessage.type === 'ERROR' ? (
                  <AlertTriangle className="w-4 h-4 text-[#C62828] shrink-0" />
                ) : (
                  <Info className="w-4 h-4 text-[#176B4D] shrink-0" />
                )}
                <span>{statusMessage.text}</span>
              </div>
              <button
                onClick={() => setStatusMessage(null)}
                className="text-[#6B7280] hover:text-white ml-2 text-xs font-semibold px-2 py-0.5 rounded bg-[#F8F9FA]"
              >
                Dismiss
              </button>
            </div>
          )}

          {/* TAB 1: UPLOAD DATA */}
          {activeTab === 'UPLOAD' && (
            <div className="space-y-4">
              {/* Sales Data Imported Successfully Banner (Requirements 3 & 4) */}
              {salesImportSuccess && (
                <SalesImportSuccessBanner
                  financialYear={salesImportSuccess.financialYear}
                  month={salesImportSuccess.month}
                  totalInvoices={salesImportSuccess.totalInvoices}
                  totalTaxableValue={salesImportSuccess.totalTaxableValue}
                  totalGst={salesImportSuccess.totalGst}
                  onUploadToGstPortal={() => {
                    if (onTriggerGstr1Upload) {
                      onTriggerGstr1Upload();
                    }
                  }}
                  onDismiss={() => setSalesImportSuccess(null)}
                />
              )}

              {/* Target Selector */}
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2 bg-[#FFFFFF] p-1 rounded-xl border border-[#E5E7EB]">
                  <button
                    onClick={() => {
                      setUploadTarget('SALES');
                      validateAndPreviewCsv(csvContent, 'SALES');
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                      uploadTarget === 'SALES'
                        ? 'bg-[#176B4D] text-slate-950 shadow'
                        : 'text-[#6B7280] hover:text-white'
                    }`}
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5" />
                    <span>1. Sales Register (GSTR-1)</span>
                  </button>

                  <button
                    onClick={() => {
                      setUploadTarget('PURCHASES');
                      validateAndPreviewCsv(csvContent, 'PURCHASES');
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                      uploadTarget === 'PURCHASES'
                        ? 'bg-[#176B4D] text-slate-950 shadow'
                        : 'text-[#6B7280] hover:text-white'
                    }`}
                  >
                    <Layers className="w-3.5 h-3.5" />
                    <span>2. Purchase Register (Books)</span>
                  </button>

                  <button
                    onClick={() => {
                      setUploadTarget('GSTR2B');
                      validateAndPreviewCsv(csvContent, 'GSTR2B');
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                      uploadTarget === 'GSTR2B'
                        ? 'bg-purple-500 text-slate-950 shadow'
                        : 'text-[#6B7280] hover:text-white'
                    }`}
                  >
                    <GitCompare className="w-3.5 h-3.5" />
                    <span>3. GSTR-2B Statement (Portal)</span>
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleLoadSampleIntoBox(uploadTarget)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#176B4D]/20 hover:bg-[#176B4D]/30 text-[#176B4D] border border-[#176B4D]/30 text-xs font-semibold transition"
                    title="Load sample format directly into text box to test without downloading"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Load Sample Data</span>
                  </button>
                  <button
                    onClick={handleDownloadTemplate}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white hover:bg-[#E8F5EF] text-[#176B4D] border border-[#176B4D]/40 font-bold shadow-sm text-xs font-bold transition"
                    title="Download standardized CSV template for this register"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download CSV Template</span>
                  </button>
                </div>
              </div>

              {/* Sales Import Return Period Selector banner */}
              {uploadTarget === 'SALES' && (
                <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-xl bg-[#FFFFFF]/80 border border-[#176B4D]/30 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-[#176B4D]/20 text-[#176B4D] border border-[#176B4D]/30">
                      GSTR-1 Return Period
                    </span>
                    <span className="text-[#6B7280]">
                      Imported sales will automatically be tagged to: <strong className="text-white font-mono">{selectedMonth} ({selectedFy})</strong>
                    </span>
                  </div>
                  {onSelectFy && onSelectMonth && (
                    <ReturnPeriodSelector
                      selectedFy={selectedFy}
                      selectedMonth={selectedMonth}
                      onSelectFy={onSelectFy}
                      onSelectMonth={onSelectMonth}
                      compact={true}
                    />
                  )}
                </div>
              )}

              {/* Official GST Portal Templates Quick-Bar */}
              {uploadTarget === 'SALES' && (
                <div className="bg-[#FFFFFF]/80 rounded-xl p-3 border border-[#E5E7EB] flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#176B4D] px-2 py-0.5 rounded bg-emerald-500/20 border border-[#176B4D]/30">
                      Official GST Templates
                    </span>
                    <span className="text-[#6B7280] text-[11px]">
                      Quick load sample or download mandated CSV format:
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5">
                    <button
                      onClick={() => {
                        const s = getOfficialGstPortalB2bSample();
                        setCsvContent(s);
                        validateAndPreviewCsv(s, 'SALES');
                      }}
                      className="px-2.5 py-1 rounded-lg bg-[#FFFFFF] hover:bg-slate-700 text-[#176B4D] border border-[#E5E7EB] text-[11px] font-semibold transition"
                      title="Load official Table 4 B2B Bills sample (b2b.csv)"
                    >
                      B2B Bills
                    </button>
                    <button
                      onClick={() => {
                        const s = getOfficialGstPortalHsnB2bSample();
                        setCsvContent(s);
                        validateAndPreviewCsv(s, 'SALES');
                      }}
                      className="px-2.5 py-1 rounded-lg bg-[#FFFFFF] hover:bg-slate-700 text-[#176B4D] border border-[#E5E7EB] text-[11px] font-semibold transition"
                      title="Load official Table 12 HSN (B2B) Registered sample (hsn_b2b.csv)"
                    >
                      HSN (B2B)
                    </button>
                    <button
                      onClick={() => {
                        const s = getOfficialGstPortalHsnB2cSample();
                        setCsvContent(s);
                        validateAndPreviewCsv(s, 'SALES');
                      }}
                      className="px-2.5 py-1 rounded-lg bg-[#FFFFFF] hover:bg-slate-700 text-[#176B4D] border border-[#E5E7EB] text-[11px] font-semibold transition"
                      title="Load official Table 12 HSN (B2C) Consumer sample (hsn_b2c.csv)"
                    >
                      HSN (B2C)
                    </button>
                    <button
                      onClick={() => {
                        const s = getOfficialGstPortalB2csSample();
                        setCsvContent(s);
                        validateAndPreviewCsv(s, 'SALES');
                      }}
                      className="px-2.5 py-1 rounded-lg bg-[#FFFFFF] hover:bg-slate-700 text-[#176B4D] border border-[#E5E7EB] text-[11px] font-semibold transition"
                      title="Load official Table 7 B2CS sample (b2cs.csv)"
                    >
                      B2C Small
                    </button>
                    <button
                      onClick={() => {
                        const s = getOfficialGstPortalDocsSample();
                        setCsvContent(s);
                        validateAndPreviewCsv(s, 'SALES');
                      }}
                      className="px-2.5 py-1 rounded-lg bg-[#FFFFFF] hover:bg-slate-700 text-[#176B4D] border border-[#E5E7EB] text-[11px] font-semibold transition"
                      title="Load official Table 13 Documents Issued sample (docs.csv)"
                    >
                      Docs Summary
                    </button>
                    <button
                      onClick={downloadGstPortalZipBundle}
                      className="px-2.5 py-1 rounded-lg bg-[#176B4D] hover:bg-emerald-400 text-slate-950 font-bold text-[11px] transition shadow flex items-center gap-1 active:scale-95"
                      title="Download complete ZIP of official GST Portal CSV Templates"
                    >
                      <Download className="w-3 h-3" />
                      <span>Download GST Templates (ZIP)</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Upload Dropzone & Paste Area */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-1 border-2 border-dashed border-[#E5E7EB] hover:border-[#176B4D]/30 rounded-xl p-5 flex flex-col items-center justify-center text-center bg-[#FFFFFF]/40 transition">
                  <Upload className="w-8 h-8 text-[#176B4D] mb-2" />
                  <div className="text-xs font-bold text-white mb-1">Choose CSV, Excel (.xlsx/.xls), or JSON</div>
                  <p className="text-[11px] text-[#6B7280] mb-3">Upload Excel Workbook, CSV, TSV, TXT, or GST Portal JSON</p>
                  <label className="cursor-pointer px-3.5 py-1.5 rounded-lg bg-[#176B4D] hover:bg-[#176B4D] text-slate-950 text-xs font-bold transition shadow-md">
                    <span>Browse Device</span>
                    <input
                      type="file"
                      accept=".csv,.tsv,.txt,.json,.xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel,text/csv,text/plain,text/tab-separated-values"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>

                <div className="md:col-span-2 flex flex-col">
                  <div className="flex items-center justify-between text-xs text-[#6B7280] mb-1">
                    <span>Or Paste Raw CSV / JSON Data directly:</span>
                    <span className="text-[10px] text-[#6B7280]">Comma-separated or JSON format</span>
                  </div>
                  <textarea
                    rows={4}
                    value={csvContent}
                    onChange={(e) => handleTextChange(e.target.value)}
                    placeholder="Paste CSV or GST Portal JSON text here (or click 'Load Sample Data' above)..."
                    className="w-full bg-[#FFFFFF] border border-[#E5E7EB] rounded-xl p-3 text-xs font-mono text-[#202124] placeholder:text-slate-600 focus:outline-none focus:border-[#176B4D]/30"
                  />
                </div>
              </div>

              {/* IMMEDIATE ONE-CLICK IMPORT ACTION BAR (Always visible directly below inputs) */}
              {csvContent.trim() && (
                <div className={`p-3.5 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md ${
                  parseResult?.success
                    ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                    : 'bg-rose-50 border-rose-300 text-rose-950'
                }`}>
                  <div className="flex items-center gap-3">
                    {parseResult?.success ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                    ) : (
                      <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
                    )}
                    <div>
                      <div className="font-bold text-xs flex items-center gap-2">
                        <span>{parseResult?.success ? `Ready to Import ${parseResult.count} Records` : 'Parsing Error Detected'}</span>
                        {parseResult?.formatName && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-200 text-emerald-900 border border-emerald-400">
                            {parseResult.formatName}
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-600 mt-0.5">
                        {parseResult?.success
                          ? `Total Taxable: ${formatINR(parseResult.totalTaxable)} • Strategy: ${importMode === 'REPLACE' ? 'Replace Existing' : 'Append'} • Tagged: ${selectedMonth} ${selectedFy}`
                          : (parseResult?.errors?.join(', ') || 'Please verify CSV format and column headers.')}
                      </div>
                    </div>
                  </div>
                  {parseResult?.success && (
                    <button
                      onClick={handleExecuteImport}
                      className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs shadow-md transition flex items-center justify-center gap-2 active:scale-95 cursor-pointer shrink-0"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Confirm & Import Data Now</span>
                    </button>
                  )}
                </div>
              )}

              {/* Import Mode: Replace vs Append */}
              <div className="flex items-center justify-between bg-[#FFFFFF]/60 p-3 rounded-xl border border-[#E5E7EB] text-xs">
                <span className="text-[#6B7280] font-medium">Import Strategy:</span>
                <div className="flex items-center gap-3">
                  <label className="flex items-center gap-1.5 cursor-pointer text-[#6B7280]">
                    <input
                      type="radio"
                      name="importMode"
                      checked={importMode === 'REPLACE'}
                      onChange={() => setImportMode('REPLACE')}
                      className="text-emerald-500 focus:ring-emerald-500"
                    />
                    <span>Replace Existing ({uploadTarget === 'SALES' ? salesCount : uploadTarget === 'PURCHASES' ? purchaseCount : gstr2bCount} records)</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer text-[#6B7280]">
                    <input
                      type="radio"
                      name="importMode"
                      checked={importMode === 'APPEND'}
                      onChange={() => setImportMode('APPEND')}
                      className="text-emerald-500 focus:ring-emerald-500"
                    />
                    <span>Append / Add To Existing</span>
                  </label>
                </div>
              </div>

              {/* Preview Box */}
              {parseResult && (
                <div className="bg-[#FFFFFF] rounded-xl p-4 border border-[#E5E7EB] space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {parseResult.success ? (
                        <CheckCircle2 className="w-4 h-4 text-[#176B4D]" />
                      ) : (
                        <AlertTriangle className="w-4 h-4 text-[#C62828]" />
                      )}
                      <span className="text-xs font-bold text-white">
                        {parseResult.success
                          ? `Ready to Import ${parseResult.count} Records`
                          : 'Parsing Errors Detected'}
                      </span>
                      {parseResult.formatName && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-[#176B4D] border border-[#176B4D]/30">
                          {parseResult.formatName}
                        </span>
                      )}
                      {parseResult.success && (
                        <span className="text-xs text-[#176B4D] font-mono">
                          (Total Taxable: {formatINR(parseResult.totalTaxable)})
                        </span>
                      )}
                    </div>

                    {parseResult.success && (
                      <button
                        onClick={handleExecuteImport}
                        className="px-4 py-1.5 rounded-lg bg-[#176B4D] hover:bg-[#176B4D] text-slate-950 font-bold text-xs shadow-md transition flex items-center gap-1.5 active:scale-95"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Confirm & Import Data</span>
                      </button>
                    )}
                  </div>

                  {parseResult.errors.length > 0 && (
                    <div className="text-xs text-[#C62828] bg-[#FDECEC] text-[#C62828] p-2.5 rounded-lg border border-rose-500/20">
                      {parseResult.errors.join(', ')}
                    </div>
                  )}

                  {parseResult.preview.length > 0 && (
                    <div className="overflow-x-auto">
                      {parseResult.preview.some((p: any) => p.isDocSummary || p.fromSerial) ? (
                        <table className="w-full text-[11px] text-left">
                          <thead>
                            <tr className="text-[#6B7280] border-b border-[#E5E7EB]">
                              <th className="py-1">Nature of Document</th>
                              <th className="py-1">Sr. No. From</th>
                              <th className="py-1">Sr. No. To</th>
                              <th className="py-1 text-right">Total Number</th>
                              <th className="py-1 text-right">Cancelled</th>
                              <th className="py-1 text-right text-[#176B4D]">Net Issued</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-800/60 font-mono text-[#6B7280]">
                            {parseResult.preview.map((p: any, idx: number) => {
                              const tot = Number(p.totalNumber || 0);
                              const can = Number(p.cancelled || 0);
                              const net = Number(p.netIssued ?? (tot - can));
                              return (
                                <tr key={idx}>
                                  <td className="py-1 font-semibold text-[#176B4D]">{p.docNature || p.descriptionPrimary}</td>
                                  <td className="py-1 font-bold text-slate-800">{p.fromSerial || '-'}</td>
                                  <td className="py-1 font-bold text-slate-800">{p.toSerial || '-'}</td>
                                  <td className="py-1 text-right font-bold text-slate-900">{tot.toLocaleString('en-IN')}</td>
                                  <td className="py-1 text-right text-amber-700">{can.toLocaleString('en-IN')}</td>
                                  <td className="py-1 text-right text-[#176B4D] font-extrabold">{net.toLocaleString('en-IN')}</td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      ) : parseResult.preview.some((p: any) => p.uqc || (p.notes && p.notes.includes('HSN Template'))) ? (
                        <table className="w-full text-[11px] text-left">
                          <thead>
                            <tr className="text-[#6B7280] border-b border-[#E5E7EB]">
                              <th className="py-1">HSN/SAC</th>
                              <th className="py-1">Description</th>
                              <th className="py-1">UQC</th>
                              <th className="py-1 text-right">Quantity</th>
                              <th className="py-1 text-right">Rate</th>
                              <th className="py-1 text-right">Taxable</th>
                              <th className="py-1 text-right">Total Tax</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-800/60 font-mono text-[#6B7280]">
                            {parseResult.preview.map((p: any, idx: number) => {
                              const isSvc = String(p.hsnSacPrimary || '').startsWith('99');
                              return (
                                <tr key={idx}>
                                  <td className="py-1 font-bold text-[#176B4D]">{p.hsnSacPrimary}</td>
                                  <td className="py-1 text-slate-700 truncate max-w-[160px]">{p.descriptionPrimary}</td>
                                  <td className="py-1 font-semibold text-slate-900">{isSvc ? 'NA' : (p.uqc || 'OTH')}</td>
                                  <td className="py-1 text-right font-bold text-slate-900">{isSvc ? 0 : (p.totalQuantity ?? 1)}</td>
                                  <td className="py-1 text-right text-slate-600">{p.gstRate}%</td>
                                  <td className="py-1 text-right text-[#176B4D] font-bold">{formatINR(p.taxableValue)}</td>
                                  <td className="py-1 text-right text-[#6B7280]">{formatINR((p.cgst || 0) + (p.sgst || 0) + (p.igst || 0) + (p.cess || 0))}</td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      ) : (
                        <table className="w-full text-[11px] text-left">
                          <thead>
                            <tr className="text-[#6B7280] border-b border-[#E5E7EB]">
                              <th className="py-1">Invoice No</th>
                              <th className="py-1">Date</th>
                              <th className="py-1">Party / GSTIN</th>
                              <th className="py-1 text-right">Taxable</th>
                              <th className="py-1 text-right">Tax</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-800/60 font-mono text-[#6B7280]">
                            {parseResult.preview.map((p: any, idx: number) => (
                              <tr key={idx}>
                                <td className="py-1 font-semibold text-slate-900">
                                  {p.invoiceNumber && !p.invoiceNumber.startsWith('B2CS/') && !p.invoiceNumber.startsWith('INV/HSN/') ? (
                                    p.invoiceNumber
                                  ) : (p as any).isB2csSummary || p.classification === 'B2C_SMALL' ? (
                                    <span className="text-amber-700 bg-amber-50 px-1 py-0.5 rounded text-[10px] font-bold">
                                      B2C Summary
                                    </span>
                                  ) : (p as any).isHsnSummary ? (
                                    <span className={`px-1 py-0.5 rounded text-[10px] font-bold ${
                                      (p as any).hsnCategory === 'B2C'
                                        ? 'text-pink-700 bg-pink-50 border border-pink-200'
                                        : 'text-purple-700 bg-purple-50 border border-purple-200'
                                    }`}>
                                      HSN ({(p as any).hsnCategory || 'B2B'}): {p.hsnSacPrimary}
                                    </span>
                                  ) : (
                                    p.invoiceNumber || '-'
                                  )}
                                </td>
                                <td className="py-1 text-[#6B7280]">{p.invoiceDate}</td>
                                <td className="py-1 truncate max-w-[200px]">{p.recipientName || p.supplierName} ({p.recipientGstin || p.supplierGstin})</td>
                                <td className="py-1 text-right text-[#176B4D]">{formatINR(p.taxableValue)}</td>
                                <td className="py-1 text-right text-[#6B7280]">{formatINR((p.cgst || 0) + (p.sgst || 0) + (p.igst || 0))}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Quick Template Banner Link */}
              <div className="bg-[#FFFFFF]/50 rounded-xl p-3 border border-[#E5E7EB] flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 text-[#6B7280]">
                  <BookOpen className="w-4 h-4 text-[#176B4D] shrink-0" />
                  <span>Need help with column names or formatting? View full schema rules & download all templates:</span>
                </div>
                <button
                  onClick={() => setActiveTab('TEMPLATES')}
                  className="px-3 py-1 rounded-lg bg-slate-500/20 hover:bg-slate-500/30 text-[#6B7280] border border-slate-500/30 font-semibold transition flex items-center gap-1 shrink-0"
                >
                  <span>Standardized Templates & Schema</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Post-Import Guided Actions */}
              <div className="bg-[#FFFFFF]/80 rounded-xl p-3.5 border border-[#E5E7EB] flex flex-wrap items-center justify-between gap-3 text-xs">
                <div className="text-[#6B7280]">
                  <span className="text-[#202124] font-semibold">Workflow Navigation:</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      onClose();
                      onNavigateTo('reconciliation');
                    }}
                    className="px-3 py-1 rounded-lg bg-white hover:bg-[#E8F5EF] text-[#176B4D] border border-[#176B4D]/40 font-bold shadow-sm font-semibold transition flex items-center gap-1"
                  >
                    <span>2B Reconciliation</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => {
                      onClose();
                      onNavigateTo('gstr1');
                    }}
                    className="px-3 py-1 rounded-lg bg-[#F8F9FA] hover:bg-slate-700 text-[#176B4D] border border-[#E5E7EB] font-semibold transition flex items-center gap-1"
                  >
                    <span>GSTR-1</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => {
                      onClose();
                      onNavigateTo('filing');
                    }}
                    className="px-3 py-1 rounded-lg bg-[#176B4D]/20 hover:bg-[#176B4D]/30 text-[#176B4D] border border-[#176B4D]/30 font-semibold transition flex items-center gap-1"
                  >
                    <span>Review & File</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: STANDARDIZED TEMPLATES (NEW COMPREHENSIVE FEATURE) */}
          {activeTab === 'TEMPLATES' && (
            <div className="space-y-5">
              {/* Header Box with Download All Button */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-slate-950/40 via-slate-900 to-slate-900 border border-slate-500/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <FileSpreadsheet className="w-4 h-4 text-[#176B4D]" />
                    <span>Standardized Engine CSV & Excel Templates</span>
                  </h4>
                  <p className="text-xs text-[#6B7280] mt-1 max-w-xl">
                    These standardized templates are pre-formatted with UTF-8 BOM encoding for perfect compatibility with Microsoft Excel, Apple Numbers, and Google Sheets.
                  </p>
                </div>
                <button
                  onClick={() => {
                    downloadAllStandardTemplates();
                    setStatusMessage({
                      type: 'SUCCESS',
                      text: 'Downloading complete template bundle (Sales, Purchases, and GSTR-2B CSVs)!'
                    });
                  }}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-slate-600 to-emerald-600 hover:from-slate-500 hover:to-emerald-500 text-slate-950 font-bold text-xs shadow-lg transition flex items-center gap-2 shrink-0 active:scale-95"
                >
                  <Download className="w-4 h-4" />
                  <span>Download All 3 Templates</span>
                </button>
              </div>

              {/* 3 Detailed Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* 1. Sales Template Card */}
                <div className="bg-[#FFFFFF]/80 rounded-xl p-4 border border-[#E5E7EB] flex flex-col justify-between space-y-4 hover:border-[#176B4D]/30 transition">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-[#176B4D] px-2 py-0.5 rounded bg-[#176B4D]/10 border border-[#176B4D]/30">
                        1. Outward Supplies
                      </span>
                      <span className="text-[10px] text-[#6B7280] font-mono">.csv</span>
                    </div>
                    <h5 className="text-xs font-bold text-white">Sales Register (GSTR-1)</h5>
                    <p className="text-[11px] text-[#6B7280] leading-relaxed">
                      Captures B2B, B2C, SEZ, and Export outward supplies. Automatically prepares Tables 4, 5, 6, 7, 9B, and 12 (HSN summary).
                    </p>
                    <div className="text-[10px] text-[#6B7280] bg-white p-2 rounded-lg font-mono">
                      invoice_number, invoice_date, recipient_gstin, taxable_value, gst_rate...
                    </div>
                  </div>

                  <div className="space-y-2 pt-2 border-t border-[#E5E7EB]">
                    <button
                      onClick={() => {
                        downloadSalesTemplate();
                        setStatusMessage({ type: 'SUCCESS', text: 'Downloaded standard_sales_register_template.csv' });
                      }}
                      className="w-full py-1.5 px-3 rounded-lg bg-[#176B4D]/20 hover:bg-[#176B4D]/30 text-[#176B4D] border border-[#176B4D]/30 text-xs font-bold transition flex items-center justify-center gap-1.5"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download Sales CSV</span>
                    </button>
                    <button
                      onClick={() => handleLoadSampleIntoBox('SALES')}
                      className="w-full py-1.5 px-3 rounded-lg bg-[#F8F9FA] hover:bg-slate-700 text-[#6B7280] text-xs font-medium transition flex items-center justify-center gap-1.5"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-[#176B4D]" />
                      <span>Load Sample into Uploader</span>
                    </button>
                  </div>
                </div>

                {/* 2. Purchase Template Card */}
                <div className="bg-[#FFFFFF]/80 rounded-xl p-4 border border-[#E5E7EB] flex flex-col justify-between space-y-4 hover:border-[#176B4D]/30 transition">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-[#176B4D] px-2 py-0.5 rounded bg-[#176B4D]/10 border border-[#176B4D]/30">
                        2. Inward Supplies
                      </span>
                      <span className="text-[10px] text-[#6B7280] font-mono">.csv</span>
                    </div>
                    <h5 className="text-xs font-bold text-white">Purchase Register (Books)</h5>
                    <p className="text-[11px] text-[#6B7280] leading-relaxed">
                      Captures inward invoices booked in your ERP/accounting. Feeds Rule 36(4) 2B Reconciliation, Section 17(5) blocked credit, and Section 9(3) RCM.
                    </p>
                    <div className="text-[10px] text-[#6B7280] bg-white p-2 rounded-lg font-mono">
                      invoice_number, supplier_gstin, taxable_value, gst_rate, is_rcm...
                    </div>
                  </div>

                  <div className="space-y-2 pt-2 border-t border-[#E5E7EB]">
                    <button
                      onClick={() => {
                        downloadPurchaseTemplate();
                        setStatusMessage({ type: 'SUCCESS', text: 'Downloaded standard_purchase_register_template.csv' });
                      }}
                      className="w-full py-1.5 px-3 rounded-lg bg-[#176B4D]/20 hover:bg-[#176B4D]/30 text-[#176B4D] border border-[#176B4D]/30 text-xs font-bold transition flex items-center justify-center gap-1.5"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download Purchase CSV</span>
                    </button>
                    <button
                      onClick={() => handleLoadSampleIntoBox('PURCHASES')}
                      className="w-full py-1.5 px-3 rounded-lg bg-[#F8F9FA] hover:bg-slate-700 text-[#6B7280] text-xs font-medium transition flex items-center justify-center gap-1.5"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-[#176B4D]" />
                      <span>Load Sample into Uploader</span>
                    </button>
                  </div>
                </div>

                {/* 3. GSTR-2B Statement Card */}
                <div className="bg-[#FFFFFF]/80 rounded-xl p-4 border border-[#E5E7EB] flex flex-col justify-between space-y-4 hover:border-purple-500/40 transition">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-purple-400 px-2 py-0.5 rounded bg-purple-500/10 border border-purple-500/20">
                        3. Portal Auto-Draft
                      </span>
                      <span className="text-[10px] text-[#6B7280] font-mono">.csv / .json</span>
                    </div>
                    <h5 className="text-xs font-bold text-white">GSTR-2B Statement</h5>
                    <p className="text-[11px] text-[#6B7280] leading-relaxed">
                      Matches the auto-drafted statement downloaded from GSTN Portal. Supports both standardized CSV and official GSTN JSON portal downloads.
                    </p>
                    <div className="text-[10px] text-[#6B7280] bg-white p-2 rounded-lg font-mono">
                      supplier_gstin, invoice_number, taxable_value, igst, cgst, sgst...
                    </div>
                  </div>

                  <div className="space-y-2 pt-2 border-t border-[#E5E7EB]">
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          downloadGstr2bCsvTemplate();
                          setStatusMessage({ type: 'SUCCESS', text: 'Downloaded standard_gstr2b_template.csv' });
                        }}
                        className="flex-1 py-1.5 px-2 rounded-lg bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/40 text-xs font-bold transition flex items-center justify-center gap-1"
                        title="Download standard GSTR-2B CSV"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>CSV</span>
                      </button>
                      <button
                        onClick={() => {
                          downloadGstr2bJsonTemplate();
                          setStatusMessage({ type: 'SUCCESS', text: 'Downloaded standard_gstr2b_gstn_sample.json' });
                        }}
                        className="flex-1 py-1.5 px-2 rounded-lg bg-[#F8F9FA] hover:bg-slate-700 text-purple-300 border border-[#E5E7EB] text-xs font-bold transition flex items-center justify-center gap-1"
                        title="Download official GSTN Portal JSON format"
                      >
                        <FileCode className="w-3.5 h-3.5" />
                        <span>GSTN JSON</span>
                      </button>
                    </div>
                    <button
                      onClick={() => handleLoadSampleIntoBox('GSTR2B')}
                      className="w-full py-1.5 px-3 rounded-lg bg-[#F8F9FA] hover:bg-slate-700 text-[#6B7280] text-xs font-medium transition flex items-center justify-center gap-1.5"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                      <span>Load Sample into Uploader</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Schema Specification Dictionary */}
              <div className="p-4 rounded-xl bg-[#FFFFFF] border border-[#E5E7EB] space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#E5E7EB] pb-3">
                  <div className="flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-[#176B4D]" />
                    <span className="text-xs font-bold text-white uppercase tracking-wider">
                      Required Field & Column Specification
                    </span>
                  </div>
                  <div className="flex items-center gap-2 bg-white p-1 rounded-lg border border-[#E5E7EB] text-xs">
                    <button
                      onClick={() => setSchemaTarget('SALES')}
                      className={`px-2.5 py-1 rounded font-semibold transition ${
                        schemaTarget === 'SALES' ? 'bg-[#176B4D] text-slate-950' : 'text-[#6B7280] hover:text-white'
                      }`}
                    >
                      Sales Schema
                    </button>
                    <button
                      onClick={() => setSchemaTarget('PURCHASES')}
                      className={`px-2.5 py-1 rounded font-semibold transition ${
                        schemaTarget === 'PURCHASES' ? 'bg-[#176B4D] text-slate-950' : 'text-[#6B7280] hover:text-white'
                      }`}
                    >
                      Purchase Schema
                    </button>
                    <button
                      onClick={() => setSchemaTarget('GSTR2B')}
                      className={`px-2.5 py-1 rounded font-semibold transition ${
                        schemaTarget === 'GSTR2B' ? 'bg-purple-500 text-slate-950' : 'text-[#6B7280] hover:text-white'
                      }`}
                    >
                      GSTR-2B Schema
                    </button>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-[#E5E7EB] text-[#6B7280]">
                        <th className="py-2 px-3 font-semibold">Column Name</th>
                        <th className="py-2 px-3 font-semibold">Status</th>
                        <th className="py-2 px-3 font-semibold">Data Type / Format</th>
                        <th className="py-2 px-3 font-semibold">Description</th>
                        <th className="py-2 px-3 font-semibold">Example Value</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 font-sans text-[#6B7280]">
                      {STANDARDIZED_SCHEMAS[schemaTarget].columns.map((col, idx) => (
                        <tr key={idx} className="hover:bg-white">
                          <td className="py-2 px-3 font-mono font-bold text-white">{col.name}</td>
                          <td className="py-2 px-3">
                            {col.required ? (
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#FDECEC] text-[#C62828] text-rose-300 border border-rose-500/30">
                                Required
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-[#F8F9FA] text-[#6B7280] border border-[#E5E7EB]">
                                Optional
                              </span>
                            )}
                          </td>
                          <td className="py-2 px-3 font-mono text-[11px] text-[#6B7280]">{col.type}</td>
                          <td className="py-2 px-3 text-[#6B7280]">{col.description}</td>
                          <td className="py-2 px-3 font-mono text-[11px] text-[#176B4D]">{col.example}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: RESET & CLEAN SLATE (RELIABLE & NON-BLOCKING) */}
          {activeTab === 'RESET' && (
            <div className="space-y-5">
              {/* Active Confirmation Banner if Wipe initiated */}
              {confirmingWipe && (
                <div className="p-4 rounded-xl bg-rose-950/50 border-2 border-rose-500/80 animate-fadeIn space-y-3">
                  <div className="flex items-center gap-2 text-rose-300">
                    <AlertTriangle className="w-5 h-5 text-[#C62828] shrink-0" />
                    <span className="text-sm font-bold">
                      {confirmingWipe === 'ALL'
                        ? 'Confirm Master Reset: Wipe ALL 3 Registers to 0?'
                        : `Confirm Clear: Wipe ${confirmingWipe} Register to 0?`}
                    </span>
                  </div>
                  <p className="text-xs text-rose-200">
                    {confirmingWipe === 'ALL'
                      ? 'This will immediately wipe all Sales invoices, Purchase invoices, and GSTR-2B statement records to empty slate (0 records). Any prior draft filings and exceptions will be reset.'
                      : `This will immediately remove all records from the ${confirmingWipe} register.`}
                  </p>
                  <div className="flex items-center gap-3 pt-1">
                    <button
                      onClick={() => {
                        if (confirmingWipe === 'ALL') executeResetAll();
                        else if (confirmingWipe === 'SALES') executeClearSales();
                        else if (confirmingWipe === 'PURCHASES') executeClearPurchases();
                        else if (confirmingWipe === 'GSTR2B') executeClearGstr2b();
                      }}
                      className="px-4 py-2 rounded-lg bg-rose-600 hover:bg-[#FDECEC] text-[#C62828] text-white font-bold text-xs shadow-md transition flex items-center gap-1.5 active:scale-95"
                    >
                      <Check className="w-4 h-4" />
                      <span>Yes, Wipe Data to 0</span>
                    </button>
                    <button
                      onClick={() => setConfirmingWipe(null)}
                      className="px-3.5 py-2 rounded-lg bg-[#F8F9FA] hover:bg-slate-700 text-[#6B7280] font-semibold text-xs border border-[#E5E7EB] transition"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}

              {/* Master Reset Section */}
              <div className="p-5 rounded-xl bg-rose-950/20 border border-rose-800/40 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-[#C62828]" />
                    <span className="text-sm font-bold text-white uppercase tracking-wider">
                      Master System Reset
                    </span>
                  </div>
                  <span className="text-xs font-mono text-[#6B7280]">
                    Total Active Records: {salesCount + purchaseCount + gstr2bCount}
                  </span>
                </div>
                <p className="text-xs text-[#6B7280] leading-relaxed">
                  Reset the entire system back to zero (100% empty slate) to start entering or uploading fresh data, or reset back to the preloaded sample demo dataset anytime. Works instantly without browser popups.
                </p>

                <div className="flex flex-wrap items-center gap-3 pt-2">
                  <button
                    onClick={() => setConfirmingWipe('ALL')}
                    className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-[#FDECEC] text-[#C62828] text-white font-bold text-xs shadow-lg shadow-rose-950/50 transition flex items-center gap-2 active:scale-95"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Reset All Data to Empty (0 Records)</span>
                  </button>

                  <button
                    onClick={executeResetAll}
                    className="px-3.5 py-2.5 rounded-xl bg-rose-900/40 hover:bg-rose-900/60 text-rose-200 border border-rose-700/50 text-xs font-bold transition flex items-center gap-1.5"
                    title="Bypass confirmation and wipe everything immediately"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Quick Wipe to 0 (Instant)</span>
                  </button>

                  <button
                    onClick={executeReloadDemo}
                    className="px-4 py-2.5 rounded-xl bg-white hover:bg-[#E8F5EF] text-[#176B4D] border border-[#176B4D]/40 font-bold shadow-sm font-bold text-xs transition flex items-center gap-2 active:scale-95"
                  >
                    <RotateCcw className="w-4 h-4 text-[#6B7280]" />
                    <span>Reload April 2026 Demo Dataset</span>
                  </button>
                </div>
              </div>

              {/* Selective Register Cleansing Section */}
              <div className="p-5 rounded-xl bg-[#FFFFFF] border border-[#E5E7EB] space-y-4">
                <div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-1">
                    Selective Register Cleansing
                  </h4>
                  <p className="text-xs text-[#6B7280]">
                    Clear individual registers if you only wish to re-upload one component without affecting the others.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* Clear Sales */}
                  <div className="p-3.5 rounded-xl bg-white border border-[#E5E7EB] flex flex-col justify-between space-y-3">
                    <div>
                      <div className="text-xs font-bold text-white mb-1">Sales Register</div>
                      <div className="text-xs text-[#6B7280] font-mono">
                        <strong className="text-[#176B4D]">{salesCount}</strong> Invoices
                      </div>
                    </div>
                    <button
                      onClick={executeClearSales}
                      className="px-3 py-1.5 rounded-lg bg-[#FDECEC] text-[#C62828] hover:bg-[#FDECEC] text-[#C62828] text-rose-300 border border-rose-500/30 text-xs font-bold flex items-center justify-center gap-1.5 transition active:scale-95"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Clear Sales to 0</span>
                    </button>
                  </div>

                  {/* Clear Purchases */}
                  <div className="p-3.5 rounded-xl bg-white border border-[#E5E7EB] flex flex-col justify-between space-y-3">
                    <div>
                      <div className="text-xs font-bold text-white mb-1">Purchase Register</div>
                      <div className="text-xs text-[#6B7280] font-mono">
                        <strong className="text-[#176B4D]">{purchaseCount}</strong> Invoices
                      </div>
                    </div>
                    <button
                      onClick={executeClearPurchases}
                      className="px-3 py-1.5 rounded-lg bg-[#FDECEC] text-[#C62828] hover:bg-[#FDECEC] text-[#C62828] text-rose-300 border border-rose-500/30 text-xs font-bold flex items-center justify-center gap-1.5 transition active:scale-95"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Clear Purchases to 0</span>
                    </button>
                  </div>

                  {/* Clear GSTR-2B */}
                  <div className="p-3.5 rounded-xl bg-white border border-[#E5E7EB] flex flex-col justify-between space-y-3">
                    <div>
                      <div className="text-xs font-bold text-white mb-1">GSTR-2B Statement</div>
                      <div className="text-xs text-[#6B7280] font-mono">
                        <strong className="text-purple-400">{gstr2bCount}</strong> Records
                      </div>
                    </div>
                    <button
                      onClick={executeClearGstr2b}
                      className="px-3 py-1.5 rounded-lg bg-[#FDECEC] text-[#C62828] hover:bg-[#FDECEC] text-[#C62828] text-rose-300 border border-rose-500/30 text-xs font-bold flex items-center justify-center gap-1.5 transition active:scale-95"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Clear 2B to 0</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-[#F8F9FA] border-t border-[#E5E7EB] flex items-center justify-between text-xs text-[#6B7280]">
          <div className="flex items-center gap-2 font-mono">
            <span>Deterministic Math • Rule 36(4) Matching • Bare Law ICAI 12th Ed</span>
          </div>
          <div className="flex items-center gap-2">
            {activeTab === 'UPLOAD' && (
              <button
                onClick={handleExecuteImport}
                disabled={!(parseResult?.success || (excelParsedInvoices && excelParsedInvoices.length > 0))}
                className={`px-4 py-1.5 rounded-lg text-white font-bold text-xs shadow-md transition flex items-center gap-1.5 active:scale-95 cursor-pointer ${
                  (parseResult?.success || (excelParsedInvoices && excelParsedInvoices.length > 0))
                    ? 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-700/30'
                    : 'bg-slate-300 text-slate-500 cursor-not-allowed opacity-50'
                }`}
                title={
                  parseResult?.success
                    ? `Confirm and import ${parseResult.count} records into ${selectedMonth} ${selectedFy}`
                    : excelParsedInvoices
                    ? `Confirm and import ${excelParsedInvoices.length} records from Excel Workbook`
                    : 'Paste CSV/JSON data or select a file to import'
                }
              >
                <Plus className="w-3.5 h-3.5" />
                <span>
                  {parseResult?.success
                    ? `Confirm & Import (${parseResult.count} Records)`
                    : excelParsedInvoices
                    ? `Confirm & Import (${excelParsedInvoices.length} Excel Records)`
                    : 'Confirm & Import Data'}
                </span>
              </button>
            )}
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-white font-bold transition cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
