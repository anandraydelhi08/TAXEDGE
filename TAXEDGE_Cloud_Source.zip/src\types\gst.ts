/**
 * GST Expert AI — Types and Domain Models
 * Bare Law (April 2026 Edition) & Indian GST Compliance Standard
 */

export type DocumentType = 'INVOICE' | 'CREDIT_NOTE' | 'DEBIT_NOTE' | 'BILL_OF_SUPPLY' | 'RECEIPT_VOUCHER';

export type SupplyType = 'INTRA_STATE' | 'INTER_STATE';

export type GSTClassification =
  | 'B2B'
  | 'B2C_LARGE'
  | 'B2C_SMALL'
  | 'EXPORT_WITH_PAYMENT'
  | 'EXPORT_WITHOUT_PAYMENT'
  | 'SEZ_WITH_PAYMENT'
  | 'SEZ_WITHOUT_PAYMENT'
  | 'DEEMED_EXPORT'
  | 'NIL_RATED'
  | 'EXEMPT'
  | 'NON_GST'
  | 'ZERO_RATED';

export type TaxTreatment = 'TAXABLE' | 'NIL_RATED' | 'EXEMPT' | 'NON_GST' | 'ZERO_RATED';

export type ITCStatus = 'ELIGIBLE' | 'INELIGIBLE' | 'PARTIALLY_ELIGIBLE' | 'REVIEW';

export type BlockedCreditReason =
  | 'SEC_17_5_A_MOTOR_VEHICLES'
  | 'SEC_17_5_B_FOOD_BEVERAGE_CATERING_HEALTH'
  | 'SEC_17_5_C_WORKS_CONTRACT_IMMOVABLE'
  | 'SEC_17_5_D_CONSTRUCTION_SELF_IMMOVABLE'
  | 'SEC_17_5_H_LOST_STOLEN_DESTROYED_GIFT_SAMPLES'
  | 'SEC_17_5_FA_CSR_EXPENDITURE'
  | 'SEC_16_4_TIME_BARRED'
  | 'RULE_37_180_DAYS_NON_PAYMENT'
  | 'RULE_37A_SUPPLIER_DEFAULT_3B'
  | 'RULE_36_4_RESTRICTED_2B_MISSING'
  | 'NONE';

export type RCMStatus = 'YES' | 'NO' | 'REVIEW';

export type RCMCategory =
  | 'GTA_GOODS_TRANSPORT'
  | 'LEGAL_ADVOCATE_SERVICES'
  | 'ARBITRAL_TRIBUNAL'
  | 'SPONSORSHIP_SERVICES'
  | 'DIRECTOR_REMUNERATION'
  | 'INSURANCE_AGENT'
  | 'RECOVERY_AGENT'
  | 'COPYRIGHT_TRANSFER'
  | 'SECURITY_SERVICES'
  | 'RENTING_MOTOR_VEHICLE'
  | 'SPECIFIED_GOODS_CASHEW_TOBACCO_COTTON'
  | 'NOT_APPLICABLE';

export type MatchStatus =
  | 'EXACT_MATCH'
  | 'PARTIAL_MATCH'
  | 'VALUE_MISMATCH'
  | 'TAX_MISMATCH'
  | 'DATE_MISMATCH'
  | 'INVOICE_MISMATCH'
  | 'SUPPLIER_GSTIN_MISMATCH'
  | 'MISSING_IN_2B'
  | 'MISSING_IN_BOOKS'
  | 'DUPLICATE'
  | 'CREDIT_NOTE_MISMATCH'
  | 'DEBIT_NOTE_MISMATCH'
  | 'POSSIBLE_MATCH'
  | 'REVIEW';

export type ExceptionSeverity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';

export interface InvoiceItem {
  id: string;
  itemDescription: string;
  hsnSac: string;
  quantity: number;
  unit: string;
  unitPrice: number;
  taxableValue: number;
  gstRate: number; // e.g. 18 for 18%
  cgst: number;
  sgst: number;
  igst: number;
  cess: number;
  total: number;
}

export interface TransactionInvoice {
  id: string;
  invoiceNumber: string;
  invoiceDate: string; // YYYY-MM-DD
  originalDocumentHash?: string;
  documentType: DocumentType;
  supplierGstin: string;
  supplierName: string;
  supplierState: string;
  supplierStateCode: string;
  recipientGstin: string;
  recipientName: string;
  recipientState: string;
  recipientStateCode: string;
  placeOfSupply: string; // 2-digit code or State name
  placeOfSupplyCode: string;
  supplyType: SupplyType;
  classification: GSTClassification;
  taxTreatment: TaxTreatment;
  hsnSacPrimary: string;
  descriptionPrimary: string;
  taxableValue: number;
  gstRate: number;
  cgst: number;
  sgst: number;
  igst: number;
  cess: number;
  totalAmount: number;
  rcm: boolean;
  rcmStatus?: RCMStatus;
  rcmCategory?: RCMCategory;
  rcmCashPaid?: boolean;
  applicableTaxRatePercent?: number;
  ecommerce: boolean;
  ecommerceOperatorGstin?: string;
  ecommerceGstin?: string;
  ecommerceOperatorName?: string;
  ecommercePlatform?: string;
  portCode?: string;
  shippingBillNumber?: string;
  shippingBillDate?: string;
  tcsDeducted?: number;
  itcEligible?: boolean;
  itcStatus: ITCStatus;
  blockedCreditReason?: BlockedCreditReason;
  itcEligibleAmount: number;
  itcIneligibleAmount: number;
  reconciliationStatus?: MatchStatus;
  gstr2bMatchedId?: string;
  confidence: number;
  reviewRequired: boolean;
  notes?: string;
  items?: InvoiceItem[];
  uqc?: string;
  totalQuantity?: number;
  isHsnSummary?: boolean;
  hsnCategory?: 'B2B' | 'B2C';
  isB2csSummary?: boolean;
  isDocSummary?: boolean;
  docNature?: string;
  fromSerial?: string;
  toSerial?: string;
  totalNumber?: number;
  cancelled?: number;
  netIssued?: number;
  originalInvoiceNumber?: string;
  originalInvoiceDate?: string;
  crDrReason?: string;
  crDrType?: 'C' | 'D';
  otherCharges?: number;
  financialYear?: string; // e.g. "2026-27"
  returnMonth?: string;   // e.g. "April"
  period?: string;        // e.g. "04-2026"
  gstr1UploadStatus?: 'PENDING' | 'UPLOADED' | 'FAILED';
  gstr1UploadRef?: string;
}

export interface GSTR2BRecord {
  id: string;
  supplierGstin: string;
  supplierName: string;
  invoiceNumber: string;
  invoiceType: 'B2B' | 'B2BA' | 'CDNR' | 'CDNRA' | 'ISD';
  invoiceDate: string;
  invoiceValue: number;
  placeOfSupply: string;
  reverseCharge: boolean;
  taxableValue: number;
  igst: number;
  cgst: number;
  sgst: number;
  cess: number;
  itcAvailable: boolean;
  itcReason?: string;
  period: string; // e.g. '042026'
  filingDate: string;
  matchStatus?: MatchStatus;
  matchedInvoiceId?: string;
  taxDifference?: number;
  taxableDifference?: number;
}

export interface ReconciliationResultItem {
  id: string;
  invoiceNumber: string;
  supplierGstin: string;
  supplierName: string;
  invoiceDate: string;
  matchStatus: MatchStatus;
  bookTaxable: number;
  bookTax: number;
  bookTotal: number;
  gstr2bTaxable: number;
  gstr2bTax: number;
  gstr2bTotal: number;
  taxableDifference: number;
  taxDifference: number;
  rootCause: string;
  itcImpact: string;
  recommendedAction: string;
  resolved: boolean;
  manualOverride?: boolean;
}

export interface GSTLawProvision {
  id: string;
  act: 'CGST_ACT' | 'IGST_ACT' | 'UTGST_ACT' | 'CGST_RULES' | 'IGST_RULES';
  chapter: string;
  sectionNumber?: string;
  ruleNumber?: string;
  title: string;
  subSection?: string;
  clauses?: string[];
  provisos?: string[];
  explanations?: string[];
  relatedRules?: string[];
  relatedSections?: string[];
  fullText: string;
  summary: string;
  amendmentDate: string;
  effectiveFrom: string;
  effectiveTo?: string;
  sourceDocument: string; // "GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)"
  sourcePage: number;
  tags: string[];
}

export interface ComplianceException {
  id: string;
  code: string;
  severity: ExceptionSeverity;
  category: 'TAX_CALCULATION' | 'GSTIN_VALIDATION' | 'POS_MISMATCH' | 'ITC_BLOCKAGE' | 'RCM_COMPLIANCE' | 'FILING_VALIDATION' | 'HSN_MISMATCH' | 'DUPLICATE';
  title: string;
  description: string;
  entityType: 'SALES_INVOICE' | 'PURCHASE_INVOICE' | 'GSTR2B' | 'GSTR1' | 'GSTR3B';
  entityId: string;
  invoiceNumber?: string;
  suggestedAction: string;
  resolved: boolean;
  resolutionNote?: string;
  resolvedAt?: string;
  timestamp: string;
}

export interface GSTR1Summary {
  period: string; // "04-2026"
  gstin: string;
  legalName: string;
  grossTurnover: number;
  b2bTaxable: number;
  b2bCount: number;
  b2bCgst: number;
  b2bSgst: number;
  b2bIgst: number;
  b2bCess: number;
  b2clTaxable: number;
  b2clCount: number;
  b2clIgst: number;
  b2csTaxable: number;
  b2csCount: number;
  b2csCgst: number;
  b2csSgst: number;
  b2csIgst: number;
  exportsTaxable: number;
  exportsCount: number;
  exportsIgst: number;
  nilExemptTurnover: number;
  creditNotesTaxable: number;
  creditNotesTax: number;
  hsnSummaryCount: number;
  b2bHsnTaxable?: number;
  b2cHsnTaxable?: number;
  totalTaxLiability: number;
  tables: {
    table4_B2B: any[];
    table5_B2CLarge: any[];
    table6_Exports: any[];
    table7_B2CSmall: any[];
    table8_NilExempt: any[];
    table9B_CreditDebitNotes: any[];
    table12_HSNSummary: any[];
    table12_HSNSummary_B2B?: any[];
    table12_HSNSummary_C2B?: any[];
    table12_HSNSummary_B2C?: any[];
    table13_DocsIssued: any[];
  };
}

export interface GSTR3BSummary {
  period: string;
  gstin: string;
  table3_1: {
    outwardTaxable: { taxable: number; igst: number; cgst: number; sgst: number; cess: number };
    outwardZeroRated: { taxable: number; igst: number; cess: number };
    otherOutwardNilExempt: { taxable: number };
    inwardRCM: { taxable: number; igst: number; cgst: number; sgst: number; cess: number };
    nonGstOutward: { taxable: number };
  };
  table4_ITC: {
    itcAvailable: {
      importGoods: { igst: number; cess: number };
      importServices: { igst: number; cess: number };
      inwardRCM: { igst: number; cgst: number; sgst: number; cess: number };
      isdCredit: { igst: number; cgst: number; sgst: number; cess: number };
      allOtherITC: { igst: number; cgst: number; sgst: number; cess: number };
    };
    itcReversed: {
      asPerRules38_42_43_and_17_5: { igst: number; cgst: number; sgst: number; cess: number };
      others: { igst: number; cgst: number; sgst: number; cess: number };
    };
    netITCAvailable: { igst: number; cgst: number; sgst: number; cess: number };
    ineligibleITC: {
      asPerSection16_4: { igst: number; cgst: number; sgst: number; cess: number };
      others: { igst: number; cgst: number; sgst: number; cess: number };
    };
  };
  table5_InwardExempt: {
    fromInterState: number;
    fromIntraState: number;
  };
  table6_1_PaymentOfTax: {
    taxPayable: { igst: number; cgst: number; sgst: number; cess: number };
    paidThroughITC: {
      igstPaidFromIgst: number;
      igstPaidFromCgst: number;
      igstPaidFromSgst: number;
      cgstPaidFromIgst: number;
      cgstPaidFromCgst: number;
      sgstPaidFromIgst: number;
      sgstPaidFromSgst: number;
      cessPaidFromCess: number;
    };
    taxPaidInCash: { igst: number; cgst: number; sgst: number; cess: number };
    interestPaidInCash: { igst: number; cgst: number; sgst: number; cess: number };
    lateFeePaidInCash: { cgst: number; sgst: number };
    totalCashPayable: number;
  };
}

export interface ECommerceReport {
  id: string;
  platform: 'AMAZON' | 'FLIPKART' | 'SWIGGY' | 'ZOMATO' | 'MEESHO' | 'SHOPIFY';
  period: string;
  operatorGstin: string;
  grossSales: number;
  salesReturn: number;
  netTaxableSales: number;
  cgstCollected: number;
  sgstCollected: number;
  igstCollected: number;
  totalTax: number;
  tcsDeductedSection52: number; // 1% (0.5% + 0.5% or 1% IGST)
  commissionDeducted: number;
  logisticsFeeDeducted: number;
  netSettlementAmount: number;
  gstr8Matched: boolean;
  booksReconciled: boolean;
  discrepancyNote?: string;
}

export interface FilingChecklistItem {
  id: string;
  label: string;
  category: 'DATA' | 'RECONCILIATION' | 'VALIDATION' | 'APPROVAL';
  status: 'COMPLETED' | 'WARNING' | 'FAILED' | 'PENDING';
  details: string;
  actionRoute?: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  actor: string;
  actorRole: 'USER' | 'AI_AGENT' | 'GST_PROVIDER' | 'SYSTEM';
  businessGstin: string;
  action: string;
  module: string;
  details: string;
  ipAddress?: string;
  payloadHash?: string;
}
