import React from 'react';
import { Send, ShieldCheck, CheckCircle2, AlertTriangle, FileText, Download, Lock, Check, Database, RotateCcw, Upload, Trash2 } from 'lucide-react';
import { GSTR1Summary, GSTR3BSummary, FilingChecklistItem } from '../types/gst';
import { formatINR } from '../utils/taxMath';
import { ClientMaster } from '../types/client';

interface FilingViewProps {
  gstr1: GSTR1Summary;
  gstr3b: GSTR3BSummary;
  readiness: { score: number; status: string; checklist: FilingChecklistItem[] };
  criticalExceptionsCount: number;
  onOpenApprovalModal: () => void;
  filingSuccessResult: any;
  currentClient?: ClientMaster | null;
  currentGstin?: string;
  onOpenDataModal?: () => void;
  onResetAllToEmpty?: () => void;
  onResetToDemoData?: () => void;
}

export const FilingView: React.FC<FilingViewProps> = ({
  gstr1,
  gstr3b,
  readiness,
  criticalExceptionsCount,
  onOpenApprovalModal,
  filingSuccessResult,
  currentClient,
  currentGstin,
  onOpenDataModal,
  onResetAllToEmpty,
  onResetToDemoData
}) => {
  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-black text-[#202124] flex items-center gap-2">
              <Send className="w-5 h-5 text-[#176B4D]" />
              GST Return Filing & Human Approval Center
            </h2>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#176B4D]/20 text-[#176B4D] font-bold border border-[#176B4D]/30">
              Statutory Gateway
            </span>
          </div>
          <p className="text-xs text-[#6B7280] mt-1">
            Filing execution layer for {currentClient?.legalName || 'Active Client'} • GSTIN: {currentGstin || '—'} • Multi-stage audit and human sign-off.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {onOpenDataModal && (
            <button
              onClick={onOpenDataModal}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-white hover:bg-[#E8F5EF] text-[#176B4D] border border-[#176B4D]/40 font-bold shadow-sm text-xs font-bold transition"
              title="Reset data or upload custom business CSVs"
            >
              <Database className="w-4 h-4 text-[#176B4D]" />
              <span>Reset / Upload Data</span>
            </button>
          )}

          {!filingSuccessResult && (
            <button
              onClick={onOpenApprovalModal}
              disabled={criticalExceptionsCount > 0}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-slate-400 hover:from-emerald-400 hover:to-slate-300 disabled:opacity-40 disabled:cursor-not-allowed text-slate-950 font-bold text-xs shadow-lg shadow-emerald-950/40 transition transform active:scale-95"
            >
              <Lock className="w-4 h-4" />
              <span>Open Human Review & Sign-Off</span>
            </button>
          )}
        </div>
      </div>

      {/* Prominent Sandbox Mode Warning Banner */}
      <div className="bg-[#FFF8E1] text-[#B7791F] border border-amber-500/30 rounded-2xl p-4 text-xs text-[#B7791F] flex items-start gap-3">
        <AlertTriangle className="w-5 h-5 text-[#B7791F] shrink-0 mt-0.5" />
        <div>
          <span className="font-bold text-amber-200 uppercase tracking-wider block">
            TEST MODE — NO ACTUAL GST RETURN HAS BEEN FILED.
          </span>
          <p className="text-[#6B7280] mt-0.5">
            The platform is integrated with the authorized GST Developer Sandbox Gateway. Returns prepared here generate simulated filing acknowledgements with cryptographic ARN hashes for validation.
          </p>
        </div>
      </div>

      {/* If already filed in this session: Show ARN Certificate Card */}
      {filingSuccessResult && (
        <div className="bg-gradient-to-br from-emerald-950/60 via-slate-900 to-slate-900 border border-[#176B4D]/30 rounded-3xl p-6 shadow-2xl space-y-4">
          <div className="flex items-center justify-between border-b border-[#176B4D]/30 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-[#176B4D]/20 text-[#176B4D] flex items-center justify-center border border-[#176B4D]/30">
                <Check className="w-7 h-7" />
              </div>
              <div>
                <h3 className="text-lg font-black text-[#202124]">
                  GST Filing Transmission Successful (Sandbox)
                </h3>
                <p className="text-xs text-[#176B4D]">
                  Acknowledgement Reference Number (ARN) issued by GST Portal Gateway
                </p>
              </div>
            </div>
            <span className="text-[11px] font-mono px-3 py-1 rounded-full bg-[#176B4D]/20 text-[#176B4D] border border-[#176B4D]/30 font-bold">
              PORTAL ACKNOWLEDGED
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="p-3 bg-[#FFFFFF]/60 rounded-xl border border-[#E5E7EB]">
              <div className="text-[10px] text-[#6B7280] uppercase font-semibold">Simulated ARN</div>
              <div className="font-mono text-[#176B4D] font-bold text-sm mt-0.5">{filingSuccessResult.arn}</div>
            </div>
            <div className="p-3 bg-[#FFFFFF]/60 rounded-xl border border-[#E5E7EB]">
              <div className="text-[10px] text-[#6B7280] uppercase font-semibold">Acknowledgement Number</div>
              <div className="font-mono text-[#202124] font-bold text-sm mt-0.5">{filingSuccessResult.acknowledgementNumber}</div>
            </div>
            <div className="p-3 bg-[#FFFFFF]/60 rounded-xl border border-[#E5E7EB]">
              <div className="text-[10px] text-[#6B7280] uppercase font-semibold">Timestamp</div>
              <div className="text-[#6B7280] font-mono mt-0.5">{new Date(filingSuccessResult.submissionDate).toLocaleString()}</div>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-[#FFFFFF] border border-[#E5E7EB] text-[11px] font-mono text-[#6B7280]">
            <strong>Payload Hash:</strong> {filingSuccessResult.hash}
          </div>
        </div>
      )}

      {/* 12-Point Filing Readiness Checklist */}
      <div className="bg-white border border-[#E5E7EB] rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-[#E5E7EB] pb-4">
          <div>
            <h3 className="text-base font-bold text-[#202124] flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-[#176B4D]" />
              12-Point Statutory Filing Readiness Checklist
            </h3>
            <p className="text-xs text-[#6B7280] mt-0.5">
              Comprehensive verification across invoice integrity, 2B matching, Section 17(5), and Rule 88C scrutiny.
            </p>
          </div>
          <div className="text-right">
            <div className="text-xl font-black text-[#176B4D]">{readiness.score}%</div>
            <div className="text-[10px] text-[#6B7280] uppercase font-bold">{readiness.status}</div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {readiness.checklist.map((item, idx) => (
            <div
              key={item.id}
              className="p-3.5 rounded-xl bg-[#F8F9FA] border border-[#E5E7EB] flex items-start justify-between gap-3 text-xs"
            >
              <div className="flex items-start gap-2.5">
                <CheckCircle2
                  className={`w-4 h-4 shrink-0 mt-0.5 ${
                    item.status === 'COMPLETED' ? 'text-[#176B4D]' : 'text-[#B7791F]'
                  }`}
                />
                <div>
                  <div className="font-semibold text-[#202124]">
                    {idx + 1}. {item.label}
                  </div>
                  <div className="text-[11px] text-[#6B7280] mt-0.5">{item.details}</div>
                </div>
              </div>
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded font-mono shrink-0 ${
                  item.status === 'COMPLETED'
                    ? 'bg-[#E8F5EF] text-[#176B4D]'
                    : 'bg-amber-950 text-[#B7791F]'
                }`}
              >
                {item.status}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
