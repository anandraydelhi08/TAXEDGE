import * as XLSX from 'xlsx';
import { TransactionInvoice, DocumentType, GSTClassification } from '../types/gst';
import { autoFixInvoiceForGstn, validateInvoiceForGstn, GstnValidationError } from '../utils/gstnPreflightValidator';
import { calculateDeterministicTax, round2 } from '../utils/taxMath';
import { gstr1Engine } from './gstr1Engine';
import {
  OFFICIAL_UQCS,
  OFFICIAL_DR_CR_REASONS,
  OFFICIAL_PORT_CODES,
  OFFICIAL_POS_LIST,
  OFFICIAL_TEMPLATE_STATES
} from '../data/gstnOfficialConstants';
import portCodesMaster from '../data/gstnOfficialPortCodes.json';

// -------------------------------------------------------------
// Type Definitions for all 6 Transaction Sheets
// -------------------------------------------------------------

export interface Gstr2CrDrNoteItem {
  id: string;
  supplierGstin: string;
  supplierName: string;
  supplierState: string;
  pos: string;
  noteNumber: string;
  noteDate: string;
  originalInvoiceNumber: string;
  originalInvoiceDate: string;
  differentialValue: number;
  igstRate: number;
  igstAmount: number;
  cgstRate: number;
  cgstAmount: number;
  sgstRate: number;
  sgstAmount: number;
  cessRate: number;
  cessAmount: number;
  otherCharges: number;
  itcEligibility: string;
  itcIgst: number;
  itcCgst: number;
  itcSgst: number;
  itcCess: number;
  noteType: 'DEBIT' | 'CREDIT';
  rcm: boolean;
  reason: string;
  preGst: boolean;
  voucherNo: string;
  voucherDate: string;
  supplyType: string;
  ineligibleSection17_5?: string;
}

export interface Gstr1AdvanceTaxItem {
  id: string;
  partyGstin: string;
  uin?: string;
  partyName: string;
  state: string;
  pos: string;
  receiptVoucherNo: string;
  receiptVoucherDate: string;
  goodsOrServices: 'GOODS' | 'SERVICES';
  hsnSac: string;
  advanceReceived: number;
  igstRate: number;
  igstAmount: number;
  cgstRate: number;
  cgstAmount: number;
  sgstRate: number;
  sgstAmount: number;
  cessRate: number;
  cessAmount: number;
  isPartyRegistered: 'Y' | 'N';
  leaseOfOldCar?: 'Y' | 'N';
}

export interface Gstr2AdvanceTaxItem {
  id: string;
  partyGstin: string;
  partyName: string;
  state: string;
  pos: string;
  paymentVoucherNo: string;
  paymentVoucherDate: string;
  goodsOrServices: 'GOODS' | 'SERVICES';
  hsnSac: string;
  advancePaid: number;
  igstRate: number;
  igstAmount: number;
  cgstRate: number;
  cgstAmount: number;
  sgstRate: number;
  sgstAmount: number;
  cessRate: number;
  cessAmount: number;
  isPartyRegistered: 'Y' | 'N';
}

export interface ParseResult {
  sales: TransactionInvoice[];
  purchases: TransactionInvoice[];
  creditDebitNotes: TransactionInvoice[];
  gstr2CrDrNotes: Gstr2CrDrNoteItem[];
  gstr1AdvanceTax: Gstr1AdvanceTaxItem[];
  gstr2AdvanceTax: Gstr2AdvanceTaxItem[];
  totalParsed: number;
  errors: string[];
}

// -------------------------------------------------------------
// Official Sheet Merges extracted directly from WEB_GST_Template.xls
// -------------------------------------------------------------

export const SALE_MERGES = [
  { s: { c: 34, r: 0 }, e: { c: 34, r: 1 } },
  { s: { c: 33, r: 0 }, e: { c: 33, r: 1 } },
  { s: { c: 0, r: 0 }, e: { c: 0, r: 1 } },
  { s: { c: 2, r: 0 }, e: { c: 2, r: 1 } },
  { s: { c: 3, r: 0 }, e: { c: 3, r: 1 } },
  { s: { c: 5, r: 0 }, e: { c: 10, r: 0 } },
  { s: { c: 13, r: 0 }, e: { c: 14, r: 0 } },
  { s: { c: 17, r: 0 }, e: { c: 18, r: 0 } },
  { s: { c: 30, r: 0 }, e: { c: 30, r: 1 } },
  { s: { c: 25, r: 0 }, e: { c: 25, r: 1 } },
  { s: { c: 21, r: 0 }, e: { c: 21, r: 1 } },
  { s: { c: 31, r: 0 }, e: { c: 31, r: 1 } },
  { s: { c: 29, r: 0 }, e: { c: 29, r: 1 } },
  { s: { c: 28, r: 0 }, e: { c: 28, r: 1 } },
  { s: { c: 24, r: 0 }, e: { c: 24, r: 1 } },
  { s: { c: 32, r: 0 }, e: { c: 32, r: 1 } },
  { s: { c: 4, r: 0 }, e: { c: 4, r: 1 } },
  { s: { c: 1, r: 0 }, e: { c: 1, r: 1 } },
  { s: { c: 11, r: 0 }, e: { c: 11, r: 1 } },
  { s: { c: 23, r: 0 }, e: { c: 23, r: 1 } },
  { s: { c: 27, r: 0 }, e: { c: 27, r: 1 } },
  { s: { c: 19, r: 0 }, e: { c: 20, r: 0 } },
  { s: { c: 22, r: 0 }, e: { c: 22, r: 1 } },
  { s: { c: 26, r: 0 }, e: { c: 26, r: 1 } },
  { s: { c: 12, r: 0 }, e: { c: 12, r: 1 } },
  { s: { c: 15, r: 0 }, e: { c: 16, r: 0 } }
];

export const PURCHASE_MERGES = [
  { s: { c: 21, r: 0 }, e: { c: 21, r: 1 } },
  { s: { c: 31, r: 0 }, e: { c: 31, r: 1 } },
  { s: { c: 10, r: 0 }, e: { c: 10, r: 1 } },
  { s: { c: 18, r: 0 }, e: { c: 19, r: 0 } },
  { s: { c: 27, r: 0 }, e: { c: 27, r: 1 } },
  { s: { c: 28, r: 0 }, e: { c: 28, r: 1 } },
  { s: { c: 0, r: 0 }, e: { c: 0, r: 1 } },
  { s: { c: 1, r: 0 }, e: { c: 1, r: 1 } },
  { s: { c: 2, r: 0 }, e: { c: 2, r: 1 } },
  { s: { c: 4, r: 0 }, e: { c: 9, r: 0 } },
  { s: { c: 12, r: 0 }, e: { c: 13, r: 0 } },
  { s: { c: 22, r: 0 }, e: { c: 25, r: 0 } },
  { s: { c: 11, r: 0 }, e: { c: 11, r: 1 } },
  { s: { c: 14, r: 0 }, e: { c: 15, r: 0 } },
  { s: { c: 16, r: 0 }, e: { c: 17, r: 0 } },
  { s: { c: 3, r: 0 }, e: { c: 3, r: 1 } },
  { s: { c: 32, r: 0 }, e: { c: 32, r: 1 } },
  { s: { c: 29, r: 0 }, e: { c: 29, r: 1 } },
  { s: { c: 30, r: 0 }, e: { c: 30, r: 1 } },
  { s: { c: 26, r: 0 }, e: { c: 26, r: 1 } },
  { s: { c: 20, r: 0 }, e: { c: 20, r: 1 } }
];

export const GSTR1_CR_DR_MERGES = [
  { s: { c: 30, r: 0 }, e: { c: 30, r: 1 } },
  { s: { c: 3, r: 0 }, e: { c: 3, r: 1 } },
  { s: { c: 36, r: 0 }, e: { c: 36, r: 1 } },
  { s: { c: 33, r: 0 }, e: { c: 33, r: 1 } },
  { s: { c: 34, r: 0 }, e: { c: 34, r: 1 } },
  { s: { c: 35, r: 0 }, e: { c: 35, r: 1 } },
  { s: { c: 22, r: 0 }, e: { c: 22, r: 1 } },
  { s: { c: 23, r: 0 }, e: { c: 23, r: 1 } },
  { s: { c: 24, r: 0 }, e: { c: 24, r: 1 } },
  { s: { c: 25, r: 0 }, e: { c: 25, r: 1 } },
  { s: { c: 28, r: 0 }, e: { c: 28, r: 1 } },
  { s: { c: 31, r: 0 }, e: { c: 31, r: 1 } },
  { s: { c: 29, r: 0 }, e: { c: 29, r: 1 } },
  { s: { c: 0, r: 0 }, e: { c: 0, r: 1 } },
  { s: { c: 2, r: 0 }, e: { c: 2, r: 1 } },
  { s: { c: 5, r: 0 }, e: { c: 6, r: 0 } },
  { s: { c: 7, r: 0 }, e: { c: 8, r: 0 } },
  { s: { c: 4, r: 0 }, e: { c: 4, r: 1 } },
  { s: { c: 14, r: 0 }, e: { c: 15, r: 0 } },
  { s: { c: 9, r: 0 }, e: { c: 9, r: 1 } },
  { s: { c: 13, r: 0 }, e: { c: 13, r: 1 } },
  { s: { c: 16, r: 0 }, e: { c: 17, r: 0 } },
  { s: { c: 1, r: 0 }, e: { c: 1, r: 1 } },
  { s: { c: 32, r: 0 }, e: { c: 32, r: 1 } },
  { s: { c: 10, r: 0 }, e: { c: 10, r: 1 } },
  { s: { c: 11, r: 0 }, e: { c: 11, r: 1 } },
  { s: { c: 12, r: 0 }, e: { c: 12, r: 1 } },
  { s: { c: 27, r: 0 }, e: { c: 27, r: 1 } },
  { s: { c: 20, r: 0 }, e: { c: 21, r: 0 } },
  { s: { c: 26, r: 0 }, e: { c: 26, r: 1 } },
  { s: { c: 18, r: 0 }, e: { c: 19, r: 0 } }
];

export const GSTR2_CR_DR_MERGES = [
  { s: { c: 25, r: 0 }, e: { c: 25, r: 2 } },
  { s: { c: 17, r: 0 }, e: { c: 17, r: 2 } },
  { s: { c: 24, r: 0 }, e: { c: 24, r: 2 } },
  { s: { c: 13, r: 1 }, e: { c: 14, r: 1 } },
  { s: { c: 19, r: 1 }, e: { c: 19, r: 2 } },
  { s: { c: 23, r: 0 }, e: { c: 23, r: 2 } },
  { s: { c: 4, r: 1 }, e: { c: 4, r: 2 } },
  { s: { c: 9, r: 1 }, e: { c: 10, r: 1 } },
  { s: { c: 9, r: 0 }, e: { c: 16, r: 0 } },
  { s: { c: 15, r: 1 }, e: { c: 16, r: 1 } },
  { s: { c: 20, r: 1 }, e: { c: 20, r: 2 } },
  { s: { c: 5, r: 1 }, e: { c: 5, r: 2 } },
  { s: { c: 21, r: 1 }, e: { c: 21, r: 2 } },
  { s: { c: 30, r: 0 }, e: { c: 30, r: 2 } },
  { s: { c: 27, r: 0 }, e: { c: 27, r: 2 } },
  { s: { c: 28, r: 0 }, e: { c: 28, r: 2 } },
  { s: { c: 26, r: 0 }, e: { c: 26, r: 2 } },
  { s: { c: 7, r: 1 }, e: { c: 7, r: 2 } },
  { s: { c: 19, r: 0 }, e: { c: 22, r: 0 } },
  { s: { c: 29, r: 0 }, e: { c: 29, r: 2 } },
  { s: { c: 11, r: 1 }, e: { c: 12, r: 1 } },
  { s: { c: 6, r: 1 }, e: { c: 6, r: 2 } },
  { s: { c: 22, r: 1 }, e: { c: 22, r: 2 } },
  { s: { c: 0, r: 0 }, e: { c: 0, r: 2 } },
  { s: { c: 1, r: 0 }, e: { c: 1, r: 2 } },
  { s: { c: 2, r: 0 }, e: { c: 2, r: 2 } },
  { s: { c: 4, r: 0 }, e: { c: 5, r: 0 } },
  { s: { c: 6, r: 0 }, e: { c: 7, r: 0 } },
  { s: { c: 18, r: 0 }, e: { c: 18, r: 2 } },
  { s: { c: 8, r: 0 }, e: { c: 8, r: 2 } },
  { s: { c: 3, r: 0 }, e: { c: 3, r: 2 } }
];

export const GSTR1_ADVANCE_MERGES = [
  { s: { c: 1, r: 0 }, e: { c: 1, r: 1 } },
  { s: { c: 9, r: 0 }, e: { c: 9, r: 1 } },
  { s: { c: 10, r: 0 }, e: { c: 11, r: 0 } },
  { s: { c: 12, r: 0 }, e: { c: 13, r: 0 } },
  { s: { c: 14, r: 0 }, e: { c: 15, r: 0 } },
  { s: { c: 16, r: 0 }, e: { c: 17, r: 0 } },
  { s: { c: 19, r: 0 }, e: { c: 19, r: 1 } },
  { s: { c: 18, r: 0 }, e: { c: 18, r: 1 } },
  { s: { c: 8, r: 0 }, e: { c: 8, r: 1 } },
  { s: { c: 3, r: 0 }, e: { c: 3, r: 1 } },
  { s: { c: 0, r: 0 }, e: { c: 0, r: 1 } },
  { s: { c: 2, r: 0 }, e: { c: 2, r: 1 } },
  { s: { c: 5, r: 0 }, e: { c: 5, r: 1 } },
  { s: { c: 6, r: 0 }, e: { c: 6, r: 1 } },
  { s: { c: 7, r: 0 }, e: { c: 7, r: 1 } },
  { s: { c: 4, r: 0 }, e: { c: 4, r: 1 } }
];

export const GSTR2_ADVANCE_MERGES = [
  { s: { c: 7, r: 0 }, e: { c: 7, r: 1 } },
  { s: { c: 8, r: 0 }, e: { c: 8, r: 1 } },
  { s: { c: 9, r: 0 }, e: { c: 10, r: 0 } },
  { s: { c: 11, r: 0 }, e: { c: 12, r: 0 } },
  { s: { c: 13, r: 0 }, e: { c: 14, r: 0 } },
  { s: { c: 15, r: 0 }, e: { c: 16, r: 0 } },
  { s: { c: 17, r: 0 }, e: { c: 17, r: 1 } },
  { s: { c: 0, r: 0 }, e: { c: 0, r: 1 } },
  { s: { c: 1, r: 0 }, e: { c: 1, r: 1 } },
  { s: { c: 4, r: 0 }, e: { c: 4, r: 1 } },
  { s: { c: 5, r: 0 }, e: { c: 5, r: 1 } },
  { s: { c: 6, r: 0 }, e: { c: 6, r: 1 } },
  { s: { c: 3, r: 0 }, e: { c: 3, r: 1 } },
  { s: { c: 2, r: 0 }, e: { c: 2, r: 1 } }
];

// -------------------------------------------------------------
// Demo Sample Data for Sheets 4, 5, 6
// -------------------------------------------------------------

export const DEMO_GSTR2_CR_DR_NOTES: Gstr2CrDrNoteItem[] = [
  {
    id: 'G2CDN-001',
    supplierGstin: '27AAACB2234M1Z2',
    supplierName: 'TechFlow Components Ltd',
    supplierState: 'MAHARASHTRA',
    pos: '07',
    noteNumber: 'DBN/2026/081',
    noteDate: '2026-10-18',
    originalInvoiceNumber: 'BILL-9082',
    originalInvoiceDate: '2026-09-12',
    differentialValue: 15000,
    igstRate: 18,
    igstAmount: 2700,
    cgstRate: 0,
    cgstAmount: 0,
    sgstRate: 0,
    sgstAmount: 0,
    cessRate: 0,
    cessAmount: 0,
    otherCharges: 0,
    itcEligibility: 'ELIGIBLE',
    itcIgst: 2700,
    itcCgst: 0,
    itcSgst: 0,
    itcCess: 0,
    noteType: 'DEBIT',
    rcm: false,
    reason: '04-Correction in Invoice',
    preGst: false,
    voucherNo: '',
    voucherDate: '',
    supplyType: 'INTER',
    ineligibleSection17_5: ''
  },
  {
    id: 'G2CDN-002',
    supplierGstin: '07AABCS5544N1Z9',
    supplierName: 'Apex Hardware & Metal Fabricators',
    supplierState: 'DELHI',
    pos: '07',
    noteNumber: 'CRN/2026/014',
    noteDate: '2026-10-24',
    originalInvoiceNumber: 'INV-4412',
    originalInvoiceDate: '2026-10-02',
    differentialValue: 8000,
    igstRate: 0,
    igstAmount: 0,
    cgstRate: 9,
    cgstAmount: 720,
    sgstRate: 9,
    sgstAmount: 720,
    cessRate: 0,
    cessAmount: 0,
    otherCharges: 0,
    itcEligibility: 'ELIGIBLE',
    itcIgst: 0,
    itcCgst: 720,
    itcSgst: 720,
    itcCess: 0,
    noteType: 'CREDIT',
    rcm: false,
    reason: '01-Sales Return',
    preGst: false,
    voucherNo: '',
    voucherDate: '',
    supplyType: 'INTRA',
    ineligibleSection17_5: ''
  }
];

export const DEMO_GSTR1_ADVANCE_TAX: Gstr1AdvanceTaxItem[] = [
  {
    id: 'G1ADV-001',
    partyGstin: '07AABCR1234M1Z1',
    uin: '',
    partyName: 'Apex Cloud Infotech Ltd',
    state: 'DELHI',
    pos: '07',
    receiptVoucherNo: 'ADV-REC-001',
    receiptVoucherDate: '2026-10-20',
    goodsOrServices: 'SERVICES',
    hsnSac: '998313',
    advanceReceived: 50000,
    igstRate: 0,
    igstAmount: 0,
    cgstRate: 9,
    cgstAmount: 4500,
    sgstRate: 9,
    sgstAmount: 4500,
    cessRate: 0,
    cessAmount: 0,
    isPartyRegistered: 'Y',
    leaseOfOldCar: 'N'
  },
  {
    id: 'G1ADV-002',
    partyGstin: '24AAACT9988D1Z2',
    uin: '',
    partyName: 'Gujarat Precision Works',
    state: 'GUJARAT',
    pos: '24',
    receiptVoucherNo: 'ADV-REC-002',
    receiptVoucherDate: '2026-10-25',
    goodsOrServices: 'SERVICES',
    hsnSac: '998314',
    advanceReceived: 35000,
    igstRate: 18,
    igstAmount: 6300,
    cgstRate: 0,
    cgstAmount: 0,
    sgstRate: 0,
    sgstAmount: 0,
    cessRate: 0,
    cessAmount: 0,
    isPartyRegistered: 'Y',
    leaseOfOldCar: 'N'
  }
];

export const DEMO_GSTR2_ADVANCE_TAX: Gstr2AdvanceTaxItem[] = [
  {
    id: 'G2ADV-001',
    partyGstin: '29AAACG9988P1Z5',
    partyName: 'Bangalore Logistics Corp',
    state: 'KARNATAKA',
    pos: '29',
    paymentVoucherNo: 'ADV-PAY-001',
    paymentVoucherDate: '2026-10-22',
    goodsOrServices: 'SERVICES',
    hsnSac: '996511',
    advancePaid: 30000,
    igstRate: 18,
    igstAmount: 5400,
    cgstRate: 0,
    cgstAmount: 0,
    sgstRate: 0,
    sgstAmount: 0,
    cessRate: 0,
    cessAmount: 0,
    isPartyRegistered: 'Y'
  }
];

export class GstExcelTemplateService {
  /**
   * Applies official #CCFFCC pastel mint green styling and bold font
   * to all header cells, and sets up sheet column merges and column widths.
   */
  private applyHeaderStyles(
    ws: XLSX.WorkSheet,
    headerRowCount: number,
    colCount: number,
    merges?: XLSX.Range[]
  ) {
    if (merges && merges.length > 0) {
      ws['!merges'] = merges;
    }

    // Auto-compute column widths
    const colWidths: { wch: number }[] = [];
    for (let c = 0; c < colCount; c++) {
      colWidths.push({ wch: 18 });
    }
    ws['!cols'] = colWidths;

    // Apply #CCFFCC header background and bold font
    for (let r = 0; r < headerRowCount; r++) {
      for (let c = 0; c < colCount; c++) {
        const cellRef = XLSX.utils.encode_cell({ r, c });
        if (!ws[cellRef]) {
          ws[cellRef] = { t: 's', v: '' };
        }
        ws[cellRef].s = {
          fill: {
            patternType: 'solid',
            fgColor: { rgb: 'CCFFCC' } // Official GST Template Pastel Mint Green
          },
          font: {
            bold: true,
            color: { rgb: '003300' },
            name: 'Calibri',
            sz: 10
          },
          alignment: {
            horizontal: 'center',
            vertical: 'center',
            wrapText: true
          },
          border: {
            top: { style: 'thin', color: { rgb: 'A0C0A0' } },
            bottom: { style: 'thin', color: { rgb: 'A0C0A0' } },
            left: { style: 'thin', color: { rgb: 'A0C0A0' } },
            right: { style: 'thin', color: { rgb: 'A0C0A0' } }
          }
        };
      }
    }
  }

  /**
   * Parses official WEB_GST_Template.xls / .xlsx directly in memory.
   * Eliminates the need to ever upload external CSV files.
   */
  public parseWebGstTemplate(fileData: ArrayBuffer | Uint8Array, activeGstin: string): ParseResult {
    const workbook = XLSX.read(fileData, { type: 'array' });
    const errors: string[] = [];
    const sales: TransactionInvoice[] = [];
    const purchases: TransactionInvoice[] = [];
    const creditDebitNotes: TransactionInvoice[] = [];
    const gstr2CrDrNotes: Gstr2CrDrNoteItem[] = [];
    const gstr1AdvanceTax: Gstr1AdvanceTaxItem[] = [];
    const gstr2AdvanceTax: Gstr2AdvanceTaxItem[] = [];

    const cleanActiveGstin = (activeGstin || '07ABFFB5922Q1Z0').trim().toUpperCase();
    const activeState = cleanActiveGstin.substring(0, 2);

    // -----------------------------------------------------------------
    // 1. Parse 'SALE' Sheet (GSTR-1 Outward Supplies)
    // -----------------------------------------------------------------
    const saleSheetName = workbook.SheetNames.find(n => n.trim().toUpperCase() === 'SALE') || workbook.SheetNames[0];
    if (saleSheetName && workbook.Sheets[saleSheetName]) {
      const rows: any[][] = XLSX.utils.sheet_to_json(workbook.Sheets[saleSheetName], { header: 1 });
      for (let r = 2; r < rows.length; r++) {
        const row = rows[r];
        if (!row || row.length === 0 || row.every(c => c === null || c === undefined || c === '')) {
          continue;
        }

        try {
          const supplierGstin = String(row[0] || cleanActiveGstin).trim().toUpperCase();
          const partyGstin = String(row[1] || '').trim().toUpperCase();
          const partyName = String(row[2] || 'Customer Party').trim();
          const state = String(row[3] || '').trim();
          let pos = String(row[4] || '').trim();
          if (pos.length === 1) pos = `0${pos}`;
          if (!pos && partyGstin.length >= 2) pos = partyGstin.substring(0, 2);
          if (!pos) pos = activeState;

          const invNum = String(row[5] || `INV-${Date.now().toString().slice(-4)}-${r}`).trim();
          const invDate = this.normalizeDateString(row[6]);
          const taxableVal = parseFloat(row[10]) || 0;
          if (taxableVal <= 0) continue;

          const hsn = String(row[8] || '998313').trim();
          const isService = hsn.startsWith('99');
          const qty = isService ? 0 : (parseFloat(row[11]) || 1);
          const uqc = isService ? 'NA' : (String(row[12] || 'NOS').trim().toUpperCase());

          const igstRate = parseFloat(row[13]) || 0;
          const cgstRate = parseFloat(row[15]) || 0;
          const rate = igstRate > 0 ? igstRate : (cgstRate > 0 ? cgstRate * 2 : 18);

          const cessAmt = parseFloat(row[20]) || 0;
          const supplyTypeRaw = String(row[22] || '').trim().toUpperCase();
          const rcmVal = String(row[23] || 'N').trim().toUpperCase() === 'Y';
          const portCode = String(row[24] || '').trim().toUpperCase();
          const sbNum = String(row[25] || '').trim();
          const sbDate = this.normalizeDateString(row[26]);
          const ecomGstin = String(row[27] || '').trim();

          let classification: GSTClassification = 'B2B';
          if (supplyTypeRaw.includes('EXPORT') && supplyTypeRaw.includes('WOPAY')) {
            classification = 'EXPORT_WITHOUT_PAYMENT';
          } else if (supplyTypeRaw.includes('EXPORT')) {
            classification = 'EXPORT_WITH_PAYMENT';
          } else if (supplyTypeRaw.includes('SEZ') && supplyTypeRaw.includes('WOPAY')) {
            classification = 'SEZ_WITHOUT_PAYMENT';
          } else if (supplyTypeRaw.includes('SEZ')) {
            classification = 'SEZ_WITH_PAYMENT';
          } else if (supplyTypeRaw.includes('DEEMED')) {
            classification = 'DEEMED_EXPORT';
          } else if (!partyGstin || partyGstin === 'URP') {
            classification = (taxableVal > 250000 && pos !== activeState) ? 'B2C_LARGE' : 'B2C_SMALL';
          }

          const baseInv: TransactionInvoice = {
            id: `SL-XLS-${Date.now().toString().slice(-4)}-${r}`,
            invoiceNumber: invNum,
            invoiceDate: invDate,
            documentType: 'INVOICE',
            supplierGstin: supplierGstin || cleanActiveGstin,
            supplierName: 'Active Taxpayer Enterprise',
            supplierState: 'State',
            supplierStateCode: activeState,
            recipientGstin: partyGstin,
            recipientName: partyName,
            recipientState: state || 'State',
            recipientStateCode: pos,
            placeOfSupply: pos,
            placeOfSupplyCode: pos,
            supplyType: pos === activeState ? 'INTRA_STATE' : 'INTER_STATE',
            classification,
            taxTreatment: 'TAXABLE',
            hsnSacPrimary: hsn,
            descriptionPrimary: isService ? 'Professional/Technical Services' : 'Taxable Commercial Goods',
            uqc: uqc || (isService ? 'NA' : 'NOS'),
            totalQuantity: qty,
            taxableValue: taxableVal,
            gstRate: rate,
            cgst: 0,
            sgst: 0,
            igst: 0,
            cess: cessAmt,
            totalAmount: taxableVal,
            rcm: rcmVal,
            ecommerce: Boolean(ecomGstin),
            ecommerceGstin: ecomGstin || undefined,
            portCode: portCode || undefined,
            shippingBillNumber: sbNum || undefined,
            shippingBillDate: sbDate || undefined,
            itcEligible: true,
            itcStatus: 'ELIGIBLE',
            itcEligibleAmount: 0,
            itcIneligibleAmount: 0,
            confidence: 1.0,
            reviewRequired: false
          };

          const compliant = autoFixInvoiceForGstn(baseInv, cleanActiveGstin, true);
          sales.push(compliant);
        } catch (err: any) {
          errors.push(`Row ${r + 1} in SALE: ${err.message}`);
        }
      }
    }

    // -----------------------------------------------------------------
    // 2. Parse 'PURCHASE' Sheet (Inward Supplies / GSTR-2B / 3B)
    // -----------------------------------------------------------------
    const purchaseSheetName = workbook.SheetNames.find(n => n.trim().toUpperCase() === 'PURCHASE');
    if (purchaseSheetName && workbook.Sheets[purchaseSheetName]) {
      const rows: any[][] = XLSX.utils.sheet_to_json(workbook.Sheets[purchaseSheetName], { header: 1 });
      for (let r = 2; r < rows.length; r++) {
        const row = rows[r];
        if (!row || row.length === 0 || row.every(c => c === null || c === undefined || c === '')) {
          continue;
        }

        try {
          const supplierGstin = String(row[0] || '').trim().toUpperCase();
          const supplierName = String(row[1] || 'Supplier Vendor').trim();
          const state = String(row[2] || '').trim();
          let pos = String(row[3] || '').trim();
          if (pos.length === 1) pos = `0${pos}`;
          if (!pos && supplierGstin.length >= 2) pos = supplierGstin.substring(0, 2);
          if (!pos) pos = activeState;

          const invNum = String(row[4] || `BILL-${Date.now().toString().slice(-4)}-${r}`).trim();
          const invDate = this.normalizeDateString(row[5]);
          const taxableVal = parseFloat(row[9]) || 0;
          if (taxableVal <= 0) continue;

          const hsn = String(row[7] || '9982').trim();
          const isService = hsn.startsWith('99');
          const qty = isService ? 0 : (parseFloat(row[10]) || 1);
          const uqc = isService ? 'NA' : (String(row[11] || 'NOS').trim().toUpperCase());

          const igstRate = parseFloat(row[12]) || 0;
          const cgstRate = parseFloat(row[14]) || 0;
          const rate = igstRate > 0 ? igstRate : (cgstRate > 0 ? cgstRate * 2 : 18);
          const cessAmt = parseFloat(row[19]) || 0;
          const rcmVal = String(row[26] || 'N').trim().toUpperCase() === 'Y';
          const itcEligibility = String(row[21] || 'ELIGIBLE').trim().toUpperCase();

          const baseInv: TransactionInvoice = {
            id: `PR-XLS-${Date.now().toString().slice(-4)}-${r}`,
            invoiceNumber: invNum,
            invoiceDate: invDate,
            documentType: 'INVOICE',
            supplierGstin: supplierGstin || `${pos}AAACB2234M1Z2`,
            supplierName: supplierName,
            supplierState: state || 'State',
            supplierStateCode: pos,
            recipientGstin: cleanActiveGstin,
            recipientName: 'Active Taxpayer Enterprise',
            recipientState: 'State',
            recipientStateCode: activeState,
            placeOfSupply: activeState,
            placeOfSupplyCode: activeState,
            supplyType: pos === activeState ? 'INTRA_STATE' : 'INTER_STATE',
            classification: 'B2B',
            taxTreatment: 'TAXABLE',
            hsnSacPrimary: hsn,
            descriptionPrimary: isService ? 'Advisory / Procurement Services' : 'Inward Materials',
            uqc: uqc || (isService ? 'NA' : 'NOS'),
            totalQuantity: qty,
            taxableValue: taxableVal,
            gstRate: rate,
            cgst: 0,
            sgst: 0,
            igst: 0,
            cess: cessAmt,
            totalAmount: taxableVal,
            rcm: rcmVal,
            ecommerce: false,
            itcEligible: !itcEligibility.includes('INELIGIBLE'),
            itcStatus: itcEligibility.includes('17(5)') ? 'INELIGIBLE' : 'ELIGIBLE',
            itcEligibleAmount: 0,
            itcIneligibleAmount: 0,
            confidence: 1.0,
            reviewRequired: false
          };

          const compliant = autoFixInvoiceForGstn(baseInv, cleanActiveGstin, false);
          purchases.push(compliant);
        } catch (err: any) {
          errors.push(`Row ${r + 1} in PURCHASE: ${err.message}`);
        }
      }
    }

    // -----------------------------------------------------------------
    // 3. Parse 'GSTR-1 DEBIT CREDIT NOTE' Sheet (Table 9B)
    // -----------------------------------------------------------------
    const crdrSheetName = workbook.SheetNames.find(n => n.includes('DEBIT CREDIT NOTE') && n.includes('GSTR-1'));
    if (crdrSheetName && workbook.Sheets[crdrSheetName]) {
      const rows: any[][] = XLSX.utils.sheet_to_json(workbook.Sheets[crdrSheetName], { header: 1 });
      for (let r = 2; r < rows.length; r++) {
        const row = rows[r];
        if (!row || row.length === 0 || row.every(c => c === null || c === undefined || c === '')) {
          continue;
        }

        try {
          const partyGstin = String(row[0] || '').trim().toUpperCase();
          const partyName = String(row[2] || 'Counterparty').trim();
          let pos = String(row[4] || '').trim();
          if (pos.length === 1) pos = `0${pos}`;
          if (!pos && partyGstin.length >= 2) pos = partyGstin.substring(0, 2);
          if (!pos) pos = activeState;

          const noteNum = String(row[5] || `CDN-${Date.now().toString().slice(-4)}-${r}`).trim();
          const noteDate = this.normalizeDateString(row[6]);
          const taxableVal = parseFloat(row[13]) || 0;
          if (taxableVal <= 0) continue;

          const igstRate = parseFloat(row[14]) || 0;
          const cgstRate = parseFloat(row[16]) || 0;
          const rate = igstRate > 0 ? igstRate : (cgstRate > 0 ? cgstRate * 2 : 18);
          const noteTypeRaw = String(row[23] || 'C').trim().toUpperCase();
          const isCredit = noteTypeRaw.startsWith('C') || noteTypeRaw.includes('CREDIT');
          const reason = String(row[26] || '01-Sales Return').trim();

          const baseNote: TransactionInvoice = {
            id: `CDN-XLS-${Date.now().toString().slice(-4)}-${r}`,
            invoiceNumber: noteNum,
            invoiceDate: noteDate,
            documentType: isCredit ? 'CREDIT_NOTE' : 'DEBIT_NOTE',
            supplierGstin: cleanActiveGstin,
            supplierName: 'Active Taxpayer Enterprise',
            supplierState: 'State',
            supplierStateCode: activeState,
            recipientGstin: partyGstin,
            recipientName: partyName,
            recipientState: 'State',
            recipientStateCode: pos,
            placeOfSupply: pos,
            placeOfSupplyCode: pos,
            supplyType: pos === activeState ? 'INTRA_STATE' : 'INTER_STATE',
            classification: 'B2B',
            taxTreatment: 'TAXABLE',
            hsnSacPrimary: '998313',
            descriptionPrimary: reason,
            uqc: 'NA',
            totalQuantity: 0,
            taxableValue: taxableVal,
            gstRate: rate,
            cgst: 0,
            sgst: 0,
            igst: 0,
            cess: 0,
            totalAmount: taxableVal,
            rcm: false,
            ecommerce: false,
            notes: reason,
            itcEligible: true,
            itcStatus: 'ELIGIBLE',
            itcEligibleAmount: 0,
            itcIneligibleAmount: 0,
            confidence: 1.0,
            reviewRequired: false
          };

          const compliant = autoFixInvoiceForGstn(baseNote, cleanActiveGstin, true);
          creditDebitNotes.push(compliant);
        } catch (err: any) {
          errors.push(`Row ${r + 1} in GSTR-1 DEBIT CREDIT NOTE: ${err.message}`);
        }
      }
    }

    // -----------------------------------------------------------------
    // 4. Parse 'GSTR-2 DEBIT CREDIT NOTE' Sheet (Inward CDN)
    // -----------------------------------------------------------------
    const gstr2CdnSheetName = workbook.SheetNames.find(n => n.includes('DEBIT CREDIT NOTE') && n.includes('GSTR-2'));
    if (gstr2CdnSheetName && workbook.Sheets[gstr2CdnSheetName]) {
      const rows: any[][] = XLSX.utils.sheet_to_json(workbook.Sheets[gstr2CdnSheetName], { header: 1 });
      // Row 0, 1, 2 are headers. Data starts at row 3.
      for (let r = 3; r < rows.length; r++) {
        const row = rows[r];
        if (!row || row.length === 0 || row.every(c => c === null || c === undefined || c === '')) {
          continue;
        }

        try {
          const supplierGstin = String(row[0] || '').trim().toUpperCase();
          const supplierName = String(row[1] || 'Supplier').trim();
          const state = String(row[2] || '').trim();
          let pos = String(row[3] || '').trim();
          if (pos.length === 1) pos = `0${pos}`;
          if (!pos && supplierGstin.length >= 2) pos = supplierGstin.substring(0, 2);

          const noteNum = String(row[4] || `DBN-${r}`).trim();
          const noteDate = this.normalizeDateString(row[5]);
          const origInv = String(row[6] || '').trim();
          const origDate = this.normalizeDateString(row[7]);
          const diffVal = parseFloat(row[8]) || 0;
          if (diffVal <= 0) continue;

          const igstRate = parseFloat(row[9]) || 0;
          const igstAmt = parseFloat(row[10]) || 0;
          const cgstRate = parseFloat(row[11]) || 0;
          const cgstAmt = parseFloat(row[12]) || 0;
          const sgstRate = parseFloat(row[13]) || 0;
          const sgstAmt = parseFloat(row[14]) || 0;
          const cessRate = parseFloat(row[15]) || 0;
          const cessAmt = parseFloat(row[16]) || 0;
          const otherCharges = parseFloat(row[17]) || 0;
          const itcEligibility = String(row[18] || 'ELIGIBLE').trim().toUpperCase();

          const itcIgst = parseFloat(row[19]) || igstAmt;
          const itcCgst = parseFloat(row[20]) || cgstAmt;
          const itcSgst = parseFloat(row[21]) || sgstAmt;
          const itcCess = parseFloat(row[22]) || cessAmt;

          const noteTypeRaw = String(row[23] || 'DEBIT').trim().toUpperCase();
          const noteType = noteTypeRaw.startsWith('C') ? 'CREDIT' : 'DEBIT';
          const rcm = String(row[24] || 'N').trim().toUpperCase() === 'Y';
          const reason = String(row[25] || '01-Sales Return').trim();
          const preGst = String(row[26] || 'N').trim().toUpperCase() === 'Y';
          const voucherNo = String(row[27] || '').trim();
          const voucherDate = this.normalizeDateString(row[28]);
          const supplyType = String(row[29] || 'INTRA').trim().toUpperCase();
          const ineligible17_5 = String(row[30] || '').trim();

          gstr2CrDrNotes.push({
            id: `G2CDN-IMP-${r}`,
            supplierGstin,
            supplierName,
            supplierState: state,
            pos: pos || activeState,
            noteNumber: noteNum,
            noteDate,
            originalInvoiceNumber: origInv,
            originalInvoiceDate: origDate,
            differentialValue: diffVal,
            igstRate,
            igstAmount: igstAmt,
            cgstRate,
            cgstAmount: cgstAmt,
            sgstRate,
            sgstAmount: sgstAmt,
            cessRate,
            cessAmount: cessAmt,
            otherCharges,
            itcEligibility,
            itcIgst,
            itcCgst,
            itcSgst,
            itcCess,
            noteType,
            rcm,
            reason,
            preGst,
            voucherNo,
            voucherDate,
            supplyType,
            ineligibleSection17_5: ineligible17_5
          });
        } catch (err: any) {
          errors.push(`Row ${r + 1} in GSTR-2 DEBIT CREDIT NOTE: ${err.message}`);
        }
      }
    }

    // -----------------------------------------------------------------
    // 5. Parse 'GSTR-1 ADVANCE TAX' Sheet (Table 11A/11B)
    // -----------------------------------------------------------------
    const gstr1AdvSheetName = workbook.SheetNames.find(n => n.includes('ADVANCE TAX') && n.includes('GSTR-1'));
    if (gstr1AdvSheetName && workbook.Sheets[gstr1AdvSheetName]) {
      const rows: any[][] = XLSX.utils.sheet_to_json(workbook.Sheets[gstr1AdvSheetName], { header: 1 });
      for (let r = 2; r < rows.length; r++) {
        const row = rows[r];
        if (!row || row.length === 0 || row.every(c => c === null || c === undefined || c === '')) {
          continue;
        }

        try {
          const partyGstin = String(row[0] || '').trim().toUpperCase();
          const uin = String(row[1] || '').trim();
          const partyName = String(row[2] || 'Customer').trim();
          const state = String(row[3] || '').trim();
          let pos = String(row[4] || '').trim();
          if (pos.length === 1) pos = `0${pos}`;
          if (!pos && partyGstin.length >= 2) pos = partyGstin.substring(0, 2);

          const rVoucherNo = String(row[5] || `ADV-REC-${r}`).trim();
          const rVoucherDate = this.normalizeDateString(row[6]);
          const goodsOrServices = String(row[7] || 'SERVICES').toUpperCase().includes('GOODS') ? 'GOODS' : 'SERVICES';
          const hsnSac = String(row[8] || '998313').trim();
          const advanceReceived = parseFloat(row[9]) || 0;
          if (advanceReceived <= 0) continue;

          const igstRate = parseFloat(row[10]) || 0;
          const igstAmt = parseFloat(row[11]) || 0;
          const cgstRate = parseFloat(row[12]) || 0;
          const cgstAmt = parseFloat(row[13]) || 0;
          const sgstRate = parseFloat(row[14]) || 0;
          const sgstAmt = parseFloat(row[15]) || 0;
          const cessRate = parseFloat(row[16]) || 0;
          const cessAmt = parseFloat(row[17]) || 0;
          const isPartyRegistered = String(row[18] || (partyGstin ? 'Y' : 'N')).trim().toUpperCase() === 'Y' ? 'Y' : 'N';
          const leaseOfOldCar = String(row[19] || 'N').trim().toUpperCase() === 'Y' ? 'Y' : 'N';

          gstr1AdvanceTax.push({
            id: `G1ADV-IMP-${r}`,
            partyGstin,
            uin,
            partyName,
            state,
            pos: pos || activeState,
            receiptVoucherNo: rVoucherNo,
            receiptVoucherDate: rVoucherDate,
            goodsOrServices,
            hsnSac,
            advanceReceived,
            igstRate,
            igstAmount: igstAmt,
            cgstRate,
            cgstAmount: cgstAmt,
            sgstRate,
            sgstAmount: sgstAmt,
            cessRate,
            cessAmount: cessAmt,
            isPartyRegistered,
            leaseOfOldCar
          });
        } catch (err: any) {
          errors.push(`Row ${r + 1} in GSTR-1 ADVANCE TAX: ${err.message}`);
        }
      }
    }

    // -----------------------------------------------------------------
    // 6. Parse 'GSTR-2 ADVANCE TAX' Sheet (Inward Advance Payment)
    // -----------------------------------------------------------------
    const gstr2AdvSheetName = workbook.SheetNames.find(n => n.includes('ADVANCE TAX') && n.includes('GSTR-2'));
    if (gstr2AdvSheetName && workbook.Sheets[gstr2AdvSheetName]) {
      const rows: any[][] = XLSX.utils.sheet_to_json(workbook.Sheets[gstr2AdvSheetName], { header: 1 });
      for (let r = 2; r < rows.length; r++) {
        const row = rows[r];
        if (!row || row.length === 0 || row.every(c => c === null || c === undefined || c === '')) {
          continue;
        }

        try {
          const partyGstin = String(row[0] || '').trim().toUpperCase();
          const partyName = String(row[1] || 'Supplier').trim();
          const state = String(row[2] || '').trim();
          let pos = String(row[3] || '').trim();
          if (pos.length === 1) pos = `0${pos}`;
          if (!pos && partyGstin.length >= 2) pos = partyGstin.substring(0, 2);

          const pVoucherNo = String(row[4] || `ADV-PAY-${r}`).trim();
          const pVoucherDate = this.normalizeDateString(row[5]);
          const goodsOrServices = String(row[6] || 'SERVICES').toUpperCase().includes('GOODS') ? 'GOODS' : 'SERVICES';
          const hsnSac = String(row[7] || '996511').trim();
          const advancePaid = parseFloat(row[8]) || 0;
          if (advancePaid <= 0) continue;

          const igstRate = parseFloat(row[9]) || 0;
          const igstAmt = parseFloat(row[10]) || 0;
          const cgstRate = parseFloat(row[11]) || 0;
          const cgstAmt = parseFloat(row[12]) || 0;
          const sgstRate = parseFloat(row[13]) || 0;
          const sgstAmt = parseFloat(row[14]) || 0;
          const cessRate = parseFloat(row[15]) || 0;
          const cessAmt = parseFloat(row[16]) || 0;
          const isPartyRegistered = String(row[17] || (partyGstin ? 'Y' : 'N')).trim().toUpperCase() === 'Y' ? 'Y' : 'N';

          gstr2AdvanceTax.push({
            id: `G2ADV-IMP-${r}`,
            partyGstin,
            partyName,
            state,
            pos: pos || activeState,
            paymentVoucherNo: pVoucherNo,
            paymentVoucherDate: pVoucherDate,
            goodsOrServices,
            hsnSac,
            advancePaid,
            igstRate,
            igstAmount: igstAmt,
            cgstRate,
            cgstAmount: cgstAmt,
            sgstRate,
            sgstAmount: sgstAmt,
            cessRate,
            cessAmount: cessAmt,
            isPartyRegistered
          });
        } catch (err: any) {
          errors.push(`Row ${r + 1} in GSTR-2 ADVANCE TAX: ${err.message}`);
        }
      }
    }

    return {
      sales,
      purchases,
      creditDebitNotes,
      gstr2CrDrNotes,
      gstr1AdvanceTax,
      gstr2AdvanceTax,
      totalParsed:
        sales.length +
        purchases.length +
        creditDebitNotes.length +
        gstr2CrDrNotes.length +
        gstr1AdvanceTax.length +
        gstr2AdvanceTax.length,
      errors
    };
  }

  /**
   * Generates a complete 10-sheet Excel workbook (.xlsx) strictly matching
   * WEB_GST_Template.xls column-for-column, with #CCFFCC pastel green styling,
   * merges, column widths, and masters ready for offline storage or editing.
   */
  public exportToWebGstTemplate(
    sales: TransactionInvoice[],
    purchases: TransactionInvoice[],
    creditDebitNotes: TransactionInvoice[],
    activeGstin: string,
    extraSheets?: {
      gstr2CrDrNotes?: Gstr2CrDrNoteItem[];
      gstr1AdvanceTax?: Gstr1AdvanceTaxItem[];
      gstr2AdvanceTax?: Gstr2AdvanceTaxItem[];
    }
  ): Uint8Array {
    const wb = XLSX.utils.book_new();
    const cleanActiveGstin = (activeGstin || '07ABFFB5922Q1Z0').trim().toUpperCase();

    // -------------------------------------------------------------
    // Sheet 1: SALE (35 cols, 2 rows header)
    // -------------------------------------------------------------
    const saleHeaderRow0 = [
      'GSTIN', 'PARTY UIN', 'NAME OF PARTY', 'STATE', 'POS', 'INVOICE', null, null, null, null, null,
      'QTY', 'UQC', 'IGST', null, 'CGST', null, 'SGST/ UTGST', null, 'CESS', null,
      'OTHER CHARGES', 'SUPPLY TYPE', 'REVERSE CHARGE', 'PORT CODE',
      'SHIPPING BILL/ BILL OF EXPORT NO.', 'SHIPPING BILL/ BILL OF EXPORT DATE',
      'ECOM GSTIN', 'VOUCHER NO', 'VOUCHER DATE', 'Lease OF Old Car', 'IRN', 'Ack No', 'Ack Date', 'Section 9(5)'
    ];
    const saleHeaderRow1 = [
      null, null, null, null, null,
      'NO.', 'DATE', 'ITEM VALUE', 'HSN/SAC', 'GOODS /\nSERVICES', 'TAXABLE VALUE',
      null, null, 'RATE', 'AMOUNT', 'RATE', 'AMOUNT', 'RATE', 'AMOUNT', 'RATE', 'AMOUNT'
    ];

    const saleRows: any[][] = [saleHeaderRow0, saleHeaderRow1];

    sales.forEach(inv => {
      const isInter = inv.supplyType === 'INTER_STATE' || inv.igst > 0;
      const isService = (inv.hsnSacPrimary || '').startsWith('99');
      saleRows.push([
        inv.supplierGstin || cleanActiveGstin,
        inv.recipientGstin || '',
        inv.recipientName || '',
        inv.recipientState || '',
        (inv.placeOfSupplyCode || inv.placeOfSupply || '07').toString().padStart(2, '0'),
        inv.invoiceNumber,
        inv.invoiceDate,
        inv.totalAmount,
        inv.hsnSacPrimary || '998313',
        isService ? 'SERVICES' : 'GOODS',
        inv.taxableValue,
        isService ? 0 : (inv.totalQuantity || 1),
        inv.uqc || (isService ? 'NA' : 'NOS'),
        isInter ? inv.gstRate : 0,
        isInter ? inv.igst : 0,
        isInter ? 0 : (inv.gstRate / 2),
        isInter ? 0 : inv.cgst,
        isInter ? 0 : (inv.gstRate / 2),
        isInter ? 0 : inv.sgst,
        0,
        inv.cess || 0,
        0, // Other charges
        inv.classification === 'EXPORT_WITH_PAYMENT' ? 'EXPORT WITH PAYMENT' :
        inv.classification === 'EXPORT_WITHOUT_PAYMENT' ? 'EXPORT W/O PAYMENT' :
        isInter ? 'INTER' : 'INTRA',
        inv.rcm ? 'Y' : 'N',
        inv.portCode || '',
        inv.shippingBillNumber || '',
        inv.shippingBillDate || '',
        inv.ecommerceGstin || '',
        '', // Voucher No
        '', // Voucher Date
        'N',
        '', // IRN
        '', // Ack No
        '', // Ack Date
        'N' // Section 9(5)
      ]);
    });

    const saleSheet = XLSX.utils.aoa_to_sheet(saleRows);
    this.applyHeaderStyles(saleSheet, 2, 35, SALE_MERGES);
    XLSX.utils.book_append_sheet(wb, saleSheet, 'SALE');

    // -------------------------------------------------------------
    // Sheet 2: PURCHASE (33 cols, 2 rows header)
    // -------------------------------------------------------------
    const purchaseHeaderRow0 = [
      'GSTIN', 'NAME OF PARTY', 'STATE', 'POS', 'INVOICE/BILL OF ENTRY', null, null, null, null, null,
      'QUANTITY', 'UQC', 'IGST', null, 'CGST', null, 'SGST/UTGST', null, 'CESS', null,
      'Other Charges', 'ELIGIBILITY OF ITC', 'TOTAL TAX AVAILABLE AS ITC', null, null, null,
      'REVERSE CHARGE', 'SUPPLY TYPE', 'PORT CODE', 'VOUCHER NO', 'VOUCHER DATE',
      'InEligible ITC(As Per Section 17(5))', 'GL Code'
    ];
    const purchaseHeaderRow1 = [
      null, null, null, null,
      'NO', 'Date', 'Item Value', 'HSN/SAC', 'GOODS/\nSERVICES', 'TAXABLE VALUE',
      null, null, 'RATE', 'AMOUNT', 'RATE', 'AMOUNT', 'RATE', 'AMOUNT', 'RATE', 'AMOUNT',
      null, null, 'IGST', 'CGST', 'SGST/UTGST', 'CESS'
    ];

    const purchaseRows: any[][] = [purchaseHeaderRow0, purchaseHeaderRow1];

    purchases.forEach(inv => {
      const isInter = inv.supplyType === 'INTER_STATE' || inv.igst > 0;
      const isService = (inv.hsnSacPrimary || '').startsWith('99');
      purchaseRows.push([
        inv.supplierGstin,
        inv.supplierName,
        inv.supplierState || '',
        (inv.placeOfSupplyCode || inv.placeOfSupply || '07').toString().padStart(2, '0'),
        inv.invoiceNumber,
        inv.invoiceDate,
        inv.totalAmount,
        inv.hsnSacPrimary || '9982',
        isService ? 'SERVICES' : 'GOODS',
        inv.taxableValue,
        isService ? 0 : (inv.totalQuantity || 1),
        inv.uqc || (isService ? 'NA' : 'NOS'),
        isInter ? inv.gstRate : 0,
        isInter ? inv.igst : 0,
        isInter ? 0 : (inv.gstRate / 2),
        isInter ? 0 : inv.cgst,
        isInter ? 0 : (inv.gstRate / 2),
        isInter ? 0 : inv.sgst,
        0,
        inv.cess || 0,
        0,
        inv.itcEligible ? 'ELIGIBLE' : 'INELIGIBLE',
        isInter ? inv.igst : 0,
        isInter ? 0 : inv.cgst,
        isInter ? 0 : inv.sgst,
        inv.cess || 0,
        inv.rcm ? 'Y' : 'N',
        isInter ? 'INTER' : 'INTRA',
        inv.portCode || '',
        '',
        '',
        inv.blockedCreditReason || '',
        ''
      ]);
    });

    const purchaseSheet = XLSX.utils.aoa_to_sheet(purchaseRows);
    this.applyHeaderStyles(purchaseSheet, 2, 33, PURCHASE_MERGES);
    XLSX.utils.book_append_sheet(wb, purchaseSheet, 'PURCHASE');

    // -------------------------------------------------------------
    // Sheet 3: GSTR-1 DEBIT CREDIT NOTE (37 cols, 2 rows header)
    // -------------------------------------------------------------
    const crdrHeaderRow0 = [
      'PARTY GSTIN', 'PARTY UIN', 'PARTY NAME', 'STATE', 'POS', 'CR/DB NOTE', null, 'INVOICE', null,
      'HSN CODE', 'UQC', 'GOODS/SERVICES ', 'QTY', 'DIFFERENTIAL VALUE FOR WHICH CR/DB NOTE ISSUED',
      'IGST', null, 'CGST', null, 'SGST/UTGST', null, 'CESS', null, 'Other Charges',
      'CR/DB NOTE TYPE', 'REVERSE CHARGE', 'ECOM GSTIN', 'Reason ', 'Pre GST Regime ',
      'VOUCHER NO', 'VOUCHER DATE', 'Lease OF Old Car', 'Supply Type', 'Supply Type where tax is not charged',
      'IRN', 'Ack No', 'Ack Date', 'Section 9(5)'
    ];
    const crdrHeaderRow1 = [
      null, null, null, null, null,
      'NO.', 'DATE', 'NO.', 'DATE',
      null, null, null, null, null,
      'RATE', 'TAX', 'RATE', 'TAX', 'RATE', 'TAX', 'RATE', 'TAX'
    ];

    const crdrRows: any[][] = [crdrHeaderRow0, crdrHeaderRow1];

    creditDebitNotes.forEach(note => {
      const isInter = note.supplyType === 'INTER_STATE' || note.igst > 0;
      crdrRows.push([
        note.recipientGstin,
        '',
        note.recipientName,
        note.recipientState || '',
        (note.placeOfSupplyCode || note.placeOfSupply || '07').toString().padStart(2, '0'),
        note.invoiceNumber,
        note.invoiceDate,
        note.originalInvoiceNumber || 'INV/ORIG/001',
        note.originalInvoiceDate || note.invoiceDate,
        note.hsnSacPrimary || '998313',
        note.uqc || 'NA',
        'SERVICES',
        0,
        note.taxableValue,
        isInter ? note.gstRate : 0,
        isInter ? note.igst : 0,
        isInter ? 0 : (note.gstRate / 2),
        isInter ? 0 : note.cgst,
        isInter ? 0 : (note.gstRate / 2),
        isInter ? 0 : note.sgst,
        0,
        note.cess || 0,
        0,
        note.documentType === 'DEBIT_NOTE' ? 'DEBIT' : 'CREDIT',
        note.rcm ? 'Y' : 'N',
        '',
        note.notes || '01-Sales Return',
        'N',
        '',
        '',
        'N',
        isInter ? 'INTER' : 'INTRA',
        '',
        '',
        '',
        '',
        'N'
      ]);
    });

    const crdrSheet = XLSX.utils.aoa_to_sheet(crdrRows);
    this.applyHeaderStyles(crdrSheet, 2, 37, GSTR1_CR_DR_MERGES);
    XLSX.utils.book_append_sheet(wb, crdrSheet, 'GSTR-1 DEBIT CREDIT NOTE');

    // -------------------------------------------------------------
    // Sheet 4: GSTR-2 DEBIT CREDIT NOTE (31 cols, 3 rows header)
    // -------------------------------------------------------------
    const gstr2CdnRow0 = [
      'GSTIN', 'NAME OF PARTY', 'STATE', 'POS', 'DEBIT/CREDIT NOTE', null, 'ORIGINAL INVOICE', null,
      'DIFFERENTIAL VALUE(+/-)', 'DIFFERENTIAL TAX', null, null, null, null, null, null, null,
      'Other Charges', 'ELIGIBILITY FOR ITC', 'TOTAL TAX AVAILABLE AS ITC', null, null, null,
      'DEBIT/CREDIT NOTE TYPE', 'REVERSE CHARGE', 'Reason for issuing DR/CR Note', 'Pre-GST Regime',
      'VOUCHER NO', 'VOUCHER DATE', 'Supply Type', 'InEligible ITC(As Per Section 17(5))'
    ];
    const gstr2CdnRow1 = [
      null, null, null, null, 'NO', 'Date', 'NO', 'Date', null,
      'IGST', null, 'CGST', null, 'SGST/UTGST', null, 'CESS', null,
      null, null, 'IGST', 'CGST', 'SGST/UTGST', 'CESS'
    ];
    const gstr2CdnRow2 = [
      null, null, null, null, null, null, null, null, null,
      'RATE', 'AMOUNT', 'RATE', 'AMOUNT', 'RATE', 'AMOUNT', 'RATE', 'AMOUNT'
    ];

    const gstr2CdnRows: any[][] = [gstr2CdnRow0, gstr2CdnRow1, gstr2CdnRow2];

    const g2CdnData = extraSheets?.gstr2CrDrNotes || DEMO_GSTR2_CR_DR_NOTES;
    g2CdnData.forEach(item => {
      gstr2CdnRows.push([
        item.supplierGstin,
        item.supplierName,
        item.supplierState,
        item.pos,
        item.noteNumber,
        item.noteDate,
        item.originalInvoiceNumber,
        item.originalInvoiceDate,
        item.differentialValue,
        item.igstRate,
        item.igstAmount,
        item.cgstRate,
        item.cgstAmount,
        item.sgstRate,
        item.sgstAmount,
        item.cessRate,
        item.cessAmount,
        item.otherCharges,
        item.itcEligibility,
        item.itcIgst,
        item.itcCgst,
        item.itcSgst,
        item.itcCess,
        item.noteType,
        item.rcm ? 'Y' : 'N',
        item.reason,
        item.preGst ? 'Y' : 'N',
        item.voucherNo,
        item.voucherDate,
        item.supplyType,
        item.ineligibleSection17_5 || ''
      ]);
    });

    const gstr2CdnSheet = XLSX.utils.aoa_to_sheet(gstr2CdnRows);
    this.applyHeaderStyles(gstr2CdnSheet, 3, 31, GSTR2_CR_DR_MERGES);
    XLSX.utils.book_append_sheet(wb, gstr2CdnSheet, 'GSTR-2 DEBIT CREDIT NOTE');

    // -------------------------------------------------------------
    // Sheet 5: GSTR-1 ADVANCE TAX (20 cols, 2 rows header)
    // -------------------------------------------------------------
    const gstr1AdvRow0 = [
      'PARTY GSTIN', 'UIN', 'PARTY NAME', 'STATE', 'POS', 'Receipt Voucher NO.', 'Receipt Voucher date',
      'GOODS/\nSERVICES', 'HSN/SAC', 'ADVANCE RECEIVED (Exclusive of taxes)', 'IGST', null, 'CGST', null,
      'SGST/UTGST', null, 'CESS', null, 'Is Party Registered', 'Lease OF Old Car'
    ];
    const gstr1AdvRow1 = [
      null, null, null, null, null, null, null, null, null, null,
      'RATE', 'AMOUNT', 'RATE', 'AMOUNT', 'RATE', 'AMOUNT', 'RATE', 'AMOUNT'
    ];

    const gstr1AdvRows: any[][] = [gstr1AdvRow0, gstr1AdvRow1];

    const g1AdvData = extraSheets?.gstr1AdvanceTax || DEMO_GSTR1_ADVANCE_TAX;
    g1AdvData.forEach(item => {
      gstr1AdvRows.push([
        item.partyGstin,
        item.uin || '',
        item.partyName,
        item.state,
        item.pos,
        item.receiptVoucherNo,
        item.receiptVoucherDate,
        item.goodsOrServices,
        item.hsnSac,
        item.advanceReceived,
        item.igstRate,
        item.igstAmount,
        item.cgstRate,
        item.cgstAmount,
        item.sgstRate,
        item.sgstAmount,
        item.cessRate,
        item.cessAmount,
        item.isPartyRegistered,
        item.leaseOfOldCar || 'N'
      ]);
    });

    const gstr1AdvSheet = XLSX.utils.aoa_to_sheet(gstr1AdvRows);
    this.applyHeaderStyles(gstr1AdvSheet, 2, 20, GSTR1_ADVANCE_MERGES);
    XLSX.utils.book_append_sheet(wb, gstr1AdvSheet, 'GSTR-1 ADVANCE TAX');

    // -------------------------------------------------------------
    // Sheet 6: GSTR-2 ADVANCE TAX (18 cols, 2 rows header)
    // -------------------------------------------------------------
    const gstr2AdvRow0 = [
      'PARTY GSTIN', 'PARTY NAME', 'STATE', 'POS', 'Payment Voucher no.', 'Payment Voucher date',
      'GOODS/\nSERVICES', 'HSN/SAC', 'ADVANCE PAID', 'IGST', null, 'CGST', null, 'SGST/UTGST', null,
      'CESS', null, 'Is Party Registered'
    ];
    const gstr2AdvRow1 = [
      null, null, null, null, null, null, null, null, null,
      'RATE', 'AMOUNT', 'RATE', 'AMOUNT', 'RATE', 'AMOUNT', 'RATE', 'AMOUNT'
    ];

    const gstr2AdvRows: any[][] = [gstr2AdvRow0, gstr2AdvRow1];

    const g2AdvData = extraSheets?.gstr2AdvanceTax || DEMO_GSTR2_ADVANCE_TAX;
    g2AdvData.forEach(item => {
      gstr2AdvRows.push([
        item.partyGstin,
        item.partyName,
        item.state,
        item.pos,
        item.paymentVoucherNo,
        item.paymentVoucherDate,
        item.goodsOrServices,
        item.hsnSac,
        item.advancePaid,
        item.igstRate,
        item.igstAmount,
        item.cgstRate,
        item.cgstAmount,
        item.sgstRate,
        item.sgstAmount,
        item.cessRate,
        item.cessAmount,
        item.isPartyRegistered
      ]);
    });

    const gstr2AdvSheet = XLSX.utils.aoa_to_sheet(gstr2AdvRows);
    this.applyHeaderStyles(gstr2AdvSheet, 2, 18, GSTR2_ADVANCE_MERGES);
    XLSX.utils.book_append_sheet(wb, gstr2AdvSheet, 'GSTR-2 ADVANCE TAX');

    // -------------------------------------------------------------
    // Sheet 7: STATE (40 official states and territories)
    // -------------------------------------------------------------
    const stateSheet = XLSX.utils.aoa_to_sheet(OFFICIAL_TEMPLATE_STATES.map(s => [s]));
    this.applyHeaderStyles(stateSheet, 0, 1);
    XLSX.utils.book_append_sheet(wb, stateSheet, 'STATE');

    // -------------------------------------------------------------
    // Sheet 8: PORT (769 official Indian Customs Port Codes)
    // -------------------------------------------------------------
    const portSheet = XLSX.utils.aoa_to_sheet((portCodesMaster as any[]).map(p => [p.code, p.name]));
    this.applyHeaderStyles(portSheet, 0, 2);
    XLSX.utils.book_append_sheet(wb, portSheet, 'PORT');

    // -------------------------------------------------------------
    // Sheet 9: CrDrReasons (7 statutory reasons)
    // -------------------------------------------------------------
    const reasonsSheet = XLSX.utils.aoa_to_sheet(OFFICIAL_DR_CR_REASONS.map(r => [r]));
    this.applyHeaderStyles(reasonsSheet, 0, 1);
    XLSX.utils.book_append_sheet(wb, reasonsSheet, 'CrDrReasons');

    // -------------------------------------------------------------
    // Sheet 10: UQCMaster (46 official UQCs)
    // -------------------------------------------------------------
    const uqcSheet = XLSX.utils.aoa_to_sheet(OFFICIAL_UQCS.map(u => [u.code]));
    this.applyHeaderStyles(uqcSheet, 0, 1);
    XLSX.utils.book_append_sheet(wb, uqcSheet, 'UQCMaster');

    const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array', cellStyles: true });
    return new Uint8Array(wbout);
  }

  /**
   * Helper to normalize various date representations into YYYY-MM-DD
   */
  private normalizeDateString(dateVal: any): string {
    if (!dateVal) return new Date().toISOString().split('T')[0];

    // Handle Excel numeric serial dates (e.g. 45312)
    if (typeof dateVal === 'number') {
      const d = XLSX.SSF.parse_date_code(dateVal);
      if (d) {
        return `${d.y}-${String(d.m).padStart(2, '0')}-${String(d.d).padStart(2, '0')}`;
      }
    }

    const s = String(dateVal).trim();
    // YYYY-MM-DD
    if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;

    // DD-MM-YYYY or DD/MM/YYYY
    if (/^\d{2}[-/]\d{2}[-/]\d{4}$/.test(s)) {
      const parts = s.split(/[-/]/);
      return `${parts[2]}-${parts[1]}-${parts[0]}`;
    }

    return new Date().toISOString().split('T')[0];
  }
}

export const gstExcelTemplateService = new GstExcelTemplateService();

/**
 * Downloads official WEB_GST_Template.xlsx pre-filled with transaction data across all 10 sheets
 */
export function downloadWebGstTemplate(
  sales: TransactionInvoice[],
  purchases: TransactionInvoice[] = [],
  creditDebitNotes: TransactionInvoice[] = [],
  activeGstin: string = '07ABFFB5922Q1Z0',
  extraSheetsOrFilename?:
    | {
        gstr2CrDrNotes?: Gstr2CrDrNoteItem[];
        gstr1AdvanceTax?: Gstr1AdvanceTaxItem[];
        gstr2AdvanceTax?: Gstr2AdvanceTaxItem[];
      }
    | string,
  maybeFilename: string = 'WEB_GST_Template.xlsx'
) {
  let extraSheets:
    | {
        gstr2CrDrNotes?: Gstr2CrDrNoteItem[];
        gstr1AdvanceTax?: Gstr1AdvanceTaxItem[];
        gstr2AdvanceTax?: Gstr2AdvanceTaxItem[];
      }
    | undefined = undefined;
  let filename = maybeFilename;

  if (typeof extraSheetsOrFilename === 'string') {
    filename = extraSheetsOrFilename;
  } else if (extraSheetsOrFilename) {
    extraSheets = extraSheetsOrFilename;
  }

  const bytes = gstExcelTemplateService.exportToWebGstTemplate(
    sales,
    purchases,
    creditDebitNotes,
    activeGstin,
    extraSheets
  );
  const blob = new Blob([bytes.buffer as ArrayBuffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Downloads official blank WEB_GST_Template with all 10 sheets, styling and official masters
 */
export function downloadBlankWebGstTemplate(activeGstin: string = '07ABFFB5922Q1Z0') {
  // Try direct download of original binary .xls if hosted, otherwise export .xlsx
  const directLink = '/WEB_GST_Template.xls';
  const a = document.createElement('a');
  a.href = directLink;
  a.download = 'WEB_GST_Template.xls';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}
