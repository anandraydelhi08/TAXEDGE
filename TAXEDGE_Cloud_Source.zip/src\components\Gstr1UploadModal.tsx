import React, { useState } from 'react';
import {
  Upload,
  CheckCircle2,
  AlertTriangle,
  X,
  FileCheck2,
  ShieldCheck,
  Server,
  Lock,
  ArrowRight,
  RefreshCw,
  Building2,
  Calendar
} from 'lucide-react';
import { TransactionInvoice } from '../types/gst';
import { formatINR } from '../utils/taxMath';
import { gstProvider } from '../services/gstProvider';

interface Gstr1UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  gstin: string;
  financialYear: string;
  month: string;
  period: string; // e.g. "04-2026"
  invoices: TransactionInvoice[];
  onOpenCredentialVault?: (gstin: string) => void;
  onUploadSuccess?: (result: any) => void;
}

export const Gstr1UploadModal: React.FC<Gstr1UploadModalProps> = ({
  isOpen,
  onClose,
  gstin,
  financialYear,
  month,
  period,
  invoices,
  onOpenCredentialVault,
  onUploadSuccess
}) => {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadResult, setUploadResult] = useState<{
    success: boolean;
    referenceId?: string;
    acknowledgementNumber?: string;
    status?: string;
    timestamp?: string;
    totalInvoices?: number;
    totalTaxableValue?: number;
    totalGst?: number;
    gspProvider?: string;
    portalUsername?: string;
    message?: string;
    error?: string;
  } | null>(null);

  if (!isOpen) return null;

  const totalInvoices = invoices.length;
  const totalTaxable = invoices.reduce((acc, inv) => acc + (inv.taxableValue || 0), 0);
  const totalGst = invoices.reduce(
    (acc, inv) => acc + (inv.igst || 0) + (inv.cgst || 0) + (inv.sgst || 0) + (inv.cess || 0),
    0
  );

  const handleConfirmAndUpload = async () => {
    setIsUploading(true);
    setUploadResult(null);

    try {
      const res = await gstProvider.uploadGSTR1({
        gstin,
        financialYear,
        month,
        period,
        invoices
      });

      setUploadResult(res);
      if (res.success && onUploadSuccess) {
        onUploadSuccess(res);
      }
    } catch (err: any) {
      setUploadResult({
        success: false,
        error: err.message || 'Failed to upload GSTR-1 to GST Portal'
      });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#FFFFFF]/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white border border-[#E5E7EB] rounded-2xl max-w-xl w-full shadow-2xl p-6 space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-[#176B4D]/10 border border-[#176B4D]/30 text-[#176B4D]">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <span>GSTR-1 Portal Direct Upload</span>
                <span className="font-mono text-xs px-2 py-0.5 rounded bg-[#176B4D]/20 text-[#176B4D] font-semibold">
                  API Gateway
                </span>
              </h2>
              <p className="text-xs text-[#6B7280]">
                Direct transmission via configured Authorized GST Suvidha Provider (GSP)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-[#6B7280] hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* State 1: Confirmation View Before Upload */}
        {!uploadResult && (
          <div className="space-y-4 text-xs">
            <div className="p-4 rounded-xl bg-[#FFFFFF]/80 border border-[#E5E7EB] space-y-3">
              <div className="text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider">
                Upload Scope & Summary Confirmation
              </div>

              <div className="grid grid-cols-2 gap-3 pt-1">
                <div className="p-3 rounded-lg bg-white border border-[#E5E7EB]">
                  <span className="block text-[10px] uppercase font-semibold text-[#6B7280] mb-0.5">
                    Financial Year
                  </span>
                  <span className="font-mono font-bold text-white text-sm">
                    {financialYear}
                  </span>
                </div>

                <div className="p-3 rounded-lg bg-white border border-[#E5E7EB]">
                  <span className="block text-[10px] uppercase font-semibold text-[#6B7280] mb-0.5">
                    Month
                  </span>
                  <span className="font-bold text-white text-sm">
                    {month}
                  </span>
                </div>

                <div className="p-3 rounded-lg bg-white border border-[#E5E7EB]">
                  <span className="block text-[10px] uppercase font-semibold text-[#6B7280] mb-0.5">
                    Target GSTIN
                  </span>
                  <span className="font-mono font-semibold text-[#176B4D] text-xs">
                    {gstin}
                  </span>
                </div>

                <div className="p-3 rounded-lg bg-white border border-[#E5E7EB]">
                  <span className="block text-[10px] uppercase font-semibold text-[#6B7280] mb-0.5">
                    Invoices
                  </span>
                  <span className="font-mono font-bold text-white text-sm">
                    {totalInvoices}
                  </span>
                </div>

                <div className="p-3 rounded-lg bg-white border border-[#E5E7EB]">
                  <span className="block text-[10px] uppercase font-semibold text-[#6B7280] mb-0.5">
                    Taxable Value
                  </span>
                  <span className="font-mono font-bold text-[#B7791F] text-sm">
                    {formatINR(totalTaxable)}
                  </span>
                </div>

                <div className="p-3 rounded-lg bg-white border border-[#E5E7EB]">
                  <span className="block text-[10px] uppercase font-semibold text-[#6B7280] mb-0.5">
                    GST
                  </span>
                  <span className="font-mono font-bold text-[#176B4D] text-sm">
                    {formatINR(totalGst)}
                  </span>
                </div>
              </div>
            </div>

            <p className="text-[11px] text-[#6B7280]">
              Clicking <strong>Confirm & Upload</strong> transmits Table 4 (B2B), Table 5 (B2C Large), Table 7 (B2C Small), and HSN summaries to the GST portal using your configured portal credentials.
            </p>

            {/* Confirmation Action Buttons */}
            <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-[#E5E7EB]">
              <button
                type="button"
                onClick={onClose}
                disabled={isUploading}
                className="px-4 py-2 rounded-xl bg-[#F8F9FA] hover:bg-slate-700 text-[#6B7280] font-bold text-xs transition"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmAndUpload}
                disabled={isUploading || totalInvoices === 0}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white font-bold text-xs shadow-md shadow-emerald-900/40 transition flex items-center gap-2 disabled:opacity-50"
              >
                {isUploading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-white" />
                    <span>Transmitting to GSTN...</span>
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4" />
                    <span>Confirm & Upload</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* State 2: Error when API/GSP not configured */}
        {uploadResult && !uploadResult.success && (
          <div className="space-y-4 text-xs">
            <div className="p-4 rounded-xl bg-[#FDECEC] text-[#C62828] border border-rose-500/30 text-rose-200 space-y-2">
              <div className="flex items-center gap-2 text-rose-300 font-bold text-sm">
                <AlertTriangle className="w-5 h-5 text-[#C62828] shrink-0" />
                <span>{uploadResult.error || 'GST Portal API not configured'}</span>
              </div>
              <p className="text-[#6B7280] text-xs">
                To upload outward supplies directly to GSTR-1, you must configure the GST Portal Username and Password for GSTIN <span className="font-mono text-[#176B4D] font-bold">{gstin}</span>.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-[#FFFFFF]/80 border border-[#E5E7EB] flex items-center justify-between gap-3">
              <div>
                <div className="font-semibold text-white">Need to set up credentials?</div>
                <div className="text-[11px] text-[#6B7280]">Add credentials in Client Master or Credential Vault.</div>
              </div>
              {onOpenCredentialVault && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenCredentialVault(gstin);
                  }}
                  className="px-3.5 py-1.5 rounded-lg bg-[#FFF8E1] text-[#B7791F] hover:bg-[#FFF8E1] text-[#B7791F] border border-amber-500/40 text-[#B7791F] font-bold text-xs transition shrink-0"
                >
                  Configure Credentials
                </button>
              )}
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#E5E7EB]">
              <button
                type="button"
                onClick={() => setUploadResult(null)}
                className="px-4 py-2 rounded-xl bg-[#F8F9FA] hover:bg-slate-700 text-[#6B7280] font-semibold text-xs"
              >
                Back
              </button>
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-[#F8F9FA] hover:bg-slate-700 text-white font-bold text-xs"
              >
                Close
              </button>
            </div>
          </div>
        )}

        {/* State 3: Successful API Confirmation and Actual Status */}
        {uploadResult && uploadResult.success && (
          <div className="space-y-4 text-xs">
            <div className="p-4 rounded-xl bg-[#176B4D]/10 border border-[#176B4D]/30 text-emerald-200 space-y-3">
              <div className="flex items-center justify-between border-b border-[#176B4D]/30 pb-2.5">
                <div className="flex items-center gap-2 font-bold text-white text-sm">
                  <CheckCircle2 className="w-5 h-5 text-[#176B4D] shrink-0" />
                  <span>GSTR-1 Upload Confirmed</span>
                </div>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono bg-[#176B4D]/20 text-[#176B4D] border border-[#176B4D]/30 uppercase">
                  {uploadResult.status}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2.5 text-xs">
                <div>
                  <span className="block text-[10px] uppercase font-semibold text-[#6B7280]">
                    Portal Reference ID
                  </span>
                  <span className="font-mono text-[#176B4D] font-bold text-xs">
                    {uploadResult.referenceId}
                  </span>
                </div>
                <div>
                  <span className="block text-[10px] uppercase font-semibold text-[#6B7280]">
                    Acknowledgement No.
                  </span>
                  <span className="font-mono text-white text-xs">
                    {uploadResult.acknowledgementNumber}
                  </span>
                </div>
                <div>
                  <span className="block text-[10px] uppercase font-semibold text-[#6B7280]">
                    GSP Integration Gateway
                  </span>
                  <span className="text-[#202124] font-medium">
                    {uploadResult.gspProvider}
                  </span>
                </div>
                <div>
                  <span className="block text-[10px] uppercase font-semibold text-[#6B7280]">
                    Timestamp
                  </span>
                  <span className="text-[#6B7280] font-mono text-[11px]">
                    {uploadResult.timestamp}
                  </span>
                </div>
              </div>

              <div className="pt-2 border-t border-[#176B4D]/30 grid grid-cols-3 gap-2 text-center">
                <div className="p-2 rounded bg-white border border-[#E5E7EB]">
                  <div className="text-[10px] text-[#6B7280]">Invoices</div>
                  <div className="font-mono font-bold text-white">{uploadResult.totalInvoices}</div>
                </div>
                <div className="p-2 rounded bg-white border border-[#E5E7EB]">
                  <div className="text-[10px] text-[#6B7280]">Taxable Value</div>
                  <div className="font-mono font-bold text-[#B7791F]">{formatINR(uploadResult.totalTaxableValue || 0)}</div>
                </div>
                <div className="p-2 rounded bg-white border border-[#E5E7EB]">
                  <div className="text-[10px] text-[#6B7280]">Total GST</div>
                  <div className="font-mono font-bold text-[#176B4D]">{formatINR(uploadResult.totalGst || 0)}</div>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#E5E7EB]">
              <button
                type="button"
                onClick={onClose}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-slate-500 hover:from-emerald-500 hover:to-slate-400 text-slate-950 font-bold text-xs shadow-md transition"
              >
                Done
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
