/**
 * Deterministic Financial Arithmetic and GST Tax Engine
 * Rule: Financial math MUST happen in deterministic backend code, never in floating point approximations.
 */

export function round2(num: number): number {
  return Math.round((num + Number.EPSILON) * 100) / 100;
}

export function formatINR(val: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(val);
}

export interface TaxCalculationResult {
  taxableValue: number;
  gstRate: number;
  isInterState: boolean;
  cgst: number;
  sgst: number;
  igst: number;
  cess: number;
  totalTax: number;
  totalAmount: number;
  rcmApplicable: boolean;
}

export function calculateDeterministicTax(
  taxableValue: number,
  gstRate: number,
  isInterState: boolean,
  isRcm: boolean = false,
  cessRate: number = 0
): TaxCalculationResult {
  const roundedTaxable = round2(taxableValue);
  const rateFraction = gstRate / 100;

  let cgst = 0;
  let sgst = 0;
  let igst = 0;
  let cess = 0;

  if (cessRate > 0) {
    cess = round2(roundedTaxable * (cessRate / 100));
  }

  if (isInterState) {
    igst = round2(roundedTaxable * rateFraction);
  } else {
    const halfRate = rateFraction / 2;
    cgst = round2(roundedTaxable * halfRate);
    sgst = round2(roundedTaxable * halfRate);
  }

  const totalTax = round2(cgst + sgst + igst + cess);
  const totalAmount = round2(roundedTaxable + totalTax);

  return {
    taxableValue: roundedTaxable,
    gstRate,
    isInterState,
    cgst,
    sgst,
    igst,
    cess,
    totalTax,
    totalAmount,
    rcmApplicable: isRcm
  };
}

export function verifyInvoiceTotals(inv: {
  taxableValue: number;
  cgst: number;
  sgst: number;
  igst: number;
  cess: number;
  totalAmount: number;
}): { valid: boolean; calculatedTotal: number; difference: number } {
  const sumOfComponents = round2(inv.taxableValue + inv.cgst + inv.sgst + inv.igst + inv.cess);
  const reportedTotal = round2(inv.totalAmount);
  const diff = round2(Math.abs(sumOfComponents - reportedTotal));
  return {
    valid: diff <= 0.05, // Allow +/- 5 paise rounding difference
    calculatedTotal: sumOfComponents,
    difference: diff
  };
}

export interface ITCSetOffLedger {
  liability: { igst: number; cgst: number; sgst: number; cess: number };
  itcAvailable: { igst: number; cgst: number; sgst: number; cess: number };
  itcUtilised: {
    igstFromIgst: number;
    igstFromCgst: number;
    igstFromSgst: number;
    cgstFromIgst: number;
    cgstFromCgst: number;
    sgstFromIgst: number;
    sgstFromSgst: number;
    cessFromCess: number;
  };
  cashPayable: { igst: number; cgst: number; sgst: number; cess: number };
  closingITC: { igst: number; cgst: number; sgst: number; cess: number };
}

/**
 * Computes GST payment set-off strictly complying with Section 49, 49A, 49B and Rule 88A
 * Priority:
 * 1. IGST Credit is FIRST fully exhausted against IGST Liability, then CGST & SGST.
 * 2. CGST Credit is utilised against CGST Liability, then IGST Liability.
 * 3. SGST Credit is utilised against SGST Liability, then IGST Liability.
 * 4. Cross-utilisation between CGST and SGST is STRICTLY PROHIBITED.
 */
export function calculateRule88ASetOff(
  grossLiability: { igst: number; cgst: number; sgst: number; cess: number },
  availableITC: { igst: number; cgst: number; sgst: number; cess: number }
): ITCSetOffLedger {
  let remLiabilityIgst = round2(grossLiability.igst);
  let remLiabilityCgst = round2(grossLiability.cgst);
  let remLiabilitySgst = round2(grossLiability.sgst);
  let remLiabilityCess = round2(grossLiability.cess);

  let remCreditIgst = round2(availableITC.igst);
  let remCreditCgst = round2(availableITC.cgst);
  let remCreditSgst = round2(availableITC.sgst);
  let remCreditCess = round2(availableITC.cess);

  const itcUtilised = {
    igstFromIgst: 0,
    igstFromCgst: 0,
    igstFromSgst: 0,
    cgstFromIgst: 0,
    cgstFromCgst: 0,
    sgstFromIgst: 0,
    sgstFromSgst: 0,
    cessFromCess: 0
  };

  // Step 1: Utilize IGST Credit against IGST Liability
  const igstAgainstIgst = Math.min(remCreditIgst, remLiabilityIgst);
  itcUtilised.igstFromIgst = round2(igstAgainstIgst);
  remCreditIgst = round2(remCreditIgst - igstAgainstIgst);
  remLiabilityIgst = round2(remLiabilityIgst - igstAgainstIgst);

  // Step 2: Utilize remaining IGST Credit against CGST & SGST Liability
  if (remCreditIgst > 0 && remLiabilityCgst > 0) {
    const igstAgainstCgst = Math.min(remCreditIgst, remLiabilityCgst);
    itcUtilised.cgstFromIgst = round2(igstAgainstCgst);
    remCreditIgst = round2(remCreditIgst - igstAgainstCgst);
    remLiabilityCgst = round2(remLiabilityCgst - igstAgainstCgst);
  }

  if (remCreditIgst > 0 && remLiabilitySgst > 0) {
    const igstAgainstSgst = Math.min(remCreditIgst, remLiabilitySgst);
    itcUtilised.sgstFromIgst = round2(igstAgainstSgst);
    remCreditIgst = round2(remCreditIgst - igstAgainstSgst);
    remLiabilitySgst = round2(remLiabilitySgst - igstAgainstSgst);
  }

  // Step 3: Utilize CGST Credit against CGST Liability, then IGST Liability
  if (remLiabilityCgst > 0 && remCreditCgst > 0) {
    const cgstAgainstCgst = Math.min(remCreditCgst, remLiabilityCgst);
    itcUtilised.cgstFromCgst = round2(cgstAgainstCgst);
    remCreditCgst = round2(remCreditCgst - cgstAgainstCgst);
    remLiabilityCgst = round2(remLiabilityCgst - cgstAgainstCgst);
  }
  if (remLiabilityIgst > 0 && remCreditCgst > 0) {
    const cgstAgainstIgst = Math.min(remCreditCgst, remLiabilityIgst);
    itcUtilised.igstFromCgst = round2(cgstAgainstIgst);
    remCreditCgst = round2(remCreditCgst - cgstAgainstIgst);
    remLiabilityIgst = round2(remLiabilityIgst - cgstAgainstIgst);
  }

  // Step 4: Utilize SGST Credit against SGST Liability, then IGST Liability
  if (remLiabilitySgst > 0 && remCreditSgst > 0) {
    const sgstAgainstSgst = Math.min(remCreditSgst, remLiabilitySgst);
    itcUtilised.sgstFromSgst = round2(sgstAgainstSgst);
    remCreditSgst = round2(remCreditSgst - sgstAgainstSgst);
    remLiabilitySgst = round2(remLiabilitySgst - sgstAgainstSgst);
  }
  if (remLiabilityIgst > 0 && remCreditSgst > 0) {
    const sgstAgainstIgst = Math.min(remCreditSgst, remLiabilityIgst);
    itcUtilised.igstFromSgst = round2(sgstAgainstIgst);
    remCreditSgst = round2(remCreditSgst - sgstAgainstIgst);
    remLiabilityIgst = round2(remLiabilityIgst - sgstAgainstIgst);
  }

  // Step 5: Cess Credit against Cess Liability
  if (remLiabilityCess > 0 && remCreditCess > 0) {
    const cessAgainstCess = Math.min(remCreditCess, remLiabilityCess);
    itcUtilised.cessFromCess = round2(cessAgainstCess);
    remCreditCess = round2(remCreditCess - cessAgainstCess);
    remLiabilityCess = round2(remLiabilityCess - cessAgainstCess);
  }

  return {
    liability: { ...grossLiability },
    itcAvailable: { ...availableITC },
    itcUtilised,
    cashPayable: {
      igst: round2(remLiabilityIgst),
      cgst: round2(remLiabilityCgst),
      sgst: round2(remLiabilitySgst),
      cess: round2(remLiabilityCess)
    },
    closingITC: {
      igst: round2(remCreditIgst),
      cgst: round2(remCreditCgst),
      sgst: round2(remCreditSgst),
      cess: round2(remCreditCess)
    }
  };
}
