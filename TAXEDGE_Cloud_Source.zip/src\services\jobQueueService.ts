/**
 * Background Job Queue System for CA GST Practice Automation
 * Executes bulk 2B syncs, reconciliations, and return syncs asynchronously without blocking the UI.
 */

import { BackgroundJob } from '../types/client';
import { gstProvider } from './gstProvider';
import { clientStorageService } from './clientStorageService';
import { credentialVaultService } from './credentialVaultService';
import { reconciliationEngine } from './reconciliationEngine';

export type JobQueueListener = (jobs: BackgroundJob[]) => void;

class JobQueueService {
  private jobs: BackgroundJob[] = [];
  private listeners: Set<JobQueueListener> = new Set();
  private isProcessing: boolean = false;

  public subscribe(listener: JobQueueListener): () => void {
    this.listeners.add(listener);
    listener([...this.jobs]);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    for (const listener of this.listeners) {
      listener([...this.jobs]);
    }
  }

  public getJobs(): BackgroundJob[] {
    return [...this.jobs];
  }

  public clearCompleted() {
    this.jobs = this.jobs.filter(j => j.status === 'Processing' || j.status === 'Queued');
    this.notify();
  }

  /**
   * Enqueues a single or bulk sync jobs for GSTINs
   */
  public enqueueBulk2BSync(
    gstinsToSync: { clientId: string; clientName: string; gstin: string }[],
    period: string = '04-2026'
  ): void {
    const newJobs: BackgroundJob[] = gstinsToSync.map(item => ({
      id: `job-2b-${item.gstin}-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      type: '2B_SYNC',
      clientId: item.clientId,
      clientName: item.clientName,
      gstin: item.gstin,
      period,
      status: 'Queued',
      progressPercent: 0,
      startTime: new Date().toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata' }),
      retryCount: 0
    }));

    this.jobs.unshift(...newJobs);
    this.notify();
    this.processQueue();
  }

  public retryJob(jobId: string) {
    const job = this.jobs.find(j => j.id === jobId);
    if (!job) return;

    job.status = 'Queued';
    job.progressPercent = 0;
    job.errorMessage = undefined;
    job.retryCount += 1;
    this.notify();
    this.processQueue();
  }

  public retryAllFailed() {
    for (const job of this.jobs) {
      if (job.status === 'Failed') {
        job.status = 'Queued';
        job.progressPercent = 0;
        job.errorMessage = undefined;
        job.retryCount += 1;
      }
    }
    this.notify();
    this.processQueue();
  }

  private async processQueue() {
    if (this.isProcessing) return;
    this.isProcessing = true;

    while (true) {
      const nextJob = this.jobs.find(j => j.status === 'Queued');
      if (!nextJob) break;

      nextJob.status = 'Processing';
      nextJob.progressPercent = 20;
      this.notify();

      try {
        await this.executeJob(nextJob);
        nextJob.status = 'Completed';
        nextJob.progressPercent = 100;
        nextJob.endTime = new Date().toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata' });
      } catch (err: any) {
        nextJob.status = 'Failed';
        nextJob.errorMessage = err.message || 'Operation failed during GSTN connection';
        nextJob.progressPercent = 100;
        nextJob.endTime = new Date().toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata' });
      }

      this.notify();
      // Brief pause between jobs to mimic distributed queue throttle
      await new Promise(r => setTimeout(r, 400));
    }

    this.isProcessing = false;
  }

  private async executeJob(job: BackgroundJob): Promise<void> {
    const cred = credentialVaultService.getCredential(job.gstin);

    if (!cred || cred.credentialStatus === 'UNCONFIGURED' || cred.apiConnectionStatus === 'OFFLINE') {
      // Simulate failed connection gracefully
      const allGstins = clientStorageService.getAllGstins();
      const gstinEntry = allGstins.find(g => g.gstin === job.gstin);
      if (gstinEntry) {
        gstinEntry.status2B = 'NOT_IMPORTED';
        clientStorageService.updateGstin(gstinEntry);
      }
      throw new Error('GST PORTAL INTEGRATION NOT CONFIGURED: No active GSP credential linked for this GSTIN.');
    }

    if (cred.credentialStatus === 'NEEDS_AUTH') {
      const allGstins = clientStorageService.getAllGstins();
      const gstinEntry = allGstins.find(g => g.gstin === job.gstin);
      if (gstinEntry) {
        gstinEntry.status2B = 'REVIEW_REQUIRED';
        clientStorageService.updateGstin(gstinEntry);
      }
      throw new Error('GSTN Auth Session Expired: 2FA/OTP re-verification required for ' + cred.portalUsername);
    }

    // Progress step 1: Authenticate with GSP
    job.progressPercent = 40;
    this.notify();
    await gstProvider.authenticate(job.gstin);

    // Progress step 2: Fetch GSTR-2B Statement
    job.progressPercent = 65;
    this.notify();
    const gstr2bResponse = await gstProvider.getGSTR2B(job.gstin, job.period);

    // Progress step 3: Store imported data & auto-trigger reconciliation
    job.progressPercent = 85;
    this.notify();

    const clientData = clientStorageService.getClientData(job.clientId, job.gstin, job.period);
    clientData.gstr2b = gstr2bResponse.records;

    // Run automatic reconciliation
    const recon = reconciliationEngine.reconcilePurchaseVs2B(clientData.purchases, gstr2bResponse.records);
    clientStorageService.saveClientData(job.clientId, job.gstin, job.period, clientData);

    // Update GSTIN Master summary status
    const allGstins = clientStorageService.getAllGstins();
    const gstinEntry = allGstins.find(g => g.gstin === job.gstin);
    if (gstinEntry) {
      gstinEntry.last2bSync = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }) + ' IST';
      gstinEntry.eligibleItc = recon.financialSummary.eligibleItc;
      gstinEntry.status2B = recon.stats.reviewRequiredCount > 0 ? 'REVIEW_REQUIRED' : 'RECONCILED';
      clientStorageService.updateGstin(gstinEntry);
    }

    job.resultSummary = `Synced ${gstr2bResponse.totalInvoices} invoices (Taxable: ₹${gstr2bResponse.totalTaxableValue.toLocaleString('en-IN')}) • Reconciled (${recon.stats.totalMatchRatePercent}% match)`;
  }
}

export const jobQueueService = new JobQueueService();
