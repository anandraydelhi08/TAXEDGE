/**
 * Official GSTN Constants & Master Code Dictionaries
 * Source: Official Goods and Services Tax Network (GSTN) Offline Tool & Schema Specifications
 */

export interface UqcEntry {
  code: string;
  name: string;
}

export const OFFICIAL_UQCS: UqcEntry[] = [
  { code: 'BAG', name: 'BAGS' },
  { code: 'BAL', name: 'BALE' },
  { code: 'BDL', name: 'BUNDLES' },
  { code: 'BKL', name: 'BUCKLES' },
  { code: 'BOU', name: 'BILLIONS OF UNITS' },
  { code: 'BOX', name: 'BOX' },
  { code: 'BTL', name: 'BOTTLES' },
  { code: 'BUN', name: 'BUNCHES' },
  { code: 'CAN', name: 'CANS' },
  { code: 'CBM', name: 'CUBIC METERS' },
  { code: 'CCM', name: 'CUBIC CENTIMETERS' },
  { code: 'CMS', name: 'CENTIMETERS' },
  { code: 'CTN', name: 'CARTONS' },
  { code: 'DOZ', name: 'DOZENS' },
  { code: 'DRM', name: 'DRUMS' },
  { code: 'GGK', name: 'GREAT GROSS' },
  { code: 'GMS', name: 'GRAMMES' },
  { code: 'GRS', name: 'GROSS' },
  { code: 'GYD', name: 'GROSS YARDS' },
  { code: 'KGS', name: 'KILOGRAMS' },
  { code: 'KLR', name: 'KILOLITRE' },
  { code: 'KME', name: 'KILOMETRE' },
  { code: 'MLT', name: 'MILLILITRE' },
  { code: 'MTR', name: 'METERS' },
  { code: 'MTS', name: 'METRIC TON' },
  { code: 'NOS', name: 'NUMBERS' },
  { code: 'OTH', name: 'OTHERS' },
  { code: 'PAC', name: 'PACKS' },
  { code: 'PCS', name: 'PIECES' },
  { code: 'PRS', name: 'PAIRS' },
  { code: 'QTL', name: 'QUINTAL' },
  { code: 'ROL', name: 'ROLLS' },
  { code: 'SET', name: 'SETS' },
  { code: 'SQF', name: 'SQUARE FEET' },
  { code: 'SQM', name: 'SQUARE METERS' },
  { code: 'SQY', name: 'SQUARE YARDS' },
  { code: 'TBS', name: 'TABLETS' },
  { code: 'TGM', name: 'TEN GROSS' },
  { code: 'THD', name: 'THOUSANDS' },
  { code: 'TON', name: 'TONNES' },
  { code: 'TUB', name: 'TUBES' },
  { code: 'UGS', name: 'US GALLONS' },
  { code: 'UNT', name: 'UNITS' },
  { code: 'YDS', name: 'YARDS' },
  { code: 'LTR', name: 'LITRES' },
  { code: 'NA', name: 'NOT APPLICABLE (Services)' }
];

export const OFFICIAL_DR_CR_REASONS = [
  '01-Sales Return',
  '02-Post Sale Discount',
  '03-Deficiency in services',
  '04-Correction in Invoice',
  '05-Change in POS',
  '06-Finalization of Provisional assessment',
  '07-Others'
];

export interface PortCodeEntry {
  code: string;
  name: string;
}

export const OFFICIAL_PORT_CODES: PortCodeEntry[] = [
  { code: 'INNSA1', name: 'Nhava Sheva Sea (JNPT Mumbai)' },
  { code: 'INBOM4', name: 'Bombay Air Cargo (Sahar ACC)' },
  { code: 'INBOM1', name: 'Bombay Sea (Mumbai Port)' },
  { code: 'INDEL4', name: 'Delhi Air Cargo (IGI Airport)' },
  { code: 'INMAA1', name: 'Chennai Sea' },
  { code: 'INMAA4', name: 'Chennai Air Cargo' },
  { code: 'INCCU1', name: 'Kolkata Sea' },
  { code: 'INCCU4', name: 'Kolkata Air Cargo' },
  { code: 'INMUN1', name: 'Mundra Port' },
  { code: 'INIXY1', name: 'Kandla Sea' },
  { code: 'INBLR4', name: 'Bangalore Air Cargo' },
  { code: 'INAMD4', name: 'Ahmedabad Air Cargo' },
  { code: 'INHYD4', name: 'Hyderabad Air Cargo' },
  { code: 'INCOK1', name: 'Cochin Sea' },
  { code: 'INCOK4', name: 'Cochin Air Cargo' },
  { code: 'INVTZ1', name: 'Visakhapatnam Sea' },
  { code: 'INHAL1', name: 'Haldia Sea' },
  { code: 'INPPG6', name: 'Patparganj ICD (Delhi)' },
  { code: 'INTKD6', name: 'Tughlakabad ICD (Delhi)' },
  { code: 'INDER6', name: 'Dadri ICD (Greater Noida)' },
  { code: 'INWFD6', name: 'Whitefield ICD (Bangalore)' },
  { code: 'INPNQ4', name: 'Pune Air Cargo' },
  { code: 'INNGP6', name: 'Nagpur ICD' },
  { code: 'INLDH6', name: 'Ludhiana ICD' },
  { code: 'DEEMED', name: 'Deemed Export' }
];

export interface StatePosEntry {
  code: string;
  name: string;
}

export const OFFICIAL_POS_LIST: StatePosEntry[] = [
  { code: '01', name: 'JAMMU AND KASHMIR' },
  { code: '02', name: 'HIMACHAL PRADESH' },
  { code: '03', name: 'PUNJAB' },
  { code: '04', name: 'CHANDIGARH' },
  { code: '05', name: 'UTTARAKHAND' },
  { code: '06', name: 'HARYANA' },
  { code: '07', name: 'DELHI' },
  { code: '08', name: 'RAJASTHAN' },
  { code: '09', name: 'UTTAR PRADESH' },
  { code: '10', name: 'BIHAR' },
  { code: '11', name: 'SIKKIM' },
  { code: '12', name: 'ARUNACHAL PRADESH' },
  { code: '13', name: 'NAGALAND' },
  { code: '14', name: 'MANIPUR' },
  { code: '15', name: 'MIZORAM' },
  { code: '16', name: 'TRIPURA' },
  { code: '17', name: 'MEGHALAYA' },
  { code: '18', name: 'ASSAM' },
  { code: '19', name: 'WEST BENGAL' },
  { code: '20', name: 'JHARKHAND' },
  { code: '21', name: 'ODISHA' },
  { code: '22', name: 'CHHATTISGARH' },
  { code: '23', name: 'MADHYA PRADESH' },
  { code: '24', name: 'GUJARAT' },
  { code: '26', name: 'DADRA & NAGAR HAVELI AND DAMAN & DIU' },
  { code: '27', name: 'MAHARASHTRA' },
  { code: '29', name: 'KARNATAKA' },
  { code: '30', name: 'GOA' },
  { code: '31', name: 'LAKSHWADEEP' },
  { code: '32', name: 'KERALA' },
  { code: '33', name: 'TAMILNADU' },
  { code: '34', name: 'PONDICHERRY' },
  { code: '35', name: 'ANDAMAN AND NICOBAR ISLANDS' },
  { code: '36', name: 'TELANGANA' },
  { code: '37', name: 'ANDHRA PRADESH' },
  { code: '38', name: 'LADAKH' },
  { code: '97', name: 'OTHER TERRITORY' }
];

export const OFFICIAL_TEMPLATE_STATES: string[] = [
  'ANDAMAN AND NICOBAR ISLANDS',
  'ANDHRA PRADESH',
  'ARUNACHAL PRADESH',
  'ASSAM',
  'BIHAR',
  'CHANDIGARH',
  'DADRA & NAGAR HAVELI',
  'DAMAN & DIU',
  'DELHI',
  'GOA',
  'GUJARAT',
  'HARYANA',
  'HIMACHAL PRADESH',
  'JAMMU & KASHMIR',
  'KARNATAKA',
  'KERALA',
  'LAKSHWADEEP',
  'MADHYA PRADESH',
  'MAHARASHTRA',
  'MANIPUR',
  'MEGHALAYA',
  'MIZORAM',
  'NAGALAND',
  'ODISHA',
  'PONDICHERRY',
  'PUNJAB',
  'RAJASTHAN',
  'SIKKIM',
  'TAMILNADU',
  'TRIPURA',
  'UTTAR PRADESH',
  'WEST BENGAL',
  'CHHATTISGARH',
  'UTTARAKHAND',
  'JHARKHAND',
  'TELANGANA',
  'LADAKH',
  'OTHER TERRITORY',
  'FOREIGN COUNTRY',
  'STATE OUTSIDE INDIA'
];

export const OFFICIAL_SUPPLY_TYPES = [
  { id: 'B2B', label: 'B2B (Regular Registered)' },
  { id: 'B2CL', label: 'B2C Large (Inter-state > 2.5L)' },
  { id: 'B2CS', label: 'B2C Small (Retail / Intra-state)' },
  { id: 'EXPORT_WPAY', label: 'Export With Payment (WPAY)' },
  { id: 'EXPORT_WOPAY', label: 'Export Without Payment / LUT (WOPAY)' },
  { id: 'SEZ_WPAY', label: 'SEZ With Payment' },
  { id: 'SEZ_WOPAY', label: 'SEZ Without Payment' },
  { id: 'DEEMED_EXPORT', label: 'Deemed Export' }
];

export const OFFICIAL_ITC_OPTIONS = [
  { id: 'ELIGIBLE', label: 'Eligible ITC (All other inputs/services)' },
  { id: 'INELIGIBLE', label: 'Ineligible ITC (Non-business / Exempt)' },
  { id: 'BLOCKED_17_5', label: 'Blocked ITC under Section 17(5)' }
];

export const OFFICIAL_BLOCKED_REASONS = [
  { id: 'SEC_17_5_A_MOTOR_VEHICLES', label: 'Sec 17(5)(a) - Motor Vehicles & Conveyances' },
  { id: 'SEC_17_5_B_FOOD_BEVERAGE_CATERING_HEALTH', label: 'Sec 17(5)(b) - Food, Catering, Beauty & Health' },
  { id: 'SEC_17_5_C_WORKS_CONTRACT_IMMOVABLE', label: 'Sec 17(5)(c) - Works Contract Immovable Property' },
  { id: 'SEC_17_5_D_CONSTRUCTION_SELF_IMMOVABLE', label: 'Sec 17(5)(d) - Construction on Own Account' },
  { id: 'SEC_17_5_H_LOST_STOLEN_DESTROYED_GIFT_SAMPLES', label: 'Sec 17(5)(h) - Lost, Stolen, Destroyed, Gifts' },
  { id: 'SEC_17_5_FA_CSR_EXPENDITURE', label: 'Sec 17(5)(fa) - CSR Expenditure' },
  { id: 'SEC_16_4_TIME_BARRED', label: 'Sec 16(4) - Time Barred Invoice' },
  { id: 'RULE_37_180_DAYS_NON_PAYMENT', label: 'Rule 37 - 180 Days Non-Payment Reversal' }
];
