import React from 'react';
import { History, ShieldCheck, Download, Search, Terminal } from 'lucide-react';
import { AuditLog } from '../types/gst';

interface AuditTrailViewProps {
  logs: AuditLog[];
}

export const AuditTrailView: React.FC<AuditTrailViewProps> = ({ logs }) => {
  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-black text-white flex items-center gap-2">
              <History className="w-5 h-5 text-[#176B4D]" />
              Statutory Audit Trail (Section 35 & 36)
            </h2>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#176B4D]/20 text-[#176B4D] font-bold border border-[#176B4D]/30">
              Immutable Records
            </span>
          </div>
          <p className="text-xs text-[#6B7280] mt-1">
            Tamper-evident logs of all invoice ingestions, legal classifications, 2B reconciliations, and filing approvals.
          </p>
        </div>
      </div>

      {/* Logs Table */}
      <div className="bg-white border border-[#E5E7EB] rounded-xl overflow-hidden shadow-lg p-5 space-y-4">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#6B7280]">
            <thead className="bg-[#F8F9FA] text-[#6B7280] text-[11px] uppercase font-semibold">
              <tr>
                <th className="px-4 py-3">Timestamp</th>
                <th className="px-3 py-3">Actor & Role</th>
                <th className="px-3 py-3">Module</th>
                <th className="px-4 py-3">Action Description</th>
                <th className="px-4 py-3">Details / Resolution</th>
                <th className="px-3 py-3 font-mono">Payload Hash</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {logs.map(log => (
                <tr key={log.id} className="hover:bg-[#F8F9FA]">
                  <td className="px-4 py-3 text-[#6B7280] font-mono whitespace-nowrap">
                    {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </td>
                  <td className="px-3 py-3">
                    <span className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded ${
                      log.actorRole === 'USER'
                        ? 'bg-[#E8F5EF] text-[#176B4D] border border-emerald-800'
                        : log.actorRole === 'AI_AGENT'
                        ? 'bg-[#E8F5EF] text-[#176B4D] border border-emerald-800'
                        : 'bg-purple-950 text-purple-300 border border-purple-800'
                    }`}>
                      {log.actorRole}
                    </span>
                    <div className="text-[10px] text-[#6B7280] mt-0.5">{log.actor}</div>
                  </td>
                  <td className="px-3 py-3 font-semibold text-white">{log.module}</td>
                  <td className="px-4 py-3 text-[#176B4D] font-medium">{log.action}</td>
                  <td className="px-4 py-3 text-[#6B7280] text-[11px]">{log.details}</td>
                  <td className="px-3 py-3 font-mono text-[10px] text-[#6B7280] truncate max-w-[120px]">
                    {log.payloadHash || 'SHA256:7e91a0...'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
