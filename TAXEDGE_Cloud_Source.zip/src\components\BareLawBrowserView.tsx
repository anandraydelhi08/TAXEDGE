import React, { useState } from 'react';
import { BookOpen, Search, Filter, ShieldCheck, ChevronRight, Bookmark, ArrowRight, ExternalLink } from 'lucide-react';
import { gstRagService } from '../services/gstRagService';
import { GSTLawProvision } from '../types/gst';

interface BareLawBrowserViewProps {
  onOpenAI: (prompt: string) => void;
}

export const BareLawBrowserView: React.FC<BareLawBrowserViewProps> = ({ onOpenAI }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedAct, setSelectedAct] = useState<string>('ALL');
  const [activeProvision, setActiveProvision] = useState<GSTLawProvision | null>(null);

  const searchResults = gstRagService.searchGSTLaw(
    searchTerm,
    selectedAct !== 'ALL' ? { act: selectedAct } : undefined
  );

  const displayedProvisions = searchResults.map(r => r.provision);
  const currentItem = activeProvision || displayedProvisions[0] || null;

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-black text-[#202124] flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-[#B7791F]" />
              GST Bare Law Knowledge Base (April 2026 Edition)
            </h2>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#FFF8E1] text-[#B7791F] text-[#B7791F] font-bold border border-amber-500/30">
              ICAI 12th Revised Edition
            </span>
          </div>
          <p className="text-xs text-[#6B7280] mt-1">
            Authoritative legal reference incorporating all amendments up to 31 March 2026.
          </p>
        </div>

        <button
          onClick={() => onOpenAI(`Explain ${currentItem?.sectionNumber ? 'Section ' + currentItem.sectionNumber : 'Rule ' + currentItem?.ruleNumber} under ICAI Bare Law April 2026`)}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-bold text-xs shadow-md transition"
        >
          <span>Ask AI about Current Section</span>
        </button>
      </div>

      {/* Search and Act Filter */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-3 bg-white border border-[#E5E7EB] p-3 rounded-xl">
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 text-[#176B4D] absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Search section (e.g. '16', '17(5)', '9(3)', 'Rule 88A', 'RCM', 'ITC')..."
            className="w-full bg-[#F8F9FA] border border-[#E5E7EB] text-[#202124] text-xs rounded-lg pl-9 pr-3 py-2 focus:outline-none focus:border-amber-500"
          />
        </div>

        <div className="flex items-center gap-1.5 w-full md:w-auto overflow-x-auto">
          {[
            { id: 'ALL', label: 'All Provisions' },
            { id: 'CGST_ACT', label: 'CGST Act, 2017' },
            { id: 'IGST_ACT', label: 'IGST Act, 2017' },
            { id: 'CGST_RULES', label: 'CGST Rules, 2017' }
          ].map(act => (
            <button
              key={act.id}
              onClick={() => setSelectedAct(act.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
                selectedAct === act.id
                  ? 'bg-[#FFF8E1] text-[#B7791F] text-[#B7791F] border border-amber-500/40'
                  : 'bg-[#F8F9FA] text-[#6B7280] hover:bg-slate-700'
              }`}
            >
              {act.label}
            </button>
          ))}
        </div>
      </div>

      {/* 2-Column Split: Provision List vs Full Legal Text */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Provision List */}
        <div className="lg:col-span-4 bg-white border border-[#E5E7EB] rounded-xl overflow-hidden shadow-lg max-h-[700px] overflow-y-auto divide-y divide-slate-800">
          {displayedProvisions.map(p => {
            const isSelected = currentItem?.id === p.id;
            return (
              <button
                key={p.id}
                onClick={() => setActiveProvision(p)}
                className={`w-full p-3.5 text-left transition flex items-start justify-between gap-2 ${
                  isSelected ? 'bg-[#FFF8E1] text-[#B7791F] border-l-4 border-amber-500 text-amber-200' : 'hover:bg-[#F8F9FA] text-[#6B7280]'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-[#B7791F]">
                      {p.sectionNumber ? `Section ${p.sectionNumber}` : `Rule ${p.ruleNumber}`}
                    </span>
                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-[#F8F9FA] text-[#6B7280] font-mono">
                      {p.act}
                    </span>
                  </div>
                  <div className="text-xs font-semibold text-[#202124] mt-1 leading-snug">{p.title}</div>
                  <div className="text-[11px] text-[#6B7280] line-clamp-2 mt-1">{p.summary}</div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-600 shrink-0 mt-1" />
              </button>
            );
          })}
        </div>

        {/* Right: Detailed Bare Law Reader */}
        {currentItem && (
          <div className="lg:col-span-8 bg-white border border-[#E5E7EB] rounded-2xl p-6 shadow-xl space-y-6">
            <div className="border-b border-[#E5E7EB] pb-4">
              <div className="flex items-center justify-between text-xs text-[#6B7280]">
                <span className="font-mono uppercase tracking-wider text-[#B7791F] font-bold">
                  {currentItem.chapter}
                </span>
                <span className="font-mono text-[#6B7280] bg-[#F8F9FA] px-2 py-0.5 rounded">
                  Source: ICAI Bare Law (April 2026 Edition) • Page {currentItem.sourcePage}
                </span>
              </div>
              <h3 className="text-xl font-black text-[#202124] mt-2">
                {currentItem.sectionNumber ? `Section ${currentItem.sectionNumber}. ` : `Rule ${currentItem.ruleNumber}. `}
                {currentItem.title}
              </h3>
              <div className="flex flex-wrap items-center gap-2 mt-2">
                <span className="text-[10px] px-2 py-0.5 rounded bg-[#F8F9FA] text-[#6B7280] font-mono">
                  Effective From: {currentItem.effectiveFrom}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-[#E8F5EF] text-[#176B4D] border border-emerald-800 font-mono">
                  Amendments Incorporated: Up to 31 March 2026
                </span>
              </div>
            </div>

            {/* Summary */}
            <div className="p-4 rounded-xl bg-amber-950/20 border border-amber-800/40 text-xs text-amber-200">
              <strong>Core Statutory Summary:</strong> {currentItem.summary}
            </div>

            {/* Full Statutory Clauses */}
            {currentItem.clauses && currentItem.clauses.length > 0 && (
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#6B7280]">
                  Statutory Provisions & Subsections
                </h4>
                <div className="space-y-2">
                  {currentItem.clauses.map((clause, idx) => (
                    <div key={idx} className="p-3 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-xs text-[#202124] leading-relaxed font-sans">
                      {clause}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Provisos */}
            {currentItem.provisos && currentItem.provisos.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#B7791F]">
                  Statutory Provisos & Conditions
                </h4>
                <div className="space-y-2">
                  {currentItem.provisos.map((proviso, idx) => (
                    <div key={idx} className="p-3 rounded-lg bg-amber-950/20 border border-amber-800/30 text-xs text-amber-100 italic">
                      {proviso}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Explanations */}
            {currentItem.explanations && currentItem.explanations.length > 0 && (
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#6B7280]">
                  Explanations
                </h4>
                <div className="space-y-2">
                  {currentItem.explanations.map((exp, idx) => (
                    <div key={idx} className="p-3 rounded-lg bg-[#FFFFFF]/20 border border-[#E5E7EB] text-xs text-[#202124]">
                      {exp}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Cross Links to Rules and Sections */}
            <div className="flex flex-wrap items-center gap-2 pt-4 border-t border-[#E5E7EB] text-xs">
              <span className="text-[#6B7280] font-medium">Associated CGST Rules:</span>
              {(currentItem.relatedRules || ['Rule 36', 'Rule 60']).map(r => (
                <button
                  key={r}
                  onClick={() => setSearchTerm(r)}
                  className="px-2 py-1 rounded bg-[#F8F9FA] hover:bg-slate-700 text-[#6B7280] font-mono transition"
                >
                  {r}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
