export const FINANCIAL_YEARS = ['2026-27', '2025-26', '2024-25'] as const;
export type FinancialYear = typeof FINANCIAL_YEARS[number];

export interface ReturnMonthInfo {
  name: string;
  number: string;
  fyOffset: number; // 0 for Apr-Dec, 1 for Jan-Mar
  quarter: 'Q1' | 'Q2' | 'Q3' | 'Q4';
}

export const RETURN_MONTHS: ReturnMonthInfo[] = [
  { name: 'April', number: '04', fyOffset: 0, quarter: 'Q1' },
  { name: 'May', number: '05', fyOffset: 0, quarter: 'Q1' },
  { name: 'June', number: '06', fyOffset: 0, quarter: 'Q1' },
  { name: 'July', number: '07', fyOffset: 0, quarter: 'Q2' },
  { name: 'August', number: '08', fyOffset: 0, quarter: 'Q2' },
  { name: 'September', number: '09', fyOffset: 0, quarter: 'Q2' },
  { name: 'October', number: '10', fyOffset: 0, quarter: 'Q3' },
  { name: 'November', number: '11', fyOffset: 0, quarter: 'Q3' },
  { name: 'December', number: '12', fyOffset: 0, quarter: 'Q3' },
  { name: 'January', number: '01', fyOffset: 1, quarter: 'Q4' },
  { name: 'February', number: '02', fyOffset: 1, quarter: 'Q4' },
  { name: 'March', number: '03', fyOffset: 1, quarter: 'Q4' }
];

export interface ReturnPeriod {
  financialYear: string;
  month: string;
  periodCode: string;     // e.g. "04-2026"
  numericPeriod: string;  // e.g. "042026"
  year: number;           // e.g. 2026
  monthNumber: string;    // e.g. "04"
  displayPeriod: string;  // e.g. "April 2026"
  quarter: string;        // e.g. "Q1"
}

export function computeReturnPeriod(fy: string = '2026-27', monthName: string = 'April'): ReturnPeriod {
  const startYear = parseInt(fy.split('-')[0], 10) || 2026;
  const m = RETURN_MONTHS.find(rm => rm.name.toLowerCase() === monthName.toLowerCase()) || RETURN_MONTHS[0];
  const calendarYear = startYear + m.fyOffset;
  const periodCode = `${m.number}-${calendarYear}`;
  const numericPeriod = `${m.number}${calendarYear}`;

  return {
    financialYear: fy,
    month: m.name,
    periodCode,
    numericPeriod,
    year: calendarYear,
    monthNumber: m.number,
    displayPeriod: `${m.name} ${calendarYear}`,
    quarter: m.quarter
  };
}
