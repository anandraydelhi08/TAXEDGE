/**
 * Server-side Gemini AI Integration with @google/genai SDK
 * Implements Function Calling for GST Law RAG, Invoices, Returns, ITC, and RCM
 */

import { GoogleGenAI, Type, FunctionDeclaration } from '@google/genai';
import { gstRagService } from '../src/services/gstRagService';
import { rcmEngine } from '../src/services/rcmEngine';
import { itcEngine } from '../src/services/itcEngine';
import { calculateDeterministicTax, formatINR } from '../src/utils/taxMath';
import { validateGstinFormat } from '../src/data/masterData';

// Shared Gemini client utility with User-Agent telemetry
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({
  apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build'
    }
  }
});

// Function Declarations as specified in Part 29 of prompt
const gstTools: FunctionDeclaration[] = [
  {
    name: 'search_gst_law',
    description: 'Searches ICAI Bare Law (April 2026 Edition) for sections, rules, and statutory provisions.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        query: { type: Type.STRING, description: 'Search keywords, e.g. "Section 16 ITC eligibility" or "Section 9(3) RCM goods"' },
        act: { type: Type.STRING, description: 'Optional act filter: CGST_ACT, IGST_ACT, or CGST_RULES' }
      },
      required: ['query']
    }
  },
  {
    name: 'check_rcm',
    description: 'Checks Reverse Charge Mechanism (RCM) applicability under Section 9(3) / 9(4) for a specific transaction.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        supplierGstin: { type: Type.STRING, description: 'Supplier 15-character GSTIN' },
        recipientGstin: { type: Type.STRING, description: 'Recipient 15-character GSTIN' },
        hsnSac: { type: Type.STRING, description: 'HSN or SAC code, e.g. 998211 for Legal services or 9405 for Lamps' },
        description: { type: Type.STRING, description: 'Description of goods or services' },
        taxableValue: { type: Type.NUMBER, description: 'Taxable amount in INR' },
        isInterState: { type: Type.BOOLEAN, description: 'True if inter-state (IGST), false if intra-state' }
      },
      required: ['description', 'taxableValue']
    }
  },
  {
    name: 'check_itc',
    description: 'Evaluates Input Tax Credit eligibility, checking Section 16 conditions and Section 17(5) blocked credits.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        hsnSac: { type: Type.STRING, description: 'HSN/SAC code' },
        description: { type: Type.STRING, description: 'Description of purchase expense' },
        taxableValue: { type: Type.NUMBER, description: 'Taxable value' },
        totalTax: { type: Type.NUMBER, description: 'Total GST amount' },
        isIn2B: { type: Type.BOOLEAN, description: 'Whether invoice appears in GSTR-2B statement' },
        isRcm: { type: Type.BOOLEAN, description: 'Whether transaction is subject to RCM' }
      },
      required: ['description', 'totalTax']
    }
  },
  {
    name: 'calculate_tax',
    description: 'Performs deterministic tax calculation and component breakdown (CGST/SGST vs IGST).',
    parameters: {
      type: Type.OBJECT,
      properties: {
        taxableValue: { type: Type.NUMBER, description: 'Taxable value in INR' },
        gstRate: { type: Type.NUMBER, description: 'Rate percentage, e.g. 5, 12, 18, 28' },
        isInterState: { type: Type.BOOLEAN, description: 'Whether supply is inter-state' }
      },
      required: ['taxableValue', 'gstRate', 'isInterState']
    }
  },
  {
    name: 'validate_gstin',
    description: 'Validates statutory 15-character GSTIN format and state jurisdiction.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        gstin: { type: Type.STRING, description: '15-character GSTIN string' }
      },
      required: ['gstin']
    }
  }
];

export async function handleGeminiChat(reqBody: { message: string; history?: any[] }): Promise<{ text: string; structuredDecision?: any }> {
  const userMessage = reqBody.message || '';

  // If no API key configured or fallback is needed, use deterministic GST RAG Engine
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    const legalEval = gstRagService.evaluateLegalQuestion(userMessage);
    const searchRes = gstRagService.searchGSTLaw(userMessage).slice(0, 2);

    let citations = searchRes.map(r => `• **${r.provision.act} ${r.provision.sectionNumber ? 'Section ' + r.provision.sectionNumber : 'Rule ' + r.provision.ruleNumber}** — *${r.provision.title}* (Page ${r.provision.sourcePage})`).join('\n');

    return {
      text: `### GST Expert Legal Analysis\n\n` +
        `**DECISION:** ${legalEval.decision}\n\n` +
        `**WHY:** ${legalEval.why}\n\n` +
        `**APPLICABLE LAW:** ${legalEval.applicableLaw}\n` +
        `**SECTION:** ${legalEval.section}\n` +
        `**RULE:** ${legalEval.rule}\n\n` +
        `**APPLICATION TO TRANSACTION:**\n${legalEval.applicationToTransaction}\n\n` +
        `**CALCULATION:**\n${legalEval.calculation}\n\n` +
        `**CONFIDENCE:** ${(legalEval.confidence * 100).toFixed(0)}%\n` +
        `**SOURCE:** ${legalEval.source}\n` +
        `**HUMAN REVIEW REQUIRED:** ${legalEval.humanReviewRequired ? 'YES' : 'NO'}\n\n` +
        (citations ? `**RELEVANT BARE LAW CITATIONS (ICAI April 2026 Edition):**\n${citations}` : ''),
      structuredDecision: legalEval
    };
  }

  try {
    const systemInstruction = `You are "GST Expert", a senior GST compliance specialist and legal advisor for Indian Goods and Services Tax law.
You operate on the revised 12th edition of "GST Act(s) and Rule(s) - Bare Law (April 2026 Edition)" published by the Institute of Chartered Accountants of India (ICAI).
Rules:
1. Never fabricate legal sections or rules.
2. Financial calculations must be verified using the calculate_tax tool.
3. For every legal response, format your answer clearly with:
DECISION: [Specific outcome]
WHY: [Concise legal rationale]
APPLICABLE LAW: [Act/Rules]
SECTION: [Section numbers]
RULE: [Rule numbers]
APPLICATION TO TRANSACTION: [How law applies to user facts]
CALCULATION: [Deterministic math]
CONFIDENCE: [Percentage]
SOURCE: [ICAI Bare Law 2026 Edition Citation]
HUMAN REVIEW REQUIRED: [YES/NO]
4. Emphasize that RCM liabilities must be discharged in CASH through the Electronic Cash Ledger and cannot be paid using existing ITC.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: userMessage,
      config: {
        systemInstruction,
        tools: [{ functionDeclarations: gstTools }]
      }
    });

    const functionCalls = response.functionCalls;
    if (functionCalls && functionCalls.length > 0) {
      const call = functionCalls[0];
      let toolResult: any = null;

      if (call.name === 'search_gst_law') {
        const query = (call.args as any)?.query || userMessage;
        const res = gstRagService.searchGSTLaw(query).slice(0, 3);
        toolResult = res.map(r => ({
          section: r.provision.sectionNumber,
          rule: r.provision.ruleNumber,
          title: r.provision.title,
          summary: r.provision.summary,
          page: r.provision.sourcePage
        }));
      } else if (call.name === 'check_rcm') {
        const args = call.args as any;
        toolResult = rcmEngine.evaluateRCM({
          supplierGstin: args.supplierGstin || '',
          recipientGstin: args.recipientGstin || '',
          hsnSac: args.hsnSac || '',
          description: args.description || '',
          taxableValue: args.taxableValue || 0,
          isInterState: !!args.isInterState,
          date: '2026-04-20'
        });
      } else if (call.name === 'check_itc') {
        const args = call.args as any;
        toolResult = itcEngine.evaluateITC({
          invoiceDate: '2026-04-20',
          hsnSac: args.hsnSac || '',
          description: args.description || '',
          taxableValue: args.taxableValue || 0,
          totalTax: args.totalTax || 0,
          isRcm: !!args.isRcm,
          hasInvoiceCopy: true,
          goodsReceived: true,
          isIn2B: args.isIn2B !== false
        });
      } else if (call.name === 'calculate_tax') {
        const args = call.args as any;
        toolResult = calculateDeterministicTax(args.taxableValue, args.gstRate, args.isInterState);
      } else if (call.name === 'validate_gstin') {
        const args = call.args as any;
        toolResult = validateGstinFormat(args.gstin);
      }

      // Second turn with tool result to get finalized explanation
      const followUp = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: [
          { role: 'user', parts: [{ text: userMessage }] },
          { role: 'model', parts: [{ functionCall: call }] },
          {
            role: 'user',
            parts: [{
              functionResponse: {
                name: call.name,
                response: { result: toolResult }
              }
            }]
          }
        ],
        config: { systemInstruction }
      });

      return {
        text: followUp.text || 'Analysis completed.',
        structuredDecision: toolResult
      };
    }

    return {
      text: response.text || 'Unable to generate response from GST Expert.',
      structuredDecision: null
    };
  } catch (error: any) {
    console.error('Gemini API Error:', error);
    // Graceful fallback to local RAG engine
    const legalEval = gstRagService.evaluateLegalQuestion(userMessage);
    return {
      text: `### GST Expert Legal Analysis (Local Bare Law Engine)\n\n` +
        `**DECISION:** ${legalEval.decision}\n\n` +
        `**WHY:** ${legalEval.why}\n\n` +
        `**APPLICABLE LAW:** ${legalEval.applicableLaw}\n` +
        `**SECTION:** ${legalEval.section}\n` +
        `**RULE:** ${legalEval.rule}\n\n` +
        `**APPLICATION TO TRANSACTION:**\n${legalEval.applicationToTransaction}\n\n` +
        `**CALCULATION:**\n${legalEval.calculation}\n\n` +
        `**CONFIDENCE:** ${(legalEval.confidence * 100).toFixed(0)}%\n` +
        `**SOURCE:** ${legalEval.source}\n` +
        `**HUMAN REVIEW REQUIRED:** ${legalEval.humanReviewRequired ? 'YES' : 'NO'}`,
      structuredDecision: legalEval
    };
  }
}
