import React from 'react';
import { CheckCircle2, Upload, FileCheck2, ArrowRight, X } from 'lucide-react';
import { formatINR } from '../utils/taxMath';

interface SalesImportSuccessBannerProps {
  financialYear: string;
  month: string;
  totalInvoices: number;
  totalTaxableValue: number;
  totalGst: number;
  onUploadToGstPortal: () => void;
  onDismiss?: () => void;
}

export const SalesImportSuccessBanner: React.FC<SalesImportSuccessBannerProps> = ({
  financialYear,
  month,
  totalInvoices,
  totalTaxableValue,
  totalGst,
  onUploadToGstPortal,
  onDismiss
}) => {
  return (
    <div className="bg-white border border-[#E5E7EB] rounded-2xl p-5 shadow-sm relative overflow-hidden animate-in fade-in slide-in-from-top-2 duration-300">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* Left Info */}
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#E8F5EF] text-[#176B4D] flex items-center justify-center shrink-0 border border-[#176B4D]/20">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-[#202124]">
                Sales Data Imported Successfully
              </h3>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#E8F5EF] text-[#176B4D] border border-[#176B4D]/20 font-bold">
                {month} {financialYear}
              </span>
            </div>
            <p className="text-xs text-[#6B7280] mt-0.5">
              Sales invoices auto-tagged with return period <span className="font-semibold text-[#176B4D]">{month} ({financialYear})</span> and ready for GSTR-1 outward filing.
            </p>

            {/* Metrics Row */}
            <div className="flex flex-wrap items-center gap-4 mt-2.5 text-xs">
              <div className="bg-[#F8F9FA] border border-[#E5E7EB] px-3.5 py-1.5 rounded-lg shadow-sm">
                <span className="text-[10px] text-[#6B7280] uppercase font-bold block">Total Invoices</span>
                <span className="font-mono font-bold text-[#202124] text-sm">{totalInvoices}</span>
              </div>
              <div className="bg-[#F8F9FA] border border-[#E5E7EB] px-3.5 py-1.5 rounded-lg shadow-sm">
                <span className="text-[10px] text-[#6B7280] uppercase font-bold block">Total Taxable Value</span>
                <span className="font-mono font-bold text-[#202124] text-sm">{formatINR(totalTaxableValue)}</span>
              </div>
              <div className="bg-[#F8F9FA] border border-[#E5E7EB] px-3.5 py-1.5 rounded-lg shadow-sm">
                <span className="text-[10px] text-[#6B7280] uppercase font-bold block">Total GST</span>
                <span className="font-mono font-bold text-[#176B4D] text-sm">{formatINR(totalGst)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right CTA */}
        <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
          <button
            onClick={onUploadToGstPortal}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#176B4D] hover:bg-[#12543B] text-white font-bold text-xs shadow-sm transition transform active:scale-95"
            title="Upload outward sales data to GSTR-1 via Authorized GSP"
          >
            <Upload className="w-4 h-4 text-white" />
            <span>Upload to GST Portal</span>
          </button>

          {onDismiss && (
            <button
              onClick={onDismiss}
              className="p-1.5 rounded-lg text-[#6B7280] hover:text-[#202124] hover:bg-[#F8F9FA] transition"
              title="Dismiss notification"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
