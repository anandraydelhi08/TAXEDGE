import React, { useState } from 'react';
import { Plus, Search, Filter, Download, ArrowUpRight, CheckCircle2, AlertTriangle, FileSpreadsheet, X, Upload, Trash2, Database, FolderArchive } from 'lucide-react';
import { TransactionInvoice, GSTClassification, DocumentType } from '../types/gst';
import { formatINR, calculateDeterministicTax } from '../utils/taxMath';
import { INDIAN_STATES, validateGstinFormat } from '../data/masterData';
import { ClientMaster } from '../types/client';
import { GstPortalCsvModal } from './GstPortalCsvModal';

interface SalesRegisterViewProps {
  sales: TransactionInvoice[];
  currentClient?: ClientMaster | null;
  currentGstin?: string;
  onAddInvoice: (inv: TransactionInvoice) => void;
  onOpenDataModal?: (target?: 'SALES' | 'PURCHASES' | 'GSTR2B') => void;
  onClearSales?: () => void;
  onDeleteSale?: (id: string) => void;
  onUploadToGstPortal?: () => void;
  selectedFy?: string;
  selectedMonth?: string;
  onImportSales?: (items: TransactionInvoice[], mode: 'REPLACE' | 'APPEND') => void;
}

export const SalesRegisterView: React.FC<SalesRegisterViewProps> = ({
  sales,
  currentClient,
  currentGstin,
  onAddInvoice,
  onOpenDataModal,
  onClearSales,
  onDeleteSale,
  onUploadToGstPortal,
  selectedFy,
  selectedMonth,
  onImportSales
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterClass, setFilterClass] = useState<string>('ALL');
  const [showAddModal, setShowAddModal] = useState(false);
  const [isCsvModalOpen, setIsCsvModalOpen] = useState(false);

  const activeStateCode = (currentGstin || currentClient?.primaryGstin || '07').substring(0, 2);

  // New Invoice Form state
  const [invNum, setInvNum] = useState(`INV/2026-27/00${sales.length + 1}`);
  const [invDate, setInvDate] = useState('2026-04-28');
  const [docType, setDocType] = useState<DocumentType>('INVOICE');
  const [recipientGstin, setRecipientGstin] = useState('27AAACG0561F1ZK');
  const [recipientName, setRecipientName] = useState('Godrej Infotech Solutions Ltd');
  const [posCode, setPosCode] = useState(activeStateCode);
  const [hsnCode, setHsnCode] = useState('998313');
  const [description, setDescription] = useState('Custom Enterprise Cloud Architecture');
  const [taxableValue, setTaxableValue] = useState<number>(350000);
  const [gstRate, setGstRate] = useState<number>(18);
  const [isRcm, setIsRcm] = useState<boolean>(false);

  // Live tax calculation
  const isInterState = posCode !== activeStateCode;
  const taxCalc = calculateDeterministicTax(taxableValue, gstRate, isInterState, isRcm);

  // Classification determination
  let computedClassification: GSTClassification = 'B2B';
  if (recipientGstin === 'URP' || recipientGstin === '') {
    if (isInterState && taxableValue > 250000) {
      computedClassification = 'B2C_LARGE';
    } else {
      computedClassification = 'B2C_SMALL';
    }
  } else if (recipientGstin === 'OVERSEAS') {
    computedClassification = 'EXPORT_WITHOUT_PAYMENT';
  } else {
    computedClassification = 'B2B';
  }

  const handleCreateInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    const newInv: TransactionInvoice = {
      id: `SL-${Date.now()}`,
      invoiceNumber: invNum,
      invoiceDate: invDate,
      documentType: docType,
      supplierGstin: currentGstin || currentClient?.primaryGstin || '',
      supplierName: currentClient?.legalName || currentClient?.name || 'Registered Client',
      supplierState: currentClient?.state || INDIAN_STATES.find(s => s.code === activeStateCode)?.name || 'Maharashtra',
      supplierStateCode: activeStateCode,
      recipientGstin: recipientGstin || 'URP',
      recipientName,
      recipientState: INDIAN_STATES.find(s => s.code === posCode)?.name || 'Other State',
      recipientStateCode: posCode,
      placeOfSupply: INDIAN_STATES.find(s => s.code === posCode)?.name || 'Maharashtra',
      placeOfSupplyCode: posCode,
      supplyType: isInterState ? 'INTER_STATE' : 'INTRA_STATE',
      classification: computedClassification,
      taxTreatment: computedClassification.startsWith('EXPORT') ? 'ZERO_RATED' : 'TAXABLE',
      hsnSacPrimary: hsnCode,
      descriptionPrimary: description,
      taxableValue,
      gstRate,
      cgst: taxCalc.cgst,
      sgst: taxCalc.sgst,
      igst: taxCalc.igst,
      cess: taxCalc.cess,
      totalAmount: taxCalc.totalAmount,
      rcm: isRcm,
      rcmStatus: isRcm ? 'YES' : 'NO',
      ecommerce: false,
      itcStatus: 'ELIGIBLE',
      itcEligibleAmount: 0,
      itcIneligibleAmount: 0,
      confidence: 1.0,
      reviewRequired: false
    };

    onAddInvoice(newInv);
    setShowAddModal(false);
  };

  const filteredSales = sales.filter(s => {
    const invNumStr = s.invoiceNumber || '';
    const recNameStr = s.recipientName || '';
    const recGstinStr = s.recipientGstin || '';
    const hsnStr = s.hsnSacPrimary || '';
    const matchesSearch =
      invNumStr.toLowerCase().includes(searchTerm.toLowerCase()) ||
      recNameStr.toLowerCase().includes(searchTerm.toLowerCase()) ||
      recGstinStr.toLowerCase().includes(searchTerm.toLowerCase()) ||
      hsnStr.includes(searchTerm);

    const matchesClass = filterClass === 'ALL' || s.classification === filterClass;
    return matchesSearch && matchesClass;
  });

  const exportCsv = () => {
    const headers = ['Invoice No', 'Date', 'Type', 'Recipient GSTIN', 'Recipient Name', 'POS', 'HSN/SAC', 'Taxable Value', 'GST Rate', 'IGST', 'CGST', 'SGST', 'Total', 'Classification'];
    const rows = filteredSales.map(s => [
      s.invoiceNumber || ((s as any).isB2csSummary ? `B2CS-${s.placeOfSupplyCode}` : (s as any).isHsnSummary ? `HSN-${s.hsnSacPrimary}` : 'Summary'),
      s.invoiceDate,
      s.documentType,
      s.recipientGstin,
      `"${s.recipientName}"`,
      s.placeOfSupplyCode,
      s.hsnSacPrimary,
      s.taxableValue,
      s.gstRate,
      s.igst,
      s.cgst,
      s.sgst,
      s.totalAmount,
      s.classification
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Sales_Register_April_2026.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-black text-[#202124] flex items-center gap-2">
              <ArrowUpRight className="w-5 h-5 text-[#176B4D]" />
              Outward Sales Register
            </h2>
            {selectedMonth && selectedFy && (
              <span className="text-[11px] font-mono px-2.5 py-0.5 rounded-full bg-[#176B4D]/20 text-[#176B4D] font-semibold border border-[#176B4D]/30">
                {selectedMonth} ({selectedFy})
              </span>
            )}
          </div>
          <p className="text-xs text-[#6B7280] mt-1">
            GSTR-1 feeder register • Outward invoices, export LUTs, credit notes, and B2C summaries.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {onUploadToGstPortal && (
            <button
              onClick={onUploadToGstPortal}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-[#176B4D] hover:bg-[#12543B] text-white text-xs font-bold transition shadow-md shadow-emerald-950/40"
              title="Upload outward sales to GSTR-1 on GST Portal"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Upload to GST Portal</span>
            </button>
          )}

          {onOpenDataModal && (
            <button
              onClick={() => onOpenDataModal('SALES')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#176B4D]/20 hover:bg-[#176B4D]/30 text-[#176B4D] border border-[#176B4D]/30 text-xs font-bold transition shadow-sm"
              title="Upload your business sales invoice CSV or Excel"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Upload Sales CSV</span>
            </button>
          )}

          {onClearSales && sales.length > 0 && (
            <button
              onClick={onClearSales}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#FDECEC] text-[#C62828] hover:bg-[#FDECEC] text-[#C62828] text-rose-200 border border-rose-500/40 text-xs font-bold transition shadow-sm active:scale-95"
              title="Clear all invoices from Sales Register"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear</span>
            </button>
          )}

          <button
            onClick={() => setIsCsvModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition shadow-sm"
            title="Export or Import official GST Portal Section-wise CSVs (b2b,sez,de.csv, cdnr.csv, etc.)"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-300" />
            <span>GST Portal CSV Hub</span>
          </button>

          <button
            onClick={exportCsv}
            disabled={filteredSales.length === 0}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white hover:bg-[#E8F5EF] disabled:opacity-40 text-[#176B4D] border border-[#176B4D]/40 font-bold shadow-sm text-xs font-bold transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-[#176B4D] hover:bg-emerald-400 text-slate-950 text-xs font-bold transition shadow-md shadow-emerald-950/40"
          >
            <Plus className="w-4 h-4" />
            <span>New Sales Invoice</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-3 bg-white border border-[#E5E7EB] p-3 rounded-xl">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-[#176B4D] absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Search invoice number, GSTIN, customer, HSN..."
            className="w-full bg-[#F8F9FA] border border-[#E5E7EB] text-[#202124] text-xs rounded-lg pl-9 pr-3 py-2 focus:outline-none focus:border-[#176B4D]/30"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
          <span className="text-xs text-[#6B7280] flex items-center gap-1">
            <Filter className="w-3 h-3 text-[#176B4D]" /> Filter:
          </span>
          {['ALL', 'B2B', 'B2C_LARGE', 'B2C_SMALL', 'EXPORT_WITHOUT_PAYMENT'].map(c => (
            <button
              key={c}
              onClick={() => setFilterClass(c)}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition ${
                filterClass === c
                  ? 'bg-[#176B4D]/20 text-[#176B4D] border border-[#176B4D]/30 font-semibold'
                  : 'bg-[#F8F9FA] text-[#6B7280] hover:bg-slate-700'
              }`}
            >
              {c.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-[#E5E7EB] rounded-xl overflow-hidden shadow-lg">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#6B7280]">
            <thead className="bg-[#F8F9FA] text-[#6B7280] text-[11px] uppercase tracking-wider font-semibold border-b border-[#E5E7EB]">
              <tr>
                <th className="px-4 py-3">Invoice No & Date</th>
                <th className="px-4 py-3">Recipient Customer</th>
                <th className="px-3 py-3">POS</th>
                <th className="px-3 py-3">HSN/SAC</th>
                <th className="px-4 py-3 text-right">Taxable Value</th>
                <th className="px-3 py-3 text-center">Rate</th>
                <th className="px-4 py-3 text-right">IGST</th>
                <th className="px-4 py-3 text-right">CGST+SGST</th>
                <th className="px-4 py-3 text-right">Total Amount</th>
                <th className="px-3 py-3 text-center">Classification</th>
                <th className="px-3 py-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {filteredSales.length === 0 ? (
                <tr>
                  <td colSpan={11} className="px-4 py-12 text-center text-[#6B7280]">
                    <div className="max-w-md mx-auto space-y-3">
                      <div className="w-10 h-10 rounded-full bg-[#F8F9FA] text-[#6B7280] flex items-center justify-center mx-auto">
                        <FileSpreadsheet className="w-5 h-5" />
                      </div>
                      <div className="text-sm font-bold text-[#202124]">
                        {sales.length === 0 ? 'No Sales Invoices Recorded' : 'No Invoices Matching Filter'}
                      </div>
                      <p className="text-xs text-[#6B7280]">
                        {sales.length === 0
                          ? 'Upload your business sales invoices via CSV/Excel or click New Sales Invoice to add individual bills.'
                          : 'Try changing your search term or classification filter above.'}
                      </p>
                      {sales.length === 0 && (
                        <div className="flex items-center justify-center gap-2 pt-2">
                          {onOpenDataModal && (
                            <button
                              onClick={() => onOpenDataModal('SALES')}
                              className="px-3.5 py-1.5 rounded-lg bg-[#176B4D] hover:bg-[#176B4D] text-slate-950 font-bold text-xs transition"
                            >
                              Upload Sales CSV
                            </button>
                          )}
                          <button
                            onClick={() => setShowAddModal(true)}
                            className="px-3.5 py-1.5 rounded-lg bg-white hover:bg-[#E8F5EF] text-[#176B4D] border border-[#176B4D]/40 font-bold shadow-sm text-xs font-semibold transition"
                          >
                            Add Invoice Manually
                          </button>
                        </div>
                      )}
                    </div>
                  </td>
                </tr>
              ) : (
                filteredSales.map(inv => {
                const isInter = inv.supplyType === 'INTER_STATE';
                return (
                  <tr key={inv.id} className="hover:bg-[#F8F9FA] transition">
                    <td className="px-4 py-3 font-medium text-[#202124]">
                      {inv.invoiceNumber && !inv.invoiceNumber.startsWith('B2CS/') && !inv.invoiceNumber.startsWith('INV/HSN/') ? (
                        <div className="font-mono text-[#176B4D] font-semibold">{inv.invoiceNumber}</div>
                      ) : (inv as any).isB2csSummary || inv.classification === 'B2C_SMALL' || inv.id?.startsWith('PORTAL-B2CS') ? (
                        <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-bold bg-amber-50 text-amber-800 border border-amber-200">
                          <span>B2C Small Summary</span>
                          <span className="text-[10px] text-amber-600 font-mono font-normal">POS: {inv.placeOfSupplyCode || inv.placeOfSupply}</span>
                        </div>
                      ) : (inv as any).isHsnSummary || inv.id?.startsWith('PORTAL-HSN') ? (
                        <div className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-bold ${
                          (inv as any).hsnCategory === 'B2C'
                            ? 'bg-pink-50 text-pink-800 border border-pink-200'
                            : 'bg-purple-50 text-purple-800 border border-purple-200'
                        }`}>
                          <span>HSN ({(inv as any).hsnCategory || 'B2B'})</span>
                          <span className={`text-[10px] font-mono font-normal ${(inv as any).hsnCategory === 'B2C' ? 'text-pink-600' : 'text-purple-600'}`}>{inv.hsnSacPrimary}</span>
                        </div>
                      ) : (
                        <div className="font-mono text-slate-400 italic text-xs">Summary Row</div>
                      )}
                      <div className="text-[10px] text-[#6B7280]">{inv.invoiceDate} • {inv.documentType}</div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-medium text-[#202124]">{inv.recipientName}</div>
                      <div className="text-[10px] font-mono text-[#6B7280]">{inv.recipientGstin}</div>
                    </td>
                    <td className="px-3 py-3">
                      <span className="font-mono px-1.5 py-0.5 rounded bg-[#F8F9FA] text-[#6B7280]">
                        {inv.placeOfSupplyCode}
                      </span>
                    </td>
                    <td className="px-3 py-3 font-mono text-[#6B7280]">
                      {inv.hsnSacPrimary}
                    </td>
                    <td className="px-4 py-3 text-right font-mono font-medium">
                      {formatINR(inv.taxableValue)}
                    </td>
                    <td className="px-3 py-3 text-center">
                      <span className="text-[11px] px-1.5 py-0.5 rounded bg-[#F8F9FA] text-[#6B7280] font-mono">
                        {inv.gstRate}%
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right font-mono text-[#176B4D]">
                      {inv.igst > 0 ? formatINR(inv.igst) : '—'}
                    </td>
                    <td className="px-4 py-3 text-right font-mono text-[#176B4D]">
                      {inv.cgst > 0 ? formatINR(inv.cgst + inv.sgst) : '—'}
                    </td>
                    <td className="px-4 py-3 text-right font-mono font-bold text-[#202124]">
                      {formatINR(inv.totalAmount)}
                    </td>
                    <td className="px-3 py-3 text-center">
                      <span className={`inline-block text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                        inv.classification === 'B2B'
                          ? 'bg-[#176B4D]/20 text-[#176B4D] border border-[#176B4D]/30'
                          : inv.classification === 'B2C_LARGE'
                          ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                          : inv.classification.startsWith('EXPORT')
                          ? 'bg-slate-500/20 text-[#6B7280] border border-slate-500/40'
                          : 'bg-slate-700 text-[#6B7280]'
                      }`}>
                        {inv.classification}
                      </span>
                    </td>
                    <td className="px-3 py-3 text-center">
                      {onDeleteSale && (
                        <button
                          onClick={() => onDeleteSale(inv.id)}
                          className="p-1 rounded-md text-[#6B7280] hover:text-[#C62828] hover:bg-[#FDECEC] text-[#C62828] transition"
                          title={`Delete invoice ${inv.invoiceNumber}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              }))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Invoice Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border border-[#E5E7EB] rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl animate-in fade-in zoom-in-95">
            <div className="p-4 bg-[#F8F9FA] border-b border-[#E5E7EB] flex items-center justify-between">
              <h3 className="text-sm font-bold text-[#202124] flex items-center gap-2">
                <Plus className="w-4 h-4 text-[#176B4D]" />
                Record New Sales Invoice
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-[#6B7280] hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateInvoice} className="p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs text-[#6B7280] block mb-1">Invoice Number</label>
                  <input
                    type="text"
                    required
                    value={invNum}
                    onChange={e => setInvNum(e.target.value)}
                    className="w-full bg-[#F8F9FA] border border-[#E5E7EB] rounded-lg px-3 py-1.5 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs text-[#6B7280] block mb-1">Invoice Date</label>
                  <input
                    type="date"
                    required
                    value={invDate}
                    onChange={e => setInvDate(e.target.value)}
                    className="w-full bg-[#F8F9FA] border border-[#E5E7EB] rounded-lg px-3 py-1.5 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs text-[#6B7280] block mb-1">Doc Type</label>
                  <select
                    value={docType}
                    onChange={e => setDocType(e.target.value as DocumentType)}
                    className="w-full bg-[#F8F9FA] border border-[#E5E7EB] rounded-lg px-3 py-1.5 text-xs text-white"
                  >
                    <option value="INVOICE">Tax Invoice</option>
                    <option value="CREDIT_NOTE">Credit Note (Sec 34)</option>
                    <option value="DEBIT_NOTE">Debit Note</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-[#6B7280] block mb-1">Recipient GSTIN (or 'URP' / 'OVERSEAS')</label>
                  <input
                    type="text"
                    required
                    value={recipientGstin}
                    onChange={e => setRecipientGstin(e.target.value.toUpperCase())}
                    className="w-full bg-[#F8F9FA] border border-[#E5E7EB] rounded-lg px-3 py-1.5 text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs text-[#6B7280] block mb-1">Recipient Trade/Legal Name</label>
                  <input
                    type="text"
                    required
                    value={recipientName}
                    onChange={e => setRecipientName(e.target.value)}
                    className="w-full bg-[#F8F9FA] border border-[#E5E7EB] rounded-lg px-3 py-1.5 text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs text-[#6B7280] block mb-1">Place of Supply (POS)</label>
                  <select
                    value={posCode}
                    onChange={e => setPosCode(e.target.value)}
                    className="w-full bg-[#F8F9FA] border border-[#E5E7EB] rounded-lg px-3 py-1.5 text-xs text-white"
                  >
                    {INDIAN_STATES.map(s => (
                      <option key={s.code} value={s.code}>{s.code} - {s.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-xs text-[#6B7280] block mb-1">HSN / SAC Code</label>
                  <input
                    type="text"
                    required
                    value={hsnCode}
                    onChange={e => setHsnCode(e.target.value)}
                    className="w-full bg-[#F8F9FA] border border-[#E5E7EB] rounded-lg px-3 py-1.5 text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs text-[#6B7280] block mb-1">GST Rate (%)</label>
                  <select
                    value={gstRate}
                    onChange={e => setGstRate(Number(e.target.value))}
                    className="w-full bg-[#F8F9FA] border border-[#E5E7EB] rounded-lg px-3 py-1.5 text-xs text-white"
                  >
                    <option value={0}>0% (Zero-rated / Nil)</option>
                    <option value={5}>5%</option>
                    <option value={12}>12%</option>
                    <option value={18}>18% (Standard)</option>
                    <option value={28}>28%</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs text-[#6B7280] block mb-1">Description of Goods / Services</label>
                <input
                  type="text"
                  required
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  className="w-full bg-[#F8F9FA] border border-[#E5E7EB] rounded-lg px-3 py-1.5 text-xs text-white"
                />
              </div>

              <div>
                <label className="text-xs text-[#6B7280] block mb-1">Taxable Value (₹)</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={taxableValue}
                  onChange={e => setTaxableValue(Number(e.target.value))}
                  className="w-full bg-[#F8F9FA] border border-[#E5E7EB] rounded-lg px-3 py-1.5 text-xs text-white font-mono"
                />
              </div>

              {/* Tax Live Preview Box */}
              <div className="p-3 bg-[#FFFFFF] border border-[#E5E7EB] rounded-xl space-y-1 text-xs">
                <div className="flex justify-between text-[#6B7280]">
                  <span>Supply Nature:</span>
                  <span className="font-semibold text-[#202124]">{isInterState ? 'INTER-STATE (IGST)' : 'INTRA-STATE (CGST + SGST)'}</span>
                </div>
                <div className="flex justify-between text-[#6B7280]">
                  <span>Classification:</span>
                  <span className="font-semibold text-[#176B4D]">{computedClassification}</span>
                </div>
                {isInterState ? (
                  <div className="flex justify-between text-[#176B4D] font-mono">
                    <span>IGST ({gstRate}%):</span>
                    <span>{formatINR(taxCalc.igst)}</span>
                  </div>
                ) : (
                  <>
                    <div className="flex justify-between text-[#176B4D] font-mono">
                      <span>CGST ({gstRate / 2}%):</span>
                      <span>{formatINR(taxCalc.cgst)}</span>
                    </div>
                    <div className="flex justify-between text-[#176B4D] font-mono">
                      <span>SGST ({gstRate / 2}%):</span>
                      <span>{formatINR(taxCalc.sgst)}</span>
                    </div>
                  </>
                )}
                <div className="flex justify-between text-white font-bold font-mono border-t border-[#E5E7EB] pt-1 mt-1 text-sm">
                  <span>Total Invoice Amount:</span>
                  <span>{formatINR(taxCalc.totalAmount)}</span>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-lg bg-[#F8F9FA] hover:bg-slate-700 text-[#6B7280] text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-[#176B4D] hover:bg-emerald-400 text-slate-950 text-xs font-bold shadow-md shadow-emerald-950/40"
                >
                  Save & Validate Invoice
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Official GST Portal CSV Modal */}
      <GstPortalCsvModal
        isOpen={isCsvModalOpen}
        onClose={() => setIsCsvModalOpen(false)}
        sales={sales}
        gstin={currentGstin || currentClient?.primaryGstin || '07ABFFB5922Q1Z0'}
        legalName={currentClient?.name || 'Registered Client'}
        period={`${selectedMonth || 'April'}-${selectedFy || '2026-27'}`}
        financialYear={selectedFy || '2026-27'}
        month={selectedMonth || 'April'}
        onImportSales={onImportSales}
      />
    </div>
  );
};
