import React, { useState } from 'react';
import { Plus, Search, Filter, Download, ArrowDownLeft, ShieldAlert, CheckCircle2, AlertTriangle, Layers, Repeat, X, Upload, Trash2, Database, FileSpreadsheet } from 'lucide-react';
import { TransactionInvoice, ITCStatus, BlockedCreditReason } from '../types/gst';
import { formatINR, calculateDeterministicTax } from '../utils/taxMath';
import { INDIAN_STATES } from '../data/masterData';
import { ClientMaster } from '../types/client';
import { itcEngine } from '../services/itcEngine';
import { rcmEngine } from '../services/rcmEngine';

interface PurchaseRegisterViewProps {
  purchases: TransactionInvoice[];
  currentClient?: ClientMaster | null;
  currentGstin?: string;
  onAddPurchase: (inv: TransactionInvoice) => void;
  onOpenDataModal?: (target?: 'SALES' | 'PURCHASES' | 'GSTR2B') => void;
  onClearPurchases?: () => void;
  onDeletePurchase?: (id: string) => void;
}

export const PurchaseRegisterView: React.FC<PurchaseRegisterViewProps> = ({
  purchases,
  currentClient,
  currentGstin,
  onAddPurchase,
  onOpenDataModal,
  onClearPurchases,
  onDeletePurchase
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [showAddModal, setShowAddModal] = useState(false);

  const activeStateCode = (currentGstin || currentClient?.primaryGstin || '27').substring(0, 2);

  // Form State
  const [invNum, setInvNum] = useState(`PUR/2026/0${purchases.length + 1}`);
  const [invDate, setInvDate] = useState('2026-04-25');
  const [supplierGstin, setSupplierGstin] = useState('27AAACB2100P1Z0');
  const [supplierName, setSupplierName] = useState('Vodafone Idea Telecommunications Ltd');
  const [posCode, setPosCode] = useState(activeStateCode);
  const [hsnCode, setHsnCode] = useState('998411');
  const [description, setDescription] = useState('Enterprise Data Bandwidth Line');
  const [taxableValue, setTaxableValue] = useState<number>(100000);
  const [gstRate, setGstRate] = useState<number>(18);
  const [isIn2B, setIsIn2B] = useState<boolean>(true);

  const isInterState = posCode !== activeStateCode;
  const taxCalc = calculateDeterministicTax(taxableValue, gstRate, isInterState);

  // Automatic Legal Rule Evaluation
  const rcmCheck = rcmEngine.evaluateRCM({
    supplierGstin,
    recipientGstin: currentGstin || currentClient?.primaryGstin || '',
    hsnSac: hsnCode,
    description,
    taxableValue,
    isInterState,
    date: invDate
  });

  const itcCheck = itcEngine.evaluateITC({
    invoiceDate: invDate,
    hsnSac: hsnCode,
    description,
    taxableValue,
    totalTax: taxCalc.totalTax,
    isRcm: rcmCheck.isRcm,
    hasInvoiceCopy: true,
    goodsReceived: true,
    isIn2B
  });

  const handleCreatePurchase = (e: React.FormEvent) => {
    e.preventDefault();
    const newPur: TransactionInvoice = {
      id: `PR-${Date.now()}`,
      invoiceNumber: invNum,
      invoiceDate: invDate,
      documentType: 'INVOICE',
      supplierGstin,
      supplierName,
      supplierState: INDIAN_STATES.find(s => s.code === posCode)?.name || 'Maharashtra',
      supplierStateCode: posCode,
      recipientGstin: currentGstin || currentClient?.primaryGstin || '',
      recipientName: currentClient?.legalName || currentClient?.name || 'Registered Client',
      recipientState: currentClient?.state || 'Maharashtra',
      recipientStateCode: activeStateCode,
      placeOfSupply: currentClient?.state || 'Maharashtra',
      placeOfSupplyCode: activeStateCode,
      supplyType: isInterState ? 'INTER_STATE' : 'INTRA_STATE',
      classification: 'B2B',
      taxTreatment: 'TAXABLE',
      hsnSacPrimary: hsnCode,
      descriptionPrimary: description,
      taxableValue,
      gstRate,
      cgst: taxCalc.cgst,
      sgst: taxCalc.sgst,
      igst: taxCalc.igst,
      cess: taxCalc.cess,
      totalAmount: taxCalc.totalAmount,
      rcm: rcmCheck.isRcm,
      rcmStatus: rcmCheck.rcmStatus,
      rcmCategory: rcmCheck.rcmCategory,
      rcmCashPaid: rcmCheck.isRcm,
      ecommerce: false,
      itcStatus: itcCheck.itcStatus,
      blockedCreditReason: itcCheck.blockedReason,
      itcEligibleAmount: itcCheck.eligibleAmount,
      itcIneligibleAmount: itcCheck.ineligibleAmount,
      reconciliationStatus: isIn2B ? 'EXACT_MATCH' : 'MISSING_IN_2B',
      confidence: 1.0,
      reviewRequired: itcCheck.reviewRequired || rcmCheck.reviewRequired
    };

    onAddPurchase(newPur);
    setShowAddModal(false);
  };

  const filteredPurchases = purchases.filter(p => {
    const matchesSearch =
      p.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.supplierName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.supplierGstin.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.descriptionPrimary.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus =
      filterStatus === 'ALL' ||
      (filterStatus === 'ELIGIBLE' && p.itcStatus === 'ELIGIBLE') ||
      (filterStatus === 'BLOCKED' && p.itcStatus === 'INELIGIBLE') ||
      (filterStatus === 'RCM' && p.rcm) ||
      (filterStatus === 'MISMATCH' && p.reconciliationStatus === 'TAX_MISMATCH') ||
      (filterStatus === 'MISSING_2B' && p.reconciliationStatus === 'MISSING_IN_2B');

    return matchesSearch && matchesStatus;
  });

  const exportCsv = () => {
    const headers = ['Invoice No', 'Date', 'Supplier GSTIN', 'Supplier Name', 'HSN/SAC', 'Taxable Value', 'GST Rate', 'IGST', 'CGST', 'SGST', 'Total', 'RCM', 'ITC Status', 'Blocked Reason', '2B Status'];
    const rows = filteredPurchases.map(p => [
      p.invoiceNumber,
      p.invoiceDate,
      p.supplierGstin,
      `"${p.supplierName}"`,
      p.hsnSacPrimary,
      p.taxableValue,
      p.gstRate,
      p.igst,
      p.cgst,
      p.sgst,
      p.totalAmount,
      p.rcm ? 'YES' : 'NO',
      p.itcStatus,
      p.blockedCreditReason || 'NONE',
      p.reconciliationStatus || 'PENDING'
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Purchase_Register_April_2026.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-[#202124] flex items-center gap-2">
            <ArrowDownLeft className="w-5 h-5 text-[#176B4D]" />
            Inward Purchase Register
          </h2>
          <p className="text-xs text-[#6B7280] mt-1">
            GSTR-2B reconciliation source & Section 16/17(5) Input Tax Credit determination register.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {onOpenDataModal && (
            <button
              onClick={() => onOpenDataModal('PURCHASES')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white hover:bg-[#E8F5EF] text-[#176B4D] border border-[#176B4D]/40 font-bold shadow-sm text-xs font-semibold transition shadow-sm"
              title="Upload your business purchase invoice CSV or Excel"
            >
              <Upload className="w-3.5 h-3.5 text-[#176B4D]" />
              <span>Upload Purchases CSV</span>
            </button>
          )}

          {onClearPurchases && purchases.length > 0 && (
            <button
              onClick={onClearPurchases}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#FDECEC] text-[#C62828] hover:bg-rose-100 border border-rose-200 text-xs font-bold transition shadow-sm active:scale-95"
              title="Clear all invoices from Purchase Register"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear</span>
            </button>
          )}

          <button
            onClick={exportCsv}
            disabled={filteredPurchases.length === 0}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white hover:bg-[#E8F5EF] disabled:opacity-40 text-[#176B4D] border border-[#176B4D]/40 font-bold shadow-sm text-xs font-bold transition shadow-sm"
          >
            <Download className="w-3.5 h-3.5 text-[#176B4D]" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-[#176B4D] hover:bg-[#12543B] text-white text-xs font-bold transition shadow-sm"
          >
            <Plus className="w-4 h-4 text-white" />
            <span>Record Inward Invoice</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-3 bg-white border border-[#E5E7EB] p-3 rounded-xl shadow-sm">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-[#176B4D] absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Search vendor, GSTIN, invoice number, items..."
            className="w-full bg-[#F8F9FA] border border-[#E5E7EB] text-[#202124] text-xs rounded-lg pl-9 pr-3 py-2 focus:outline-none focus:border-[#176B4D]"
          />
        </div>

        <div className="flex items-center gap-1.5 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
          <span className="text-xs text-[#6B7280] font-semibold flex items-center gap-1">
            <Filter className="w-3 h-3 text-[#176B4D]" /> Filter:
          </span>
          {[
            { id: 'ALL', label: 'All Invoices' },
            { id: 'ELIGIBLE', label: 'Eligible ITC' },
            { id: 'BLOCKED', label: 'Sec 17(5) Blocked' },
            { id: 'RCM', label: 'Sec 9(3) RCM' },
            { id: 'MISMATCH', label: 'Tax Mismatch' },
            { id: 'MISSING_2B', label: 'Missing in 2B' }
          ].map(f => (
            <button
              key={f.id}
              onClick={() => setFilterStatus(f.id)}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
                filterStatus === f.id
                  ? 'bg-[#E8F5EF] text-[#176B4D] border border-[#176B4D]/30'
                  : 'bg-[#F8F9FA] text-[#202124] hover:bg-[#E5E7EB] border border-[#E5E7EB]'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-[#E5E7EB] rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#202124]">
            <thead className="bg-[#F8F9FA] text-[#202124] text-[11px] uppercase tracking-wider font-bold border-b border-[#E5E7EB]">
              <tr>
                <th className="px-4 py-3">Invoice No & Date</th>
                <th className="px-4 py-3">Supplier Vendor</th>
                <th className="px-3 py-3">HSN/SAC</th>
                <th className="px-4 py-3 text-right">Taxable Value</th>
                <th className="px-4 py-3 text-right">Total Tax</th>
                <th className="px-4 py-3 text-right">Total Value</th>
                <th className="px-3 py-3 text-center">RCM</th>
                <th className="px-3 py-3 text-center">ITC Eligibility</th>
                <th className="px-3 py-3 text-center">2B Status</th>
                <th className="px-3 py-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E5E7EB] font-sans">
              {filteredPurchases.length === 0 ? (
                <tr>
                  <td colSpan={10} className="px-4 py-12 text-center text-[#6B7280]">
                    <div className="max-w-md mx-auto space-y-3">
                      <div className="w-10 h-10 rounded-full bg-[#F8F9FA] text-[#6B7280] flex items-center justify-center mx-auto border border-[#E5E7EB]">
                        <FileSpreadsheet className="w-5 h-5 text-[#176B4D]" />
                      </div>
                      <div className="text-sm font-bold text-[#202124]">
                        {purchases.length === 0 ? 'No Purchase Invoices Recorded' : 'No Purchases Matching Filter'}
                      </div>
                      <p className="text-xs text-[#6B7280]">
                        {purchases.length === 0
                          ? 'Upload your business purchase invoices via CSV/Excel or click Record Inward Invoice to add bills.'
                          : 'Try changing your search term or status filter above.'}
                      </p>
                      {purchases.length === 0 && (
                        <div className="flex items-center justify-center gap-2 pt-2">
                          {onOpenDataModal && (
                            <button
                              onClick={() => onOpenDataModal('PURCHASES')}
                              className="px-3.5 py-1.5 rounded-lg bg-slate-600 hover:bg-slate-500 text-slate-950 font-bold text-xs transition"
                            >
                              Upload Purchases CSV
                            </button>
                          )}
                          <button
                            onClick={() => setShowAddModal(true)}
                            className="px-3.5 py-1.5 rounded-lg bg-white hover:bg-[#E8F5EF] text-[#176B4D] border border-[#176B4D]/40 font-bold shadow-sm text-xs font-semibold transition"
                          >
                            Add Invoice Manually
                          </button>
                        </div>
                      )}
                    </div>
                  </td>
                </tr>
              ) : (
                filteredPurchases.map(inv => {
                const totalTax = inv.cgst + inv.sgst + inv.igst + inv.cess;
                return (
                  <tr key={inv.id} className="hover:bg-[#F8F9FA] transition">
                    <td className="px-4 py-3 font-medium text-[#202124]">
                      <div className="font-mono text-[#6B7280] font-semibold">{inv.invoiceNumber}</div>
                      <div className="text-[10px] text-[#6B7280]">{inv.invoiceDate}</div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-medium text-[#202124]">{inv.supplierName}</div>
                      <div className="text-[10px] font-mono text-[#6B7280]">{inv.supplierGstin}</div>
                      <div className="text-[10px] text-[#6B7280] truncate max-w-xs">{inv.descriptionPrimary}</div>
                    </td>
                    <td className="px-3 py-3 font-mono text-[#6B7280]">
                      {inv.hsnSacPrimary}
                    </td>
                    <td className="px-4 py-3 text-right font-mono font-medium">
                      {formatINR(inv.taxableValue)}
                    </td>
                    <td className="px-4 py-3 text-right font-mono">
                      {inv.igst > 0 ? (
                        <span className="text-[#176B4D]">{formatINR(inv.igst)} (IGST)</span>
                      ) : (
                        <span className="text-[#176B4D]">{formatINR(inv.cgst + inv.sgst)} (C+S)</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right font-mono font-bold text-[#202124]">
                      {formatINR(inv.totalAmount)}
                    </td>
                    <td className="px-3 py-3 text-center">
                      {inv.rcm ? (
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/40">
                          <Repeat className="w-3 h-3" /> YES (Cash)
                        </span>
                      ) : (
                        <span className="text-[#6B7280] text-[11px]">—</span>
                      )}
                    </td>
                    <td className="px-3 py-3 text-center">
                      <span className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        inv.itcStatus === 'ELIGIBLE'
                          ? 'bg-[#176B4D]/20 text-[#176B4D] border border-[#176B4D]/30'
                          : inv.itcStatus === 'INELIGIBLE'
                          ? 'bg-[#FDECEC] text-[#C62828] text-rose-300 border border-rose-500/40'
                          : 'bg-[#FFF8E1] text-[#B7791F] text-[#B7791F] border border-amber-500/40'
                      }`}>
                        {inv.itcStatus}
                      </span>
                      {inv.blockedCreditReason && inv.blockedCreditReason !== 'NONE' && (
                        <div className="text-[9px] text-[#C62828] mt-0.5 font-mono">
                          {inv.blockedCreditReason.replace('SEC_17_5_', '17(5)-')}
                        </div>
                      )}
                    </td>
                    <td className="px-3 py-3 text-center">
                      <span className={`inline-block text-[10px] font-semibold px-2 py-0.5 rounded ${
                        inv.reconciliationStatus === 'EXACT_MATCH'
                          ? 'bg-[#E8F5EF] text-[#176B4D] border border-emerald-800'
                          : inv.reconciliationStatus === 'TAX_MISMATCH'
                          ? 'bg-amber-950 text-[#B7791F] border border-amber-800'
                          : inv.reconciliationStatus === 'MISSING_IN_2B'
                          ? 'bg-rose-950 text-[#C62828] border border-rose-800'
                          : 'bg-[#F8F9FA] text-[#6B7280]'
                      }`}>
                        {inv.reconciliationStatus || 'PENDING'}
                      </span>
                    </td>
                    <td className="px-3 py-3 text-center">
                      {onDeletePurchase && (
                        <button
                          onClick={() => onDeletePurchase(inv.id)}
                          className="p-1 rounded-md text-[#6B7280] hover:text-[#C62828] hover:bg-[#FDECEC] text-[#C62828] transition"
                          title={`Delete invoice ${inv.invoiceNumber}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              }))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Inward Invoice Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border border-[#E5E7EB] rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl">
            <div className="p-4 bg-[#F8F9FA] border-b border-[#E5E7EB] flex items-center justify-between">
              <h3 className="text-sm font-bold text-[#202124] flex items-center gap-2">
                <Plus className="w-4 h-4 text-[#176B4D]" />
                Record Inward Purchase Invoice
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-[#6B7280] hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreatePurchase} className="p-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-[#6B7280] block mb-1">Invoice Number</label>
                  <input
                    type="text"
                    required
                    value={invNum}
                    onChange={e => setInvNum(e.target.value)}
                    className="w-full bg-[#F8F9FA] border border-[#E5E7EB] rounded-lg px-3 py-1.5 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs text-[#6B7280] block mb-1">Invoice Date</label>
                  <input
                    type="date"
                    required
                    value={invDate}
                    onChange={e => setInvDate(e.target.value)}
                    className="w-full bg-[#F8F9FA] border border-[#E5E7EB] rounded-lg px-3 py-1.5 text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-[#6B7280] block mb-1">Supplier GSTIN</label>
                  <input
                    type="text"
                    required
                    value={supplierGstin}
                    onChange={e => setSupplierGstin(e.target.value.toUpperCase())}
                    className="w-full bg-[#F8F9FA] border border-[#E5E7EB] rounded-lg px-3 py-1.5 text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs text-[#6B7280] block mb-1">Supplier Business Name</label>
                  <input
                    type="text"
                    required
                    value={supplierName}
                    onChange={e => setSupplierName(e.target.value)}
                    className="w-full bg-[#F8F9FA] border border-[#E5E7EB] rounded-lg px-3 py-1.5 text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs text-[#6B7280] block mb-1">Supplier State (POS)</label>
                  <select
                    value={posCode}
                    onChange={e => setPosCode(e.target.value)}
                    className="w-full bg-[#F8F9FA] border border-[#E5E7EB] rounded-lg px-3 py-1.5 text-xs text-white"
                  >
                    {INDIAN_STATES.map(s => (
                      <option key={s.code} value={s.code}>{s.code} - {s.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-xs text-[#6B7280] block mb-1">HSN / SAC Code</label>
                  <input
                    type="text"
                    required
                    value={hsnCode}
                    onChange={e => setHsnCode(e.target.value)}
                    className="w-full bg-[#F8F9FA] border border-[#E5E7EB] rounded-lg px-3 py-1.5 text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs text-[#6B7280] block mb-1">GST Rate (%)</label>
                  <select
                    value={gstRate}
                    onChange={e => setGstRate(Number(e.target.value))}
                    className="w-full bg-[#F8F9FA] border border-[#E5E7EB] rounded-lg px-3 py-1.5 text-xs text-white"
                  >
                    <option value={5}>5%</option>
                    <option value={12}>12%</option>
                    <option value={18}>18%</option>
                    <option value={28}>28%</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs text-[#6B7280] block mb-1">Item / Service Description</label>
                <input
                  type="text"
                  required
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  className="w-full bg-[#F8F9FA] border border-[#E5E7EB] rounded-lg px-3 py-1.5 text-xs text-white"
                />
              </div>

              <div>
                <label className="text-xs text-[#6B7280] block mb-1">Taxable Value (₹)</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={taxableValue}
                  onChange={e => setTaxableValue(Number(e.target.value))}
                  className="w-full bg-[#F8F9FA] border border-[#E5E7EB] rounded-lg px-3 py-1.5 text-xs text-white font-mono"
                />
              </div>

              {/* Legal Engine Diagnostics Box */}
              <div className="p-3 bg-[#FFFFFF] border border-[#E5E7EB] rounded-xl space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-[#6B7280]">RCM Evaluation:</span>
                  <span className={`font-bold ${rcmCheck.isRcm ? 'text-purple-400' : 'text-[#6B7280]'}`}>
                    {rcmCheck.rcmStatus} • {rcmCheck.rcmCategory}
                  </span>
                </div>
                {rcmCheck.isRcm && (
                  <p className="text-[11px] text-purple-300/90 bg-purple-950/30 p-2 rounded border border-purple-800/40">
                    Mandatory Section 49(4) cash payment in Table 3.1(d). Eligible for subsequent ITC.
                  </p>
                )}

                <div className="flex items-center justify-between border-t border-[#E5E7EB] pt-1.5">
                  <span className="text-[#6B7280]">ITC Statutory Determination:</span>
                  <span className={`font-bold ${itcCheck.itcStatus === 'ELIGIBLE' ? 'text-[#176B4D]' : 'text-[#C62828]'}`}>
                    {itcCheck.itcStatus} {itcCheck.blockedReason !== 'NONE' ? `(${itcCheck.blockedReason})` : ''}
                  </span>
                </div>
                <div className="text-[11px] text-[#6B7280]">
                  {itcCheck.reason} ({itcCheck.sourceCitation})
                </div>

                <div className="flex justify-between text-white font-bold font-mono border-t border-[#E5E7EB] pt-1.5 text-sm">
                  <span>Gross Invoice Total:</span>
                  <span>{formatINR(taxCalc.totalAmount)}</span>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-lg bg-[#F8F9FA] hover:bg-slate-700 text-[#6B7280] text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-slate-500 hover:bg-slate-400 text-slate-950 text-xs font-bold shadow-md shadow-slate-950/40"
                >
                  Save Inward Invoice
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
