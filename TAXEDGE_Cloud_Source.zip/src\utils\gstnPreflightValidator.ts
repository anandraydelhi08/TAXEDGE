/**
 * GSTN Pre-Flight Schema Validator & Auto-Corrector (v3.2.4 Schema Compliant)
 * Enforces strict GST Portal schema rules to guarantee ZERO upload errors on services.gst.gov.in
 */

import { TransactionInvoice } from '../types/gst';
import { OFFICIAL_UQCS, OFFICIAL_POS_LIST, OFFICIAL_DR_CR_REASONS, OFFICIAL_PORT_CODES } from '../data/gstnOfficialConstants';
import { calculateDeterministicTax, round2 } from './taxMath';

export const GSTIN_REGEX = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
export const INVOICE_NUM_REGEX = /^[A-Za-z0-9/-]{1,16}$/;
export const DATE_REGEX = /^\d{4}-\d{2}-\d{2}$/;

export interface GstnValidationError {
  invoiceId: string;
  invoiceNumber: string;
  field: string;
  issue: string;
  suggestedFix?: string;
  severity: 'ERROR' | 'WARNING';
}

export interface GstnValidationSummary {
  isValid: boolean;
  totalInvoices: number;
  validCount: number;
  errorCount: number;
  errors: GstnValidationError[];
  reconciliation: {
    totalTaxable: number;
    totalIgst: number;
    totalCgst: number;
    totalSgst: number;
    totalCess: number;
    totalInvoiceValue: number;
  };
}

/**
 * Validates a single transaction against GST Portal Schema v3.2.4
 */
export function validateInvoiceForGstn(
  inv: TransactionInvoice,
  supplierGstin: string,
  isOutward: boolean = true
): GstnValidationError[] {
  const errors: GstnValidationError[] = [];
  const invNum = inv.invoiceNumber?.trim() || 'UNSPECIFIED';

  // 1. Invoice Number format check (GST Rule 46(b): max 16 chars, alphanumeric, /, -)
  if (!inv.invoiceNumber || !inv.invoiceNumber.trim()) {
    errors.push({
      invoiceId: inv.id,
      invoiceNumber: invNum,
      field: 'invoiceNumber',
      issue: 'Invoice number is empty. GSTN requires a unique invoice number.',
      severity: 'ERROR'
    });
  } else if (inv.invoiceNumber.length > 16) {
    errors.push({
      invoiceId: inv.id,
      invoiceNumber: invNum,
      field: 'invoiceNumber',
      issue: `Invoice number "${inv.invoiceNumber}" exceeds GSTN limit of 16 characters (${inv.invoiceNumber.length} chars).`,
      suggestedFix: inv.invoiceNumber.substring(0, 16),
      severity: 'ERROR'
    });
  } else if (!INVOICE_NUM_REGEX.test(inv.invoiceNumber)) {
    errors.push({
      invoiceId: inv.id,
      invoiceNumber: invNum,
      field: 'invoiceNumber',
      issue: `Invoice number contains invalid characters. GSTN only allows letters, numbers, slash (/), and hyphen (-).`,
      suggestedFix: inv.invoiceNumber.replace(/[^A-Za-z0-9/-]/g, ''),
      severity: 'ERROR'
    });
  }

  // 2. Invoice Date check (YYYY-MM-DD or DD-MM-YYYY)
  if (!inv.invoiceDate || !inv.invoiceDate.trim()) {
    errors.push({
      invoiceId: inv.id,
      invoiceNumber: invNum,
      field: 'invoiceDate',
      issue: 'Invoice date is missing.',
      severity: 'ERROR'
    });
  }

  // 3. Counterparty GSTIN Validation
  const counterpartyGstin = isOutward ? inv.recipientGstin : inv.supplierGstin;
  const isB2B = inv.classification === 'B2B' || inv.classification === 'DEEMED_EXPORT' || inv.classification?.startsWith('SEZ');
  
  if (isB2B) {
    if (!counterpartyGstin || !counterpartyGstin.trim()) {
      errors.push({
        invoiceId: inv.id,
        invoiceNumber: invNum,
        field: 'counterpartyGstin',
        issue: `${isOutward ? 'Buyer' : 'Supplier'} GSTIN is missing for B2B supply.`,
        severity: 'ERROR'
      });
    } else {
      const cleanGstin = counterpartyGstin.trim().toUpperCase();
      if (!GSTIN_REGEX.test(cleanGstin)) {
        errors.push({
          invoiceId: inv.id,
          invoiceNumber: invNum,
          field: 'counterpartyGstin',
          issue: `Invalid GSTIN "${cleanGstin}". Must be 15 alphanumeric characters matching GSTN format (e.g., 27AABCT3419K1ZM).`,
          severity: 'ERROR'
        });
      }
    }
  }

  // 4. POS (Place of Supply) Check
  const pos = (inv.placeOfSupplyCode || inv.placeOfSupply || '').toString().padStart(2, '0').slice(0, 2);
  const isValidPos = OFFICIAL_POS_LIST.some(p => p.code === pos);
  if (!isValidPos) {
    errors.push({
      invoiceId: inv.id,
      invoiceNumber: invNum,
      field: 'placeOfSupply',
      issue: `Invalid Place of Supply code "${pos}". Must be a valid 2-digit state code (01 to 38, or 97).`,
      severity: 'ERROR'
    });
  }

  // 5. Taxable Value & Tax Math
  if (typeof inv.taxableValue !== 'number' || isNaN(inv.taxableValue) || inv.taxableValue <= 0) {
    errors.push({
      invoiceId: inv.id,
      invoiceNumber: invNum,
      field: 'taxableValue',
      issue: 'Taxable value must be a positive number greater than 0.',
      severity: 'ERROR'
    });
  }

  const supplierState = (supplierGstin || '07').substring(0, 2);
  const isInterState = pos !== supplierState;

  if (isInterState) {
    if ((inv.cgst || 0) > 0 || (inv.sgst || 0) > 0) {
      errors.push({
        invoiceId: inv.id,
        invoiceNumber: invNum,
        field: 'taxBreakdown',
        issue: `Inter-state transaction (Supplier: ${supplierState}, POS: ${pos}) cannot have CGST or SGST. Full tax must be IGST.`,
        severity: 'ERROR'
      });
    }
  } else {
    if ((inv.igst || 0) > 0) {
      errors.push({
        invoiceId: inv.id,
        invoiceNumber: invNum,
        field: 'taxBreakdown',
        issue: `Intra-state transaction (Supplier: ${supplierState}, POS: ${pos}) cannot have IGST. Tax must be split equally into CGST & SGST.`,
        severity: 'ERROR'
      });
    }
  }

  // 6. HSN / SAC Code Check
  const hsn = (inv.hsnSacPrimary || '').trim();
  if (!hsn) {
    errors.push({
      invoiceId: inv.id,
      invoiceNumber: invNum,
      field: 'hsnSacPrimary',
      issue: 'HSN/SAC code is mandatory post-May 2025 mandates. Minimum 4 digits for goods or SAC 99 for services.',
      suggestedFix: '998313',
      severity: 'ERROR'
    });
  } else if (hsn.length < 4) {
    errors.push({
      invoiceId: inv.id,
      invoiceNumber: invNum,
      field: 'hsnSacPrimary',
      issue: `HSN code "${hsn}" is only ${hsn.length} digits. GSTN requires at least 4 digits.`,
      severity: 'ERROR'
    });
  }

  // 7. UQC and Quantity Checks
  const isService = hsn.startsWith('99');
  if (isService) {
    if (inv.uqc && inv.uqc !== 'NA' && inv.uqc !== 'OTH') {
      errors.push({
        invoiceId: inv.id,
        invoiceNumber: invNum,
        field: 'uqc',
        issue: `Services (SAC ${hsn}) must have UQC as 'NA' (Not Applicable).`,
        suggestedFix: 'NA',
        severity: 'WARNING'
      });
    }
  } else {
    if (inv.uqc && !OFFICIAL_UQCS.some(u => u.code === inv.uqc)) {
      errors.push({
        invoiceId: inv.id,
        invoiceNumber: invNum,
        field: 'uqc',
        issue: `Invalid UQC unit "${inv.uqc}". Must be from the official GSTN UQC list (e.g. NOS, KGS, PCS, BOX).`,
        severity: 'ERROR'
      });
    }
  }

  // 8. Credit / Debit Note Specifics
  if (inv.documentType === 'CREDIT_NOTE' || inv.documentType === 'DEBIT_NOTE') {
    if (!inv.notes && !inv.descriptionPrimary) {
      errors.push({
        invoiceId: inv.id,
        invoiceNumber: invNum,
        field: 'reason',
        issue: 'Credit/Debit Note requires a statutory reason (e.g. 01-Sales Return, 02-Post Sale Discount).',
        suggestedFix: '01-Sales Return',
        severity: 'WARNING'
      });
    }
  }

  // 9. Export Specifics
  if (inv.classification?.startsWith('EXPORT')) {
    if (!inv.portCode) {
      errors.push({
        invoiceId: inv.id,
        invoiceNumber: invNum,
        field: 'portCode',
        issue: 'Export invoice requires a 6-character Indian Customs Port Code (e.g., INNSA1, INBOM4).',
        suggestedFix: 'INNSA1',
        severity: 'WARNING'
      });
    }
  }

  return errors;
}

/**
 * Automatically repairs an invoice to be 100% compliant with GST Portal Schema
 */
export function autoFixInvoiceForGstn(
  inv: TransactionInvoice,
  supplierGstin: string,
  isOutward: boolean = true
): TransactionInvoice {
  const cleanSupplierGstin = (supplierGstin || '07ABFFB5922Q1Z0').trim().toUpperCase();
  const supplierState = cleanSupplierGstin.substring(0, 2);

  // 1. Sanitize Invoice Number
  let invNum = (inv.invoiceNumber || `INV-${Date.now().toString().slice(-4)}`)
    .replace(/[^A-Za-z0-9/-]/g, '')
    .trim()
    .substring(0, 16);
  if (!invNum) invNum = `INV-${Date.now().toString().slice(-4)}`;

  // 2. Format Date
  let invDate = inv.invoiceDate;
  if (!invDate || !DATE_REGEX.test(invDate)) {
    invDate = new Date().toISOString().split('T')[0];
  }

  // 3. Counterparty GSTIN & POS Resolution
  let counterpartyGstin = (isOutward ? inv.recipientGstin : inv.supplierGstin) || '';
  counterpartyGstin = counterpartyGstin.trim().toUpperCase();

  let pos = (inv.placeOfSupplyCode || inv.placeOfSupply || '').toString().padStart(2, '0').slice(0, 2);
  if (GSTIN_REGEX.test(counterpartyGstin)) {
    pos = counterpartyGstin.substring(0, 2);
  }
  if (!OFFICIAL_POS_LIST.some(p => p.code === pos)) {
    pos = supplierState;
  }

  const isInterState = pos !== supplierState;

  // 4. Tax Deterministic Calculation
  const taxableVal = round2(Number(inv.taxableValue) || 1000);
  const gstRate = Number(inv.gstRate ?? 18);
  const taxMath = calculateDeterministicTax(taxableVal, gstRate, isInterState);

  // 5. HSN & UQC Auto-Correction
  let hsn = (inv.hsnSacPrimary || '').trim();
  if (!hsn || hsn.length < 4) {
    hsn = '998313'; // Standard Default SAC for Professional/Business/IT Services
  }

  const isService = hsn.startsWith('99');
  let uqc = inv.uqc || (isService ? 'NA' : 'NOS');
  if (isService) {
    uqc = 'NA';
  } else if (!OFFICIAL_UQCS.some(u => u.code === uqc)) {
    uqc = 'NOS';
  }

  const qty = isService ? 0 : (Number(inv.totalQuantity) > 0 ? Number(inv.totalQuantity) : 1);

  // 6. Classification resolution & Statutory GSTIN Compliance
  let classification = inv.classification;
  const hasValidCounterpartyGstin = GSTIN_REGEX.test(counterpartyGstin);

  if (isOutward) {
    if (hasValidCounterpartyGstin) {
      if (!classification || classification === 'B2C_SMALL' || classification === 'B2C_LARGE') {
        classification = 'B2B';
      }
    } else {
      // Recipient does not have a valid 15-digit GSTIN.
      // Under CGST Section 31 & GSTR-1 schema rules, outward supplies without a valid registered GSTIN
      // CANNOT be uploaded to Table 4 (B2B). They must be classified as B2C_LARGE or B2C_SMALL with empty recipientGstin.
      if (taxMath.totalAmount > 250000 && isInterState) {
        classification = 'B2C_LARGE';
      } else {
        classification = 'B2C_SMALL';
      }
    }
  } else {
    // Inward (Purchase)
    if (!classification) {
      classification = hasValidCounterpartyGstin ? 'B2B' : 'B2C_SMALL';
    }
  }

  const finalSupplierGstin = isOutward
    ? cleanSupplierGstin
    : (hasValidCounterpartyGstin ? counterpartyGstin : (inv.supplierGstin || ''));

  const finalRecipientGstin = isOutward
    ? (hasValidCounterpartyGstin ? counterpartyGstin : '')
    : cleanSupplierGstin;

  return {
    ...inv,
    invoiceNumber: invNum,
    invoiceDate: invDate,
    supplierGstin: finalSupplierGstin,
    recipientGstin: finalRecipientGstin,
    placeOfSupply: pos,
    placeOfSupplyCode: pos,
    supplyType: isInterState ? 'INTER_STATE' : 'INTRA_STATE',
    classification,
    hsnSacPrimary: hsn,
    uqc,
    totalQuantity: qty,
    taxableValue: taxMath.taxableValue,
    gstRate,
    cgst: taxMath.cgst,
    sgst: taxMath.sgst,
    igst: taxMath.igst,
    cess: round2(inv.cess || 0),
    totalAmount: round2(taxMath.totalAmount + round2(inv.cess || 0)),
    rcm: Boolean(inv.rcm),
    itcEligible: inv.itcEligible ?? true,
    itcStatus: inv.itcStatus || 'ELIGIBLE'
  };
}

/**
 * Validates entire batch of invoices for GST Portal upload readiness
 */
export function validateBatchGstn(
  invoices: TransactionInvoice[],
  supplierGstin: string,
  isOutward: boolean = true
): GstnValidationSummary {
  const allErrors: GstnValidationError[] = [];
  let validCount = 0;
  let errorCount = 0;

  let totalTaxable = 0;
  let totalIgst = 0;
  let totalCgst = 0;
  let totalSgst = 0;
  let totalCess = 0;
  let totalInvoiceValue = 0;

  invoices.forEach(inv => {
    const errs = validateInvoiceForGstn(inv, supplierGstin, isOutward);
    if (errs.length > 0) {
      errorCount++;
      allErrors.push(...errs);
    } else {
      validCount++;
    }

    totalTaxable = round2(totalTaxable + (inv.taxableValue || 0));
    totalIgst = round2(totalIgst + (inv.igst || 0));
    totalCgst = round2(totalCgst + (inv.cgst || 0));
    totalSgst = round2(totalSgst + (inv.sgst || 0));
    totalCess = round2(totalCess + (inv.cess || 0));
    totalInvoiceValue = round2(totalInvoiceValue + (inv.totalAmount || 0));
  });

  return {
    isValid: allErrors.filter(e => e.severity === 'ERROR').length === 0,
    totalInvoices: invoices.length,
    validCount,
    errorCount,
    errors: allErrors,
    reconciliation: {
      totalTaxable,
      totalIgst,
      totalCgst,
      totalSgst,
      totalCess,
      totalInvoiceValue
    }
  };
}
