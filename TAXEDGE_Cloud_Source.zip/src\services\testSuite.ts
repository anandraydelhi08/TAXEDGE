/**
 * Automated GST Verification and Compliance Test Suite (Part 38)
 * Verifies all financial math, legal rules, return preparation, and reconciliation logic.
 */

import { calculateDeterministicTax, verifyInvoiceTotals, calculateRule88ASetOff } from '../utils/taxMath';
import { rcmEngine } from './rcmEngine';
import { itcEngine } from './itcEngine';
import { reconciliationEngine } from './reconciliationEngine';
import { gstr1Engine } from './gstr1Engine';
import { gstr3bEngine } from './gstr3bEngine';
import { INITIAL_SALES_REGISTER, INITIAL_PURCHASE_REGISTER, INITIAL_GSTR2B_RECORDS } from '../data/masterData';
import { autoFixInvoiceForGstn } from '../utils/gstnPreflightValidator';

export interface TestCaseResult {
  id: string;
  name: string;
  category: 'TAX_MATH' | 'LEGAL_RULE' | 'RECONCILIATION' | 'RETURNS' | 'RCM' | 'ITC';
  passed: boolean;
  expected: string;
  actual: string;
  durationMs: number;
}

export class GSTTestSuite {
  public runAllTests(): TestCaseResult[] {
    const results: TestCaseResult[] = [];

    // Test 1: Intra-state 18% Tax Calculation
    const t1Start = performance.now();
    const t1 = calculateDeterministicTax(100000, 18, false);
    results.push({
      id: 'TC-01',
      name: 'Intra-State 18% GST Split (CGST 9% + SGST 9%)',
      category: 'TAX_MATH',
      passed: t1.cgst === 9000 && t1.sgst === 9000 && t1.igst === 0 && t1.totalAmount === 118000,
      expected: 'CGST: ₹9,000, SGST: ₹9,000, IGST: ₹0, Total: ₹1,18,000',
      actual: `CGST: ₹${t1.cgst}, SGST: ₹${t1.sgst}, IGST: ₹${t1.igst}, Total: ₹${t1.totalAmount}`,
      durationMs: Math.round(performance.now() - t1Start)
    });

    // Test 2: Inter-state 18% Tax Calculation
    const t2Start = performance.now();
    const t2 = calculateDeterministicTax(50000, 18, true);
    results.push({
      id: 'TC-02',
      name: 'Inter-State 18% GST Allocation (IGST 18%)',
      category: 'TAX_MATH',
      passed: t2.cgst === 0 && t2.sgst === 0 && t2.igst === 9000 && t2.totalAmount === 59000,
      expected: 'CGST: ₹0, SGST: ₹0, IGST: ₹9,000, Total: ₹59,000',
      actual: `CGST: ₹${t2.cgst}, SGST: ₹${t2.sgst}, IGST: ₹${t2.igst}, Total: ₹${t2.totalAmount}`,
      durationMs: Math.round(performance.now() - t2Start)
    });

    // Test 3: Precision Line Item Verification
    const t3Start = performance.now();
    const t3 = verifyInvoiceTotals({
      taxableValue: 249999.99,
      cgst: 22499.999,
      sgst: 22499.999,
      igst: 0,
      cess: 0,
      totalAmount: 294999.99
    });
    results.push({
      id: 'TC-03',
      name: 'Deterministic Invoice Total Verification (No Floating-Point Leakage)',
      category: 'TAX_MATH',
      passed: t3.valid,
      expected: 'Valid total within 5 paise rounding tolerance',
      actual: `Valid: ${t3.valid} (Diff: ₹${t3.difference})`,
      durationMs: Math.round(performance.now() - t3Start)
    });

    // Test 4: Section 17(5)(a) Motor Vehicle ITC Blockage
    const t4Start = performance.now();
    const t4 = itcEngine.evaluateITC({
      invoiceDate: '2026-04-14',
      hsnSac: '870322',
      description: 'Hyundai sedan car executive service and parts',
      taxableValue: 60000,
      totalTax: 10800,
      isRcm: false,
      hasInvoiceCopy: true,
      goodsReceived: true,
      isIn2B: true
    });
    results.push({
      id: 'TC-04',
      name: 'Section 17(5)(a) Blocked Credit Recognition',
      category: 'ITC',
      passed: t4.itcStatus === 'INELIGIBLE' && t4.blockedReason === 'SEC_17_5_A_MOTOR_VEHICLES',
      expected: 'Status: INELIGIBLE, Reason: SEC_17_5_A_MOTOR_VEHICLES',
      actual: `Status: ${t4.itcStatus}, Reason: ${t4.blockedReason}`,
      durationMs: Math.round(performance.now() - t4Start)
    });

    // Test 5: Legal Advocate Services RCM Recognition
    const t5Start = performance.now();
    const t5 = rcmEngine.evaluateRCM({
      supplierGstin: '27AAAFL4820B1Z3',
      recipientGstin: '27AABCT1332L1Z5',
      hsnSac: '998211',
      description: 'Legal representation before High Court',
      taxableValue: 100000,
      isInterState: false,
      date: '2026-04-10'
    });
    results.push({
      id: 'TC-05',
      name: 'Section 9(3) Advocate Fees RCM & Cash Payment Obligation',
      category: 'RCM',
      passed: t5.rcmStatus === 'YES' && t5.cashPaymentMandatory === true,
      expected: 'RCM: YES, Cash Payment Mandatory: true',
      actual: `RCM: ${t5.rcmStatus}, Cash Payment: ${t5.cashPaymentMandatory}`,
      durationMs: Math.round(performance.now() - t5Start)
    });

    // Test 6: Rule 88A Order of ITC Utilisation (Exhaust IGST first)
    const t6Start = performance.now();
    const t6 = calculateRule88ASetOff(
      { igst: 100000, cgst: 50000, sgst: 50000, cess: 0 },
      { igst: 150000, cgst: 20000, sgst: 20000, cess: 0 }
    );
    // IGST credit 150k covers 100k IGST liability, leaving 50k IGST credit to cover CGST/SGST liability
    results.push({
      id: 'TC-06',
      name: 'Rule 88A Statutory ITC Set-off Order (IGST 100% first)',
      category: 'RETURNS',
      passed: t6.itcUtilised.igstFromIgst === 100000 && t6.closingITC.igst === 0,
      expected: 'IGST from IGST: ₹1,00,000, Remaining IGST credit applied to CGST/SGST',
      actual: `IGST from IGST: ₹${t6.itcUtilised.igstFromIgst}, Closing IGST Credit: ₹${t6.closingITC.igst}`,
      durationMs: Math.round(performance.now() - t6Start)
    });

    // Test 7: Multi-Pass GSTR-2B Reconciliation Accuracy
    const t7Start = performance.now();
    const t7 = reconciliationEngine.reconcilePurchaseVs2B(INITIAL_PURCHASE_REGISTER, INITIAL_GSTR2B_RECORDS);
    results.push({
      id: 'TC-07',
      name: 'GSTR-2B Multi-Pass Reconciliation & Discrepancy Detection',
      category: 'RECONCILIATION',
      passed: t7.stats.exactMatches >= 5 && t7.stats.taxMismatches >= 1 && t7.stats.missingIn2B >= 1,
      expected: 'Detected Exact Matches, Tax Mismatch (Vodafone), and Missing in 2B',
      actual: `Exact: ${t7.stats.exactMatches}, Tax Mismatch: ${t7.stats.taxMismatches}, Missing in 2B: ${t7.stats.missingIn2B}`,
      durationMs: Math.round(performance.now() - t7Start)
    });

    // Test 8: GSTR-1 Table 12 HSN Summary Integrity
    const t8Start = performance.now();
    const gstr1 = gstr1Engine.prepareGSTR1(INITIAL_SALES_REGISTER);
    const totalHsnTaxable = gstr1.tables.table12_HSNSummary.reduce((sum, h) => sum + h.taxableValue, 0);
    results.push({
      id: 'TC-08',
      name: 'GSTR-1 Table 12 HSN Summary Alignment',
      category: 'RETURNS',
      passed: gstr1.hsnSummaryCount > 0 && Math.abs(totalHsnTaxable - gstr1.grossTurnover) <= 100000, // Accounts for credit notes
      expected: 'Table 12 HSN lines properly populated and reconciled',
      actual: `HSN Lines: ${gstr1.hsnSummaryCount}, Total Taxable: ₹${totalHsnTaxable}`,
      durationMs: Math.round(performance.now() - t8Start)
    });

    // Test 9: Zero-Portal-Error B2C Auto-Reclassification for Unregistered Counterparty
    const t9Start = performance.now();
    const unregInv = autoFixInvoiceForGstn({
      id: 'TEST-UNREG-01',
      invoiceNumber: 'INV/2026/999',
      invoiceDate: '2026-04-15',
      documentType: 'INVOICE',
      supplierGstin: '07ABFFB5922Q1Z0',
      recipientGstin: '', // Missing buyer GSTIN
      placeOfSupply: '07',
      taxableValue: 5000,
      gstRate: 18,
      classification: 'B2B' // Erroneously marked B2B by user
    } as any, '07ABFFB5922Q1Z0', true);

    results.push({
      id: 'TC-09',
      name: 'Unregistered Outward Supply Auto-Reclassification to B2CS (No Dummy GSTIN)',
      category: 'LEGAL_RULE',
      passed: unregInv.classification === 'B2C_SMALL' && unregInv.recipientGstin === '',
      expected: 'Classification: B2C_SMALL, recipientGstin: ""',
      actual: `Classification: ${unregInv.classification}, recipientGstin: "${unregInv.recipientGstin}"`,
      durationMs: Math.round(performance.now() - t9Start)
    });

    // Test 10: GSTR-3B Table 3.1 & Table 4 Credit Note Netting Math
    const t10Start = performance.now();
    const testSales = [
      {
        id: 'S1',
        invoiceNumber: 'INV-1',
        invoiceDate: '2026-04-01',
        documentType: 'INVOICE',
        supplierGstin: '07ABFFB5922Q1Z0',
        placeOfSupply: '07',
        taxableValue: 100000,
        gstRate: 18,
        cgst: 9000,
        sgst: 9000,
        igst: 0,
        cess: 0,
        classification: 'B2B',
        supplyType: 'INTRA_STATE'
      },
      {
        id: 'CN1',
        invoiceNumber: 'CN-1',
        invoiceDate: '2026-04-10',
        documentType: 'CREDIT_NOTE',
        supplierGstin: '07ABFFB5922Q1Z0',
        placeOfSupply: '07',
        taxableValue: 20000,
        gstRate: 18,
        cgst: 1800,
        sgst: 1800,
        igst: 0,
        cess: 0,
        classification: 'B2B',
        supplyType: 'INTRA_STATE'
      }
    ] as any;
    const test3b = gstr3bEngine.prepareGSTR3B(testSales, [], [], '04-2026', '07ABFFB5922Q1Z0');
    // Net outward taxable must be 100k - 20k = 80k
    results.push({
      id: 'TC-10',
      name: 'Section 34 Credit Note Netting in GSTR-3B Table 3.1(a)',
      category: 'RETURNS',
      passed: test3b.table3_1.outwardTaxable.taxable === 80000 && test3b.table3_1.outwardTaxable.cgst === 7200,
      expected: 'Net Taxable: ₹80,000, CGST: ₹7,200',
      actual: `Net Taxable: ₹${test3b.table3_1.outwardTaxable.taxable}, CGST: ₹${test3b.table3_1.outwardTaxable.cgst}`,
      durationMs: Math.round(performance.now() - t10Start)
    });

    return results;
  }
}

export const gstTestSuite = new GSTTestSuite();
