import React from 'react';
import { Database, AlertCircle, X, Check, ArrowRight } from 'lucide-react';

interface DemoConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
}

export const DemoConfirmationModal: React.FC<DemoConfirmationModalProps> = ({
  isOpen,
  onClose,
  onConfirm
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-[#FFFFFF]/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-white border border-[#E5E7EB] rounded-2xl max-w-md w-full shadow-2xl overflow-hidden p-6 space-y-5">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#FFF8E1] text-[#B7791F] border border-amber-500/20 text-[#B7791F] flex items-center justify-center">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#202124] tracking-tight">Load Demo Practice Dataset</h3>
              <p className="text-xs text-[#6B7280]">CA GST Automation Benchmark Data</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-[#6B7280] hover:text-white p-1 rounded-lg hover:bg-[#F8F9FA] transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 rounded-xl bg-[#F8F9FA] border border-[#E5E7EB] space-y-2">
          <p className="text-xs text-[#202124] leading-relaxed font-medium">
            Demo data will create sample clients, GSTINs, invoices and reconciliation records. Continue?
          </p>
          <ul className="text-[11px] text-[#6B7280] space-y-1 list-disc list-inside pt-1">
            <li>4 realistic Indian CA clients across states & business types</li>
            <li>6 multi-state GSTIN registrations with secure vault credentials</li>
            <li>Sample sales register, purchase register, and GSTR-2B statement</li>
            <li>5-level reconciliation test scenarios with rule exceptions</li>
          </ul>
        </div>

        <div className="flex items-center justify-end gap-3 pt-1">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-[#F8F9FA] hover:bg-slate-700 text-[#6B7280] text-xs font-bold border border-[#E5E7EB] transition"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => {
              onConfirm();
              onClose();
            }}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-slate-500 hover:from-emerald-500 hover:to-slate-400 text-slate-950 text-xs font-bold shadow-lg shadow-emerald-950/50 flex items-center gap-1.5 transition active:scale-95"
          >
            <Check className="w-4 h-4" />
            <span>Load Demo Data</span>
          </button>
        </div>
      </div>
    </div>
  );
};
