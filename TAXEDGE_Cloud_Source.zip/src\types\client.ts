/**
 * GST Practice AI — Multi-Client CA Domain Models
 * Supports Firm-level management of hundreds/thousands of clients and GSTINs
 */

export type BusinessType = 'Company' | 'Partnership' | 'Proprietorship' | 'LLP' | 'Other';
export type ReturnFrequency = 'Monthly' | 'QRMP';
export type ClientStatus = 'Active' | 'Archived' | 'Notice Received' | 'Onboarding';

export interface GSTINMasterEntry {
  gstin: string;
  clientId: string;
  legalName: string;
  tradeName: string;
  state: string;
  stateCode: string;
  registrationDate: string;
  registrationStatus: 'Active' | 'Suspended' | 'Cancelled';
  returnType: 'Regular' | 'Composition' | 'SEZ Unit' | 'ISD';
  businessType: BusinessType;
  portalUsername: string;
  encryptedPasswordMask: string; // "••••••••" - never exposed in plain text
  credentialStatus: 'CONNECTED' | 'NEEDS_AUTH' | 'EXPIRED' | 'UNCONFIGURED';
  lastVerified?: string;
  lastSuccessfulLogin?: string;
  otpRequirement: boolean;
  apiConnectionStatus: 'AUTHORIZED_GSP' | 'SANDBOX' | 'OFFLINE';
  last2bSync?: string;
  lastGstr1Sync?: string;
  lastGstr3bSync?: string;
  status2B: 'NOT_IMPORTED' | 'IMPORTING' | 'IMPORTED' | 'RECONCILING' | 'RECONCILED' | 'REVIEW_REQUIRED' | 'READY_FOR_FILING' | 'FILED';
  eligibleItc: number;
  taxLiability: number;
  notes?: string;
}

export interface ClientMaster {
  id: string; // e.g. "CLI-001"
  name: string;
  tradeName: string;
  legalName: string;
  pan: string;
  primaryGstin: string;
  additionalGstins: string[];
  businessType: BusinessType;
  state: string;
  registeredAddress: string;
  contactPerson: string;
  mobile: string;
  email: string;
  assignedStaff: string; // CA/Staff name
  returnFrequency: ReturnFrequency;
  financialYear: string; // "2026-27"
  status: ClientStatus;
  notes?: string;
  createdDate: string;
}

export interface BackgroundJob {
  id: string;
  type: '2B_SYNC' | '2B_RECONCILIATION' | 'GSTR1_SYNC' | 'GSTR3B_SYNC' | 'INVOICE_PROCESSING' | 'REPORT_GENERATION';
  clientId: string;
  clientName: string;
  gstin: string;
  period: string;
  status: 'Queued' | 'Processing' | 'Completed' | 'Failed' | 'Retry';
  progressPercent: number;
  startTime: string;
  endTime?: string;
  resultSummary?: string;
  errorMessage?: string;
  retryCount: number;
}

export interface BulkImportResult {
  totalRows: number;
  imported: number;
  failed: number;
  duplicates: number;
  invalidGstin: number;
  missingFields: number;
  errors: { row: number; identifier: string; reason: string }[];
}
