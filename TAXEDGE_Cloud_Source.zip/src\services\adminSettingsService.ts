/**
 * GST Practice AI — Administration & Practice Settings Service
 * Manages CA Firm Branding, Global Statutory Tolerances, Master HSN Overrides,
 * System Feature Toggles, and Full One-Click System Snapshots (JSON Backup/Restore).
 */

import { clientStorageService } from './clientStorageService';
import { credentialVaultService } from './credentialVaultService';
import { ClientMaster, GSTINMasterEntry } from '../types/client';

export interface PracticeSettings {
  firmName: string;
  frn: string; // Firm Registration Number
  partnerName: string;
  membershipNo: string;
  email: string;
  phone: string;
  address: string;
  defaultState: string;
  financialYear: string;
  defaultReturnPeriod: string;
  reconciliationTolerance: number; // in INR, e.g. ₹2
  strictRule37: boolean; // 180-day ITC reversal
  autoDetect17_5: boolean; // 17(5) blocked credit auto detection
  autoCalculateRCM: boolean; // Sec 9(3)/9(4) reverse charge calculation
  geminiApiKey: string;
}

export interface HsnOverride {
  code: string;
  description: string;
  gstRate: number; // 0, 5, 12, 18, 28
  isCustom?: boolean;
}

const SETTINGS_KEY = 'gst_practice_ai_admin_settings_v1';
const HSN_OVERRIDES_KEY = 'gst_practice_ai_hsn_overrides_v1';

export const DEFAULT_PRACTICE_SETTINGS: PracticeSettings = {
  firmName: 'Sharma & Associates, Chartered Accountants',
  frn: '109824W',
  partnerName: 'CA Rahul Sharma, FCA',
  membershipNo: '049821',
  email: 'contact@sharma-ca.in',
  phone: '+91 98100 12345',
  address: 'Level 4, Barakhamba Road, Connaught Place, New Delhi 110001',
  defaultState: 'Delhi',
  financialYear: '2026-27',
  defaultReturnPeriod: '04-2026',
  reconciliationTolerance: 2.0,
  strictRule37: true,
  autoDetect17_5: true,
  autoCalculateRCM: true,
  geminiApiKey: ''
};

class AdminSettingsService {
  private settings: PracticeSettings = DEFAULT_PRACTICE_SETTINGS;
  private hsnOverrides: Record<string, HsnOverride> = {};

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage(): void {
    try {
      const stored = localStorage.getItem(SETTINGS_KEY);
      if (stored) {
        this.settings = { ...DEFAULT_PRACTICE_SETTINGS, ...JSON.parse(stored) };
      }
    } catch (e) {
      console.warn('Failed to load admin settings from localStorage:', e);
    }

    try {
      const storedHsn = localStorage.getItem(HSN_OVERRIDES_KEY);
      if (storedHsn) {
        this.hsnOverrides = JSON.parse(storedHsn);
      }
    } catch (e) {
      console.warn('Failed to load HSN overrides from localStorage:', e);
    }
  }

  public getSettings(): PracticeSettings {
    return { ...this.settings };
  }

  public saveSettings(updated: Partial<PracticeSettings>): PracticeSettings {
    this.settings = { ...this.settings, ...updated };
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(this.settings));
    } catch (e) {
      console.warn('Failed to save admin settings to localStorage:', e);
    }
    return { ...this.settings };
  }

  public resetSettings(): PracticeSettings {
    this.settings = { ...DEFAULT_PRACTICE_SETTINGS };
    try {
      localStorage.removeItem(SETTINGS_KEY);
    } catch (e) {}
    return { ...this.settings };
  }

  public getHsnOverrides(): Record<string, HsnOverride> {
    return { ...this.hsnOverrides };
  }

  public saveHsnOverride(code: string, description: string, gstRate: number, isCustom: boolean = false): void {
    const cleanCode = code.trim();
    this.hsnOverrides[cleanCode] = {
      code: cleanCode,
      description,
      gstRate,
      isCustom
    };
    try {
      localStorage.setItem(HSN_OVERRIDES_KEY, JSON.stringify(this.hsnOverrides));
    } catch (e) {
      console.warn('Failed to save HSN overrides:', e);
    }
  }

  public deleteHsnOverride(code: string): void {
    delete this.hsnOverrides[code];
    try {
      localStorage.setItem(HSN_OVERRIDES_KEY, JSON.stringify(this.hsnOverrides));
    } catch (e) {}
  }

  public resetHsnOverrides(): void {
    this.hsnOverrides = {};
    try {
      localStorage.removeItem(HSN_OVERRIDES_KEY);
    } catch (e) {}
  }

  /**
   * One-Click Complete Database JSON Export
   */
  public exportFullSystemSnapshot(): any {
    const clients = clientStorageService.getClients();
    const gstins = clientStorageService.getAllGstins();
    const credentials = credentialVaultService.getAllCredentials();
    const settings = this.getSettings();
    const hsnOverrides = this.getHsnOverrides();

    // Extract all client-isolated datasets across localStorage
    const clientDataMap: Record<string, any> = {};
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && (key.startsWith('gst_practice_ai_data_') || key.startsWith('gst_practice_ai_acc_'))) {
        try {
          clientDataMap[key] = JSON.parse(localStorage.getItem(key) || '{}');
        } catch {}
      }
    }

    return {
      version: '3.2.4',
      exportTimestamp: new Date().toISOString(),
      firmSettings: settings,
      hsnOverrides,
      clients,
      gstins,
      credentials,
      clientDataMap
    };
  }

  /**
   * One-Click Complete Database JSON Import
   */
  public importFullSystemSnapshot(snapshot: any): { success: boolean; message: string; count?: number } {
    if (!snapshot || typeof snapshot !== 'object') {
      return { success: false, message: 'Invalid snapshot format.' };
    }

    try {
      if (snapshot.firmSettings) {
        this.saveSettings(snapshot.firmSettings);
      }
      if (snapshot.hsnOverrides) {
        this.hsnOverrides = snapshot.hsnOverrides;
        localStorage.setItem(HSN_OVERRIDES_KEY, JSON.stringify(this.hsnOverrides));
      }
      if (Array.isArray(snapshot.clients)) {
        localStorage.setItem('gst_practice_ai_clients_v2', JSON.stringify(snapshot.clients));
      }
      if (Array.isArray(snapshot.gstins)) {
        localStorage.setItem('gst_practice_ai_gstins_v2', JSON.stringify(snapshot.gstins));
      }
      if (snapshot.clientDataMap && typeof snapshot.clientDataMap === 'object') {
        Object.entries(snapshot.clientDataMap).forEach(([k, val]) => {
          localStorage.setItem(k, JSON.stringify(val));
        });
      }

      return {
        success: true,
        message: `Successfully restored snapshot from ${snapshot.exportTimestamp || 'backup'}.`,
        count: Array.isArray(snapshot.clients) ? snapshot.clients.length : 0
      };
    } catch (err: any) {
      return { success: false, message: `Import failed: ${err.message}` };
    }
  }
}

export const adminSettingsService = new AdminSettingsService();
