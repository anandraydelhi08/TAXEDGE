import React from 'react';
import { Repeat, AlertTriangle, CheckCircle2, Wallet, BookOpen, ShieldCheck, FileText } from 'lucide-react';
import { TransactionInvoice } from '../types/gst';
import { formatINR } from '../utils/taxMath';

interface RCMEngineViewProps {
  purchases: TransactionInvoice[];
  sales: TransactionInvoice[];
  onOpenAI: (prompt: string) => void;
}

export const RCMEngineView: React.FC<RCMEngineViewProps> = ({ purchases, sales, onOpenAI }) => {
  const rcmPurchases = purchases.filter(p => p.rcm);
  const totalRcmTaxable = rcmPurchases.reduce((sum, p) => sum + p.taxableValue, 0);
  const totalRcmTax = rcmPurchases.reduce((sum, p) => sum + (p.cgst + p.sgst + p.igst + p.cess), 0);

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-[#202124] flex items-center gap-2">
              <Repeat className="w-5 h-5 text-[#176B4D]" />
              Reverse Charge Mechanism (RCM) Engine
            </h2>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#E8F5EF] text-[#176B4D] font-bold border border-[#176B4D]/30">
              Section 9(3) & 9(4) CGST Act
            </span>
          </div>
          <p className="text-xs text-[#6B7280] mt-1">
            Statutory shift of tax liability to recipient, mandatory Electronic Cash Ledger settlement, and separate ITC claim.
          </p>
        </div>

        <button
          onClick={() => onOpenAI('Explain reverse charge under Section 9(3) and Notification 13/2017-CT(R) Bare Law April 2026')}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white hover:bg-[#E8F5EF] text-[#176B4D] border border-[#176B4D]/40 text-xs font-bold transition shadow-sm"
        >
          <BookOpen className="w-3.5 h-3.5 text-[#176B4D]" />
          <span>Section 9(3) Bare Law Citations</span>
        </button>
      </div>

      {/* Critical Statutory Rule Banner */}
      <div className="bg-[#FFF8E1] border border-[#B7791F]/30 rounded-2xl p-5 shadow-sm space-y-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#B7791F]/15 text-[#B7791F] flex items-center justify-center shrink-0 border border-[#B7791F]/20">
            <Wallet className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-[#202124]">
              Mandatory Cash Payment Rule (Section 49(4) Explanation)
            </h3>
            <p className="text-xs text-[#6B7280] mt-0.5 leading-relaxed">
              Tax payable on reverse charge under Section 9(3) and 9(4) CANNOT be discharged through the Electronic Credit Ledger (ITC). It must be paid 100% in CASH via the Electronic Cash Ledger. Once paid, it becomes eligible ITC in subsequent return.
            </p>
          </div>
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-[#E5E7EB] rounded-xl p-4 shadow-sm">
          <div className="text-[11px] text-[#6B7280] font-semibold uppercase tracking-wider">Inward RCM Taxable Value</div>
          <div className="text-xl font-bold text-[#202124] mt-1 font-mono">{formatINR(totalRcmTaxable)}</div>
          <div className="text-[10px] text-[#6B7280] mt-1">Reported in GSTR-3B Table 3.1(d)</div>
        </div>

        <div className="bg-white border border-[#B7791F]/30 rounded-xl p-4 shadow-sm bg-[#FFF8E1]/20">
          <div className="text-[11px] text-[#B7791F] font-semibold uppercase tracking-wider">Mandatory Cash Payment Liability</div>
          <div className="text-xl font-bold text-[#B7791F] mt-1 font-mono">{formatINR(totalRcmTax)}</div>
          <div className="text-[10px] text-[#6B7280] mt-1">Electronic Cash Ledger debit required</div>
        </div>

        <div className="bg-white border border-[#176B4D]/30 rounded-xl p-4 shadow-sm bg-[#E8F5EF]/20">
          <div className="text-[11px] text-[#176B4D] font-semibold uppercase tracking-wider">Subsequent ITC Claimable (Sec 16)</div>
          <div className="text-xl font-bold text-[#176B4D] mt-1 font-mono">{formatINR(totalRcmTax)}</div>
          <div className="text-[10px] text-[#6B7280] mt-1">Credited in GSTR-3B Table 4(A)(3)</div>
        </div>
      </div>

      {/* Inward RCM Transactions Table */}
      <div className="bg-white border border-[#E5E7EB] rounded-xl overflow-hidden shadow-sm space-y-4 p-5">
        <h3 className="text-sm font-bold text-[#202124] flex items-center gap-2">
          <FileText className="w-4 h-4 text-[#176B4D]" />
          Active Inward RCM Supplies (Section 9(3))
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#202124]">
            <thead className="bg-[#F8F9FA] text-[#202124] text-[11px] uppercase tracking-wider font-bold border-b border-[#E5E7EB]">
              <tr>
                <th className="px-4 py-3">Invoice No & Date</th>
                <th className="px-4 py-3">Supplier Name & GSTIN</th>
                <th className="px-3 py-3">Category</th>
                <th className="px-3 py-3">HSN/SAC</th>
                <th className="px-4 py-3 text-right">Taxable Value</th>
                <th className="px-3 py-3 text-center">Rate</th>
                <th className="px-4 py-3 text-right">RCM Tax Liability</th>
                <th className="px-3 py-3 text-center">Payment Mode</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E5E7EB] font-sans">
              {rcmPurchases.map(inv => (
                <tr key={inv.id} className="hover:bg-[#F8F9FA] transition">
                  <td className="px-4 py-3 font-mono text-[#202124] font-semibold">
                    {inv.invoiceNumber}
                    <div className="text-[10px] text-[#6B7280] font-sans">{inv.invoiceDate}</div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="font-semibold text-[#202124]">{inv.supplierName}</div>
                    <div className="text-[10px] font-mono text-[#6B7280]">{inv.supplierGstin}</div>
                  </td>
                  <td className="px-3 py-3 font-semibold text-[#176B4D]">
                    {inv.rcmCategory?.replace(/_/g, ' ') || 'NOTIFIED_SERVICE'}
                  </td>
                  <td className="px-3 py-3 font-mono text-[#6B7280]">
                    {inv.hsnSacPrimary}
                  </td>
                  <td className="px-4 py-3 text-right font-mono font-medium text-[#202124]">
                    {formatINR(inv.taxableValue)}
                  </td>
                  <td className="px-3 py-3 text-center font-mono font-semibold text-[#202124]">
                    {inv.gstRate}%
                  </td>
                  <td className="px-4 py-3 text-right font-mono font-bold text-[#B7791F]">
                    {formatINR(inv.cgst + inv.sgst + inv.igst)}
                  </td>
                  <td className="px-3 py-3 text-center">
                    <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-[#FFF8E1] text-[#B7791F] border border-[#B7791F]/30">
                      CASH ONLY (Sec 49)
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
