import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { defineConfig, Plugin } from 'vite';
import { VitePWA } from 'vite-plugin-pwa';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function apiServerPlugin(): Plugin {
  return {
    name: 'api-server-plugin',
    transformIndexHtml: {
      order: 'pre',
      handler() {
        return [
          {
            tag: 'script',
            children: `(function() {
              const origError = console.error;
              console.error = function(...args) {
                const msg = args.map(a => (typeof a === 'object' && a ? (a.message || a.stack || JSON.stringify(a)) : String(a))).join(' ');
                if (msg.includes('send was called before connect') || msg.includes("reading 'send'") || msg.includes('[vite]')) {
                  return;
                }
                origError.apply(console, args);
              };
              const origWarn = console.warn;
              console.warn = function(...args) {
                const msg = args.map(a => String(a)).join(' ');
                if (msg.includes('send was called before connect') || msg.includes("reading 'send'") || msg.includes('[vite]')) {
                  return;
                }
                origWarn.apply(console, args);
              };
              window.addEventListener('error', function(e) {
                if (e && e.message && (e.message.includes('send was called before connect') || e.message.includes("reading 'send'"))) {
                  e.preventDefault();
                  e.stopImmediatePropagation();
                }
              }, true);
              window.addEventListener('unhandledrejection', function(e) {
                if (e && e.reason && String(e.reason).includes('send was called before connect')) {
                  e.preventDefault();
                  e.stopImmediatePropagation();
                }
              }, true);
            })();`,
            injectTo: 'head-prepend',
          },
        ];
      },
    },
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (req.url?.startsWith('/api/gemini/chat') && req.method === 'POST') {
          let body = '';
          req.on('data', chunk => {
            body += chunk;
          });
          req.on('end', async () => {
            try {
              const { handleGeminiChat } = await import('./server/geminiHandler.ts');
              const parsed = body ? JSON.parse(body) : {};
              const result = await handleGeminiChat(parsed);
              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify(result));
            } catch (err: any) {
              res.statusCode = 500;
              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify({ error: err.message || 'Internal error' }));
            }
          });
          return;
        }
        if (
          req.url === '/apk' ||
          req.url === '/download' ||
          req.url === '/download-apk'
        ) {
          const apkHtmlPath = path.resolve(__dirname, 'public/apk.html');
          if (fs.existsSync(apkHtmlPath)) {
            res.setHeader('Content-Type', 'text/html; charset=utf-8');
            const stream = fs.createReadStream(apkHtmlPath);
            stream.pipe(res);
            return;
          }
        }
        if (
          req.url?.startsWith('/GST-Practice-AI.apk') ||
          req.url?.startsWith('/api/download/gst-practice-ai.apk') ||
          req.url === '/download/apk'
        ) {
          const apkPath = fs.existsSync(path.resolve(__dirname, 'public/GST-Practice-AI.apk'))
            ? path.resolve(__dirname, 'public/GST-Practice-AI.apk')
            : path.resolve(__dirname, 'dist/GST-Practice-AI.apk');
          if (fs.existsSync(apkPath)) {
            const stat = fs.statSync(apkPath);
            res.setHeader('Content-Type', 'application/vnd.android.package-archive');
            res.setHeader('Content-Disposition', 'attachment; filename="GST-Practice-AI.apk"');
            res.setHeader('Content-Length', stat.size);
            res.setHeader('Cache-Control', 'no-cache');
            const readStream = fs.createReadStream(apkPath);
            readStream.pipe(res);
            return;
          }
        }
        next();
      });
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [
      react(),
      tailwindcss(),
      apiServerPlugin(),
      VitePWA({
        registerType: 'autoUpdate',
        includeAssets: ['favicon.ico', 'apple-touch-icon.png', 'icon.svg'],
        manifest: {
          id: '/',
          name: 'TAXEDGE — Enterprise GST Compliance Platform',
          short_name: 'TAXEDGE',
          description: 'Enterprise GST Compliance Platform, GSTR-1/3B filing, and 5-Level 2B Auto-Reconciliation',
          theme_color: '#0B1F44',
          background_color: '#0B1F44',
          display: 'standalone',
          orientation: 'portrait-primary',
          start_url: '/',
          scope: '/',
          icons: [
            {
              src: '/pwa-192x192.png',
              sizes: '192x192',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'any',
            },
            {
              src: '/pwa-maskable-512x512.png',
              sizes: '512x512',
              type: 'image/png',
              purpose: 'maskable',
            },
          ],
        },
        workbox: {
          globPatterns: ['**/*.{js,css,html,ico,png,svg,woff,woff2}'],
          runtimeCaching: [
            {
              urlPattern: /^https:\/\/fonts\.googleapis\.com\/.*/i,
              handler: 'CacheFirst',
              options: {
                cacheName: 'google-fonts-cache',
                expiration: {
                  maxEntries: 10,
                  maxAgeSeconds: 60 * 60 * 24 * 365,
                },
                cacheableResponse: {
                  statuses: [0, 200],
                },
              },
            },
            {
              urlPattern: /^https:\/\/fonts\.gstatic\.com\/.*/i,
              handler: 'CacheFirst',
              options: {
                cacheName: 'gstatic-fonts-cache',
                expiration: {
                  maxEntries: 10,
                  maxAgeSeconds: 60 * 60 * 24 * 365,
                },
                cacheableResponse: {
                  statuses: [0, 200],
                },
              },
            },
          ],
        },
        devOptions: {
          enabled: false,
        },
      }),
    ],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      port: 3000,
      host: '0.0.0.0',
      hmr: false,
    },
    build: {
      chunkSizeWarningLimit: 1500,
      rollupOptions: {
        output: {
          manualChunks(id) {
            if (id.includes('node_modules')) {
              if (id.includes('lucide-react')) {
                return 'lucide-icons';
              }
              if (id.includes('react') || id.includes('react-dom')) {
                return 'vendor-react';
              }
              return 'vendor';
            }
          },
        },
      },
    },
  };
});

