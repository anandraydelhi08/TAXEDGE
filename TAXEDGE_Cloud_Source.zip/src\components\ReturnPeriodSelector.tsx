import React from 'react';
import { Calendar, ChevronDown } from 'lucide-react';
import { FINANCIAL_YEARS, RETURN_MONTHS } from '../services/returnPeriodService';

interface ReturnPeriodSelectorProps {
  selectedFy: string;
  selectedMonth: string;
  onSelectFy: (fy: string) => void;
  onSelectMonth: (month: string) => void;
  compact?: boolean;
}

export const ReturnPeriodSelector: React.FC<ReturnPeriodSelectorProps> = ({
  selectedFy,
  selectedMonth,
  onSelectFy,
  onSelectMonth,
  compact = false
}) => {
  return (
    <div className={`flex items-center gap-1.5 ${compact ? '' : 'p-1 rounded-xl bg-[#F8F9FA] border border-[#E5E7EB]'}`}>
      {/* Financial Year Selector */}
      <div className="flex items-center gap-1.5 bg-white hover:bg-[#F8F9FA] border border-[#E5E7EB] px-2.5 py-1.5 rounded-lg text-xs transition shadow-sm">
        <Calendar className="w-3.5 h-3.5 text-[#176B4D] shrink-0" />
        <span className="text-[10px] uppercase font-bold text-[#6B7280]">FY:</span>
        <select
          value={selectedFy}
          onChange={e => onSelectFy(e.target.value)}
          className="bg-transparent font-bold text-[#202124] focus:outline-none cursor-pointer text-xs"
          title="Select Financial Year"
        >
          {FINANCIAL_YEARS.map(fy => (
            <option key={fy} value={fy} className="bg-white text-[#202124]">
              {fy}
            </option>
          ))}
        </select>
      </div>

      {/* Month Selector */}
      <div className="flex items-center gap-1.5 bg-white hover:bg-[#F8F9FA] border border-[#E5E7EB] px-2.5 py-1.5 rounded-lg text-xs transition shadow-sm">
        <span className="text-[10px] uppercase font-bold text-[#6B7280]">Month:</span>
        <select
          value={selectedMonth}
          onChange={e => onSelectMonth(e.target.value)}
          className="bg-transparent font-bold text-[#202124] focus:outline-none cursor-pointer text-xs"
          title="Select Return Month"
        >
          {RETURN_MONTHS.map(m => (
            <option key={m.name} value={m.name} className="bg-white text-[#202124]">
              {m.name}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
};
