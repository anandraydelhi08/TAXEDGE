/**
 * GST Reconciliation Engine
 * Multi-Client CA Practice Edition
 *
 * Matching Hierarchy:
 * LEVEL 1: GSTIN + Invoice Number + Invoice Date
 * LEVEL 2: GSTIN + Invoice Number
 * LEVEL 3: GSTIN + Taxable Value
 * LEVEL 4: GSTIN + Tax Amount
 * LEVEL 5: Fuzzy invoice-number matching (INV/001, INV-001, INV001, 001)
 *
 * Important Rule: Fuzzy matching NEVER overwrites original invoice data.
 */

import { TransactionInvoice, GSTR2BRecord, ReconciliationResultItem, MatchStatus } from '../types/gst';
import { round2 } from '../utils/taxMath';

export function normalizeInvoiceNumber(invNum: string): string {
  if (!invNum) return '';
  return invNum.trim().toUpperCase().replace(/[\/\-_\\.\s]/g, '').replace(/^0+/, '');
}

/**
 * Calculates string similarity between two invoice strings (0 to 1)
 */
export function calculateFuzzySimilarity(a: string, b: string): number {
  const normA = normalizeInvoiceNumber(a);
  const normB = normalizeInvoiceNumber(b);
  if (normA === normB) return 1.0;
  if (!normA || !normB) return 0;
  if (normA.includes(normB) || normB.includes(normA)) return 0.85;

  // Levenshtein similarity
  const m = normA.length;
  const n = normB.length;
  const d: number[][] = [];
  for (let i = 0; i <= m; i++) d[i] = [i];
  for (let j = 0; j <= n; j++) d[0][j] = j;

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = normA[i - 1] === normB[j - 1] ? 0 : 1;
      d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost);
    }
  }

  const maxLen = Math.max(m, n);
  return maxLen === 0 ? 1 : round2(1 - d[m][n] / maxLen);
}

export interface DetailedFinancialSummary {
  bookTaxable: number;
  gstr2bTaxable: number;
  diffTaxable: number;

  bookIgst: number;
  gstr2bIgst: number;
  diffIgst: number;

  bookCgst: number;
  gstr2bCgst: number;
  diffCgst: number;

  bookSgst: number;
  gstr2bSgst: number;
  diffSgst: number;

  bookCess: number;
  gstr2bCess: number;
  diffCess: number;

  totalBookTax: number;
  total2BTax: number;
  netTaxVariance: number;

  itcBooks: number;
  itc2B: number;
  eligibleItc: number;
  ineligibleItc: number;
  differenceItc: number;
}

export interface ReconciliationSummaryStats {
  totalPurchases: number;
  total2B: number;
  exactMatches: number;
  partialMatches: number;
  valueMismatches: number;
  taxMismatches: number;
  dateMismatches: number;
  fuzzyMatches: number;
  missingIn2B: number;
  missingInBooks: number;
  duplicateCount: number;
  creditNoteMismatches: number;
  reviewRequiredCount: number;
  totalMatchRatePercent: number;
}

export class ReconciliationEngine {
  /**
   * Reconciles Purchase Register against GSTR-2B using 5-level matching
   */
  public reconcilePurchaseVs2B(
    purchases: TransactionInvoice[],
    gstr2bRecords: GSTR2BRecord[],
    toleranceValue: number = 2.0 // ₹2 tolerance for rounding
  ): {
    results: ReconciliationResultItem[];
    stats: ReconciliationSummaryStats;
    financialSummary: DetailedFinancialSummary;
  } {
    const results: ReconciliationResultItem[] = [];
    const matched2BIds = new Set<string>();

    let exactMatches = 0;
    let partialMatches = 0;
    let valueMismatches = 0;
    let taxMismatches = 0;
    let dateMismatches = 0;
    let fuzzyMatches = 0;
    let missingIn2B = 0;
    let creditNoteMismatches = 0;
    let duplicateCount = 0;

    // Financial accumulations
    let bookTaxableSum = 0;
    let bookIgstSum = 0;
    let bookCgstSum = 0;
    let bookSgstSum = 0;
    let bookCessSum = 0;

    let itcBooksEligibleSum = 0;
    let itcBooksIneligibleSum = 0;

    // Detect duplicates in purchase register
    const seenPurchases = new Map<string, number>();
    for (const p of purchases) {
      const key = `${p.supplierGstin.trim().toUpperCase()}_${normalizeInvoiceNumber(p.invoiceNumber)}`;
      seenPurchases.set(key, (seenPurchases.get(key) || 0) + 1);
    }

    for (const purchase of purchases) {
      const bTaxable = round2(purchase.taxableValue);
      const bIgst = round2(purchase.igst);
      const bCgst = round2(purchase.cgst);
      const bSgst = round2(purchase.sgst);
      const bCess = round2(purchase.cess);
      const bTax = round2(bIgst + bCgst + bSgst + bCess);
      const bTotal = round2(purchase.totalAmount);

      bookTaxableSum = round2(bookTaxableSum + bTaxable);
      bookIgstSum = round2(bookIgstSum + bIgst);
      bookCgstSum = round2(bookCgstSum + bCgst);
      bookSgstSum = round2(bookSgstSum + bSgst);
      bookCessSum = round2(bookCessSum + bCess);

      if (purchase.itcStatus === 'INELIGIBLE') {
        itcBooksIneligibleSum = round2(itcBooksIneligibleSum + bTax);
      } else {
        itcBooksEligibleSum = round2(itcBooksEligibleSum + bTax);
      }

      const normBookInv = normalizeInvoiceNumber(purchase.invoiceNumber);
      const pGstin = purchase.supplierGstin.trim().toUpperCase();
      const isDuplicateInBooks = (seenPurchases.get(`${pGstin}_${normBookInv}`) || 0) > 1;

      if (isDuplicateInBooks) {
        duplicateCount++;
      }

      // LEVEL 1: GSTIN + Invoice Number + Invoice Date
      let match = gstr2bRecords.find(
        r => !matched2BIds.has(r.id) &&
             r.supplierGstin.trim().toUpperCase() === pGstin &&
             normalizeInvoiceNumber(r.invoiceNumber) === normBookInv &&
             r.invoiceDate === purchase.invoiceDate
      );
      let matchLevel = match ? 1 : 0;

      // LEVEL 2: GSTIN + Invoice Number
      if (!match) {
        match = gstr2bRecords.find(
          r => !matched2BIds.has(r.id) &&
               r.supplierGstin.trim().toUpperCase() === pGstin &&
               normalizeInvoiceNumber(r.invoiceNumber) === normBookInv
        );
        if (match) matchLevel = 2;
      }

      // LEVEL 3: GSTIN + Taxable Value (within tolerance)
      if (!match) {
        match = gstr2bRecords.find(
          r => !matched2BIds.has(r.id) &&
               r.supplierGstin.trim().toUpperCase() === pGstin &&
               Math.abs(r.taxableValue - bTaxable) <= toleranceValue
        );
        if (match) matchLevel = 3;
      }

      // LEVEL 4: GSTIN + Tax Amount (within tolerance)
      if (!match) {
        match = gstr2bRecords.find(
          r => !matched2BIds.has(r.id) &&
               r.supplierGstin.trim().toUpperCase() === pGstin &&
               Math.abs((r.cgst + r.sgst + r.igst + r.cess) - bTax) <= toleranceValue
        );
        if (match) matchLevel = 4;
      }

      // LEVEL 5: Fuzzy Invoice-Number Matching (INV/001 vs INV-001 vs 001)
      let fuzzyScore = 0;
      if (!match) {
        let bestCandidate: GSTR2BRecord | null = null;
        let highestSim = 0;

        for (const r of gstr2bRecords) {
          if (matched2BIds.has(r.id)) continue;
          if (r.supplierGstin.trim().toUpperCase() !== pGstin) continue;

          const sim = calculateFuzzySimilarity(purchase.invoiceNumber, r.invoiceNumber);
          if (sim >= 0.75 && sim > highestSim) {
            highestSim = sim;
            bestCandidate = r;
          }
        }

        if (bestCandidate) {
          match = bestCandidate;
          matchLevel = 5;
          fuzzyScore = highestSim;
          fuzzyMatches++;
        }
      }

      if (match) {
        matched2BIds.add(match.id);
        const g2bTax = round2(match.cgst + match.sgst + match.igst + match.cess);
        const g2bTaxable = round2(match.taxableValue);
        const g2bTotal = round2(match.invoiceValue);

        const diffTaxable = round2(g2bTaxable - bTaxable);
        const diffTax = round2(g2bTax - bTax);

        let status: MatchStatus = 'EXACT_MATCH';
        let rootCause = 'Invoice and tax values match exactly with GSTR-2B.';
        let itcImpact = 'Full eligible ITC claimable in GSTR-3B Table 4(A)(5).';
        let action = 'No action required.';

        if (match.invoiceType === 'CDNR' && purchase.documentType !== 'CREDIT_NOTE') {
          status = 'CREDIT_NOTE_MISMATCH';
          creditNoteMismatches++;
          rootCause = 'Document mismatch: Supplier reported Credit Note (CDNR) in 2B while Books show Invoice.';
          itcImpact = 'ITC must be reduced or reversed in Table 4(B)(2).';
          action = 'Verify supplier credit note copy and reverse ITC in Books.';
        } else if (matchLevel === 5) {
          status = 'POSSIBLE_MATCH';
          partialMatches++;
          rootCause = `Fuzzy invoice number match (${Math.round(fuzzyScore * 100)}% similarity). Books: "${purchase.invoiceNumber}" vs 2B: "${match.invoiceNumber}".`;
          itcImpact = 'Original invoice number retained. ITC claimable once verified.';
          action = 'Review invoice syntax format difference with supplier.';
        } else if (Math.abs(diffTax) > toleranceValue) {
          status = 'TAX_MISMATCH';
          taxMismatches++;
          rootCause = `Tax variance of ₹${Math.abs(diffTax)}. Supplier reported tax rate at variance with books.`;
          itcImpact = diffTax < 0
            ? `Restricted to 2B amount: Cannot claim excess ₹${Math.abs(diffTax)} under Rule 36(4).`
            : `2B shows higher tax by ₹${diffTax}. Verify original tax invoice copy.`;
          action = 'Contact supplier to amend in next GSTR-1 or correct book tax rate.';
        } else if (Math.abs(diffTaxable) > toleranceValue) {
          status = 'VALUE_MISMATCH';
          valueMismatches++;
          partialMatches++;
          rootCause = `Taxable base mismatch of ₹${Math.abs(diffTaxable)}.`;
          itcImpact = 'Audit query flag: ITC difference requires book adjustment.';
          action = 'Verify whether discount or freight was omitted by supplier.';
        } else if (match.invoiceDate !== purchase.invoiceDate) {
          status = 'DATE_MISMATCH';
          dateMismatches++;
          partialMatches++;
          rootCause = `Date mismatch: Books record ${purchase.invoiceDate}, 2B records ${match.invoiceDate}.`;
          itcImpact = 'Valid for ITC if within same financial year.';
          action = 'Update accounting record to reflect supplier tax invoice date.';
        } else if (isDuplicateInBooks) {
          status = 'DUPLICATE';
          rootCause = `Duplicate entry in Purchase Register: Invoice ${purchase.invoiceNumber} booked multiple times.`;
          itcImpact = 'Risk of double ITC claim. Immediate reversal required.';
          action = 'Remove or void duplicate invoice entry in Purchase Register.';
        } else {
          exactMatches++;
        }

        results.push({
          id: `REC-${purchase.id}`,
          invoiceNumber: purchase.invoiceNumber,
          supplierGstin: purchase.supplierGstin,
          supplierName: purchase.supplierName,
          invoiceDate: purchase.invoiceDate,
          matchStatus: status,
          bookTaxable: bTaxable,
          bookTax: bTax,
          bookTotal: bTotal,
          gstr2bTaxable: g2bTaxable,
          gstr2bTax: g2bTax,
          gstr2bTotal: g2bTotal,
          taxableDifference: diffTaxable,
          taxDifference: diffTax,
          rootCause,
          itcImpact,
          recommendedAction: action,
          resolved: status === 'EXACT_MATCH'
        });
      } else {
        // Missing in 2B
        missingIn2B++;
        results.push({
          id: `REC-${purchase.id}`,
          invoiceNumber: purchase.invoiceNumber,
          supplierGstin: purchase.supplierGstin,
          supplierName: purchase.supplierName,
          invoiceDate: purchase.invoiceDate,
          matchStatus: 'MISSING_IN_2B',
          bookTaxable: bTaxable,
          bookTax: bTax,
          bookTotal: bTotal,
          gstr2bTaxable: 0,
          gstr2bTax: 0,
          gstr2bTotal: 0,
          taxableDifference: -bTaxable,
          taxDifference: -bTax,
          rootCause: purchase.rcm
            ? 'Inward RCM Supply: Reverse charge invoice is not uploaded in vendor GSTR-1.'
            : 'Supplier has not uploaded invoice in GSTR-1 or filed with wrong recipient GSTIN.',
          itcImpact: purchase.rcm
            ? 'ITC available once tax is paid in cash in GSTR-3B Table 3.1(d).'
            : `Rule 36(4) BLOCK: ₹${bTax} cannot be availed in GSTR-3B until supplier files GSTR-1.`,
          recommendedAction: purchase.rcm
            ? 'Pay via Cash Ledger in Table 3.1(d) and claim ITC in Table 4(A)(3).'
            : 'Send automated GSTIN reminder notice to supplier finance department.',
          resolved: purchase.rcm
        });
      }
    }

    // Records in GSTR-2B Missing in Books
    let missingInBooks = 0;
    let g2bTaxableSum = 0;
    let g2bIgstSum = 0;
    let g2bCgstSum = 0;
    let g2bSgstSum = 0;
    let g2bCessSum = 0;
    let itc2bEligibleSum = 0;
    let itc2bIneligibleSum = 0;

    for (const record of gstr2bRecords) {
      const rTaxable = round2(record.taxableValue);
      const rIgst = round2(record.igst);
      const rCgst = round2(record.cgst);
      const rSgst = round2(record.sgst);
      const rCess = round2(record.cess);
      const rTax = round2(rIgst + rCgst + rSgst + rCess);

      g2bTaxableSum = round2(g2bTaxableSum + rTaxable);
      g2bIgstSum = round2(g2bIgstSum + rIgst);
      g2bCgstSum = round2(g2bCgstSum + rCgst);
      g2bSgstSum = round2(g2bSgstSum + rSgst);
      g2bCessSum = round2(g2bCessSum + rCess);

      if (record.itcAvailable) {
        itc2bEligibleSum = round2(itc2bEligibleSum + rTax);
      } else {
        itc2bIneligibleSum = round2(itc2bIneligibleSum + rTax);
      }

      if (!matched2BIds.has(record.id)) {
        missingInBooks++;
        results.push({
          id: `REC-2B-${record.id}`,
          invoiceNumber: record.invoiceNumber,
          supplierGstin: record.supplierGstin,
          supplierName: record.supplierName,
          invoiceDate: record.invoiceDate,
          matchStatus: 'MISSING_IN_BOOKS',
          bookTaxable: 0,
          bookTax: 0,
          bookTotal: 0,
          gstr2bTaxable: rTaxable,
          gstr2bTax: rTax,
          gstr2bTotal: record.invoiceValue,
          taxableDifference: rTaxable,
          taxDifference: rTax,
          rootCause: 'Invoice appears in GSTR-2B auto-drafted statement but is not booked in purchase register.',
          itcImpact: `Potential unclaimed ITC of ₹${rTax}. Can be availed once invoice is accounted for.`,
          recommendedAction: 'Fetch invoice copy from vendor, verify goods/services receipt, and book entry in ERP.',
          resolved: false
        });
      }
    }

    const totalItems = purchases.length + missingInBooks;
    const matchRate = totalItems > 0 ? round2((exactMatches / totalItems) * 100) : 100;
    const totalBookTax = round2(bookIgstSum + bookCgstSum + bookSgstSum + bookCessSum);
    const total2BTax = round2(g2bIgstSum + g2bCgstSum + g2bSgstSum + g2bCessSum);

    const financialSummary: DetailedFinancialSummary = {
      bookTaxable: bookTaxableSum,
      gstr2bTaxable: g2bTaxableSum,
      diffTaxable: round2(g2bTaxableSum - bookTaxableSum),

      bookIgst: bookIgstSum,
      gstr2bIgst: g2bIgstSum,
      diffIgst: round2(g2bIgstSum - bookIgstSum),

      bookCgst: bookCgstSum,
      gstr2bCgst: g2bCgstSum,
      diffCgst: round2(g2bCgstSum - bookCgstSum),

      bookSgst: bookSgstSum,
      gstr2bSgst: g2bSgstSum,
      diffSgst: round2(g2bSgstSum - bookSgstSum),

      bookCess: bookCessSum,
      gstr2bCess: g2bCessSum,
      diffCess: round2(g2bCessSum - bookCessSum),

      totalBookTax,
      total2BTax,
      netTaxVariance: round2(total2BTax - totalBookTax),

      itcBooks: round2(itcBooksEligibleSum + itcBooksIneligibleSum),
      itc2B: round2(itc2bEligibleSum + itc2bIneligibleSum),
      eligibleItc: itc2bEligibleSum,
      ineligibleItc: round2(itcBooksIneligibleSum + itc2bIneligibleSum),
      differenceItc: round2(itc2bEligibleSum - itcBooksEligibleSum)
    };

    const reviewRequiredCount = results.filter(r => !r.resolved && r.matchStatus !== 'EXACT_MATCH').length;

    return {
      results,
      stats: {
        totalPurchases: purchases.length,
        total2B: gstr2bRecords.length,
        exactMatches,
        partialMatches,
        valueMismatches,
        taxMismatches,
        dateMismatches,
        fuzzyMatches,
        missingIn2B,
        missingInBooks,
        duplicateCount,
        creditNoteMismatches,
        reviewRequiredCount,
        totalMatchRatePercent: matchRate
      },
      financialSummary
    };
  }

  /**
   * Reconciles GSTR-1 vs GSTR-3B (Rule 88C DRC-01B Scrutiny)
   */
  public reconcileGSTR1Vs3B(
    gstr1Summary: {
      turnover: number;
      igst: number;
      cgst: number;
      sgst: number;
      cess: number;
      totalTax: number;
    },
    gstr3bSummary: {
      turnover: number;
      igst: number;
      cgst: number;
      sgst: number;
      cess: number;
      totalTax: number;
    }
  ) {
    const diffTurnover = round2(gstr1Summary.turnover - gstr3bSummary.turnover);
    const diffIgst = round2(gstr1Summary.igst - gstr3bSummary.igst);
    const diffCgst = round2(gstr1Summary.cgst - gstr3bSummary.cgst);
    const diffSgst = round2(gstr1Summary.sgst - gstr3bSummary.sgst);
    const diffCess = round2(gstr1Summary.cess - gstr3bSummary.cess);
    const diffTotalTax = round2(gstr1Summary.totalTax - gstr3bSummary.totalTax);

    // Rule 88C triggers when GSTR-1 liability exceeds GSTR-3B by > ₹25 Lakhs or > 20%
    const percentageVariance = gstr3bSummary.totalTax > 0
      ? round2((diffTotalTax / gstr3bSummary.totalTax) * 100)
      : 0;

    const drc01BTriggered = diffTotalTax > 2500000 || percentageVariance > 20;

    return {
      matched: Math.abs(diffTotalTax) <= 1.0,
      diffTurnover,
      diffIgst,
      diffCgst,
      diffSgst,
      diffCess,
      diffTotalTax,
      percentageVariance,
      drc01BTriggered,
      legalNote: drc01BTriggered
        ? 'CRITICAL ALERT (Rule 88C): Outward tax liability reported in GSTR-1 exceeds GSTR-3B beyond threshold. System will issue automated Form GST DRC-01B notice.'
        : 'Rule 88C Compliance: GSTR-1 and GSTR-3B tax figures are within acceptable statutory limits.'
    };
  }
}

export const reconciliationEngine = new ReconciliationEngine();
