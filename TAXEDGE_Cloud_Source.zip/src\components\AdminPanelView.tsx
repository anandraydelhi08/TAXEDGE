import React, { useState, useMemo, useEffect } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  Edit2,
  Save,
  X,
  Plus,
  Trash2,
  Copy,
  Download,
  Upload,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Search,
  Filter,
  ArrowRight,
  Building2,
  Users,
  FileSpreadsheet,
  Layers,
  Sliders,
  Settings,
  Database,
  Sparkles,
  Check,
  KeyRound,
  FileText,
  ChevronDown,
  ChevronUp,
  RefreshCw,
  Hash,
  Eye,
  Percent,
  AlertCircle,
  FolderInput,
  ExternalLink
} from 'lucide-react';
import { ClientMaster, GSTINMasterEntry, BusinessType, ReturnFrequency, ClientStatus } from '../types/client';
import { TransactionInvoice, DocumentType, GSTClassification, ITCStatus, BlockedCreditReason } from '../types/gst';
import { INDIAN_STATES, validateGstinFormat } from '../data/masterData';
import { GSTN_HSN_MASTER } from '../utils/hsnMaster';
import { calculateDeterministicTax, formatINR, round2 } from '../utils/taxMath';
import { adminSettingsService, PracticeSettings, HsnOverride } from '../services/adminSettingsService';
import { clientStorageService } from '../services/clientStorageService';
import { gstr1Engine } from '../services/gstr1Engine';
import {
  gstExcelTemplateService,
  downloadWebGstTemplate,
  downloadBlankWebGstTemplate,
  Gstr2CrDrNoteItem,
  Gstr1AdvanceTaxItem,
  Gstr2AdvanceTaxItem,
  DEMO_GSTR2_CR_DR_NOTES,
  DEMO_GSTR1_ADVANCE_TAX,
  DEMO_GSTR2_ADVANCE_TAX
} from '../services/gstExcelTemplateService';
import portCodesMaster from '../data/gstnOfficialPortCodes.json';
import {
  OFFICIAL_UQCS,
  OFFICIAL_DR_CR_REASONS,
  OFFICIAL_PORT_CODES,
  OFFICIAL_POS_LIST,
  OFFICIAL_SUPPLY_TYPES,
  OFFICIAL_ITC_OPTIONS,
  OFFICIAL_BLOCKED_REASONS,
  OFFICIAL_TEMPLATE_STATES
} from '../data/gstnOfficialConstants';
import {
  validateInvoiceForGstn,
  autoFixInvoiceForGstn,
  validateBatchGstn,
  GSTIN_REGEX,
  INVOICE_NUM_REGEX
} from '../utils/gstnPreflightValidator';

interface AdminPanelViewProps {
  clients: ClientMaster[];
  gstins: GSTINMasterEntry[];
  selectedClientId: string;
  selectedGstin: string;
  sales: TransactionInvoice[];
  purchases: TransactionInvoice[];
  onSelectClientAndGstin: (clientId: string, gstin: string) => void;
  onAddClient: (client: ClientMaster) => void;
  onUpdateClient: (client: ClientMaster) => void;
  onDeleteClient: (clientId: string) => void;
  onUpdateSales: (sales: TransactionInvoice[]) => void;
  onUpdatePurchases: (purchases: TransactionInvoice[]) => void;
  onLoadDemo: () => void;
  onResetAll: () => void;
  isDemoMode: boolean;
  onFirmSettingsChange?: (settings: PracticeSettings) => void;
}

type AdminTab = 'clients' | 'transactions' | 'firm' | 'hsn' | 'rules' | 'backup';

export const AdminPanelView: React.FC<AdminPanelViewProps> = ({
  clients,
  gstins,
  selectedClientId,
  selectedGstin,
  sales,
  purchases,
  onSelectClientAndGstin,
  onAddClient,
  onUpdateClient,
  onDeleteClient,
  onUpdateSales,
  onUpdatePurchases,
  onLoadDemo,
  onResetAll,
  isDemoMode,
  onFirmSettingsChange
}) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('transactions');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // -------------------------------------------------------------
  // 1. PRACTICE & FIRM SETTINGS STATE
  // -------------------------------------------------------------
  const [settings, setSettings] = useState<PracticeSettings>(() => adminSettingsService.getSettings());

  const handleSettingChange = (field: keyof PracticeSettings, value: any) => {
    setSettings(prev => ({ ...prev, [field]: value }));
  };

  const handleSaveSettings = () => {
    adminSettingsService.saveSettings(settings);
    if (onFirmSettingsChange) {
      onFirmSettingsChange(settings);
    }
    showToast('Practice & Firm profile saved in 1 click!');
  };

  const applyPreset = (presetType: 'CA_FIRM' | 'TAX_CONSULTANT' | 'ENTERPRISE') => {
    let preset: Partial<PracticeSettings> = {};
    if (presetType === 'CA_FIRM') {
      preset = {
        firmName: 'Sharma & Associates, Chartered Accountants',
        frn: '109824W',
        partnerName: 'CA Rahul Sharma, FCA',
        membershipNo: '049821',
        email: 'partners@sharma-ca.in',
        phone: '+91 98100 12345',
        defaultState: 'Delhi',
        reconciliationTolerance: 2.0
      };
    } else if (presetType === 'TAX_CONSULTANT') {
      preset = {
        firmName: 'National Tax & GST Advisory Services',
        frn: 'N/A (Tax Practitioner)',
        partnerName: 'Adv. Vikramaditya Sen',
        membershipNo: 'STP-DL-8821',
        email: 'advocate@nationaltax.in',
        phone: '+91 98200 67890',
        defaultState: 'Maharashtra',
        reconciliationTolerance: 5.0
      };
    } else {
      preset = {
        firmName: 'Global Corporate Tax Solutions LLP',
        frn: 'LLPIN-AAA-9821',
        partnerName: 'CA Ananya Roy, Partner Tax & Regulatory',
        membershipNo: '054321',
        email: 'regulatory@globaltax.com',
        phone: '+91 80 4123 4567',
        defaultState: 'Karnataka',
        reconciliationTolerance: 1.0
      };
    }

    const updated = { ...settings, ...preset };
    setSettings(updated);
    adminSettingsService.saveSettings(updated);
    if (onFirmSettingsChange) onFirmSettingsChange(updated);
    showToast(`Applied ${presetType} preset profile!`);
  };

  // -------------------------------------------------------------
  // 2. CLIENT MASTER 1-CLICK INLINE EDITING STATE
  // -------------------------------------------------------------
  const [clientSearch, setClientSearch] = useState('');
  const [clientStatusFilter, setClientStatusFilter] = useState('ALL');
  const [editingClientId, setEditingClientId] = useState<string | null>(null);
  const [editingClientForm, setEditingClientForm] = useState<Partial<ClientMaster>>({});

  const filteredClients = useMemo(() => {
    return clients.filter(c => {
      const matchSearch =
        c.name.toLowerCase().includes(clientSearch.toLowerCase()) ||
        c.primaryGstin.toLowerCase().includes(clientSearch.toLowerCase()) ||
        c.pan.toLowerCase().includes(clientSearch.toLowerCase()) ||
        c.state.toLowerCase().includes(clientSearch.toLowerCase());
      const matchStatus = clientStatusFilter === 'ALL' || c.status === clientStatusFilter;
      return matchSearch && matchStatus;
    });
  }, [clients, clientSearch, clientStatusFilter]);

  const handleStartEditClient = (c: ClientMaster) => {
    setEditingClientId(c.id);
    setEditingClientForm({ ...c });
  };

  const handleCancelEditClient = () => {
    setEditingClientId(null);
    setEditingClientForm({});
  };

  const handleSaveClientInline = (clientId: string) => {
    const orig = clients.find(c => c.id === clientId);
    if (!orig) return;

    const updated: ClientMaster = {
      ...orig,
      ...editingClientForm,
      id: clientId,
      primaryGstin: (editingClientForm.primaryGstin || orig.primaryGstin).toUpperCase().trim(),
      pan: (editingClientForm.pan || orig.pan).toUpperCase().trim()
    };

    onUpdateClient(updated);
    setEditingClientId(null);
    setEditingClientForm({});
    showToast(`Updated client "${updated.name}" successfully!`);
  };

  const handleQuickAddClient = () => {
    const newId = `CLI-AUTO-${Date.now().toString().slice(-4)}`;
    const newClient: ClientMaster = {
      id: newId,
      name: `New Client Entity (${newId})`,
      tradeName: `Trading Enterprise`,
      legalName: `New Client Enterprise LLP`,
      pan: 'ABCDE1234F',
      primaryGstin: '27ABCDE1234F1Z5',
      additionalGstins: [],
      businessType: 'Company',
      state: 'Maharashtra',
      registeredAddress: 'Corporate Office, Financial District',
      contactPerson: 'Authorized Signatory',
      mobile: '+91 98000 00000',
      email: 'accounts@newclient.in',
      assignedStaff: settings.partnerName || 'Senior Tax Associate',
      returnFrequency: 'Monthly',
      financialYear: settings.financialYear || '2026-27',
      status: 'Active',
      createdDate: new Date().toISOString().split('T')[0]
    };

    onAddClient(newClient);
    setEditingClientId(newId);
    setEditingClientForm({ ...newClient });
    showToast(`Added client "${newClient.name}". Edit details below!`);
  };

  const handleCloneClient = (c: ClientMaster) => {
    const cloneId = `CLI-CPY-${Date.now().toString().slice(-4)}`;
    const cloned: ClientMaster = {
      ...c,
      id: cloneId,
      name: `${c.name} (Copy)`,
      tradeName: `${c.tradeName} (Copy)`,
      primaryGstin: `${c.primaryGstin.slice(0, 14)}Z`,
      createdDate: new Date().toISOString().split('T')[0]
    };
    onAddClient(cloned);
    showToast(`Cloned client to ${cloned.name}!`);
  };

  // -------------------------------------------------------------
  // 3. GST PORTAL COMPLIANT IN-APP TEMPLATE WORKBENCH STATE
  // Aligned with WEB_GST_Template.xls: SALE, PURCHASE, GSTR-1 DEBIT CREDIT NOTE
  // -------------------------------------------------------------
  // 3. GST PORTAL COMPLIANT IN-APP TEMPLATE WORKBENCH STATE
  // Aligned with all 10 Sheets of WEB_GST_Template.xls:
  // SALE, PURCHASE, GSTR-1 CR/DR, GSTR-2 CR/DR, GSTR-1 ADVANCE, GSTR-2 ADVANCE, MASTERS
  // -------------------------------------------------------------
  type TxnSheet =
    | 'SALE'
    | 'PURCHASE'
    | 'GSTR1_CR_DR'
    | 'GSTR2_CR_DR'
    | 'GSTR1_ADVANCE'
    | 'GSTR2_ADVANCE'
    | 'MASTERS_REF';

  const [txnSheetTab, setTxnSheetTab] = useState<TxnSheet>('SALE');
  const [txnSearch, setTxnSearch] = useState('');
  const [editingTxnId, setEditingTxnId] = useState<string | null>(null);
  const [editingTxnForm, setEditingTxnForm] = useState<Partial<TransactionInvoice>>({});
  const [expandedTxnId, setExpandedTxnId] = useState<string | null>(null);
  const [masterRefSearch, setMasterRefSearch] = useState('');
  const [masterRefSubTab, setMasterRefSubTab] = useState<'UQCS' | 'PORTS' | 'REASONS' | 'STATES'>('UQCS');
  const excelFileInputRef = React.useRef<HTMLInputElement | null>(null);

  // States for GSTR-2 CR/DR, GSTR-1 Advance Tax, GSTR-2 Advance Tax
  const [gstr2CrDrNotes, setGstr2CrDrNotes] = useState<Gstr2CrDrNoteItem[]>([]);
  const [editingG2CdnId, setEditingG2CdnId] = useState<string | null>(null);
  const [editingG2CdnForm, setEditingG2CdnForm] = useState<Partial<Gstr2CrDrNoteItem>>({});

  const [gstr1AdvanceTax, setGstr1AdvanceTax] = useState<Gstr1AdvanceTaxItem[]>([]);
  const [editingG1AdvId, setEditingG1AdvId] = useState<string | null>(null);
  const [editingG1AdvForm, setEditingG1AdvForm] = useState<Partial<Gstr1AdvanceTaxItem>>({});

  const [gstr2AdvanceTax, setGstr2AdvanceTax] = useState<Gstr2AdvanceTaxItem[]>([]);
  const [editingG2AdvId, setEditingG2AdvId] = useState<string | null>(null);
  const [editingG2AdvForm, setEditingG2AdvForm] = useState<Partial<Gstr2AdvanceTaxItem>>({});

  // Synchronize isolated sheets (4, 5, 6) with Client Storage
  useEffect(() => {
    if (selectedClientId && selectedGstin) {
      const p = settings.defaultReturnPeriod || '04-2026';
      const cData = clientStorageService.getClientData(selectedClientId, selectedGstin, p);
      if (cData.gstr2CrDrNotes && cData.gstr2CrDrNotes.length > 0) {
        setGstr2CrDrNotes(cData.gstr2CrDrNotes);
      } else {
        setGstr2CrDrNotes(isDemoMode ? DEMO_GSTR2_CR_DR_NOTES : []);
      }
      if (cData.gstr1AdvanceTax && cData.gstr1AdvanceTax.length > 0) {
        setGstr1AdvanceTax(cData.gstr1AdvanceTax);
      } else {
        setGstr1AdvanceTax(isDemoMode ? DEMO_GSTR1_ADVANCE_TAX : []);
      }
      if (cData.gstr2AdvanceTax && cData.gstr2AdvanceTax.length > 0) {
        setGstr2AdvanceTax(cData.gstr2AdvanceTax);
      } else {
        setGstr2AdvanceTax(isDemoMode ? DEMO_GSTR2_ADVANCE_TAX : []);
      }
    }
  }, [selectedClientId, selectedGstin, isDemoMode, settings.defaultReturnPeriod]);

  const persistExtraSheets = (
    updatedG2Cdn?: Gstr2CrDrNoteItem[],
    updatedG1Adv?: Gstr1AdvanceTaxItem[],
    updatedG2Adv?: Gstr2AdvanceTaxItem[]
  ) => {
    if (!selectedClientId || !selectedGstin) return;
    const p = settings.defaultReturnPeriod || '04-2026';
    const cData = clientStorageService.getClientData(selectedClientId, selectedGstin, p);
    clientStorageService.saveClientData(selectedClientId, selectedGstin, p, {
      ...cData,
      gstr2CrDrNotes: updatedG2Cdn ?? gstr2CrDrNotes,
      gstr1AdvanceTax: updatedG1Adv ?? gstr1AdvanceTax,
      gstr2AdvanceTax: updatedG2Adv ?? gstr2AdvanceTax
    });
  };

  const activeTxnList = useMemo(() => {
    if (txnSheetTab === 'SALE') {
      return sales.filter(s => s.documentType !== 'CREDIT_NOTE' && s.documentType !== 'DEBIT_NOTE');
    }
    if (txnSheetTab === 'PURCHASE') {
      return purchases;
    }
    if (txnSheetTab === 'GSTR1_CR_DR') {
      return sales.filter(s => s.documentType === 'CREDIT_NOTE' || s.documentType === 'DEBIT_NOTE');
    }
    return [];
  }, [txnSheetTab, sales, purchases]);

  const isOutwardSheet = txnSheetTab === 'SALE' || txnSheetTab === 'GSTR1_CR_DR' || txnSheetTab === 'GSTR1_ADVANCE';

  // Live Sheet Statistics for the Dynamic Color Hero Banner
  const sheetStats = useMemo(() => {
    if (txnSheetTab === 'SALE') {
      const list = sales.filter(s => s.documentType !== 'CREDIT_NOTE' && s.documentType !== 'DEBIT_NOTE');
      const taxable = list.reduce((sum, s) => sum + (s.taxableValue || 0), 0);
      const tax = list.reduce((sum, s) => sum + ((s.igst || 0) + (s.cgst || 0) + (s.sgst || 0) + (s.cess || 0)), 0);
      return { count: list.length, taxable, tax, label: 'Table 4A, 4B, 6B, 6C, B2C, Export (35 Columns)', theme: 'emerald' };
    }
    if (txnSheetTab === 'PURCHASE') {
      const taxable = purchases.reduce((sum, s) => sum + (s.taxableValue || 0), 0);
      const tax = purchases.reduce((sum, s) => sum + ((s.igst || 0) + (s.cgst || 0) + (s.sgst || 0) + (s.cess || 0)), 0);
      return { count: purchases.length, taxable, tax, label: 'Inward Supplies / GSTR-2B ITC Register (33 Columns)', theme: 'blue' };
    }
    if (txnSheetTab === 'GSTR1_CR_DR') {
      const list = sales.filter(s => s.documentType === 'CREDIT_NOTE' || s.documentType === 'DEBIT_NOTE');
      const taxable = list.reduce((sum, s) => sum + (s.taxableValue || 0), 0);
      const tax = list.reduce((sum, s) => sum + ((s.igst || 0) + (s.cgst || 0) + (s.sgst || 0) + (s.cess || 0)), 0);
      return { count: list.length, taxable, tax, label: 'Table 9B Outward Debit & Credit Notes (37 Columns)', theme: 'purple' };
    }
    if (txnSheetTab === 'GSTR2_CR_DR') {
      const taxable = gstr2CrDrNotes.reduce((sum, s) => sum + (s.differentialValue || 0), 0);
      const tax = gstr2CrDrNotes.reduce((sum, s) => sum + ((s.igstAmount || 0) + (s.cgstAmount || 0) + (s.sgstAmount || 0) + (s.cessAmount || 0)), 0);
      return { count: gstr2CrDrNotes.length, taxable, tax, label: 'Inward Credit & Debit Notes from Vendors (31 Columns)', theme: 'rose' };
    }
    if (txnSheetTab === 'GSTR1_ADVANCE') {
      const taxable = gstr1AdvanceTax.reduce((sum, s) => sum + (s.advanceReceived || 0), 0);
      const tax = gstr1AdvanceTax.reduce((sum, s) => sum + ((s.igstAmount || 0) + (s.cgstAmount || 0) + (s.sgstAmount || 0) + (s.cessAmount || 0)), 0);
      return { count: gstr1AdvanceTax.length, taxable, tax, label: 'Table 11A / 11B Tax on Advances Received (20 Columns)', theme: 'amber' };
    }
    if (txnSheetTab === 'GSTR2_ADVANCE') {
      const taxable = gstr2AdvanceTax.reduce((sum, s) => sum + (s.advancePaid || 0), 0);
      const tax = gstr2AdvanceTax.reduce((sum, s) => sum + ((s.igstAmount || 0) + (s.cgstAmount || 0) + (s.sgstAmount || 0) + (s.cessAmount || 0)), 0);
      return { count: gstr2AdvanceTax.length, taxable, tax, label: 'Inward Advances Paid Subject to RCM (18 Columns)', theme: 'teal' };
    }
    return { count: 0, taxable: 0, tax: 0, label: 'Official GSTN Codes & Masters (4 Sheets)', theme: 'slate' };
  }, [txnSheetTab, sales, purchases, gstr2CrDrNotes, gstr1AdvanceTax, gstr2AdvanceTax]);

  // Real-time GSTN Pre-Flight Validation across all rows of active register
  const validationSummary = useMemo(() => {
    return validateBatchGstn(activeTxnList, selectedGstin, isOutwardSheet);
  }, [activeTxnList, selectedGstin, isOutwardSheet]);

  const filteredTxns = useMemo(() => {
    return activeTxnList.filter(inv => {
      const q = txnSearch.toLowerCase();
      return (
        inv.invoiceNumber?.toLowerCase().includes(q) ||
        inv.supplierGstin?.toLowerCase().includes(q) ||
        inv.recipientGstin?.toLowerCase().includes(q) ||
        inv.supplierName?.toLowerCase().includes(q) ||
        inv.recipientName?.toLowerCase().includes(q) ||
        inv.hsnSacPrimary?.toLowerCase().includes(q) ||
        inv.descriptionPrimary?.toLowerCase().includes(q)
      );
    });
  }, [activeTxnList, txnSearch]);

  const handleStartEditTxn = (inv: TransactionInvoice) => {
    setEditingTxnId(inv.id);
    setEditingTxnForm({ ...inv });
  };

  const handleCancelEditTxn = () => {
    setEditingTxnId(null);
    setEditingTxnForm({});
  };

  // Recalculates tax deterministically when amount, rate, or POS changes
  const handleTxnTaxRecalc = (taxableVal: number, rate: number, pos: string) => {
    const supplierState = (selectedGstin || '07').substring(0, 2);
    const isInterState = pos !== supplierState;
    const taxRes = calculateDeterministicTax(taxableVal, rate, isInterState);
    setEditingTxnForm(prev => ({
      ...prev,
      taxableValue: taxRes.taxableValue,
      gstRate: rate,
      placeOfSupply: pos,
      placeOfSupplyCode: pos,
      supplyType: isInterState ? 'INTER_STATE' : 'INTRA_STATE',
      cgst: taxRes.cgst,
      sgst: taxRes.sgst,
      igst: taxRes.igst,
      totalAmount: round2(taxRes.totalAmount + Number(prev.cess || 0))
    }));
  };

  const handleSaveTxnInline = (invId: string) => {
    if (txnSheetTab === 'PURCHASE') {
      const list = [...purchases];
      const idx = list.findIndex(i => i.id === invId);
      if (idx < 0) return;
      const baseInv: TransactionInvoice = {
        ...list[idx],
        ...editingTxnForm,
        id: invId
      };
      const compliantInv = autoFixInvoiceForGstn(baseInv, selectedGstin, false);
      list[idx] = compliantInv;
      onUpdatePurchases(list);
      setEditingTxnId(null);
      setEditingTxnForm({});
      showToast(`Saved purchase invoice #${compliantInv.invoiceNumber} (100% GSTN Schema Valid)!`);
    } else {
      // SALE or GSTR1_CR_DR
      const list = [...sales];
      const idx = list.findIndex(i => i.id === invId);
      if (idx < 0) return;
      const baseInv: TransactionInvoice = {
        ...list[idx],
        ...editingTxnForm,
        id: invId
      };
      const compliantInv = autoFixInvoiceForGstn(baseInv, selectedGstin, true);
      list[idx] = compliantInv;
      onUpdateSales(list);
      setEditingTxnId(null);
      setEditingTxnForm({});
      showToast(`Saved invoice #${compliantInv.invoiceNumber} (100% GSTN Schema Valid)!`);
    }
  };

  // Handlers for Sheets 4, 5, 6 with Instant Persistence
  const handleSaveG2Cdn = (id: string) => {
    const updated = gstr2CrDrNotes.map(item => (item.id === id ? { ...item, ...editingG2CdnForm } : item));
    setGstr2CrDrNotes(updated);
    persistExtraSheets(updated, undefined, undefined);
    setEditingG2CdnId(null);
    setEditingG2CdnForm({});
    showToast('Saved GSTR-2 Debit/Credit Note!');
  };

  const handleSaveG1Adv = (id: string) => {
    const updated = gstr1AdvanceTax.map(item => (item.id === id ? { ...item, ...editingG1AdvForm } : item));
    setGstr1AdvanceTax(updated);
    persistExtraSheets(undefined, updated, undefined);
    setEditingG1AdvId(null);
    setEditingG1AdvForm({});
    showToast('Saved GSTR-1 Advance Tax record!');
  };

  const handleSaveG2Adv = (id: string) => {
    const updated = gstr2AdvanceTax.map(item => (item.id === id ? { ...item, ...editingG2AdvForm } : item));
    setGstr2AdvanceTax(updated);
    persistExtraSheets(undefined, undefined, updated);
    setEditingG2AdvId(null);
    setEditingG2AdvForm({});
    showToast('Saved GSTR-2 Advance Tax record!');
  };

  // 1-Click Add Single Row
  const handleQuickAddTxn = () => {
    const currentClientObj = clients.find(c => c.id === selectedClientId);
    const clientState = (selectedGstin || '27').substring(0, 2);
    const otherState = clientState === '27' ? '07' : '27';

    if (txnSheetTab === 'SALE') {
      const newId = `SL-${Date.now().toString().slice(-6)}`;
      const invNum = `INV/2026-27/${Math.floor(1000 + Math.random() * 9000)}`;
      const newInv = autoFixInvoiceForGstn({
        id: newId,
        invoiceNumber: invNum,
        invoiceDate: new Date().toISOString().split('T')[0],
        documentType: 'INVOICE',
        supplierGstin: selectedGstin,
        supplierName: currentClientObj?.name || 'Active Enterprise',
        supplierState: 'State',
        supplierStateCode: clientState,
        recipientGstin: `${otherState}AAACB9988P1Z1`,
        recipientName: 'Prime Customer Pvt Ltd',
        recipientState: 'State',
        recipientStateCode: otherState,
        placeOfSupply: otherState,
        placeOfSupplyCode: otherState,
        supplyType: 'INTER_STATE',
        classification: 'B2B',
        taxTreatment: 'TAXABLE',
        hsnSacPrimary: '847130',
        descriptionPrimary: 'Data Processing Hardware Machines',
        uqc: 'NOS',
        totalQuantity: 1,
        taxableValue: 50000.0,
        gstRate: 18,
        cgst: 0,
        sgst: 0,
        igst: 9000.0,
        cess: 0,
        totalAmount: 59000.0,
        rcm: false,
        ecommerce: false,
        itcEligible: true,
        itcStatus: 'ELIGIBLE',
        itcEligibleAmount: 9000.0,
        itcIneligibleAmount: 0,
        confidence: 1.0,
        reviewRequired: false
      }, selectedGstin, true);
      onUpdateSales([newInv, ...sales]);
      setEditingTxnId(newId);
      setEditingTxnForm({ ...newInv });
      showToast(`Added row #${invNum} in SALE. Edit fields inline!`);
    } else if (txnSheetTab === 'PURCHASE') {
      const newId = `PR-${Date.now().toString().slice(-6)}`;
      const invNum = `BILL/2026-27/${Math.floor(1000 + Math.random() * 9000)}`;
      const newInv = autoFixInvoiceForGstn({
        id: newId,
        invoiceNumber: invNum,
        invoiceDate: new Date().toISOString().split('T')[0],
        documentType: 'INVOICE',
        supplierGstin: `${otherState}AAACB2234M1Z2`,
        supplierName: 'Standard Supplier Ltd',
        supplierState: 'State',
        supplierStateCode: otherState,
        recipientGstin: selectedGstin,
        recipientName: currentClientObj?.name || 'Active Enterprise',
        recipientState: 'State',
        recipientStateCode: clientState,
        placeOfSupply: clientState,
        placeOfSupplyCode: clientState,
        supplyType: 'INTER_STATE',
        classification: 'B2B',
        taxTreatment: 'TAXABLE',
        hsnSacPrimary: '9982',
        descriptionPrimary: 'Legal & Professional Advisory Services',
        uqc: 'NA',
        totalQuantity: 0,
        taxableValue: 25000.0,
        gstRate: 18,
        cgst: 0,
        sgst: 0,
        igst: 4500.0,
        cess: 0,
        totalAmount: 29500.0,
        rcm: false,
        ecommerce: false,
        itcEligible: true,
        itcStatus: 'ELIGIBLE',
        itcEligibleAmount: 4500.0,
        itcIneligibleAmount: 0,
        confidence: 1.0,
        reviewRequired: false
      }, selectedGstin, false);
      onUpdatePurchases([newInv, ...purchases]);
      setEditingTxnId(newId);
      setEditingTxnForm({ ...newInv });
      showToast(`Added purchase bill #${invNum} in PURCHASE. Edit fields inline!`);
    } else if (txnSheetTab === 'GSTR1_CR_DR') {
      const newId = `CDN-${Date.now().toString().slice(-6)}`;
      const noteNum = `CN/2026-27/${Math.floor(100 + Math.random() * 900)}`;
      const newNote = autoFixInvoiceForGstn({
        id: newId,
        invoiceNumber: noteNum,
        invoiceDate: new Date().toISOString().split('T')[0],
        documentType: 'CREDIT_NOTE',
        supplierGstin: selectedGstin,
        supplierName: currentClientObj?.name || 'Active Enterprise',
        supplierState: 'State',
        supplierStateCode: clientState,
        recipientGstin: `${otherState}AAACB9988P1Z1`,
        recipientName: 'Prime Customer Pvt Ltd',
        recipientState: 'State',
        recipientStateCode: otherState,
        placeOfSupply: otherState,
        placeOfSupplyCode: otherState,
        supplyType: 'INTER_STATE',
        classification: 'B2B',
        taxTreatment: 'TAXABLE',
        hsnSacPrimary: '847130',
        descriptionPrimary: '01-Sales Return',
        notes: '01-Sales Return',
        crDrReason: '01-Sales Return',
        crDrType: 'C',
        originalInvoiceNumber: 'INV/2026-27/1001',
        originalInvoiceDate: new Date().toISOString().split('T')[0],
        uqc: 'NOS',
        totalQuantity: 1,
        taxableValue: 5000.0,
        gstRate: 18,
        cgst: 0,
        sgst: 0,
        igst: 900.0,
        cess: 0,
        totalAmount: 5900.0,
        rcm: false,
        ecommerce: false,
        itcEligible: true,
        itcStatus: 'ELIGIBLE',
        itcEligibleAmount: 900.0,
        itcIneligibleAmount: 0,
        confidence: 1.0,
        reviewRequired: false
      }, selectedGstin, true);
      onUpdateSales([newNote, ...sales]);
      setEditingTxnId(newId);
      setEditingTxnForm({ ...newNote });
      showToast(`Added Credit Note #${noteNum} in GSTR-1 DEBIT CREDIT NOTE.`);
    } else if (txnSheetTab === 'GSTR2_CR_DR') {
      const newId = `G2CDN-${Date.now().toString().slice(-6)}`;
      const noteNum = `DBN/2026-27/${Math.floor(100 + Math.random() * 900)}`;
      const newNote: Gstr2CrDrNoteItem = {
        id: newId,
        supplierGstin: `${otherState}AAACB2234M1Z2`,
        supplierName: 'Vendor Inward Supplier Ltd',
        supplierState: 'State',
        pos: clientState,
        noteNumber: noteNum,
        noteDate: new Date().toISOString().split('T')[0],
        originalInvoiceNumber: `BILL-${Math.floor(1000 + Math.random() * 9000)}`,
        originalInvoiceDate: new Date().toISOString().split('T')[0],
        differentialValue: 10000,
        igstRate: 18,
        igstAmount: 1800,
        cgstRate: 0,
        cgstAmount: 0,
        sgstRate: 0,
        sgstAmount: 0,
        cessRate: 0,
        cessAmount: 0,
        otherCharges: 0,
        itcEligibility: 'ELIGIBLE',
        itcIgst: 1800,
        itcCgst: 0,
        itcSgst: 0,
        itcCess: 0,
        noteType: 'DEBIT',
        rcm: false,
        reason: '01-Sales Return',
        preGst: false,
        voucherNo: '',
        voucherDate: '',
        supplyType: 'INTER',
        ineligibleSection17_5: ''
      };
      setGstr2CrDrNotes([newNote, ...gstr2CrDrNotes]);
      setEditingG2CdnId(newId);
      setEditingG2CdnForm({ ...newNote });
      showToast('Added row in GSTR-2 DEBIT CREDIT NOTE.');
    } else if (txnSheetTab === 'GSTR1_ADVANCE') {
      const newId = `G1ADV-${Date.now().toString().slice(-6)}`;
      const newAdv: Gstr1AdvanceTaxItem = {
        id: newId,
        partyGstin: `${otherState}AAACB9988P1Z1`,
        uin: '',
        partyName: 'Advance Client Corp',
        state: 'State',
        pos: otherState,
        receiptVoucherNo: `ADV-REC-${Math.floor(100 + Math.random() * 900)}`,
        receiptVoucherDate: new Date().toISOString().split('T')[0],
        goodsOrServices: 'SERVICES',
        hsnSac: '998313',
        advanceReceived: 25000,
        igstRate: 18,
        igstAmount: 4500,
        cgstRate: 0,
        cgstAmount: 0,
        sgstRate: 0,
        sgstAmount: 0,
        cessRate: 0,
        cessAmount: 0,
        isPartyRegistered: 'Y',
        leaseOfOldCar: 'N'
      };
      setGstr1AdvanceTax([newAdv, ...gstr1AdvanceTax]);
      setEditingG1AdvId(newId);
      setEditingG1AdvForm({ ...newAdv });
      showToast('Added row in GSTR-1 ADVANCE TAX.');
    } else if (txnSheetTab === 'GSTR2_ADVANCE') {
      const newId = `G2ADV-${Date.now().toString().slice(-6)}`;
      const newAdv: Gstr2AdvanceTaxItem = {
        id: newId,
        partyGstin: `${otherState}AAACB2234M1Z2`,
        partyName: 'Advance Vendor Ltd',
        state: 'State',
        pos: clientState,
        paymentVoucherNo: `ADV-PAY-${Math.floor(100 + Math.random() * 900)}`,
        paymentVoucherDate: new Date().toISOString().split('T')[0],
        goodsOrServices: 'SERVICES',
        hsnSac: '996511',
        advancePaid: 20000,
        igstRate: 18,
        igstAmount: 3600,
        cgstRate: 0,
        cgstAmount: 0,
        sgstRate: 0,
        sgstAmount: 0,
        cessRate: 0,
        cessAmount: 0,
        isPartyRegistered: 'Y'
      };
      setGstr2AdvanceTax([newAdv, ...gstr2AdvanceTax]);
      setEditingG2AdvId(newId);
      setEditingG2AdvForm({ ...newAdv });
      showToast('Added row in GSTR-2 ADVANCE TAX.');
    }
  };

  // 1-Click Add Multiple Rows
  const handleAddMultipleRows = (count: number = 5) => {
    const currentClientObj = clients.find(c => c.id === selectedClientId);
    const clientState = (selectedGstin || '27').substring(0, 2);
    const otherState = clientState === '27' ? '07' : '27';
    const newItems: TransactionInvoice[] = [];

    for (let i = 1; i <= count; i++) {
      if (txnSheetTab === 'PURCHASE') {
        const id = `PR-${Date.now()}-${i}`;
        const invNum = `BILL/26-27/${Math.floor(100 + Math.random() * 900)}`;
        newItems.push(autoFixInvoiceForGstn({
          id,
          invoiceNumber: invNum,
          invoiceDate: new Date().toISOString().split('T')[0],
          documentType: 'INVOICE',
          supplierGstin: `${otherState}AAACB2234M1Z2`,
          supplierName: 'Vendor Supply Corp',
          supplierState: 'State',
          supplierStateCode: otherState,
          recipientGstin: selectedGstin,
          recipientName: currentClientObj?.name || 'Active Enterprise',
          recipientState: 'State',
          recipientStateCode: clientState,
          placeOfSupply: clientState,
          placeOfSupplyCode: clientState,
          supplyType: 'INTER_STATE',
          classification: 'B2B',
          taxTreatment: 'TAXABLE',
          hsnSacPrimary: '9982',
          descriptionPrimary: 'Procurement Services',
          uqc: 'NA',
          totalQuantity: 0,
          taxableValue: 12000.0,
          gstRate: 18,
          cgst: 0,
          sgst: 0,
          igst: 2160.0,
          cess: 0,
          totalAmount: 14160.0,
          rcm: false,
          ecommerce: false,
          itcEligible: true,
          itcStatus: 'ELIGIBLE',
          itcEligibleAmount: 2160.0,
          itcIneligibleAmount: 0,
          confidence: 1.0,
          reviewRequired: false
        }, selectedGstin, false));
      } else if (txnSheetTab === 'GSTR1_CR_DR') {
        const id = `CDN-${Date.now()}-${i}`;
        const noteNum = `CN/26-27/${Math.floor(100 + Math.random() * 900)}`;
        newItems.push(autoFixInvoiceForGstn({
          id,
          invoiceNumber: noteNum,
          invoiceDate: new Date().toISOString().split('T')[0],
          documentType: 'CREDIT_NOTE',
          supplierGstin: selectedGstin,
          supplierName: currentClientObj?.name || 'Active Enterprise',
          supplierState: 'State',
          supplierStateCode: clientState,
          recipientGstin: `${otherState}AAACB9988P1Z1`,
          recipientName: 'Counterparty Buyer',
          recipientState: 'State',
          recipientStateCode: otherState,
          placeOfSupply: otherState,
          placeOfSupplyCode: otherState,
          supplyType: 'INTER_STATE',
          classification: 'B2B',
          taxTreatment: 'TAXABLE',
          hsnSacPrimary: '8471',
          descriptionPrimary: '02-Post Sale Discount',
          notes: '02-Post Sale Discount',
          crDrReason: '02-Post Sale Discount',
          crDrType: 'C',
          originalInvoiceNumber: `INV/26-27/${100 + i}`,
          originalInvoiceDate: new Date().toISOString().split('T')[0],
          uqc: 'NOS',
          totalQuantity: 1,
          taxableValue: 3000.0,
          gstRate: 18,
          cgst: 0,
          sgst: 0,
          igst: 540.0,
          cess: 0,
          totalAmount: 3540.0,
          rcm: false,
          ecommerce: false,
          itcEligible: true,
          itcStatus: 'ELIGIBLE',
          itcEligibleAmount: 540.0,
          itcIneligibleAmount: 0,
          confidence: 1.0,
          reviewRequired: false
        }, selectedGstin, true));
      } else {
        // SALE
        const id = `SL-${Date.now()}-${i}`;
        const invNum = `INV/26-27/${Math.floor(100 + Math.random() * 900)}`;
        newItems.push(autoFixInvoiceForGstn({
          id,
          invoiceNumber: invNum,
          invoiceDate: new Date().toISOString().split('T')[0],
          documentType: 'INVOICE',
          supplierGstin: selectedGstin,
          supplierName: currentClientObj?.name || 'Active Enterprise',
          supplierState: 'State',
          supplierStateCode: clientState,
          recipientGstin: `${otherState}AAACB9988P1Z1`,
          recipientName: 'Client Recipient',
          recipientState: 'Delhi',
          recipientStateCode: otherState,
          placeOfSupply: otherState,
          placeOfSupplyCode: otherState,
          supplyType: 'INTER_STATE',
          classification: 'B2B',
          taxTreatment: 'TAXABLE',
          hsnSacPrimary: '847130',
          descriptionPrimary: 'Data Processing Hardware Units',
          uqc: 'NOS',
          totalQuantity: 1,
          taxableValue: 15000.0,
          gstRate: 18,
          cgst: 0,
          sgst: 0,
          igst: 2700.0,
          cess: 0,
          totalAmount: 17700.0,
          rcm: false,
          ecommerce: false,
          itcEligible: true,
          itcStatus: 'ELIGIBLE',
          itcEligibleAmount: 2700.0,
          itcIneligibleAmount: 0,
          confidence: 1.0,
          reviewRequired: false
        }, selectedGstin, true));
      }
    }

    if (txnSheetTab === 'PURCHASE') {
      onUpdatePurchases([...newItems, ...purchases]);
    } else {
      onUpdateSales([...newItems, ...sales]);
    }
    showToast(`Added ${count} official template rows! Edit inline in 1 click.`);
  };

  // 1-Click Auto-Fix All for GSTN Upload (Guarantees zero upload errors on services.gst.gov.in)
  const handleAutoFixAllGstn = () => {
    if (txnSheetTab === 'PURCHASE') {
      const fixed = purchases.map(inv => autoFixInvoiceForGstn(inv, selectedGstin, false));
      onUpdatePurchases(fixed);
      showToast(`⚡ 1-Click Auto-Fix applied! All ${fixed.length} purchase records are 100% GSTN Schema Compliant.`);
    } else {
      const fixed = sales.map(inv => autoFixInvoiceForGstn(inv, selectedGstin, true));
      onUpdateSales(fixed);
      showToast(`⚡ 1-Click Auto-Fix applied! All ${fixed.length} sales/note records are 100% GSTN Schema Compliant.`);
    }
  };

  // 1-Click Download Official GSTN JSON (v3.2.4)
  const handleDownloadGstnJson = () => {
    try {
      // First ensure all sales and notes are 100% schema compliant
      const sanitizedSales = sales.map(inv => autoFixInvoiceForGstn(inv, selectedGstin, true));
      onUpdateSales(sanitizedSales);

      const currentClientObj = clients.find(c => c.id === selectedClientId);
      const summary = gstr1Engine.prepareGSTR1(
        sanitizedSales,
        settings.defaultReturnPeriod || '04-2026',
        selectedGstin,
        currentClientObj?.legalName
      );
      const jsonPayload = gstr1Engine.generateGSTNJsonPayload(summary);

      const blob = new Blob([jsonPayload], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `GSTR1_${selectedGstin}_${(settings.defaultReturnPeriod || '04-2026').replace('-', '')}.json`;
      a.click();
      URL.revokeObjectURL(url);
      showToast('100% GST Portal Schema-compliant JSON downloaded successfully! Zero portal errors guaranteed.');
    } catch (err: any) {
      alert(`Error generating GSTN JSON: ${err.message}`);
    }
  };

  // Import WEB_GST_Template directly from Excel (.xls or .xlsx)
  const handleImportExcelFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const buffer = await file.arrayBuffer();
      const res = gstExcelTemplateService.parseWebGstTemplate(buffer, selectedGstin);
      if (res.sales.length > 0 || res.creditDebitNotes.length > 0) {
        onUpdateSales([...res.sales, ...res.creditDebitNotes, ...sales]);
      }
      if (res.purchases.length > 0) {
        onUpdatePurchases([...res.purchases, ...purchases]);
      }
      const updatedG2Cdn = res.gstr2CrDrNotes && res.gstr2CrDrNotes.length > 0 ? [...res.gstr2CrDrNotes, ...gstr2CrDrNotes] : undefined;
      const updatedG1Adv = res.gstr1AdvanceTax && res.gstr1AdvanceTax.length > 0 ? [...res.gstr1AdvanceTax, ...gstr1AdvanceTax] : undefined;
      const updatedG2Adv = res.gstr2AdvanceTax && res.gstr2AdvanceTax.length > 0 ? [...res.gstr2AdvanceTax, ...gstr2AdvanceTax] : undefined;

      if (updatedG2Cdn) setGstr2CrDrNotes(updatedG2Cdn);
      if (updatedG1Adv) setGstr1AdvanceTax(updatedG1Adv);
      if (updatedG2Adv) setGstr2AdvanceTax(updatedG2Adv);
      persistExtraSheets(updatedG2Cdn, updatedG1Adv, updatedG2Adv);
      showToast(
        `Imported ${res.totalParsed} records across official sheets from ${file.name}! 100% GST Portal Compliant.`
      );
    } catch (err: any) {
      alert(`Failed to import Excel template: ${err.message}`);
    } finally {
      if (excelFileInputRef.current) excelFileInputRef.current.value = '';
    }
  };

  // Export to official WEB_GST_Template.xlsx (with all 10 sheets & #CCFFCC pastel green headers)
  const handleExportExcelFile = () => {
    try {
      const crdr = sales.filter(s => s.documentType === 'CREDIT_NOTE' || s.documentType === 'DEBIT_NOTE');
      const pureSales = sales.filter(s => s.documentType !== 'CREDIT_NOTE' && s.documentType !== 'DEBIT_NOTE');
      downloadWebGstTemplate(
        pureSales,
        purchases,
        crdr,
        selectedGstin,
        {
          gstr2CrDrNotes,
          gstr1AdvanceTax,
          gstr2AdvanceTax
        },
        `WEB_GST_Template_${selectedGstin}.xlsx`
      );
      showToast('Downloaded official WEB_GST_Template.xlsx with all 10 sheets, pastel green headers, and masters!');
    } catch (err: any) {
      alert(`Error exporting Excel: ${err.message}`);
    }
  };

  const handleDeleteTxn = (invId: string) => {
    if (txnSheetTab === 'PURCHASE') {
      onUpdatePurchases(purchases.filter(i => i.id !== invId));
    } else if (txnSheetTab === 'SALE' || txnSheetTab === 'GSTR1_CR_DR') {
      onUpdateSales(sales.filter(i => i.id !== invId));
    } else if (txnSheetTab === 'GSTR2_CR_DR') {
      const updated = gstr2CrDrNotes.filter(i => i.id !== invId);
      setGstr2CrDrNotes(updated);
      persistExtraSheets(updated, undefined, undefined);
    } else if (txnSheetTab === 'GSTR1_ADVANCE') {
      const updated = gstr1AdvanceTax.filter(i => i.id !== invId);
      setGstr1AdvanceTax(updated);
      persistExtraSheets(undefined, updated, undefined);
    } else if (txnSheetTab === 'GSTR2_ADVANCE') {
      const updated = gstr2AdvanceTax.filter(i => i.id !== invId);
      setGstr2AdvanceTax(updated);
      persistExtraSheets(undefined, undefined, updated);
    }
    showToast('Deleted record.');
  };

  const handleBatchSetRate = (targetRate: number) => {
    const isPurchase = txnSheetTab === 'PURCHASE';
    const list = isPurchase ? [...purchases] : [...sales];
    const currentClientStateCode = selectedGstin ? selectedGstin.substring(0, 2) : '27';

    const updated = list.map(inv => {
      const counterpartyGstin = !isPurchase ? inv.recipientGstin : inv.supplierGstin;
      const counterpartyStateCode = counterpartyGstin ? counterpartyGstin.substring(0, 2) : currentClientStateCode;
      const isInter = counterpartyStateCode !== currentClientStateCode;
      const tax = calculateDeterministicTax(inv.taxableValue, targetRate, isInter);

      return {
        ...inv,
        gstRate: targetRate,
        cgst: tax.cgst,
        sgst: tax.sgst,
        igst: tax.igst,
        totalAmount: tax.totalAmount
      };
    });

    if (isPurchase) {
      onUpdatePurchases(updated);
    } else {
      onUpdateSales(updated);
    }
    showToast(`Batch updated ${updated.length} invoices to ${targetRate}% GST in 1 click!`);
  };

  // -------------------------------------------------------------
  // 4. MASTER HSN & RATES STATE
  // -------------------------------------------------------------
  const [hsnSearch, setHsnSearch] = useState('');
  const [hsnOverrides, setHsnOverrides] = useState<Record<string, HsnOverride>>(() =>
    adminSettingsService.getHsnOverrides()
  );
  const [editingHsnCode, setEditingHsnCode] = useState<string | null>(null);
  const [editingHsnForm, setEditingHsnForm] = useState<{ description: string; gstRate: number }>({
    description: '',
    gstRate: 18
  });
  const [newHsnCode, setNewHsnCode] = useState('');
  const [newHsnDesc, setNewHsnDesc] = useState('');
  const [newHsnRate, setNewHsnRate] = useState(18);

  const displayHsnList = useMemo(() => {
    const query = hsnSearch.toLowerCase().trim();
    const list: Array<{ code: string; description: string; gstRate: number; isCustom?: boolean }> = [];

    Object.values(hsnOverrides).forEach(ov => {
      list.push({
        code: ov.code,
        description: ov.description,
        gstRate: ov.gstRate,
        isCustom: ov.isCustom || true
      });
    });

    const officialCodes = Object.entries(GSTN_HSN_MASTER);
    for (const [code, desc] of officialCodes) {
      if (!hsnOverrides[code]) {
        list.push({
          code,
          description: desc,
          gstRate: code.startsWith('99') ? 18 : 18,
          isCustom: false
        });
      }
      if (list.length >= 60 && !query) break;
    }

    if (!query) return list;
    return list.filter(item => item.code.includes(query) || item.description.toLowerCase().includes(query));
  }, [hsnSearch, hsnOverrides]);

  const handleStartEditHsn = (item: { code: string; description: string; gstRate: number }) => {
    setEditingHsnCode(item.code);
    setEditingHsnForm({ description: item.description, gstRate: item.gstRate });
  };

  const handleSaveHsnInline = (code: string) => {
    adminSettingsService.saveHsnOverride(code, editingHsnForm.description, editingHsnForm.gstRate, false);
    setHsnOverrides(adminSettingsService.getHsnOverrides());
    setEditingHsnCode(null);
    showToast(`Updated HSN code ${code} to ${editingHsnForm.gstRate}% rate!`);
  };

  const handleAddNewHsn = () => {
    if (!newHsnCode.trim()) {
      alert('Please enter a valid HSN/SAC code.');
      return;
    }
    adminSettingsService.saveHsnOverride(newHsnCode.trim(), newHsnDesc.trim() || 'Custom Business Code', newHsnRate, true);
    setHsnOverrides(adminSettingsService.getHsnOverrides());
    setNewHsnCode('');
    setNewHsnDesc('');
    showToast(`Added custom HSN/SAC code ${newHsnCode}!`);
  };

  // -------------------------------------------------------------
  // 5. ONE-CLICK BACKUP & RESTORE
  // -------------------------------------------------------------
  const [jsonImportText, setJsonImportText] = useState('');

  const handleDownloadSnapshot = () => {
    const snapshot = adminSettingsService.exportFullSystemSnapshot();
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(snapshot, null, 2));
    const dlAnchorElem = document.createElement('a');
    dlAnchorElem.setAttribute('href', dataStr);
    dlAnchorElem.setAttribute('download', `GST_Practice_AI_Backup_${new Date().toISOString().slice(0, 10)}.json`);
    dlAnchorElem.click();
    showToast('Downloaded full system snapshot JSON!');
  };

  const handleImportJson = () => {
    try {
      const parsed = JSON.parse(jsonImportText);
      const res = adminSettingsService.importFullSystemSnapshot(parsed);
      if (res.success) {
        showToast(res.message);
        setTimeout(() => window.location.reload(), 1200);
      } else {
        alert(res.message);
      }
    } catch (e: any) {
      alert(`Invalid JSON format: ${e.message}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-2xl flex items-center gap-3 border border-emerald-500/50 animate-bounce">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="text-xs font-semibold">{toastMessage}</span>
        </div>
      )}

      {/* Top Header Card */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-50 rounded-full blur-3xl -z-10 opacity-70"></div>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-lg shadow-emerald-600/20">
              <Sliders className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <h1 className="text-2xl font-black tracking-tight text-slate-900">Admin Control Panel</h1>
                <span className="bg-emerald-100 text-emerald-800 text-[11px] font-bold px-2.5 py-0.5 rounded-full border border-emerald-300">
                  Official GST In-App Template
                </span>
                {isDemoMode && (
                  <span className="bg-amber-100 text-amber-800 text-[11px] font-bold px-2.5 py-0.5 rounded-full border border-amber-300">
                    Demo Mode Active
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-600 mt-1">
                Alag se CSV upload kiye bina seedha yahi se invoices add & edit karein — 100% Guaranteed Zero Error on GST Portal JSON Upload.
              </p>
            </div>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={handleDownloadSnapshot}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition shadow-sm cursor-pointer"
              title="Download entire system database as JSON"
            >
              <Download className="w-4 h-4 text-slate-600" />
              <span>1-Click Backup JSON</span>
            </button>
            <button
              onClick={onLoadDemo}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition shadow-md shadow-emerald-600/20 cursor-pointer"
              title="Seed complete CA Practice demo portfolio"
            >
              <Sparkles className="w-4 h-4 text-emerald-200" />
              <span>1-Click Seed Demo</span>
            </button>
            <button
              onClick={onResetAll}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold transition cursor-pointer"
              title="Factory reset all database entries"
            >
              <Trash2 className="w-4 h-4 text-rose-600" />
              <span>Reset All</span>
            </button>
          </div>
        </div>

        {/* Quick KPI Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-slate-100">
          <div className="bg-slate-50/80 rounded-xl p-3 border border-slate-200/60">
            <div className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Registered Clients</div>
            <div className="text-xl font-extrabold text-slate-900 mt-0.5">{clients.length}</div>
            <div className="text-[10px] text-emerald-600 font-semibold mt-0.5">Multi-entity portfolio</div>
          </div>
          <div className="bg-slate-50/80 rounded-xl p-3 border border-slate-200/60">
            <div className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Active Workspace</div>
            <div className="text-sm font-bold text-slate-900 mt-0.5 truncate">
              {clients.find(c => c.id === selectedClientId)?.name || 'No Client'}
            </div>
            <div className="text-[10px] font-mono text-emerald-700 font-bold truncate mt-0.5">{selectedGstin || 'No GSTIN'}</div>
          </div>
          <div className="bg-slate-50/80 rounded-xl p-3 border border-slate-200/60">
            <div className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Sales Invoices</div>
            <div className="text-xl font-extrabold text-slate-900 mt-0.5">{sales.length}</div>
            <div className="text-[10px] text-slate-500 font-medium mt-0.5">
              ₹{formatINR(sales.reduce((s, i) => s + (i.taxableValue || 0), 0))}
            </div>
          </div>
          <div className="bg-slate-50/80 rounded-xl p-3 border border-slate-200/60">
            <div className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Purchase Invoices</div>
            <div className="text-xl font-extrabold text-slate-900 mt-0.5">{purchases.length}</div>
            <div className="text-[10px] text-slate-500 font-medium mt-0.5">
              ₹{formatINR(purchases.reduce((s, i) => s + (i.taxableValue || 0), 0))}
            </div>
          </div>
        </div>
      </div>

      {/* Admin Tab Navigation Bar */}
      <div className="flex items-center gap-1.5 p-1.5 bg-slate-100 rounded-2xl border border-slate-200 overflow-x-auto">
        <button
          onClick={() => setActiveTab('transactions')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition shrink-0 cursor-pointer ${
            activeTab === 'transactions'
              ? 'bg-white text-emerald-800 shadow-sm border border-slate-200/60'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
          }`}
        >
          <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
          <span>GST In-App Template Workbench</span>
          <span className="ml-1 px-1.5 py-0.5 text-[10px] rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
            {sales.length + purchases.length} Invoices
          </span>
        </button>

        <button
          onClick={() => setActiveTab('clients')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition shrink-0 cursor-pointer ${
            activeTab === 'clients'
              ? 'bg-white text-emerald-800 shadow-sm border border-slate-200/60'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
          }`}
        >
          <Users className="w-4 h-4 text-blue-600" />
          <span>Client Master</span>
          <span className="ml-1 px-1.5 py-0.5 text-[10px] rounded-full bg-blue-50 text-blue-700 border border-blue-200">
            {clients.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('firm')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition shrink-0 cursor-pointer ${
            activeTab === 'firm'
              ? 'bg-white text-emerald-800 shadow-sm border border-slate-200/60'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
          }`}
        >
          <Building2 className="w-4 h-4 text-amber-600" />
          <span>CA Firm Identity & Profile</span>
        </button>

        <button
          onClick={() => setActiveTab('hsn')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition shrink-0 cursor-pointer ${
            activeTab === 'hsn'
              ? 'bg-white text-emerald-800 shadow-sm border border-slate-200/60'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
          }`}
        >
          <Hash className="w-4 h-4 text-purple-600" />
          <span>Master HSN Rates</span>
        </button>

        <button
          onClick={() => setActiveTab('rules')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition shrink-0 cursor-pointer ${
            activeTab === 'rules'
              ? 'bg-white text-emerald-800 shadow-sm border border-slate-200/60'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
          }`}
        >
          <ShieldCheck className="w-4 h-4 text-teal-600" />
          <span>Statutory Rules & Toggles</span>
        </button>

        <button
          onClick={() => setActiveTab('backup')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition shrink-0 cursor-pointer ${
            activeTab === 'backup'
              ? 'bg-white text-emerald-800 shadow-sm border border-slate-200/60'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
          }`}
        >
          <Database className="w-4 h-4 text-slate-600" />
          <span>JSON Backup / Restore</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* TAB: GST PORTAL COMPLIANT IN-APP TEMPLATE WORKBENCH                      */}
      {/* ========================================================================= */}
      {activeTab === 'transactions' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-5 shadow-sm">
          {/* Hidden Excel Template File Input */}
          <input
            type="file"
            ref={excelFileInputRef}
            accept=".xls,.xlsx"
            onChange={handleImportExcelFile}
            className="hidden"
          />

          {/* Top Title & Register Selector */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-3 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h2 className="text-lg font-black text-slate-900">
                  GST In-App Data Entry & Official Template Workbench
                </h2>
                <span className="font-mono text-xs font-bold bg-emerald-50 text-emerald-800 px-2.5 py-1 rounded-lg border border-emerald-200">
                  Client: {clients.find(c => c.id === selectedClientId)?.name || selectedClientId} ({selectedGstin})
                </span>
                <span className="bg-indigo-50 text-indigo-700 text-[11px] font-bold px-2 py-0.5 rounded-full border border-indigo-200">
                  Official GSTN Template (v3.2.4 Aligned)
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-1">
                Yahan seedha data add aur edit karein — alag se CSV upload ki zaroorat nahi padegi. Saara tax math aur GSTN schema validation real-time chalega jisse portal upload par <strong>0% error</strong> aayega.
              </p>
            </div>

            {/* Excel Template Import / Export, Blank Template & Row Add Buttons */}
            <div className="flex items-center gap-2 flex-wrap">
              <button
                onClick={() => downloadBlankWebGstTemplate()}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold transition shadow-sm cursor-pointer border border-emerald-300"
                title="Download original official blank WEB_GST_Template.xls with all 10 sheets"
              >
                <Download className="w-4 h-4 text-emerald-600" />
                <span>Blank Official Template (.xls)</span>
              </button>

              <button
                onClick={() => excelFileInputRef.current?.click()}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition shadow-sm cursor-pointer border border-slate-300"
                title="Directly import WEB_GST_Template.xls or .xlsx (No CSV conversion needed)"
              >
                <FolderInput className="w-4 h-4 text-emerald-600" />
                <span>Import Excel (.xls/.xlsx)</span>
              </button>

              <button
                onClick={handleExportExcelFile}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-800 text-xs font-bold transition shadow-sm cursor-pointer border border-blue-300"
                title="Download all 10 sheets as official WEB_GST_Template.xlsx with pastel green headers"
              >
                <FileSpreadsheet className="w-4 h-4 text-blue-600" />
                <span>Export 10-Sheet Workbook (.xlsx)</span>
              </button>

              {txnSheetTab !== 'MASTERS_REF' && (
                <>
                  <button
                    onClick={handleQuickAddTxn}
                    className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition shadow-sm cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>+1 Row</span>
                  </button>
                  <button
                    onClick={() => handleAddMultipleRows(5)}
                    className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold transition shadow-sm cursor-pointer"
                    title="Add 5 template rows ready for entry"
                  >
                    <span>+5 Rows</span>
                  </button>
                </>
              )}
            </div>
          </div>

          {/* OFFICIAL TEMPLATE SHEET SELECTOR WITH VIBRANT COLOR GLOW */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-200">
            {/* Tab 1: SALE */}
            <button
              onClick={() => {
                setTxnSheetTab('SALE');
                setEditingTxnId(null);
                setExpandedTxnId(null);
              }}
              className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-extrabold transition cursor-pointer shrink-0 ${
                txnSheetTab === 'SALE'
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-600/30 ring-2 ring-emerald-400'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-300 animate-pulse"></span>
              <span>1. SALE (35 Cols • GSTR-1)</span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${txnSheetTab === 'SALE' ? 'bg-emerald-950 text-white' : 'bg-slate-200 text-slate-700'}`}>
                {sales.filter(s => s.documentType !== 'CREDIT_NOTE' && s.documentType !== 'DEBIT_NOTE').length}
              </span>
            </button>

            {/* Tab 2: PURCHASE */}
            <button
              onClick={() => {
                setTxnSheetTab('PURCHASE');
                setEditingTxnId(null);
                setExpandedTxnId(null);
              }}
              className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-extrabold transition cursor-pointer shrink-0 ${
                txnSheetTab === 'PURCHASE'
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg shadow-blue-600/30 ring-2 ring-blue-400'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <span className="w-2.5 h-2.5 rounded-full bg-blue-300 animate-pulse"></span>
              <span>2. PURCHASE (33 Cols • 2B/3B)</span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${txnSheetTab === 'PURCHASE' ? 'bg-blue-950 text-white' : 'bg-slate-200 text-slate-700'}`}>
                {purchases.length}
              </span>
            </button>

            {/* Tab 3: GSTR-1 DEBIT CREDIT NOTE */}
            <button
              onClick={() => {
                setTxnSheetTab('GSTR1_CR_DR');
                setEditingTxnId(null);
                setExpandedTxnId(null);
              }}
              className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-extrabold transition cursor-pointer shrink-0 ${
                txnSheetTab === 'GSTR1_CR_DR'
                  ? 'bg-gradient-to-r from-purple-600 to-fuchsia-600 text-white shadow-lg shadow-purple-600/30 ring-2 ring-purple-400'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <span className="w-2.5 h-2.5 rounded-full bg-purple-300 animate-pulse"></span>
              <span>3. GSTR-1 CR/DR (37 Cols • Table 9B)</span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${txnSheetTab === 'GSTR1_CR_DR' ? 'bg-purple-950 text-white' : 'bg-slate-200 text-slate-700'}`}>
                {sales.filter(s => s.documentType === 'CREDIT_NOTE' || s.documentType === 'DEBIT_NOTE').length}
              </span>
            </button>

            {/* Tab 4: GSTR-2 DEBIT CREDIT NOTE */}
            <button
              onClick={() => {
                setTxnSheetTab('GSTR2_CR_DR');
                setEditingTxnId(null);
                setExpandedTxnId(null);
              }}
              className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-extrabold transition cursor-pointer shrink-0 ${
                txnSheetTab === 'GSTR2_CR_DR'
                  ? 'bg-gradient-to-r from-rose-600 to-pink-600 text-white shadow-lg shadow-rose-600/30 ring-2 ring-rose-400'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <span className="w-2.5 h-2.5 rounded-full bg-rose-300 animate-pulse"></span>
              <span>4. GSTR-2 CR/DR (31 Cols • Inward)</span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${txnSheetTab === 'GSTR2_CR_DR' ? 'bg-rose-950 text-white' : 'bg-slate-200 text-slate-700'}`}>
                {gstr2CrDrNotes.length}
              </span>
            </button>

            {/* Tab 5: GSTR-1 ADVANCE TAX */}
            <button
              onClick={() => {
                setTxnSheetTab('GSTR1_ADVANCE');
                setEditingTxnId(null);
                setExpandedTxnId(null);
              }}
              className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-extrabold transition cursor-pointer shrink-0 ${
                txnSheetTab === 'GSTR1_ADVANCE'
                  ? 'bg-gradient-to-r from-amber-600 to-orange-600 text-white shadow-lg shadow-amber-600/30 ring-2 ring-amber-400'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <span className="w-2.5 h-2.5 rounded-full bg-amber-300 animate-pulse"></span>
              <span>5. GSTR-1 ADVANCE (20 Cols • Table 11)</span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${txnSheetTab === 'GSTR1_ADVANCE' ? 'bg-amber-950 text-white' : 'bg-slate-200 text-slate-700'}`}>
                {gstr1AdvanceTax.length}
              </span>
            </button>

            {/* Tab 6: GSTR-2 ADVANCE TAX */}
            <button
              onClick={() => {
                setTxnSheetTab('GSTR2_ADVANCE');
                setEditingTxnId(null);
                setExpandedTxnId(null);
              }}
              className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-extrabold transition cursor-pointer shrink-0 ${
                txnSheetTab === 'GSTR2_ADVANCE'
                  ? 'bg-gradient-to-r from-teal-600 to-cyan-600 text-white shadow-lg shadow-teal-600/30 ring-2 ring-teal-400'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <span className="w-2.5 h-2.5 rounded-full bg-teal-300 animate-pulse"></span>
              <span>6. GSTR-2 ADVANCE (18 Cols • RCM)</span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${txnSheetTab === 'GSTR2_ADVANCE' ? 'bg-teal-950 text-white' : 'bg-slate-200 text-slate-700'}`}>
                {gstr2AdvanceTax.length}
              </span>
            </button>

            {/* Tab 7: MASTERS REFERENCE */}
            <button
              onClick={() => {
                setTxnSheetTab('MASTERS_REF');
                setEditingTxnId(null);
                setExpandedTxnId(null);
              }}
              className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-extrabold transition cursor-pointer shrink-0 ${
                txnSheetTab === 'MASTERS_REF'
                  ? 'bg-slate-900 text-emerald-300 shadow-lg shadow-slate-900/40 ring-2 ring-emerald-500/50 border border-emerald-500/30'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Settings className="w-3.5 h-3.5 text-emerald-400" />
              <span>7. MASTERS REF (40 States • 769 Ports • 46 UQCs • 7 Reasons)</span>
            </button>
          </div>

          {/* DYNAMIC COLOR HERO CARD FOR ACTIVE SHEET */}
          <div
            className={`p-4 rounded-2xl border transition shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 ${
              txnSheetTab === 'SALE'
                ? 'bg-gradient-to-r from-emerald-50 via-teal-50/50 to-white border-emerald-300'
                : txnSheetTab === 'PURCHASE'
                ? 'bg-gradient-to-r from-blue-50 via-indigo-50/50 to-white border-blue-300'
                : txnSheetTab === 'GSTR1_CR_DR'
                ? 'bg-gradient-to-r from-purple-50 via-fuchsia-50/50 to-white border-purple-300'
                : txnSheetTab === 'GSTR2_CR_DR'
                ? 'bg-gradient-to-r from-rose-50 via-pink-50/50 to-white border-rose-300'
                : txnSheetTab === 'GSTR1_ADVANCE'
                ? 'bg-gradient-to-r from-amber-50 via-orange-50/50 to-white border-amber-300'
                : txnSheetTab === 'GSTR2_ADVANCE'
                ? 'bg-gradient-to-r from-teal-50 via-cyan-50/50 to-white border-teal-300'
                : 'bg-slate-900 border-slate-700 text-white'
            }`}
          >
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span
                  className={`text-xs font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full ${
                    txnSheetTab === 'SALE'
                      ? 'bg-emerald-600 text-white'
                      : txnSheetTab === 'PURCHASE'
                      ? 'bg-blue-600 text-white'
                      : txnSheetTab === 'GSTR1_CR_DR'
                      ? 'bg-purple-600 text-white'
                      : txnSheetTab === 'GSTR2_CR_DR'
                      ? 'bg-rose-600 text-white'
                      : txnSheetTab === 'GSTR1_ADVANCE'
                      ? 'bg-amber-600 text-white'
                      : txnSheetTab === 'GSTR2_ADVANCE'
                      ? 'bg-teal-600 text-white'
                      : 'bg-emerald-500 text-slate-950'
                  }`}
                >
                  {txnSheetTab.replace('_', ' ')}
                </span>
                <span className="text-xs font-bold text-slate-700">
                  {sheetStats.label}
                </span>
              </div>

              {txnSheetTab !== 'MASTERS_REF' && (
                <div className="flex items-center gap-3 mt-2 flex-wrap">
                  <div className="flex items-center gap-1.5 text-xs bg-white/90 px-3 py-1 rounded-xl border border-slate-200/80 shadow-xs">
                    <span className="text-slate-500 font-semibold">Records:</span>
                    <span className="font-mono font-black text-slate-900">{sheetStats.count}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs bg-white/90 px-3 py-1 rounded-xl border border-slate-200/80 shadow-xs">
                    <span className="text-slate-500 font-semibold">Taxable Value:</span>
                    <span className="font-mono font-black text-emerald-700">₹{formatINR(sheetStats.taxable)}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs bg-white/90 px-3 py-1 rounded-xl border border-slate-200/80 shadow-xs">
                    <span className="text-slate-500 font-semibold">Total GST:</span>
                    <span className="font-mono font-black text-blue-700">₹{formatINR(sheetStats.tax)}</span>
                  </div>
                </div>
              )}
            </div>

            {/* Quick Actions in Hero Card */}
            <div className="flex items-center gap-2 flex-wrap">
              {txnSheetTab !== 'MASTERS_REF' && !validationSummary.isValid && (
                <button
                  onClick={handleAutoFixAllGstn}
                  className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs shadow-md transition flex items-center gap-1.5 cursor-pointer"
                  title="Automatically fix POS codes, taxes, UQC and sanitize invoice numbers"
                >
                  <Sparkles className="w-4 h-4 text-slate-950" />
                  <span>⚡ 1-Click Auto-Fix for GSTN</span>
                </button>
              )}
              {isOutwardSheet && (
                <button
                  onClick={handleDownloadGstnJson}
                  className="px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-xs shadow-md transition flex items-center gap-1.5 cursor-pointer"
                  title="Download v3.2.4 Schema GSTR-1 JSON"
                >
                  <Download className="w-4 h-4" />
                  <span>📥 Download GSTR-1 JSON</span>
                </button>
              )}
            </div>
          </div>

          {/* REAL-TIME PRE-FLIGHT GSTN VALIDATION STATUS BANNER (for transaction sheets) */}
          {txnSheetTab !== 'MASTERS_REF' && (
            <div
              className={`p-4 rounded-xl border flex flex-col md:flex-row md:items-center justify-between gap-4 transition ${
                validationSummary.isValid
                  ? 'bg-emerald-50/90 border-emerald-300 text-emerald-950'
                  : 'bg-rose-50/90 border-rose-300 text-rose-950'
              }`}
            >
              <div className="flex items-center gap-3.5">
                {validationSummary.isValid ? (
                  <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-md shadow-emerald-600/30">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                ) : (
                  <div className="w-10 h-10 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0 shadow-md shadow-rose-600/30 animate-pulse">
                    <AlertTriangle className="w-6 h-6" />
                  </div>
                )}
                <div>
                  <div className="font-black text-sm flex items-center gap-2">
                    {validationSummary.isValid ? (
                      <>
                        <span>100% GSTN Schema Valid (0 Errors)</span>
                        <span className="bg-emerald-200 text-emerald-900 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                          Portal Ready
                        </span>
                      </>
                    ) : (
                      <>
                        <span>{validationSummary.errors.length} Schema Issue(s) Detected</span>
                        <span className="bg-rose-200 text-rose-900 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                          Fix Required
                        </span>
                      </>
                    )}
                  </div>
                  <div className="text-xs mt-0.5 text-slate-700">
                    {validationSummary.isValid
                      ? `GSTIN, POS State Codes, HSN, Tax Math & UQC valid. GST portal upload par koi error nahi aayega.`
                      : validationSummary.errors
                          .slice(0, 2)
                          .map(e => `[${e.invoiceNumber}] ${e.issue}`)
                          .join(' • ')}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                {!validationSummary.isValid && (
                  <button
                    onClick={handleAutoFixAllGstn}
                    className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs shadow-md transition flex items-center gap-1.5 cursor-pointer"
                    title="Automatically fix POS codes, taxes, UQC and sanitize invoice numbers"
                  >
                    <Sparkles className="w-4 h-4 text-slate-950" />
                    <span>⚡ 1-Click Auto-Fix for GSTN</span>
                  </button>
                )}
                {isOutwardSheet && (
                  <button
                    onClick={handleDownloadGstnJson}
                    className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-xs shadow-md transition flex items-center gap-1.5 cursor-pointer"
                    title="Download v3.2.4 Schema GSTR-1 JSON"
                  >
                    <Download className="w-4 h-4" />
                    <span>📥 Download GSTR-1 JSON (v3.2.4)</span>
                  </button>
                )}
              </div>
            </div>
          )}

          {/* MASTERS REFERENCE LOOKUP VIEW */}
          {txnSheetTab === 'MASTERS_REF' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between gap-3 flex-wrap bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setMasterRefSubTab('UQCS')}
                    className={`px-3 py-1.5 rounded-lg font-bold text-xs cursor-pointer ${
                      masterRefSubTab === 'UQCS' ? 'bg-emerald-600 text-white' : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                    }`}
                  >
                    46 Official UQCs
                  </button>
                  <button
                    onClick={() => setMasterRefSubTab('PORTS')}
                    className={`px-3 py-1.5 rounded-lg font-bold text-xs cursor-pointer ${
                      masterRefSubTab === 'PORTS' ? 'bg-emerald-600 text-white' : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                    }`}
                  >
                    768 Port Codes
                  </button>
                  <button
                    onClick={() => setMasterRefSubTab('REASONS')}
                    className={`px-3 py-1.5 rounded-lg font-bold text-xs cursor-pointer ${
                      masterRefSubTab === 'REASONS' ? 'bg-emerald-600 text-white' : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                    }`}
                  >
                    7 DR/CR Reasons
                  </button>
                  <button
                    onClick={() => setMasterRefSubTab('STATES')}
                    className={`px-3 py-1.5 rounded-lg font-bold text-xs cursor-pointer ${
                      masterRefSubTab === 'STATES' ? 'bg-emerald-600 text-white' : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                    }`}
                  >
                    40 Official States & POS Codes
                  </button>
                </div>

                <div className="relative min-w-[240px]">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                  <input
                    type="text"
                    placeholder="Search master codes or names..."
                    value={masterRefSearch}
                    onChange={e => setMasterRefSearch(e.target.value)}
                    className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
              </div>

              {/* Subtab 1: UQCs */}
              {masterRefSubTab === 'UQCS' && (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2.5 max-h-[500px] overflow-y-auto p-1">
                  {OFFICIAL_UQCS.filter(u =>
                    u.code.toLowerCase().includes(masterRefSearch.toLowerCase()) ||
                    u.name.toLowerCase().includes(masterRefSearch.toLowerCase())
                  ).map(u => (
                    <div
                      key={u.code}
                      onClick={() => {
                        navigator.clipboard?.writeText(u.code);
                        showToast(`Copied UQC code "${u.code}" to clipboard!`);
                      }}
                      className="p-2.5 rounded-xl border border-slate-200 bg-white hover:border-emerald-400 hover:bg-emerald-50/40 transition cursor-pointer flex flex-col justify-between"
                      title="Click to copy UQC code"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono font-black text-sm text-emerald-900 bg-emerald-100/70 px-2 py-0.5 rounded">
                          {u.code}
                        </span>
                        <Copy className="w-3 h-3 text-slate-400" />
                      </div>
                      <span className="text-[11px] font-semibold text-slate-600 mt-2 line-clamp-1">{u.name}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Subtab 2: Ports */}
              {masterRefSubTab === 'PORTS' && (
                <div className="border border-slate-200 rounded-xl max-h-[500px] overflow-y-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead className="sticky top-0 bg-slate-100 z-10">
                      <tr className="border-b border-slate-200 text-slate-700 font-bold uppercase tracking-wider text-[11px]">
                        <th className="p-3 w-32">Port Code</th>
                        <th className="p-3">Port Location / Name</th>
                        <th className="p-3 w-24 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {(portCodesMaster as Array<{ code: string; name: string }>)
                        .filter(p =>
                          p.code.toLowerCase().includes(masterRefSearch.toLowerCase()) ||
                          p.name.toLowerCase().includes(masterRefSearch.toLowerCase())
                        )
                        .slice(0, 100)
                        .map(p => (
                          <tr key={p.code} className="hover:bg-emerald-50/40">
                            <td className="p-3 font-mono font-black text-emerald-900">{p.code}</td>
                            <td className="p-3 text-slate-800 font-medium">{p.name}</td>
                            <td className="p-3 text-right">
                              <button
                                onClick={() => {
                                  navigator.clipboard?.writeText(p.code);
                                  showToast(`Copied port code "${p.code}"!`);
                                }}
                                className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[11px] font-bold cursor-pointer"
                              >
                                Copy
                              </button>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Subtab 3: Reasons */}
              {masterRefSubTab === 'REASONS' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[500px] overflow-y-auto">
                  {OFFICIAL_DR_CR_REASONS.filter(r =>
                    r.toLowerCase().includes(masterRefSearch.toLowerCase())
                  ).map(r => (
                    <div
                      key={r}
                      onClick={() => {
                        navigator.clipboard?.writeText(r);
                        showToast(`Copied reason "${r}"!`);
                      }}
                      className="p-3.5 rounded-xl border border-slate-200 bg-white hover:border-purple-300 hover:bg-purple-50/30 transition cursor-pointer flex items-center justify-between"
                    >
                      <span className="font-semibold text-slate-900 text-xs">{r}</span>
                      <Copy className="w-3.5 h-3.5 text-slate-400" />
                    </div>
                  ))}
                </div>
              )}

              {/* Subtab 4: State POS */}
              {masterRefSubTab === 'STATES' && (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5 max-h-[500px] overflow-y-auto">
                  {OFFICIAL_TEMPLATE_STATES.filter(stateName =>
                    stateName.toLowerCase().includes(masterRefSearch.toLowerCase())
                  ).map(stateName => {
                    const matchedPos = OFFICIAL_POS_LIST.find(p => p.name.toUpperCase() === stateName.toUpperCase() || stateName.toUpperCase().includes(p.name.toUpperCase()));
                    const posCode = matchedPos ? matchedPos.code : stateName.includes('FOREIGN') ? 'FC' : stateName.includes('OUTSIDE') ? 'OS' : 'OT';
                    return (
                      <div
                        key={stateName}
                        onClick={() => {
                          navigator.clipboard?.writeText(posCode);
                          showToast(`Copied POS Code "${posCode}" for ${stateName}!`);
                        }}
                        className="p-2.5 rounded-xl border border-slate-200 bg-white hover:border-blue-400 hover:bg-blue-50/30 transition cursor-pointer flex items-center justify-between"
                      >
                        <div>
                          <span className="font-mono font-black text-sm text-blue-900 bg-blue-100/70 px-2 py-0.5 rounded">
                            {posCode}
                          </span>
                          <div className="text-[11px] font-bold text-slate-700 mt-1">{stateName}</div>
                        </div>
                        <Copy className="w-3 h-3 text-slate-400" />
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* MAIN TRANSACTION TEMPLATE GRID (for SALE, PURCHASE, GSTR-1 CR/DR) */}
          {(txnSheetTab === 'SALE' || txnSheetTab === 'PURCHASE' || txnSheetTab === 'GSTR1_CR_DR') && (
            <>
              {/* Quick Batch Actions & Filter Bar */}
              <div className="flex items-center justify-between gap-3 flex-wrap bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-bold text-slate-700 text-[11px] uppercase tracking-wider">Fast Slabs:</span>
                  <button
                    onClick={() => handleBatchSetRate(18)}
                    className="px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-[11px] font-bold cursor-pointer"
                  >
                    Set All 18%
                  </button>
                  <button
                    onClick={() => handleBatchSetRate(12)}
                    className="px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-[11px] font-bold cursor-pointer"
                  >
                    Set All 12%
                  </button>
                  <button
                    onClick={() => handleBatchSetRate(5)}
                    className="px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-[11px] font-bold cursor-pointer"
                  >
                    Set All 5%
                  </button>
                  <button
                    onClick={handleAutoFixAllGstn}
                    className="px-2.5 py-1 bg-white hover:bg-slate-100 text-emerald-700 border border-emerald-300 rounded-lg text-[11px] font-bold cursor-pointer"
                  >
                    Recalculate All Taxes
                  </button>
                </div>

                <div className="relative min-w-[220px]">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                  <input
                    type="text"
                    placeholder="Search by invoice #, GSTIN, name, HSN..."
                    value={txnSearch}
                    onChange={e => setTxnSearch(e.target.value)}
                    className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                </div>
              </div>

          {/* OFFICIAL IN-APP TEMPLATE GRID */}
          <div className="overflow-x-auto border border-slate-200 rounded-xl max-h-[640px]">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="sticky top-0 z-10 shadow-md">
                <tr className="border-b border-slate-700 text-white font-black uppercase tracking-wider text-[11px]">
                  <th className="p-3 w-24 bg-slate-900 border-r border-slate-800">Doc Type</th>
                  <th className="p-3 w-32 bg-slate-900 border-r border-slate-800">{txnSheetTab === 'GSTR1_CR_DR' ? 'Note #' : 'Invoice #'}</th>
                  <th className="p-3 w-28 bg-slate-900 border-r border-slate-800">Date</th>
                  <th className="p-3 w-40 bg-slate-800 border-r border-slate-700 text-emerald-200">{isOutwardSheet ? 'Buyer GSTIN' : 'Supplier GSTIN'}</th>
                  <th className="p-3 w-40 bg-slate-800 border-r border-slate-700 text-slate-100">Party Name</th>
                  <th className="p-3 w-36 bg-slate-800 border-r border-slate-700 text-blue-200">State / POS</th>
                  <th className="p-3 w-28 bg-emerald-950 border-r border-emerald-900 text-emerald-300">HSN / SAC</th>
                  <th className="p-3 w-24 bg-emerald-950 border-r border-emerald-900 text-emerald-300">UQC</th>
                  <th className="p-3 w-20 text-right bg-emerald-950 border-r border-emerald-900 text-emerald-300">Qty</th>
                  <th className="p-3 w-28 text-right bg-emerald-900 border-r border-emerald-800 text-emerald-100 font-black">Taxable (₹)</th>
                  <th className="p-3 w-20 text-center bg-indigo-950 border-r border-indigo-900 text-indigo-300">Rate</th>
                  <th className="p-3 w-24 text-right bg-blue-950 border-r border-blue-900 text-blue-200">IGST (₹)</th>
                  <th className="p-3 w-24 text-right bg-teal-950 border-r border-teal-900 text-teal-200">CGST (₹)</th>
                  <th className="p-3 w-24 text-right bg-teal-950 border-r border-teal-900 text-teal-200">SGST (₹)</th>
                  <th className="p-3 w-28 text-right bg-amber-950 border-r border-amber-900 text-amber-200 font-black">Total (₹)</th>
                  <th className="p-3 w-32 text-right bg-purple-950 text-purple-200">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredTxns.length === 0 ? (
                  <tr>
                    <td colSpan={16} className="p-10 text-center text-slate-400">
                      No records in this register. Click <strong>"+1 Row"</strong>, <strong>"+5 Rows"</strong>, or <strong>"Import Excel"</strong> above!
                    </td>
                  </tr>
                ) : (
                  filteredTxns.map((inv, idx) => {
                    const isEditing = editingTxnId === inv.id;
                    const isExpanded = expandedTxnId === inv.id;
                    const counterpartyGstin = isOutwardSheet ? inv.recipientGstin : inv.supplierGstin;
                    const counterpartyName = isOutwardSheet ? inv.recipientName : inv.supplierName;
                    const isGstinValid = counterpartyGstin ? GSTIN_REGEX.test(counterpartyGstin.trim()) : false;

                    return (
                      <React.Fragment key={inv.id}>
                        <tr
                          className={`transition ${isEditing ? 'bg-amber-50/60' : isExpanded ? 'bg-emerald-50/30' : idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/40'} hover:bg-emerald-50/30`}
                        >
                          {/* Doc Type */}
                          <td className="p-3">
                            {isEditing ? (
                              <select
                                value={editingTxnForm.documentType || inv.documentType || 'INVOICE'}
                                onChange={e =>
                                  setEditingTxnForm(prev => ({
                                    ...prev,
                                    documentType: e.target.value as DocumentType
                                  }))
                                }
                                className="px-1.5 py-1 border border-slate-300 rounded text-[11px] font-bold bg-white"
                              >
                                <option value="INVOICE">INV (Invoice)</option>
                                <option value="CREDIT_NOTE">CR (Credit Note)</option>
                                <option value="DEBIT_NOTE">DB (Debit Note)</option>
                              </select>
                            ) : (
                              <span
                                className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                  inv.documentType === 'CREDIT_NOTE'
                                    ? 'bg-rose-100 text-rose-800'
                                    : inv.documentType === 'DEBIT_NOTE'
                                    ? 'bg-amber-100 text-amber-800'
                                    : 'bg-emerald-100 text-emerald-800'
                                }`}
                              >
                                {inv.documentType === 'CREDIT_NOTE' ? 'CR Note' : inv.documentType === 'DEBIT_NOTE' ? 'DB Note' : 'Invoice'}
                              </span>
                            )}
                          </td>

                          {/* Invoice / Note # */}
                          <td className="p-3">
                            {isEditing ? (
                              <input
                                type="text"
                                maxLength={16}
                                value={editingTxnForm.invoiceNumber ?? inv.invoiceNumber}
                                onChange={e =>
                                  setEditingTxnForm(prev => ({
                                    ...prev,
                                    invoiceNumber: e.target.value.replace(/[^A-Za-z0-9/-]/g, '')
                                  }))
                                }
                                className="w-28 px-2 py-1 border border-slate-300 rounded font-mono font-bold text-xs"
                              />
                            ) : (
                              <span className="font-mono font-bold text-slate-900">{inv.invoiceNumber}</span>
                            )}
                          </td>

                          {/* Date */}
                          <td className="p-3">
                            {isEditing ? (
                              <input
                                type="date"
                                value={editingTxnForm.invoiceDate ?? inv.invoiceDate}
                                onChange={e =>
                                  setEditingTxnForm(prev => ({
                                    ...prev,
                                    invoiceDate: e.target.value
                                  }))
                                }
                                className="px-1.5 py-1 border border-slate-300 rounded text-xs font-mono"
                              />
                            ) : (
                              <span className="font-mono text-slate-600">{inv.invoiceDate}</span>
                            )}
                          </td>

                          {/* Counterparty GSTIN */}
                          <td className="p-3">
                            {isEditing ? (
                              <input
                                type="text"
                                maxLength={15}
                                value={
                                  isOutwardSheet
                                    ? (editingTxnForm.recipientGstin ?? inv.recipientGstin)
                                    : (editingTxnForm.supplierGstin ?? inv.supplierGstin)
                                }
                                onChange={e => {
                                  const val = e.target.value.toUpperCase().trim();
                                  if (isOutwardSheet) {
                                    setEditingTxnForm(prev => ({ ...prev, recipientGstin: val }));
                                  } else {
                                    setEditingTxnForm(prev => ({ ...prev, supplierGstin: val }));
                                  }
                                  // Auto-detect POS state from 1st two digits of GSTIN
                                  if (val.length >= 2) {
                                    const detectedPos = val.substring(0, 2);
                                    if (OFFICIAL_POS_LIST.some(p => p.code === detectedPos)) {
                                      handleTxnTaxRecalc(
                                        Number(editingTxnForm.taxableValue ?? inv.taxableValue),
                                        Number(editingTxnForm.gstRate ?? inv.gstRate),
                                        detectedPos
                                      );
                                    }
                                  }
                                }}
                                placeholder="15-digit GSTIN"
                                className="w-36 px-2 py-1 border border-slate-300 rounded font-mono font-bold text-xs uppercase"
                              />
                            ) : (
                              <div className="flex items-center gap-1 font-mono">
                                <span className="font-bold text-slate-900">{counterpartyGstin || 'URP (Unregistered)'}</span>
                                {isGstinValid ? (
                                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                                ) : counterpartyGstin ? (
                                  <span title="Invalid GSTIN format">
                                    <AlertCircle className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                                  </span>
                                ) : null}
                              </div>
                            )}
                          </td>

                          {/* Counterparty Name */}
                          <td className="p-3">
                            {isEditing ? (
                              <input
                                type="text"
                                value={
                                  isOutwardSheet
                                    ? (editingTxnForm.recipientName ?? inv.recipientName)
                                    : (editingTxnForm.supplierName ?? inv.supplierName)
                                }
                                onChange={e => {
                                  const val = e.target.value;
                                  if (isOutwardSheet) {
                                    setEditingTxnForm(prev => ({ ...prev, recipientName: val }));
                                  } else {
                                    setEditingTxnForm(prev => ({ ...prev, supplierName: val }));
                                  }
                                }}
                                placeholder="Entity Name"
                                className="w-36 px-2 py-1 border border-slate-300 rounded text-xs"
                              />
                            ) : (
                              <span className="text-slate-700 truncate max-w-[130px] block">{counterpartyName}</span>
                            )}
                          </td>

                          {/* State / POS */}
                          <td className="p-3">
                            {isEditing ? (
                              <select
                                value={(editingTxnForm.placeOfSupplyCode || editingTxnForm.placeOfSupply || inv.placeOfSupply || '27').toString().padStart(2, '0')}
                                onChange={e => {
                                  const newPos = e.target.value;
                                  handleTxnTaxRecalc(
                                    Number(editingTxnForm.taxableValue ?? inv.taxableValue),
                                    Number(editingTxnForm.gstRate ?? inv.gstRate),
                                    newPos
                                  );
                                }}
                                className="px-1.5 py-1 border border-slate-300 rounded text-xs font-semibold bg-white max-w-[140px]"
                              >
                                {OFFICIAL_POS_LIST.map(p => (
                                  <option key={p.code} value={p.code}>
                                    {p.code} - {p.name}
                                  </option>
                                ))}
                              </select>
                            ) : (
                              <span className="font-mono text-slate-700">
                                {inv.placeOfSupplyCode || inv.placeOfSupply} -{' '}
                                {OFFICIAL_POS_LIST.find(p => p.code === (inv.placeOfSupplyCode || inv.placeOfSupply))?.name || inv.recipientState || 'State'}
                              </span>
                            )}
                          </td>

                          {/* HSN / SAC */}
                          <td className="p-3">
                            {isEditing ? (
                              <input
                                type="text"
                                maxLength={8}
                                value={editingTxnForm.hsnSacPrimary ?? inv.hsnSacPrimary ?? ''}
                                onChange={e => {
                                  const val = e.target.value.replace(/[^0-9]/g, '');
                                  const isService = val.startsWith('99');
                                  setEditingTxnForm(prev => ({
                                    ...prev,
                                    hsnSacPrimary: val,
                                    uqc: isService ? 'NA' : (prev.uqc && prev.uqc !== 'NA' ? prev.uqc : 'NOS'),
                                    totalQuantity: isService ? 0 : (prev.totalQuantity || 1)
                                  }));
                                }}
                                placeholder="e.g. 8471"
                                className="w-24 px-2 py-1 border border-slate-300 rounded font-mono font-bold text-xs"
                              />
                            ) : (
                              <span className="font-mono font-bold text-slate-800 bg-slate-100 px-1.5 py-0.5 rounded">
                                {inv.hsnSacPrimary || '998313'}
                              </span>
                            )}
                          </td>

                          {/* UQC */}
                          <td className="p-3">
                            {isEditing ? (
                              <select
                                value={editingTxnForm.uqc ?? inv.uqc ?? 'NOS'}
                                onChange={e =>
                                  setEditingTxnForm(prev => ({
                                    ...prev,
                                    uqc: e.target.value
                                  }))
                                }
                                className="px-1 py-1 border border-slate-300 rounded text-[11px] font-bold bg-white"
                              >
                                {OFFICIAL_UQCS.map(u => (
                                  <option key={u.code} value={u.code}>
                                    {u.code} - {u.name}
                                  </option>
                                ))}
                              </select>
                            ) : (
                              <span className="font-mono font-bold text-slate-600 text-[11px]">{inv.uqc || 'NOS'}</span>
                            )}
                          </td>

                          {/* Qty */}
                          <td className="p-3 text-right">
                            {isEditing ? (
                              <input
                                type="number"
                                min="0"
                                value={editingTxnForm.totalQuantity ?? inv.totalQuantity ?? 1}
                                onChange={e =>
                                  setEditingTxnForm(prev => ({
                                    ...prev,
                                    totalQuantity: parseFloat(e.target.value) || 0
                                  }))
                                }
                                className="w-16 px-1.5 py-1 border border-slate-300 rounded text-right font-mono text-xs"
                              />
                            ) : (
                              <span className="font-mono text-slate-700">{inv.totalQuantity ?? 1}</span>
                            )}
                          </td>

                          {/* Taxable Value */}
                          <td className="p-3 text-right font-mono">
                            {isEditing ? (
                              <input
                                type="number"
                                step="100"
                                value={editingTxnForm.taxableValue ?? inv.taxableValue}
                                onChange={e => {
                                  const newTaxable = parseFloat(e.target.value) || 0;
                                  const rate = Number(editingTxnForm.gstRate ?? inv.gstRate);
                                  const pos = (editingTxnForm.placeOfSupplyCode || inv.placeOfSupply || '27').toString().padStart(2, '0');
                                  handleTxnTaxRecalc(newTaxable, rate, pos);
                                }}
                                className="w-24 px-2 py-1 border border-slate-300 rounded text-right font-mono font-bold text-xs"
                              />
                            ) : (
                              <span className="font-bold text-slate-900">₹{formatINR(inv.taxableValue)}</span>
                            )}
                          </td>

                          {/* GST Rate */}
                          <td className="p-3 text-center">
                            {isEditing ? (
                              <select
                                value={editingTxnForm.gstRate ?? inv.gstRate}
                                onChange={e => {
                                  const newRate = parseFloat(e.target.value) || 0;
                                  const taxable = Number(editingTxnForm.taxableValue ?? inv.taxableValue);
                                  const pos = (editingTxnForm.placeOfSupplyCode || inv.placeOfSupply || '27').toString().padStart(2, '0');
                                  handleTxnTaxRecalc(taxable, newRate, pos);
                                }}
                                className="px-1.5 py-1 border border-slate-300 rounded text-xs font-bold bg-white"
                              >
                                <option value="0">0%</option>
                                <option value="5">5%</option>
                                <option value="12">12%</option>
                                <option value="18">18%</option>
                                <option value="28">28%</option>
                              </select>
                            ) : (
                              <span className="px-1.5 py-0.5 rounded font-mono font-bold text-[11px] bg-slate-100 text-slate-800">
                                {inv.gstRate}%
                              </span>
                            )}
                          </td>

                          {/* IGST */}
                          <td className="p-3 text-right font-mono text-slate-700">
                            ₹{formatINR(isEditing ? (editingTxnForm.igst ?? inv.igst) : inv.igst)}
                          </td>

                          {/* CGST */}
                          <td className="p-3 text-right font-mono text-slate-700">
                            ₹{formatINR(isEditing ? (editingTxnForm.cgst ?? inv.cgst) : inv.cgst)}
                          </td>

                          {/* SGST */}
                          <td className="p-3 text-right font-mono text-slate-700">
                            ₹{formatINR(isEditing ? (editingTxnForm.sgst ?? inv.sgst) : inv.sgst)}
                          </td>

                          {/* Total Amount */}
                          <td className="p-3 text-right font-mono font-bold text-emerald-800">
                            ₹{formatINR(isEditing ? (editingTxnForm.totalAmount ?? inv.totalAmount) : inv.totalAmount)}
                          </td>

                          {/* Actions & Expand Chevron */}
                          <td className="p-3 text-right">
                            <div className="flex items-center justify-end gap-1">
                              {/* Expand/Collapse extra fields */}
                              <button
                                onClick={() => setExpandedTxnId(isExpanded ? null : inv.id)}
                                className={`p-1 rounded-lg text-xs font-semibold flex items-center gap-0.5 transition cursor-pointer ${
                                  isExpanded ? 'bg-emerald-100 text-emerald-800' : 'hover:bg-slate-100 text-slate-500'
                                }`}
                                title="View / Edit All Government Template Fields"
                              >
                                {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                                <span className="text-[10px]">Fields</span>
                              </button>

                              {isEditing ? (
                                <>
                                  <button
                                    onClick={() => handleSaveTxnInline(inv.id)}
                                    className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-sm cursor-pointer"
                                    title="1-Click Save Changes"
                                  >
                                    <Save className="w-3 h-3" />
                                    <span>Save</span>
                                  </button>
                                  <button
                                    onClick={handleCancelEditTxn}
                                    className="p-1 hover:bg-slate-200 text-slate-500 rounded-lg cursor-pointer"
                                    title="Cancel"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                  </button>
                                </>
                              ) : (
                                <>
                                  <button
                                    onClick={() => handleStartEditTxn(inv)}
                                    className="inline-flex items-center gap-1 px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold transition cursor-pointer"
                                    title="1-Click Edit"
                                  >
                                    <Edit2 className="w-3 h-3 text-slate-600" />
                                    <span>Edit</span>
                                  </button>
                                  <button
                                    onClick={() => handleDeleteTxn(inv.id)}
                                    className="p-1 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                                    title="Delete Invoice"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </>
                              )}
                            </div>
                          </td>
                        </tr>

                        {/* EXPANDABLE GOVERNMENT TEMPLATE FIELDS ROW */}
                        {isExpanded && (
                          <tr className="bg-slate-50 border-b border-slate-200">
                            <td colSpan={16} className="p-4">
                              <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs space-y-3">
                                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                                  <span className="font-black text-xs text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                                    <Sliders className="w-3.5 h-3.5 text-emerald-600" />
                                    <span>Official Government Template Fields • #{inv.invoiceNumber}</span>
                                  </span>
                                  <span className="text-[11px] text-slate-500">
                                    These fields are validated strictly against GST Portal offline schema v3.2.4
                                  </span>
                                </div>

                                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                                  {/* Supply Type */}
                                  <div>
                                    <label className="block text-[11px] font-bold text-slate-600 mb-1">Supply Type</label>
                                    {isEditing ? (
                                      <select
                                        value={editingTxnForm.classification || inv.classification || 'B2B'}
                                        onChange={e =>
                                          setEditingTxnForm(prev => ({
                                            ...prev,
                                            classification: e.target.value as GSTClassification
                                          }))
                                        }
                                        className="w-full px-2 py-1.5 border border-slate-300 rounded text-xs bg-white font-medium"
                                      >
                                        {OFFICIAL_SUPPLY_TYPES.map(st => (
                                          <option key={st.id} value={st.id}>
                                            {st.label}
                                          </option>
                                        ))}
                                      </select>
                                    ) : (
                                      <div className="font-semibold text-slate-800 bg-slate-50 px-2 py-1 rounded border border-slate-200">
                                        {OFFICIAL_SUPPLY_TYPES.find(st => st.id === inv.classification)?.label || inv.classification}
                                      </div>
                                    )}
                                  </div>

                                  {/* Reverse Charge (RCM) */}
                                  <div>
                                    <label className="block text-[11px] font-bold text-slate-600 mb-1">Reverse Charge (RCM)</label>
                                    {isEditing ? (
                                      <select
                                        value={(editingTxnForm.rcm ?? inv.rcm) ? 'Y' : 'N'}
                                        onChange={e =>
                                          setEditingTxnForm(prev => ({
                                            ...prev,
                                            rcm: e.target.value === 'Y'
                                          }))
                                        }
                                        className="w-full px-2 py-1.5 border border-slate-300 rounded text-xs bg-white font-medium"
                                      >
                                        <option value="N">N - No RCM</option>
                                        <option value="Y">Y - Reverse Charge Applicable</option>
                                      </select>
                                    ) : (
                                      <div className="font-semibold text-slate-800 bg-slate-50 px-2 py-1 rounded border border-slate-200">
                                        {inv.rcm ? 'Y (Reverse Charge)' : 'N (No RCM)'}
                                      </div>
                                    )}
                                  </div>

                                  {/* Port Code */}
                                  <div>
                                    <label className="block text-[11px] font-bold text-slate-600 mb-1">Customs Port Code</label>
                                    {isEditing ? (
                                      <input
                                        type="text"
                                        maxLength={6}
                                        value={editingTxnForm.portCode ?? inv.portCode ?? ''}
                                        onChange={e =>
                                          setEditingTxnForm(prev => ({
                                            ...prev,
                                            portCode: e.target.value.toUpperCase().trim()
                                          }))
                                        }
                                        placeholder="e.g. INNSA1, INDEL4"
                                        className="w-full px-2 py-1.5 border border-slate-300 rounded text-xs font-mono font-bold uppercase bg-white"
                                      />
                                    ) : (
                                      <div className="font-mono font-bold text-slate-800 bg-slate-50 px-2 py-1 rounded border border-slate-200">
                                        {inv.portCode || 'NA (Domestic)'}
                                      </div>
                                    )}
                                  </div>

                                  {/* Shipping Bill # & Date */}
                                  <div>
                                    <label className="block text-[11px] font-bold text-slate-600 mb-1">Shipping Bill / Export Bill</label>
                                    {isEditing ? (
                                      <div className="flex items-center gap-1.5">
                                        <input
                                          type="text"
                                          value={editingTxnForm.shippingBillNumber ?? inv.shippingBillNumber ?? ''}
                                          onChange={e =>
                                            setEditingTxnForm(prev => ({
                                              ...prev,
                                              shippingBillNumber: e.target.value
                                            }))
                                          }
                                          placeholder="SB Number"
                                          className="w-1/2 px-2 py-1.5 border border-slate-300 rounded text-xs font-mono bg-white"
                                        />
                                        <input
                                          type="date"
                                          value={editingTxnForm.shippingBillDate ?? inv.shippingBillDate ?? ''}
                                          onChange={e =>
                                            setEditingTxnForm(prev => ({
                                              ...prev,
                                              shippingBillDate: e.target.value
                                            }))
                                          }
                                          className="w-1/2 px-1.5 py-1.5 border border-slate-300 rounded text-xs font-mono bg-white"
                                        />
                                      </div>
                                    ) : (
                                      <div className="font-mono text-slate-800 bg-slate-50 px-2 py-1 rounded border border-slate-200">
                                        {inv.shippingBillNumber ? `${inv.shippingBillNumber} (${inv.shippingBillDate || 'No date'})` : 'NA'}
                                      </div>
                                    )}
                                  </div>

                                  {/* E-Commerce GSTIN */}
                                  <div>
                                    <label className="block text-[11px] font-bold text-slate-600 mb-1">E-Commerce GSTIN (Table 14)</label>
                                    {isEditing ? (
                                      <input
                                        type="text"
                                        maxLength={15}
                                        value={editingTxnForm.ecommerceGstin ?? inv.ecommerceGstin ?? ''}
                                        onChange={e =>
                                          setEditingTxnForm(prev => ({
                                            ...prev,
                                            ecommerceGstin: e.target.value.toUpperCase().trim(),
                                            ecommerce: Boolean(e.target.value.trim())
                                          }))
                                        }
                                        placeholder="ECOM Operator GSTIN"
                                        className="w-full px-2 py-1.5 border border-slate-300 rounded text-xs font-mono uppercase bg-white"
                                      />
                                    ) : (
                                      <div className="font-mono text-slate-800 bg-slate-50 px-2 py-1 rounded border border-slate-200">
                                        {inv.ecommerceGstin || 'NA (Direct Supply)'}
                                      </div>
                                    )}
                                  </div>

                                  {/* Original Invoice Reference (for Credit/Debit Notes) */}
                                  {(inv.documentType === 'CREDIT_NOTE' || inv.documentType === 'DEBIT_NOTE') && (
                                    <div>
                                      <label className="block text-[11px] font-bold text-slate-600 mb-1">Original Invoice Ref</label>
                                      {isEditing ? (
                                        <div className="flex items-center gap-1.5">
                                          <input
                                            type="text"
                                            value={editingTxnForm.originalInvoiceNumber ?? inv.originalInvoiceNumber ?? ''}
                                            onChange={e =>
                                              setEditingTxnForm(prev => ({
                                                ...prev,
                                                originalInvoiceNumber: e.target.value
                                              }))
                                            }
                                            placeholder="Orig Inv #"
                                            className="w-1/2 px-2 py-1.5 border border-slate-300 rounded text-xs font-mono bg-white"
                                          />
                                          <input
                                            type="date"
                                            value={editingTxnForm.originalInvoiceDate ?? inv.originalInvoiceDate ?? ''}
                                            onChange={e =>
                                              setEditingTxnForm(prev => ({
                                                ...prev,
                                                originalInvoiceDate: e.target.value
                                              }))
                                            }
                                            className="w-1/2 px-1.5 py-1.5 border border-slate-300 rounded text-xs font-mono bg-white"
                                          />
                                        </div>
                                      ) : (
                                        <div className="font-mono text-slate-800 bg-slate-50 px-2 py-1 rounded border border-slate-200">
                                          {inv.originalInvoiceNumber ? `${inv.originalInvoiceNumber} (${inv.originalInvoiceDate || ''})` : 'INV/2026-27/001'}
                                        </div>
                                      )}
                                    </div>
                                  )}

                                  {/* Reason for DR/CR Note */}
                                  {(inv.documentType === 'CREDIT_NOTE' || inv.documentType === 'DEBIT_NOTE') && (
                                    <div>
                                      <label className="block text-[11px] font-bold text-slate-600 mb-1">Reason for Note</label>
                                      {isEditing ? (
                                        <select
                                          value={editingTxnForm.crDrReason || inv.crDrReason || inv.notes || '01-Sales Return'}
                                          onChange={e =>
                                            setEditingTxnForm(prev => ({
                                              ...prev,
                                              crDrReason: e.target.value,
                                              notes: e.target.value
                                            }))
                                          }
                                          className="w-full px-2 py-1.5 border border-slate-300 rounded text-xs bg-white font-medium"
                                        >
                                          {OFFICIAL_DR_CR_REASONS.map(r => (
                                            <option key={r} value={r}>
                                              {r}
                                            </option>
                                          ))}
                                        </select>
                                      ) : (
                                        <div className="font-semibold text-slate-800 bg-slate-50 px-2 py-1 rounded border border-slate-200">
                                          {inv.crDrReason || inv.notes || '01-Sales Return'}
                                        </div>
                                      )}
                                    </div>
                                  )}

                                  {/* Purchase Register ITC Status & Sec 17(5) */}
                                  {txnSheetTab === 'PURCHASE' && (
                                    <>
                                      <div>
                                        <label className="block text-[11px] font-bold text-slate-600 mb-1">Eligibility of ITC</label>
                                        {isEditing ? (
                                          <select
                                            value={editingTxnForm.itcStatus || inv.itcStatus || 'ELIGIBLE'}
                                            onChange={e =>
                                              setEditingTxnForm(prev => ({
                                                ...prev,
                                                itcStatus: e.target.value as ITCStatus,
                                                itcEligible: e.target.value === 'ELIGIBLE'
                                              }))
                                            }
                                            className="w-full px-2 py-1.5 border border-slate-300 rounded text-xs bg-white font-medium"
                                          >
                                            {OFFICIAL_ITC_OPTIONS.map(opt => (
                                              <option key={opt.id} value={opt.id}>
                                                {opt.label}
                                              </option>
                                            ))}
                                          </select>
                                        ) : (
                                          <div className="font-semibold text-slate-800 bg-slate-50 px-2 py-1 rounded border border-slate-200">
                                            {OFFICIAL_ITC_OPTIONS.find(opt => opt.id === inv.itcStatus)?.label || inv.itcStatus}
                                          </div>
                                        )}
                                      </div>

                                      <div>
                                        <label className="block text-[11px] font-bold text-slate-600 mb-1">Ineligible ITC Reason (Sec 17(5))</label>
                                        {isEditing ? (
                                          <select
                                            value={editingTxnForm.blockedCreditReason || inv.blockedCreditReason || 'NONE'}
                                            onChange={e =>
                                              setEditingTxnForm(prev => ({
                                                ...prev,
                                                blockedCreditReason: e.target.value as BlockedCreditReason
                                              }))
                                            }
                                            className="w-full px-2 py-1.5 border border-slate-300 rounded text-xs bg-white font-medium"
                                          >
                                            <option value="NONE">None (Eligible)</option>
                                            {OFFICIAL_BLOCKED_REASONS.map(br => (
                                              <option key={br.id} value={br.id}>
                                                {br.label}
                                              </option>
                                            ))}
                                          </select>
                                        ) : (
                                          <div className="font-semibold text-slate-800 bg-slate-50 px-2 py-1 rounded border border-slate-200">
                                            {OFFICIAL_BLOCKED_REASONS.find(br => br.id === inv.blockedCreditReason)?.label || 'None'}
                                          </div>
                                        )}
                                      </div>
                                    </>
                                  )}
                                </div>
                              </div>
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
            </>
          )}

          {/* ========================================================================= */}
          {/* SHEET 4: GSTR-2 DEBIT CREDIT NOTE GRID (31 Columns • Inward CDN)          */}
          {/* ========================================================================= */}
          {txnSheetTab === 'GSTR2_CR_DR' && (
            <div className="space-y-4">
              <div className="overflow-x-auto border border-rose-200 rounded-xl max-h-[640px] shadow-sm">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="sticky top-0 z-10 shadow-md">
                    <tr className="border-b border-rose-900 text-white font-black uppercase tracking-wider text-[11px]">
                      <th className="p-3 w-36 bg-slate-900 border-r border-slate-800 text-rose-200">Supplier GSTIN</th>
                      <th className="p-3 w-40 bg-slate-800 border-r border-slate-700 text-slate-100">Supplier Name</th>
                      <th className="p-3 w-28 bg-slate-800 border-r border-slate-700 text-blue-200">State / POS</th>
                      <th className="p-3 w-32 bg-rose-950 border-r border-rose-900 text-rose-200">Note #</th>
                      <th className="p-3 w-28 bg-rose-950 border-r border-rose-900 text-rose-200">Note Date</th>
                      <th className="p-3 w-32 bg-slate-900 border-r border-slate-800 text-slate-200">Orig. Invoice #</th>
                      <th className="p-3 w-28 bg-slate-900 border-r border-slate-800 text-slate-200">Orig. Date</th>
                      <th className="p-3 w-32 text-right bg-rose-900 border-r border-rose-800 text-white font-black">Diff. Value (₹)</th>
                      <th className="p-3 w-28 text-right bg-indigo-950 border-r border-indigo-900 text-indigo-200">IGST (₹)</th>
                      <th className="p-3 w-28 text-right bg-teal-950 border-r border-teal-900 text-teal-200">CGST (₹)</th>
                      <th className="p-3 w-28 text-right bg-teal-950 border-r border-teal-900 text-teal-200">SGST (₹)</th>
                      <th className="p-3 w-24 text-right bg-amber-950 border-r border-amber-900 text-amber-200">CESS (₹)</th>
                      <th className="p-3 w-28 bg-emerald-950 border-r border-emerald-900 text-emerald-200">ITC Status</th>
                      <th className="p-3 w-24 bg-purple-950 border-r border-purple-900 text-purple-200">Type</th>
                      <th className="p-3 w-36 bg-slate-900 border-r border-slate-800 text-slate-200">Reason</th>
                      <th className="p-3 w-24 text-center bg-slate-900 border-r border-slate-800 text-slate-200">RCM</th>
                      <th className="p-3 w-28 text-right bg-rose-950 text-rose-200">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-rose-100">
                    {gstr2CrDrNotes.length === 0 ? (
                      <tr>
                        <td colSpan={17} className="p-10 text-center text-slate-400">
                          No GSTR-2 Debit/Credit Notes recorded. Click <strong>"+1 Row"</strong> or <strong>"Import Excel"</strong> above!
                        </td>
                      </tr>
                    ) : (
                      gstr2CrDrNotes.map((item, idx) => {
                        const isEditing = editingG2CdnId === item.id;
                        return (
                          <tr
                            key={item.id}
                            className={`transition ${isEditing ? 'bg-amber-50/70' : idx % 2 === 0 ? 'bg-white' : 'bg-rose-50/20'} hover:bg-rose-50/40`}
                          >
                            <td className="p-3 font-mono font-bold text-slate-900">
                              {isEditing ? (
                                <input
                                  type="text"
                                  value={editingG2CdnForm.supplierGstin ?? item.supplierGstin}
                                  onChange={e => setEditingG2CdnForm(prev => ({ ...prev, supplierGstin: e.target.value.toUpperCase() }))}
                                  className="w-32 px-1.5 py-1 border border-slate-300 rounded font-mono text-xs uppercase"
                                />
                              ) : (
                                item.supplierGstin
                              )}
                            </td>
                            <td className="p-3 font-medium text-slate-800">
                              {isEditing ? (
                                <input
                                  type="text"
                                  value={editingG2CdnForm.supplierName ?? item.supplierName}
                                  onChange={e => setEditingG2CdnForm(prev => ({ ...prev, supplierName: e.target.value }))}
                                  className="w-36 px-1.5 py-1 border border-slate-300 rounded text-xs"
                                />
                              ) : (
                                item.supplierName
                              )}
                            </td>
                            <td className="p-3 font-mono text-xs">
                              {isEditing ? (
                                <input
                                  type="text"
                                  maxLength={2}
                                  value={editingG2CdnForm.pos ?? item.pos}
                                  onChange={e => setEditingG2CdnForm(prev => ({ ...prev, pos: e.target.value }))}
                                  className="w-12 px-1.5 py-1 border border-slate-300 rounded font-mono text-xs"
                                />
                              ) : (
                                `${item.pos} - ${item.supplierState || ''}`
                              )}
                            </td>
                            <td className="p-3 font-mono font-bold text-rose-900">
                              {isEditing ? (
                                <input
                                  type="text"
                                  value={editingG2CdnForm.noteNumber ?? item.noteNumber}
                                  onChange={e => setEditingG2CdnForm(prev => ({ ...prev, noteNumber: e.target.value }))}
                                  className="w-28 px-1.5 py-1 border border-slate-300 rounded font-mono text-xs"
                                />
                              ) : (
                                item.noteNumber
                              )}
                            </td>
                            <td className="p-3 font-mono text-xs">
                              {isEditing ? (
                                <input
                                  type="date"
                                  value={editingG2CdnForm.noteDate ?? item.noteDate}
                                  onChange={e => setEditingG2CdnForm(prev => ({ ...prev, noteDate: e.target.value }))}
                                  className="px-1.5 py-1 border border-slate-300 rounded text-xs"
                                />
                              ) : (
                                item.noteDate
                              )}
                            </td>
                            <td className="p-3 font-mono text-xs text-slate-600">
                              {isEditing ? (
                                <input
                                  type="text"
                                  value={editingG2CdnForm.originalInvoiceNumber ?? item.originalInvoiceNumber}
                                  onChange={e => setEditingG2CdnForm(prev => ({ ...prev, originalInvoiceNumber: e.target.value }))}
                                  className="w-28 px-1.5 py-1 border border-slate-300 rounded font-mono text-xs"
                                />
                              ) : (
                                item.originalInvoiceNumber || '-'
                              )}
                            </td>
                            <td className="p-3 font-mono text-xs text-slate-500">
                              {isEditing ? (
                                <input
                                  type="date"
                                  value={editingG2CdnForm.originalInvoiceDate ?? item.originalInvoiceDate}
                                  onChange={e => setEditingG2CdnForm(prev => ({ ...prev, originalInvoiceDate: e.target.value }))}
                                  className="px-1.5 py-1 border border-slate-300 rounded text-xs"
                                />
                              ) : (
                                item.originalInvoiceDate || '-'
                              )}
                            </td>
                            <td className="p-3 text-right font-mono font-black text-rose-950">
                              {isEditing ? (
                                <input
                                  type="number"
                                  value={editingG2CdnForm.differentialValue ?? item.differentialValue}
                                  onChange={e => {
                                    const val = parseFloat(e.target.value) || 0;
                                    const rate = editingG2CdnForm.igstRate ?? item.igstRate ?? 18;
                                    const tax = (val * rate) / 100;
                                    setEditingG2CdnForm(prev => ({
                                      ...prev,
                                      differentialValue: val,
                                      igstAmount: tax,
                                      itcIgst: tax
                                    }));
                                  }}
                                  className="w-24 px-1.5 py-1 border border-slate-300 rounded font-mono text-xs text-right"
                                />
                              ) : (
                                `₹${formatINR(item.differentialValue)}`
                              )}
                            </td>
                            <td className="p-3 text-right font-mono text-blue-900">
                              ₹{formatINR(isEditing ? (editingG2CdnForm.igstAmount ?? item.igstAmount) : item.igstAmount)}
                            </td>
                            <td className="p-3 text-right font-mono text-teal-900">
                              ₹{formatINR(isEditing ? (editingG2CdnForm.cgstAmount ?? item.cgstAmount) : item.cgstAmount)}
                            </td>
                            <td className="p-3 text-right font-mono text-teal-900">
                              ₹{formatINR(isEditing ? (editingG2CdnForm.sgstAmount ?? item.sgstAmount) : item.sgstAmount)}
                            </td>
                            <td className="p-3 text-right font-mono text-amber-900">
                              ₹{formatINR(isEditing ? (editingG2CdnForm.cessAmount ?? item.cessAmount) : item.cessAmount)}
                            </td>
                            <td className="p-3">
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                                {item.itcEligibility}
                              </span>
                            </td>
                            <td className="p-3">
                              <span
                                className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                  item.noteType === 'CREDIT' ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'
                                }`}
                              >
                                {item.noteType}
                              </span>
                            </td>
                            <td className="p-3 text-slate-700 text-xs truncate max-w-[140px]">{item.reason}</td>
                            <td className="p-3 text-center font-bold text-slate-600">{item.rcm ? 'Y' : 'N'}</td>
                            <td className="p-3 text-right">
                              {isEditing ? (
                                <div className="flex items-center justify-end gap-1.5">
                                  <button
                                    onClick={() => handleSaveG2Cdn(item.id)}
                                    className="p-1.5 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 cursor-pointer shadow-xs"
                                    title="Save changes in 1 click"
                                  >
                                    <Save className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    onClick={() => {
                                      setEditingG2CdnId(null);
                                      setEditingG2CdnForm({});
                                    }}
                                    className="p-1.5 rounded-lg bg-slate-200 text-slate-700 hover:bg-slate-300 cursor-pointer"
                                    title="Cancel"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              ) : (
                                <div className="flex items-center justify-end gap-1.5">
                                  <button
                                    onClick={() => {
                                      setEditingG2CdnId(item.id);
                                      setEditingG2CdnForm({ ...item });
                                    }}
                                    className="p-1.5 rounded-lg bg-slate-100 text-slate-700 hover:bg-rose-100 hover:text-rose-800 cursor-pointer"
                                    title="1-Click Inline Edit"
                                  >
                                    <Edit2 className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    onClick={() => handleDeleteTxn(item.id)}
                                    className="p-1.5 rounded-lg bg-slate-100 text-slate-400 hover:bg-rose-100 hover:text-rose-600 cursor-pointer"
                                    title="Delete row"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              )}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ========================================================================= */}
          {/* SHEET 5: GSTR-1 ADVANCE TAX GRID (20 Columns • Table 11A / 11B)           */}
          {/* ========================================================================= */}
          {txnSheetTab === 'GSTR1_ADVANCE' && (
            <div className="space-y-4">
              <div className="overflow-x-auto border border-amber-200 rounded-xl max-h-[640px] shadow-sm">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="sticky top-0 z-10 shadow-md">
                    <tr className="border-b border-amber-900 text-white font-black uppercase tracking-wider text-[11px]">
                      <th className="p-3 w-36 bg-slate-900 border-r border-slate-800 text-amber-200">Party GSTIN</th>
                      <th className="p-3 w-40 bg-slate-800 border-r border-slate-700 text-slate-100">Party Name</th>
                      <th className="p-3 w-28 bg-slate-800 border-r border-slate-700 text-blue-200">State / POS</th>
                      <th className="p-3 w-32 bg-amber-950 border-r border-amber-900 text-amber-200">Receipt Voucher #</th>
                      <th className="p-3 w-28 bg-amber-950 border-r border-amber-900 text-amber-200">Voucher Date</th>
                      <th className="p-3 w-24 bg-slate-900 border-r border-slate-800 text-slate-200">Type</th>
                      <th className="p-3 w-24 bg-emerald-950 border-r border-emerald-900 text-emerald-300">HSN/SAC</th>
                      <th className="p-3 w-36 text-right bg-amber-900 border-r border-amber-800 text-white font-black">Advance Recd (₹)</th>
                      <th className="p-3 w-24 text-center bg-indigo-950 border-r border-indigo-900 text-indigo-200">Rate</th>
                      <th className="p-3 w-28 text-right bg-blue-950 border-r border-blue-900 text-blue-200">IGST (₹)</th>
                      <th className="p-3 w-28 text-right bg-teal-950 border-r border-teal-900 text-teal-200">CGST (₹)</th>
                      <th className="p-3 w-28 text-right bg-teal-950 border-r border-teal-900 text-teal-200">SGST (₹)</th>
                      <th className="p-3 w-24 text-center bg-slate-900 border-r border-slate-800 text-slate-200">Registered</th>
                      <th className="p-3 w-28 text-right bg-amber-950 text-amber-200">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-amber-100">
                    {gstr1AdvanceTax.length === 0 ? (
                      <tr>
                        <td colSpan={14} className="p-10 text-center text-slate-400">
                          No Advances Received recorded. Click <strong>"+1 Row"</strong> or <strong>"Import Excel"</strong> above!
                        </td>
                      </tr>
                    ) : (
                      gstr1AdvanceTax.map((item, idx) => {
                        const isEditing = editingG1AdvId === item.id;
                        return (
                          <tr
                            key={item.id}
                            className={`transition ${isEditing ? 'bg-amber-50/70' : idx % 2 === 0 ? 'bg-white' : 'bg-amber-50/20'} hover:bg-amber-50/40`}
                          >
                            <td className="p-3 font-mono font-bold text-slate-900">
                              {isEditing ? (
                                <input
                                  type="text"
                                  value={editingG1AdvForm.partyGstin ?? item.partyGstin}
                                  onChange={e => setEditingG1AdvForm(prev => ({ ...prev, partyGstin: e.target.value.toUpperCase() }))}
                                  className="w-32 px-1.5 py-1 border border-slate-300 rounded font-mono text-xs uppercase"
                                />
                              ) : (
                                item.partyGstin || 'URP / Unregistered'
                              )}
                            </td>
                            <td className="p-3 font-medium text-slate-800">
                              {isEditing ? (
                                <input
                                  type="text"
                                  value={editingG1AdvForm.partyName ?? item.partyName}
                                  onChange={e => setEditingG1AdvForm(prev => ({ ...prev, partyName: e.target.value }))}
                                  className="w-36 px-1.5 py-1 border border-slate-300 rounded text-xs"
                                />
                              ) : (
                                item.partyName
                              )}
                            </td>
                            <td className="p-3 font-mono text-xs">{item.pos} - {item.state}</td>
                            <td className="p-3 font-mono font-bold text-amber-900">
                              {isEditing ? (
                                <input
                                  type="text"
                                  value={editingG1AdvForm.receiptVoucherNo ?? item.receiptVoucherNo}
                                  onChange={e => setEditingG1AdvForm(prev => ({ ...prev, receiptVoucherNo: e.target.value }))}
                                  className="w-28 px-1.5 py-1 border border-slate-300 rounded font-mono text-xs"
                                />
                              ) : (
                                item.receiptVoucherNo
                              )}
                            </td>
                            <td className="p-3 font-mono text-xs">
                              {isEditing ? (
                                <input
                                  type="date"
                                  value={editingG1AdvForm.receiptVoucherDate ?? item.receiptVoucherDate}
                                  onChange={e => setEditingG1AdvForm(prev => ({ ...prev, receiptVoucherDate: e.target.value }))}
                                  className="px-1.5 py-1 border border-slate-300 rounded text-xs"
                                />
                              ) : (
                                item.receiptVoucherDate
                              )}
                            </td>
                            <td className="p-3 font-semibold text-slate-700 text-xs">{item.goodsOrServices}</td>
                            <td className="p-3 font-mono text-emerald-800 font-bold">{item.hsnSac}</td>
                            <td className="p-3 text-right font-mono font-black text-amber-950">
                              {isEditing ? (
                                <input
                                  type="number"
                                  value={editingG1AdvForm.advanceReceived ?? item.advanceReceived}
                                  onChange={e => {
                                    const val = parseFloat(e.target.value) || 0;
                                    const isInter = item.pos !== (selectedGstin || '07').substring(0, 2);
                                    const rate = isEditing ? (editingG1AdvForm.igstRate ?? item.igstRate ?? 18) : item.igstRate;
                                    if (isInter) {
                                      setEditingG1AdvForm(prev => ({
                                        ...prev,
                                        advanceReceived: val,
                                        igstAmount: (val * rate) / 100,
                                        cgstAmount: 0,
                                        sgstAmount: 0
                                      }));
                                    } else {
                                      const halfRate = rate / 2;
                                      const halfTax = (val * halfRate) / 100;
                                      setEditingG1AdvForm(prev => ({
                                        ...prev,
                                        advanceReceived: val,
                                        igstAmount: 0,
                                        cgstAmount: halfTax,
                                        sgstAmount: halfTax
                                      }));
                                    }
                                  }}
                                  className="w-24 px-1.5 py-1 border border-slate-300 rounded font-mono text-xs text-right"
                                />
                              ) : (
                                `₹${formatINR(item.advanceReceived)}`
                              )}
                            </td>
                            <td className="p-3 text-center font-bold text-indigo-900">
                              {item.igstRate > 0 ? `${item.igstRate}%` : `${(item.cgstRate + item.sgstRate)}%`}
                            </td>
                            <td className="p-3 text-right font-mono text-blue-900">
                              ₹{formatINR(isEditing ? (editingG1AdvForm.igstAmount ?? item.igstAmount) : item.igstAmount)}
                            </td>
                            <td className="p-3 text-right font-mono text-teal-900">
                              ₹{formatINR(isEditing ? (editingG1AdvForm.cgstAmount ?? item.cgstAmount) : item.cgstAmount)}
                            </td>
                            <td className="p-3 text-right font-mono text-teal-900">
                              ₹{formatINR(isEditing ? (editingG1AdvForm.sgstAmount ?? item.sgstAmount) : item.sgstAmount)}
                            </td>
                            <td className="p-3 text-center font-bold text-slate-700">{item.isPartyRegistered}</td>
                            <td className="p-3 text-right">
                              {isEditing ? (
                                <div className="flex items-center justify-end gap-1.5">
                                  <button
                                    onClick={() => handleSaveG1Adv(item.id)}
                                    className="p-1.5 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 cursor-pointer shadow-xs"
                                    title="Save changes in 1 click"
                                  >
                                    <Save className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    onClick={() => {
                                      setEditingG1AdvId(null);
                                      setEditingG1AdvForm({});
                                    }}
                                    className="p-1.5 rounded-lg bg-slate-200 text-slate-700 hover:bg-slate-300 cursor-pointer"
                                    title="Cancel"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              ) : (
                                <div className="flex items-center justify-end gap-1.5">
                                  <button
                                    onClick={() => {
                                      setEditingG1AdvId(item.id);
                                      setEditingG1AdvForm({ ...item });
                                    }}
                                    className="p-1.5 rounded-lg bg-slate-100 text-slate-700 hover:bg-amber-100 hover:text-amber-800 cursor-pointer"
                                    title="1-Click Inline Edit"
                                  >
                                    <Edit2 className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    onClick={() => handleDeleteTxn(item.id)}
                                    className="p-1.5 rounded-lg bg-slate-100 text-slate-400 hover:bg-rose-100 hover:text-rose-600 cursor-pointer"
                                    title="Delete row"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              )}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ========================================================================= */}
          {/* SHEET 6: GSTR-2 ADVANCE TAX GRID (18 Columns • Inward Advance RCM)        */}
          {/* ========================================================================= */}
          {txnSheetTab === 'GSTR2_ADVANCE' && (
            <div className="space-y-4">
              <div className="overflow-x-auto border border-teal-200 rounded-xl max-h-[640px] shadow-sm">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="sticky top-0 z-10 shadow-md">
                    <tr className="border-b border-teal-900 text-white font-black uppercase tracking-wider text-[11px]">
                      <th className="p-3 w-36 bg-slate-900 border-r border-slate-800 text-teal-200">Supplier GSTIN</th>
                      <th className="p-3 w-40 bg-slate-800 border-r border-slate-700 text-slate-100">Supplier Name</th>
                      <th className="p-3 w-28 bg-slate-800 border-r border-slate-700 text-blue-200">State / POS</th>
                      <th className="p-3 w-32 bg-teal-950 border-r border-teal-900 text-teal-200">Payment Voucher #</th>
                      <th className="p-3 w-28 bg-teal-950 border-r border-teal-900 text-teal-200">Voucher Date</th>
                      <th className="p-3 w-24 bg-slate-900 border-r border-slate-800 text-slate-200">Type</th>
                      <th className="p-3 w-24 bg-emerald-950 border-r border-emerald-900 text-emerald-300">HSN/SAC</th>
                      <th className="p-3 w-36 text-right bg-teal-900 border-r border-teal-800 text-white font-black">Advance Paid (₹)</th>
                      <th className="p-3 w-24 text-center bg-indigo-950 border-r border-indigo-900 text-indigo-200">Rate</th>
                      <th className="p-3 w-28 text-right bg-blue-950 border-r border-blue-900 text-blue-200">IGST (₹)</th>
                      <th className="p-3 w-28 text-right bg-teal-950 border-r border-teal-900 text-teal-200">CGST (₹)</th>
                      <th className="p-3 w-28 text-right bg-teal-950 border-r border-teal-900 text-teal-200">SGST (₹)</th>
                      <th className="p-3 w-24 text-center bg-slate-900 border-r border-slate-800 text-slate-200">Registered</th>
                      <th className="p-3 w-28 text-right bg-teal-950 text-teal-200">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-teal-100">
                    {gstr2AdvanceTax.length === 0 ? (
                      <tr>
                        <td colSpan={14} className="p-10 text-center text-slate-400">
                          No Advances Paid recorded. Click <strong>"+1 Row"</strong> or <strong>"Import Excel"</strong> above!
                        </td>
                      </tr>
                    ) : (
                      gstr2AdvanceTax.map((item, idx) => {
                        const isEditing = editingG2AdvId === item.id;
                        return (
                          <tr
                            key={item.id}
                            className={`transition ${isEditing ? 'bg-amber-50/70' : idx % 2 === 0 ? 'bg-white' : 'bg-teal-50/20'} hover:bg-teal-50/40`}
                          >
                            <td className="p-3 font-mono font-bold text-slate-900">
                              {isEditing ? (
                                <input
                                  type="text"
                                  value={editingG2AdvForm.partyGstin ?? item.partyGstin}
                                  onChange={e => setEditingG2AdvForm(prev => ({ ...prev, partyGstin: e.target.value.toUpperCase() }))}
                                  className="w-32 px-1.5 py-1 border border-slate-300 rounded font-mono text-xs uppercase"
                                />
                              ) : (
                                item.partyGstin || 'URP / Unregistered'
                              )}
                            </td>
                            <td className="p-3 font-medium text-slate-800">
                              {isEditing ? (
                                <input
                                  type="text"
                                  value={editingG2AdvForm.partyName ?? item.partyName}
                                  onChange={e => setEditingG2AdvForm(prev => ({ ...prev, partyName: e.target.value }))}
                                  className="w-36 px-1.5 py-1 border border-slate-300 rounded text-xs"
                                />
                              ) : (
                                item.partyName
                              )}
                            </td>
                            <td className="p-3 font-mono text-xs">{item.pos} - {item.state}</td>
                            <td className="p-3 font-mono font-bold text-teal-900">
                              {isEditing ? (
                                <input
                                  type="text"
                                  value={editingG2AdvForm.paymentVoucherNo ?? item.paymentVoucherNo}
                                  onChange={e => setEditingG2AdvForm(prev => ({ ...prev, paymentVoucherNo: e.target.value }))}
                                  className="w-28 px-1.5 py-1 border border-slate-300 rounded font-mono text-xs"
                                />
                              ) : (
                                item.paymentVoucherNo
                              )}
                            </td>
                            <td className="p-3 font-mono text-xs">
                              {isEditing ? (
                                <input
                                  type="date"
                                  value={editingG2AdvForm.paymentVoucherDate ?? item.paymentVoucherDate}
                                  onChange={e => setEditingG2AdvForm(prev => ({ ...prev, paymentVoucherDate: e.target.value }))}
                                  className="px-1.5 py-1 border border-slate-300 rounded text-xs"
                                />
                              ) : (
                                item.paymentVoucherDate
                              )}
                            </td>
                            <td className="p-3 font-semibold text-slate-700 text-xs">{item.goodsOrServices}</td>
                            <td className="p-3 font-mono text-emerald-800 font-bold">{item.hsnSac}</td>
                            <td className="p-3 text-right font-mono font-black text-teal-950">
                              {isEditing ? (
                                <input
                                  type="number"
                                  value={editingG2AdvForm.advancePaid ?? item.advancePaid}
                                  onChange={e => {
                                    const val = parseFloat(e.target.value) || 0;
                                    const rate = isEditing ? (editingG2AdvForm.igstRate ?? item.igstRate ?? 18) : item.igstRate;
                                    setEditingG2AdvForm(prev => ({
                                      ...prev,
                                      advancePaid: val,
                                      igstAmount: (val * rate) / 100
                                    }));
                                  }}
                                  className="w-24 px-1.5 py-1 border border-slate-300 rounded font-mono text-xs text-right"
                                />
                              ) : (
                                `₹${formatINR(item.advancePaid)}`
                              )}
                            </td>
                            <td className="p-3 text-center font-bold text-indigo-900">
                              {item.igstRate > 0 ? `${item.igstRate}%` : `${(item.cgstRate + item.sgstRate)}%`}
                            </td>
                            <td className="p-3 text-right font-mono text-blue-900">
                              ₹{formatINR(isEditing ? (editingG2AdvForm.igstAmount ?? item.igstAmount) : item.igstAmount)}
                            </td>
                            <td className="p-3 text-right font-mono text-teal-900">
                              ₹{formatINR(isEditing ? (editingG2AdvForm.cgstAmount ?? item.cgstAmount) : item.cgstAmount)}
                            </td>
                            <td className="p-3 text-right font-mono text-teal-900">
                              ₹{formatINR(isEditing ? (editingG2AdvForm.sgstAmount ?? item.sgstAmount) : item.sgstAmount)}
                            </td>
                            <td className="p-3 text-center font-bold text-slate-700">{item.isPartyRegistered}</td>
                            <td className="p-3 text-right">
                              {isEditing ? (
                                <div className="flex items-center justify-end gap-1.5">
                                  <button
                                    onClick={() => handleSaveG2Adv(item.id)}
                                    className="p-1.5 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 cursor-pointer shadow-xs"
                                    title="Save changes in 1 click"
                                  >
                                    <Save className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    onClick={() => {
                                      setEditingG2AdvId(null);
                                      setEditingG2AdvForm({});
                                    }}
                                    className="p-1.5 rounded-lg bg-slate-200 text-slate-700 hover:bg-slate-300 cursor-pointer"
                                    title="Cancel"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              ) : (
                                <div className="flex items-center justify-end gap-1.5">
                                  <button
                                    onClick={() => {
                                      setEditingG2AdvId(item.id);
                                      setEditingG2AdvForm({ ...item });
                                    }}
                                    className="p-1.5 rounded-lg bg-slate-100 text-slate-700 hover:bg-teal-100 hover:text-teal-800 cursor-pointer"
                                    title="1-Click Inline Edit"
                                  >
                                    <Edit2 className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    onClick={() => handleDeleteTxn(item.id)}
                                    className="p-1.5 rounded-lg bg-slate-100 text-slate-400 hover:bg-rose-100 hover:text-rose-600 cursor-pointer"
                                    title="Delete row"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              )}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================= */}
      {/* TAB: CLIENT MASTER                                        */}
      {/* ========================================================= */}
      {activeTab === 'clients' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-100">
            <div>
              <h2 className="text-base font-bold text-slate-900">Clients & GSTIN Master (1-Click Inline Editor)</h2>
              <p className="text-xs text-slate-500">
                Click "Edit" on any client to immediately modify their details in place, or switch active workspace in 1 click.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleQuickAddClient}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition shadow-sm cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>1-Click Add Client</span>
              </button>
            </div>
          </div>

          {/* Filter / Search Bar */}
          <div className="flex items-center gap-3 flex-wrap">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search clients by name, GSTIN, PAN or state..."
                value={clientSearch}
                onChange={e => setClientSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <select
              value={clientStatusFilter}
              onChange={e => setClientStatusFilter(e.target.value)}
              className="px-3 py-2 text-xs border border-slate-200 rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium text-slate-700"
            >
              <option value="ALL">All Statuses</option>
              <option value="Active">Active</option>
              <option value="Notice Received">Notice Received</option>
              <option value="Onboarding">Onboarding</option>
              <option value="Archived">Archived</option>
            </select>
          </div>

          {/* Client Table */}
          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-700 font-bold uppercase tracking-wider text-[11px]">
                  <th className="p-3">Client / Legal Name</th>
                  <th className="p-3">Primary GSTIN</th>
                  <th className="p-3">PAN</th>
                  <th className="p-3">State</th>
                  <th className="p-3">Entity Type</th>
                  <th className="p-3">Frequency</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 text-right">1-Click Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredClients.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="p-8 text-center text-slate-400">
                      No clients match your filter. Click "1-Click Add Client" above to create one.
                    </td>
                  </tr>
                ) : (
                  filteredClients.map(c => {
                    const isEditing = editingClientId === c.id;
                    const isSelected = selectedClientId === c.id;

                    return (
                      <tr
                        key={c.id}
                        className={`transition ${isSelected ? 'bg-emerald-50/40' : 'hover:bg-slate-50/60'} ${
                          isEditing ? 'bg-amber-50/50' : ''
                        }`}
                      >
                        {/* Client / Legal Name */}
                        <td className="p-3">
                          {isEditing ? (
                            <div className="space-y-1">
                              <input
                                type="text"
                                value={editingClientForm.name || ''}
                                onChange={e => setEditingClientForm(prev => ({ ...prev, name: e.target.value }))}
                                placeholder="Display Name"
                                className="w-full px-2 py-1 border border-slate-300 rounded font-bold text-xs"
                              />
                              <input
                                type="text"
                                value={editingClientForm.legalName || ''}
                                onChange={e => setEditingClientForm(prev => ({ ...prev, legalName: e.target.value }))}
                                placeholder="Legal Entity Name"
                                className="w-full px-2 py-0.5 border border-slate-200 rounded text-[11px] text-slate-600"
                              />
                            </div>
                          ) : (
                            <div>
                              <div className="font-bold text-slate-900 flex items-center gap-1.5">
                                {c.name}
                                {isSelected && (
                                  <span className="bg-emerald-100 text-emerald-800 text-[9px] font-bold px-1.5 py-0.2 rounded font-mono">
                                    ACTIVE
                                  </span>
                                )}
                              </div>
                              <div className="text-[11px] text-slate-500">{c.legalName}</div>
                            </div>
                          )}
                        </td>

                        {/* Primary GSTIN */}
                        <td className="p-3">
                          {isEditing ? (
                            <input
                              type="text"
                              value={editingClientForm.primaryGstin || ''}
                              onChange={e =>
                                setEditingClientForm(prev => ({ ...prev, primaryGstin: e.target.value.toUpperCase() }))
                              }
                              className="w-36 px-2 py-1 border border-slate-300 rounded font-mono font-bold text-xs uppercase"
                            />
                          ) : (
                            <span className="font-mono font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                              {c.primaryGstin}
                            </span>
                          )}
                        </td>

                        {/* PAN */}
                        <td className="p-3">
                          {isEditing ? (
                            <input
                              type="text"
                              value={editingClientForm.pan || ''}
                              onChange={e =>
                                setEditingClientForm(prev => ({ ...prev, pan: e.target.value.toUpperCase() }))
                              }
                              className="w-28 px-2 py-1 border border-slate-300 rounded font-mono font-bold text-xs uppercase"
                            />
                          ) : (
                            <span className="font-mono text-slate-700">{c.pan}</span>
                          )}
                        </td>

                        {/* State */}
                        <td className="p-3">
                          {isEditing ? (
                            <select
                              value={editingClientForm.state || c.state}
                              onChange={e => setEditingClientForm(prev => ({ ...prev, state: e.target.value }))}
                              className="px-2 py-1 border border-slate-300 rounded text-xs"
                            >
                              {INDIAN_STATES.map(s => (
                                <option key={s.code} value={s.name}>
                                  {s.name} ({s.code})
                                </option>
                              ))}
                            </select>
                          ) : (
                            <span className="text-slate-800">{c.state}</span>
                          )}
                        </td>

                        {/* Entity Type */}
                        <td className="p-3">
                          {isEditing ? (
                            <select
                              value={editingClientForm.businessType || c.businessType}
                              onChange={e =>
                                setEditingClientForm(prev => ({
                                  ...prev,
                                  businessType: e.target.value as BusinessType
                                }))
                              }
                              className="px-2 py-1 border border-slate-300 rounded text-xs"
                            >
                              <option value="Company">Company</option>
                              <option value="Partnership">Partnership</option>
                              <option value="Proprietorship">Proprietorship</option>
                              <option value="LLP">LLP</option>
                              <option value="Other">Other</option>
                            </select>
                          ) : (
                            <span className="text-slate-700">{c.businessType}</span>
                          )}
                        </td>

                        {/* Frequency */}
                        <td className="p-3">
                          {isEditing ? (
                            <select
                              value={editingClientForm.returnFrequency || c.returnFrequency}
                              onChange={e =>
                                setEditingClientForm(prev => ({
                                  ...prev,
                                  returnFrequency: e.target.value as ReturnFrequency
                                }))
                              }
                              className="px-2 py-1 border border-slate-300 rounded text-xs font-semibold"
                            >
                              <option value="Monthly">Monthly</option>
                              <option value="QRMP">QRMP</option>
                            </select>
                          ) : (
                            <span className="font-semibold text-slate-700">{c.returnFrequency}</span>
                          )}
                        </td>

                        {/* Status */}
                        <td className="p-3">
                          {isEditing ? (
                            <select
                              value={editingClientForm.status || c.status}
                              onChange={e =>
                                setEditingClientForm(prev => ({
                                  ...prev,
                                  status: e.target.value as ClientStatus
                                }))
                              }
                              className="px-2 py-1 border border-slate-300 rounded text-xs font-bold"
                            >
                              <option value="Active">Active</option>
                              <option value="Notice Received">Notice Received</option>
                              <option value="Onboarding">Onboarding</option>
                              <option value="Archived">Archived</option>
                            </select>
                          ) : (
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                c.status === 'Active'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : c.status === 'Notice Received'
                                  ? 'bg-rose-100 text-rose-800'
                                  : 'bg-slate-100 text-slate-700'
                              }`}
                            >
                              {c.status}
                            </span>
                          )}
                        </td>

                        {/* Actions */}
                        <td className="p-3 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {isEditing ? (
                              <>
                                <button
                                  onClick={() => handleSaveClientInline(c.id)}
                                  className="inline-flex items-center gap-1 px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-sm cursor-pointer"
                                  title="1-Click Save Changes"
                                >
                                  <Save className="w-3.5 h-3.5" />
                                  <span>Save</span>
                                </button>
                                <button
                                  onClick={handleCancelEditClient}
                                  className="p-1 hover:bg-slate-200 text-slate-500 rounded-lg text-xs cursor-pointer"
                                  title="Cancel Edit"
                                >
                                  <X className="w-4 h-4" />
                                </button>
                              </>
                            ) : (
                              <>
                                <button
                                  onClick={() => handleStartEditClient(c)}
                                  className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold transition cursor-pointer"
                                  title="1-Click Inline Edit"
                                >
                                  <Edit2 className="w-3.5 h-3.5 text-slate-600" />
                                  <span>Edit</span>
                                </button>
                                {!isSelected && (
                                  <button
                                    onClick={() => onSelectClientAndGstin(c.id, c.primaryGstin)}
                                    className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-600 hover:text-white text-emerald-700 border border-emerald-200 rounded-lg text-xs font-bold transition cursor-pointer"
                                    title="Switch active workspace to this client in 1 click"
                                  >
                                    Activate
                                  </button>
                                )}
                                <button
                                  onClick={() => handleCloneClient(c)}
                                  className="p-1 hover:bg-slate-100 text-slate-400 hover:text-slate-600 rounded cursor-pointer"
                                  title="Clone Client Template"
                                >
                                  <Copy className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => {
                                    if (confirm(`Delete client "${c.name}"?`)) {
                                      onDeleteClient(c.id);
                                      showToast(`Deleted ${c.name}`);
                                    }
                                  }}
                                  className="p-1 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                                  title="Delete Client"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* TAB: CA FIRM IDENTITY & PRACTICE SETTINGS                 */}
      {/* ========================================================= */}
      {activeTab === 'firm' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-6 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-base font-bold text-slate-900">CA Practice Profile & Firm Branding (1-Click Save)</h2>
              <p className="text-xs text-slate-500">
                Customize your Chartered Accountant firm name, FRN, partners, default return period, and reconciliation tolerances.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleSaveSettings}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition shadow-md shadow-emerald-600/20 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>1-Click Save Firm Profile</span>
              </button>
            </div>
          </div>

          {/* Quick Presets Strip */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <span className="text-xs font-bold text-slate-700">1-Click Firm Presets:</span>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <button
                onClick={() => applyPreset('CA_FIRM')}
                className="px-3 py-1.5 rounded-lg bg-white hover:bg-slate-100 text-slate-800 border border-slate-200 text-xs font-bold transition shadow-sm cursor-pointer"
              >
                Chartered Accountant Firm
              </button>
              <button
                onClick={() => applyPreset('TAX_CONSULTANT')}
                className="px-3 py-1.5 rounded-lg bg-white hover:bg-slate-100 text-slate-800 border border-slate-200 text-xs font-bold transition shadow-sm cursor-pointer"
              >
                Tax Practitioner / Advocate
              </button>
              <button
                onClick={() => applyPreset('ENTERPRISE')}
                className="px-3 py-1.5 rounded-lg bg-white hover:bg-slate-100 text-slate-800 border border-slate-200 text-xs font-bold transition shadow-sm cursor-pointer"
              >
                Corporate Advisory LLP
              </button>
            </div>
          </div>

          {/* Configuration Form Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">CA Firm / Practice Name</label>
              <input
                type="text"
                value={settings.firmName}
                onChange={e => handleSettingChange('firmName', e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-bold focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Firm Registration Number (FRN)</label>
              <input
                type="text"
                value={settings.frn}
                onChange={e => handleSettingChange('frn', e.target.value)}
                placeholder="e.g. 109824W"
                className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-mono focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Senior Partner / Authorized Signatory</label>
              <input
                type="text"
                value={settings.partnerName}
                onChange={e => handleSettingChange('partnerName', e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">ICAI Membership Number</label>
              <input
                type="text"
                value={settings.membershipNo}
                onChange={e => handleSettingChange('membershipNo', e.target.value)}
                placeholder="e.g. 049821"
                className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-mono focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Official Practice Email</label>
              <input
                type="email"
                value={settings.email}
                onChange={e => handleSettingChange('email', e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Contact Phone</label>
              <input
                type="text"
                value={settings.phone}
                onChange={e => handleSettingChange('phone', e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-mono focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">Registered Office Address</label>
              <input
                type="text"
                value={settings.address}
                onChange={e => handleSettingChange('address', e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Primary State Jurisdiction</label>
              <select
                value={settings.defaultState}
                onChange={e => handleSettingChange('defaultState', e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white"
              >
                {INDIAN_STATES.map(s => (
                  <option key={s.code} value={s.name}>
                    {s.name} ({s.code})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                2B Auto-Reconciliation Tolerance (₹ INR)
              </label>
              <div className="flex items-center gap-2">
                {[1.0, 2.0, 5.0, 10.0].map(val => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => handleSettingChange('reconciliationTolerance', val)}
                    className={`flex-1 py-2 rounded-xl text-xs font-bold border transition cursor-pointer ${
                      settings.reconciliationTolerance === val
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    ± ₹{val}
                  </button>
                ))}
              </div>
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Gemini AI API Key (for Statutory Legal Assistant)
              </label>
              <div className="relative">
                <input
                  type="password"
                  value={settings.geminiApiKey}
                  onChange={e => handleSettingChange('geminiApiKey', e.target.value)}
                  placeholder="AIzaSy... (leave blank to use server environment key)"
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl text-xs font-mono focus:ring-2 focus:ring-emerald-500 focus:outline-none pr-10"
                />
                <KeyRound className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* TAB: MASTER HSN / SAC CODES & STATUTORY RATES             */}
      {/* ========================================================= */}
      {activeTab === 'hsn' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-100">
            <div>
              <h2 className="text-base font-bold text-slate-900">Master HSN / SAC Directory (1-Click Rate Editor)</h2>
              <p className="text-xs text-slate-500">
                Official GSTN statutory codes. Modify applicable tax slabs or add custom business codes in 1 click.
              </p>
            </div>
            <button
              onClick={() => {
                adminSettingsService.resetHsnOverrides();
                setHsnOverrides({});
                showToast('Restored all statutory HSN codes to GSTN default!');
              }}
              className="px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-bold transition cursor-pointer"
            >
              Reset to Defaults
            </button>
          </div>

          {/* Quick Add Custom HSN Bar */}
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
            <div className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <Plus className="w-4 h-4 text-emerald-600" />
              <span>1-Click Add Custom HSN / SAC Code</span>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <input
                type="text"
                placeholder="HSN/SAC Code (e.g. 998314)"
                value={newHsnCode}
                onChange={e => setNewHsnCode(e.target.value)}
                className="w-36 px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs font-mono font-bold bg-white"
              />
              <input
                type="text"
                placeholder="Statutory Description..."
                value={newHsnDesc}
                onChange={e => setNewHsnDesc(e.target.value)}
                className="flex-1 min-w-[200px] px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs bg-white"
              />
              <select
                value={newHsnRate}
                onChange={e => setNewHsnRate(parseFloat(e.target.value))}
                className="px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs font-bold bg-white"
              >
                <option value="0">0%</option>
                <option value="5">5%</option>
                <option value="12">12%</option>
                <option value="18">18%</option>
                <option value="28">28%</option>
              </select>
              <button
                onClick={handleAddNewHsn}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-sm cursor-pointer"
              >
                Add Code
              </button>
            </div>
          </div>

          {/* Search Bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Filter by HSN code or description..."
              value={hsnSearch}
              onChange={e => setHsnSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* HSN Table */}
          <div className="overflow-x-auto border border-slate-200 rounded-xl max-h-[480px]">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="sticky top-0 bg-slate-100 z-10">
                <tr className="border-b border-slate-200 text-slate-700 font-bold uppercase tracking-wider text-[11px]">
                  <th className="p-3 w-28">HSN / SAC</th>
                  <th className="p-3">Statutory Description</th>
                  <th className="p-3 text-center w-24">GST Rate</th>
                  <th className="p-3 text-right w-28">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {displayHsnList.map(item => {
                  const isEditing = editingHsnCode === item.code;

                  return (
                    <tr key={item.code} className={`transition ${isEditing ? 'bg-amber-50/50' : 'hover:bg-slate-50/60'}`}>
                      <td className="p-3 font-mono font-bold text-slate-900">
                        {item.code}
                        {item.isCustom && (
                          <span className="ml-1 text-[9px] px-1.5 py-0.2 rounded bg-purple-100 text-purple-800 font-sans">
                            Custom
                          </span>
                        )}
                      </td>
                      <td className="p-3 text-slate-700">
                        {isEditing ? (
                          <input
                            type="text"
                            value={editingHsnForm.description}
                            onChange={e =>
                              setEditingHsnForm(prev => ({ ...prev, description: e.target.value }))
                            }
                            className="w-full px-2 py-1 border border-slate-300 rounded text-xs"
                          />
                        ) : (
                          item.description
                        )}
                      </td>
                      <td className="p-3 text-center">
                        {isEditing ? (
                          <select
                            value={editingHsnForm.gstRate}
                            onChange={e =>
                              setEditingHsnForm(prev => ({ ...prev, gstRate: parseFloat(e.target.value) }))
                            }
                            className="px-2 py-1 border border-slate-300 rounded text-xs font-bold"
                          >
                            <option value="0">0%</option>
                            <option value="5">5%</option>
                            <option value="12">12%</option>
                            <option value="18">18%</option>
                            <option value="28">28%</option>
                          </select>
                        ) : (
                          <span className="font-mono font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                            {item.gstRate}%
                          </span>
                        )}
                      </td>
                      <td className="p-3 text-right">
                        {isEditing ? (
                          <div className="flex items-center justify-end gap-1">
                            <button
                              onClick={() => handleSaveHsnInline(item.code)}
                              className="px-2.5 py-1 bg-emerald-600 text-white rounded text-xs font-bold cursor-pointer"
                            >
                              Save
                            </button>
                            <button
                              onClick={() => setEditingHsnCode(null)}
                              className="p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => handleStartEditHsn(item)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-xs font-semibold cursor-pointer"
                          >
                            <Edit2 className="w-3 h-3 text-slate-500" />
                            <span>Edit</span>
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* TAB: STATUTORY RULES & FEATURE TOGGLES                    */}
      {/* ========================================================= */}
      {activeTab === 'rules' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-6 shadow-sm">
          <div className="pb-3 border-b border-slate-100">
            <h2 className="text-base font-bold text-slate-900">Statutory Rules & Validation Engines (1-Click Toggles)</h2>
            <p className="text-xs text-slate-500">
              Control statutory enforcement flags across GSTR-1, GSTR-3B, ITC Section 16/17, and Reverse Charge Section 9(3)/9(4).
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 flex items-start justify-between gap-3">
              <div>
                <div className="text-xs font-bold text-slate-900">Rule 37 — 180-Day Payment ITC Reversal</div>
                <div className="text-[11px] text-slate-500 mt-1">
                  Enforces automatic ITC reversal alert if payment is not made to supplier within 180 days of invoice date.
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  const updated = !settings.strictRule37;
                  handleSettingChange('strictRule37', updated);
                  adminSettingsService.saveSettings({ strictRule37: updated });
                  showToast(`Rule 37 ${updated ? 'Enabled' : 'Disabled'}!`);
                }}
                className={`w-12 h-6 rounded-full transition relative shrink-0 cursor-pointer ${
                  settings.strictRule37 ? 'bg-emerald-600' : 'bg-slate-300'
                }`}
              >
                <span
                  className={`block w-5 h-5 rounded-full bg-white shadow transition-transform absolute top-0.5 ${
                    settings.strictRule37 ? 'translate-x-6' : 'translate-x-0.5'
                  }`}
                />
              </button>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 flex items-start justify-between gap-3">
              <div>
                <div className="text-xs font-bold text-slate-900">Section 17(5) — Blocked Credit Auto-Detection</div>
                <div className="text-[11px] text-slate-500 mt-1">
                  Automatically flags motor vehicles, food & beverages, personal consumption, and CSR expenditures.
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  const updated = !settings.autoDetect17_5;
                  handleSettingChange('autoDetect17_5', updated);
                  adminSettingsService.saveSettings({ autoDetect17_5: updated });
                  showToast(`Section 17(5) Detection ${updated ? 'Enabled' : 'Disabled'}!`);
                }}
                className={`w-12 h-6 rounded-full transition relative shrink-0 cursor-pointer ${
                  settings.autoDetect17_5 ? 'bg-emerald-600' : 'bg-slate-300'
                }`}
              >
                <span
                  className={`block w-5 h-5 rounded-full bg-white shadow transition-transform absolute top-0.5 ${
                    settings.autoDetect17_5 ? 'translate-x-6' : 'translate-x-0.5'
                  }`}
                />
              </button>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 flex items-start justify-between gap-3">
              <div>
                <div className="text-xs font-bold text-slate-900">Section 9(3)/9(4) — Reverse Charge Automation</div>
                <div className="text-[11px] text-slate-500 mt-1">
                  Auto-calculates inward tax liabilities and creates matching Table 4(A)(3) ITC claims for GTA, Legal, and Director fees.
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  const updated = !settings.autoCalculateRCM;
                  handleSettingChange('autoCalculateRCM', updated);
                  adminSettingsService.saveSettings({ autoCalculateRCM: updated });
                  showToast(`RCM Engine ${updated ? 'Enabled' : 'Disabled'}!`);
                }}
                className={`w-12 h-6 rounded-full transition relative shrink-0 cursor-pointer ${
                  settings.autoCalculateRCM ? 'bg-emerald-600' : 'bg-slate-300'
                }`}
              >
                <span
                  className={`block w-5 h-5 rounded-full bg-white shadow transition-transform absolute top-0.5 ${
                    settings.autoCalculateRCM ? 'translate-x-6' : 'translate-x-0.5'
                  }`}
                />
              </button>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 flex items-start justify-between gap-3">
              <div>
                <div className="text-xs font-bold text-slate-900">Section 16(2)(aa) — 2B Match Prerequisite</div>
                <div className="text-[11px] text-slate-500 mt-1">
                  Prevents ITC claiming in GSTR-3B Table 4(A)(5) unless the invoice appears in auto-drafted GSTR-2B.
                </div>
              </div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-800 text-xs font-bold">
                <Check className="w-3.5 h-3.5" />
                <span>Statutory Mandate</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* TAB: ONE-CLICK BACKUP / RESTORE JSON                      */}
      {/* ========================================================= */}
      {activeTab === 'backup' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-6 shadow-sm">
          <div className="pb-3 border-b border-slate-100">
            <h2 className="text-base font-bold text-slate-900">One-Click System Snapshot & JSON Migration Hub</h2>
            <p className="text-xs text-slate-500">
              Export complete practice portfolio (clients, GSTINs, registers, firm settings, and credential vault) to a single JSON file.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-5 rounded-xl border border-slate-200 bg-slate-50/60 space-y-3">
              <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
                <Download className="w-5 h-5 text-emerald-600" />
                <span>Export Complete System Database</span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Generates a JSON snapshot containing all clients, GSTINs, sales invoices, purchase invoices, GSTR-2B data, firm profile, and statutory rate overrides.
              </p>
              <button
                onClick={handleDownloadSnapshot}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-600/20 transition cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Download Database JSON Snapshot</span>
              </button>
            </div>

            <div className="p-5 rounded-xl border border-slate-200 bg-slate-50/60 space-y-3">
              <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
                <Upload className="w-5 h-5 text-blue-600" />
                <span>Restore Database from JSON</span>
              </div>
              <textarea
                rows={4}
                value={jsonImportText}
                onChange={e => setJsonImportText(e.target.value)}
                placeholder="Paste JSON snapshot content here..."
                className="w-full p-2.5 text-xs font-mono border border-slate-300 rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                onClick={handleImportJson}
                disabled={!jsonImportText.trim()}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-600/20 disabled:opacity-50 transition cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>1-Click Restore Snapshot</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
