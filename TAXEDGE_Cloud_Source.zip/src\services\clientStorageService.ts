/**
 * GST Practice AI — Multi-Client CA Practice Database & Storage
 * Manages hundreds/thousands of clients with fully isolated GST datasets
 */

import { ClientMaster, GSTINMasterEntry } from '../types/client';
import { TransactionInvoice, GSTR2BRecord, AuditLog } from '../types/gst';
import { INITIAL_SALES_REGISTER, INITIAL_PURCHASE_REGISTER, INITIAL_GSTR2B_RECORDS } from '../data/masterData';
import { credentialVaultService } from './credentialVaultService';
import { DEMO_GSTR2_CR_DR_NOTES, DEMO_GSTR1_ADVANCE_TAX, DEMO_GSTR2_ADVANCE_TAX } from './gstExcelTemplateService';

const CLIENTS_STORAGE_KEY = 'gst_practice_ai_clients_v2';
const GSTINS_STORAGE_KEY = 'gst_practice_ai_gstins_v2';
const DATA_PREFIX = 'gst_practice_ai_data_';

export const DEFAULT_PRACTICE_CLIENT: ClientMaster = {
  id: 'CLI-DELHI-01',
  name: 'Delhi Practice Taxpayer',
  tradeName: 'Practice Taxpayer',
  legalName: 'Practice Taxpayer Entity',
  pan: 'ABFFB5922Q',
  primaryGstin: '07ABFFB5922Q1Z0',
  additionalGstins: [],
  businessType: 'Company',
  state: 'Delhi',
  registeredAddress: 'Connaught Place, New Delhi 110001',
  contactPerson: 'Authorized Signatory',
  mobile: '+91 98100 00000',
  email: 'accounts@taxpayer.in',
  assignedStaff: 'CA Rahul Sharma (Partner)',
  returnFrequency: 'Monthly',
  financialYear: '2026-27',
  status: 'Active',
  notes: 'Primary Taxpayer Account',
  createdDate: '2026-04-01'
};

export const DEFAULT_PRACTICE_GSTIN: GSTINMasterEntry = {
  gstin: '07ABFFB5922Q1Z0',
  clientId: 'CLI-DELHI-01',
  legalName: 'Practice Taxpayer Entity',
  tradeName: 'Practice Taxpayer',
  state: 'Delhi',
  stateCode: '07',
  registrationDate: '2017-07-01',
  registrationStatus: 'Active',
  returnType: 'Regular',
  businessType: 'Company',
  portalUsername: 'taxpayer_delhi',
  encryptedPasswordMask: '••••••••••••',
  credentialStatus: 'CONNECTED',
  lastVerified: '2026-10-29 10:00 IST',
  lastSuccessfulLogin: '2026-10-29 10:00 IST',
  otpRequirement: false,
  apiConnectionStatus: 'AUTHORIZED_GSP',
  last2bSync: '2026-10-29 10:00 IST',
  lastGstr1Sync: '2026-10-29 10:00 IST',
  lastGstr3bSync: '2026-10-29 10:00 IST',
  status2B: 'RECONCILED',
  eligibleItc: 0,
  taxLiability: 0,
  notes: 'Delhi Head Office'
};

export const SAMPLE_DEMO_CLIENTS: ClientMaster[] = [
  {
    id: 'CLI-001',
    name: 'Apex Technologies Pvt Ltd',
    tradeName: 'Apex Technologies',
    legalName: 'Apex Technologies Private Limited',
    pan: 'AABCT3419K',
    primaryGstin: '27AABCT3419K1ZM',
    additionalGstins: ['29AABCT3419K1ZO'],
    businessType: 'Company',
    state: 'Maharashtra',
    registeredAddress: 'Level 14, Tower B, Cyber City, Bandra Kurla Complex, Mumbai 400051',
    contactPerson: 'Sunil Mehta (CFO)',
    mobile: '+91 98201 44892',
    email: 'finance@apextechnologies.in',
    assignedStaff: 'CA Rahul Sharma (Partner)',
    returnFrequency: 'Monthly',
    financialYear: '2026-27',
    status: 'Active',
    notes: 'Enterprise IT exporter with domestic consulting; SEZ & 17(5) motor vehicle checks active.',
    createdDate: '2025-04-01'
  },
  {
    id: 'CLI-002',
    name: 'Bharat Retail Chains Ltd',
    tradeName: 'Bharat Supermarket & Hypermarket',
    legalName: 'Bharat Retail Chains Limited',
    pan: 'AAACB4421R',
    primaryGstin: '07AAACB4421R1ZK',
    additionalGstins: ['06AAACB4421R1ZM'],
    businessType: 'Company',
    state: 'Delhi',
    registeredAddress: 'Plot 42, Okhla Industrial Area Phase-III, New Delhi 110020',
    contactPerson: 'Rajiv Malhotra (Head of Tax)',
    mobile: '+91 98110 55123',
    email: 'tax@bharatretail.co.in',
    assignedStaff: 'Pooja Verma (Senior Tax Analyst)',
    returnFrequency: 'Monthly',
    financialYear: '2026-27',
    status: 'Active',
    notes: 'Large FMCG & retail network. High volume B2C small and e-commerce TCS integration required.',
    createdDate: '2025-06-15'
  },
  {
    id: 'CLI-003',
    name: 'Zenith Logistics LLP',
    tradeName: 'Zenith Cargo Express',
    legalName: 'Zenith Logistics LLP',
    pan: 'AAACZ8912P',
    primaryGstin: '24AAACZ8912P1ZN',
    additionalGstins: [],
    businessType: 'LLP',
    state: 'Gujarat',
    registeredAddress: 'Transport Nagar, GIDC Naroda, Ahmedabad 382330',
    contactPerson: 'Ketan Patel (Managing Partner)',
    mobile: '+91 94270 99411',
    email: 'accounts@zenithcargo.com',
    assignedStaff: 'Vikram Patel (GST Practitioner)',
    returnFrequency: 'QRMP',
    financialYear: '2026-27',
    status: 'Active',
    notes: 'Goods Transport Agency (GTA) operating under 5% RCM reverse charge and fleet fuel ITC tracking.',
    createdDate: '2025-08-10'
  },
  {
    id: 'CLI-004',
    name: 'Vikas Exports & Trading',
    tradeName: 'Vikas Overseas Handlooms',
    legalName: 'Vikas Sundaram (Proprietor)',
    pan: 'AAACV5510Q',
    primaryGstin: '33AAACV5510Q1ZZ',
    additionalGstins: [],
    businessType: 'Proprietorship',
    state: 'Tamil Nadu',
    registeredAddress: '88 Netaji Road, Tirupur, Tamil Nadu 641601',
    contactPerson: 'Vikas Sundaram',
    mobile: '+91 94432 11099',
    email: 'vikas@handloomexport.com',
    assignedStaff: 'CA Rahul Sharma (Partner)',
    returnFrequency: 'Monthly',
    financialYear: '2026-27',
    status: 'Active',
    notes: 'Zero rated export under Letter of Undertaking (LUT) with inverted duty structure refund claim.',
    createdDate: '2025-11-20'
  }
];

export const SAMPLE_DEMO_GSTINS: GSTINMasterEntry[] = [
  {
    gstin: '27AABCT3419K1ZM',
    clientId: 'CLI-001',
    legalName: 'Apex Technologies Private Limited',
    tradeName: 'Apex Technologies MH',
    state: 'Maharashtra',
    stateCode: '27',
    registrationDate: '2017-07-01',
    registrationStatus: 'Active',
    returnType: 'Regular',
    businessType: 'Company',
    portalUsername: 'apex_tech_mh',
    encryptedPasswordMask: '••••••••••••',
    credentialStatus: 'CONNECTED',
    lastVerified: '2026-04-28 09:30 IST',
    lastSuccessfulLogin: '2026-04-28 09:30 IST',
    otpRequirement: false,
    apiConnectionStatus: 'AUTHORIZED_GSP',
    last2bSync: '2026-04-28 09:35 IST',
    lastGstr1Sync: '2026-04-28 09:40 IST',
    lastGstr3bSync: '2026-04-25 18:20 IST',
    status2B: 'RECONCILED',
    eligibleItc: 128250.00,
    taxLiability: 356400.00,
    notes: 'Maharashtra Head Office & Principal Place of Business'
  },
  {
    gstin: '29AABCT3419K1ZO',
    clientId: 'CLI-001',
    legalName: 'Apex Technologies Private Limited',
    tradeName: 'Apex Technologies KA',
    state: 'Karnataka',
    stateCode: '29',
    registrationDate: '2018-02-14',
    registrationStatus: 'Active',
    returnType: 'Regular',
    businessType: 'Company',
    portalUsername: 'apex_tech_ka',
    encryptedPasswordMask: '••••••••••••',
    credentialStatus: 'CONNECTED',
    lastVerified: '2026-04-27 14:15 IST',
    lastSuccessfulLogin: '2026-04-27 14:15 IST',
    otpRequirement: false,
    apiConnectionStatus: 'AUTHORIZED_GSP',
    last2bSync: '2026-04-27 14:20 IST',
    status2B: 'RECONCILED',
    eligibleItc: 45000.00,
    taxLiability: 112000.00,
    notes: 'Bengaluru Tech Branch Office'
  },
  {
    gstin: '07AAACB4421R1ZK',
    clientId: 'CLI-002',
    legalName: 'Bharat Retail Chains Limited',
    tradeName: 'Bharat Retail Delhi Flagship',
    state: 'Delhi',
    stateCode: '07',
    registrationDate: '2017-08-20',
    registrationStatus: 'Active',
    returnType: 'Regular',
    businessType: 'Company',
    portalUsername: 'bharat_delhi_acc',
    encryptedPasswordMask: '••••••••••••',
    credentialStatus: 'CONNECTED',
    lastVerified: '2026-04-28 11:20 IST',
    lastSuccessfulLogin: '2026-04-28 11:20 IST',
    otpRequirement: true,
    apiConnectionStatus: 'AUTHORIZED_GSP',
    last2bSync: '2026-04-28 11:30 IST',
    status2B: 'REVIEW_REQUIRED',
    eligibleItc: 214000.00,
    taxLiability: 540000.00,
    notes: 'Delhi Flagship Hypermarket'
  },
  {
    gstin: '06AAACB4421R1ZM',
    clientId: 'CLI-002',
    legalName: 'Bharat Retail Chains Limited',
    tradeName: 'Bharat Retail Haryana Warehouse',
    state: 'Haryana',
    stateCode: '06',
    registrationDate: '2019-01-10',
    registrationStatus: 'Active',
    returnType: 'Regular',
    businessType: 'Company',
    portalUsername: 'bharat_haryana_wh',
    encryptedPasswordMask: '••••••••••••',
    credentialStatus: 'NEEDS_AUTH',
    lastVerified: '2026-04-20 18:00 IST',
    otpRequirement: true,
    apiConnectionStatus: 'SANDBOX',
    status2B: 'NOT_IMPORTED',
    eligibleItc: 0,
    taxLiability: 95000.00,
    notes: 'Gurugram central warehouse'
  },
  {
    gstin: '24AAACZ8912P1ZN',
    clientId: 'CLI-003',
    legalName: 'Zenith Logistics LLP',
    tradeName: 'Zenith Logistics Gujarat',
    state: 'Gujarat',
    stateCode: '24',
    registrationDate: '2019-05-18',
    registrationStatus: 'Active',
    returnType: 'Regular',
    businessType: 'LLP',
    portalUsername: 'zenith_logistics_gj',
    encryptedPasswordMask: '••••••••••••',
    credentialStatus: 'CONNECTED',
    lastVerified: '2026-04-28 08:45 IST',
    lastSuccessfulLogin: '2026-04-28 08:45 IST',
    otpRequirement: false,
    apiConnectionStatus: 'AUTHORIZED_GSP',
    last2bSync: '2026-04-28 09:00 IST',
    status2B: 'READY_FOR_FILING',
    eligibleItc: 89000.00,
    taxLiability: 45000.00,
    notes: 'Fleet operator, RCM heavy'
  },
  {
    gstin: '33AAACV5510Q1ZZ',
    clientId: 'CLI-004',
    legalName: 'Vikas Sundaram (Proprietor)',
    tradeName: 'Vikas Overseas Handlooms',
    state: 'Tamil Nadu',
    stateCode: '33',
    registrationDate: '2020-03-01',
    registrationStatus: 'Active',
    returnType: 'Regular',
    businessType: 'Proprietorship',
    portalUsername: 'vikas_exports_tn',
    encryptedPasswordMask: '••••••••••••',
    credentialStatus: 'CONNECTED',
    lastVerified: '2026-04-26 16:30 IST',
    lastSuccessfulLogin: '2026-04-26 16:30 IST',
    otpRequirement: false,
    apiConnectionStatus: 'AUTHORIZED_GSP',
    last2bSync: '2026-04-26 16:45 IST',
    status2B: 'RECONCILED',
    eligibleItc: 67200.00,
    taxLiability: 0.00,
    notes: 'Zero rated export under LUT'
  }
];

// Clean Zero-Data Initial States (No demo client auto-loading)
export const INITIAL_CLIENTS: ClientMaster[] = [];
export const INITIAL_GSTINS: GSTINMasterEntry[] = [];

export interface ClientIsolatedData {
  sales: TransactionInvoice[];
  purchases: TransactionInvoice[];
  gstr2b: GSTR2BRecord[];
  gstr2CrDrNotes?: any[];
  gstr1AdvanceTax?: any[];
  gstr2AdvanceTax?: any[];
  auditLogs: AuditLog[];
  filingResult: any;
}

class ClientStorageService {
  private clients: ClientMaster[] = [];
  private gstins: GSTINMasterEntry[] = [];

  constructor() {
    this.loadState();
  }

  private loadState() {
    try {
      const c = localStorage.getItem(CLIENTS_STORAGE_KEY);
      this.clients = c ? JSON.parse(c) : [];

      const g = localStorage.getItem(GSTINS_STORAGE_KEY);
      this.gstins = g ? JSON.parse(g) : [];
    } catch {
      this.clients = [];
      this.gstins = [];
    }

    // Clean zero-data guarantee: Do NOT auto-inject sample/demo clients unless user explicitly clicks Load Demo
    const isDemoMode = localStorage.getItem('gst_practice_ai_demo_mode') === 'true';
    if (!isDemoMode && this.clients.some(c => c.id === 'CLI-DELHI-01' || c.id === 'CLI-001')) {
      this.clients = this.clients.filter(c => c.id !== 'CLI-DELHI-01' && c.id !== 'CLI-001');
      this.gstins = this.gstins.filter(g => g.clientId !== 'CLI-DELHI-01' && g.clientId !== 'CLI-001');
      this.persistClients();
      this.persistGstins();
    }
  }

  private persistClients() {
    try {
      localStorage.setItem(CLIENTS_STORAGE_KEY, JSON.stringify(this.clients));
    } catch {}
  }

  private persistGstins() {
    try {
      localStorage.setItem(GSTINS_STORAGE_KEY, JSON.stringify(this.gstins));
    } catch {}
  }

  public getClients(): ClientMaster[] {
    return this.clients;
  }

  public getClientById(id: string): ClientMaster | undefined {
    return this.clients.find(c => c.id === id);
  }

  public addClient(client: ClientMaster): void {
    this.clients.unshift(client);
    this.persistClients();

    // Auto-create primary GSTIN record if not already present
    if (client.primaryGstin && !this.gstins.find(g => g.gstin === client.primaryGstin)) {
      this.addGstin({
        gstin: client.primaryGstin,
        clientId: client.id,
        legalName: client.legalName,
        tradeName: client.tradeName || client.name,
        state: client.state,
        stateCode: client.primaryGstin.substring(0, 2),
        registrationDate: new Date().toISOString().split('T')[0],
        registrationStatus: 'Active',
        returnType: 'Regular',
        businessType: client.businessType,
        portalUsername: client.name.toLowerCase().replace(/[^a-z0-9]/g, '_').substring(0, 15),
        encryptedPasswordMask: '••••••••••••',
        credentialStatus: 'UNCONFIGURED',
        otpRequirement: false,
        apiConnectionStatus: 'SANDBOX',
        status2B: 'NOT_IMPORTED',
        eligibleItc: 0,
        taxLiability: 0,
        notes: `Created with client record on ${new Date().toLocaleDateString('en-IN')}`
      });
    }
  }

  public updateClient(updated: ClientMaster): void {
    const idx = this.clients.findIndex(c => c.id === updated.id);
    if (idx >= 0) {
      this.clients[idx] = updated;
      this.persistClients();
    }
  }

  public deleteClient(id: string): void {
    this.clients = this.clients.filter(c => c.id !== id);
    this.persistClients();
    this.gstins = this.gstins.filter(g => g.clientId !== id);
    this.persistGstins();
  }

  public getAllGstins(): GSTINMasterEntry[] {
    return this.gstins;
  }

  public getGstinsForClient(clientId: string): GSTINMasterEntry[] {
    return this.gstins.filter(g => g.clientId === clientId);
  }

  public addGstin(entry: GSTINMasterEntry): void {
    const clean = entry.gstin.trim().toUpperCase();
    const existing = this.gstins.findIndex(g => g.gstin === clean);
    if (existing >= 0) {
      this.gstins[existing] = { ...entry, gstin: clean };
    } else {
      this.gstins.push({ ...entry, gstin: clean });
    }
    this.persistGstins();
  }

  public updateGstin(updated: GSTINMasterEntry): void {
    const idx = this.gstins.findIndex(g => g.gstin === updated.gstin);
    if (idx >= 0) {
      this.gstins[idx] = updated;
      this.persistGstins();
    }
  }

  private dataCache: Map<string, ClientIsolatedData> = new Map();

  /**
   * Retrieves isolated client data for a specific GSTIN and return period
   */
  public getClientData(clientId: string, gstin: string, period: string = '04-2026'): ClientIsolatedData {
    const key = `${DATA_PREFIX}${clientId}_${gstin}_${period}`;

    // 1. Check in-memory cache
    if (this.dataCache.has(key)) {
      return this.dataCache.get(key)!;
    }

    // 2. Check localStorage
    try {
      const stored = localStorage.getItem(key);
      if (stored) {
        const parsed: ClientIsolatedData = JSON.parse(stored);
        this.dataCache.set(key, parsed);
        return parsed;
      }
    } catch {}

    // 3. Uninitialized: Clean Empty Workspace (No demo client auto-loading)
    const initialData: ClientIsolatedData = {
      sales: [],
      purchases: [],
      gstr2b: [],
      gstr2CrDrNotes: [],
      gstr1AdvanceTax: [],
      gstr2AdvanceTax: [],
      auditLogs: [],
      filingResult: null
    };

    this.saveClientData(clientId, gstin, period, initialData);
    return initialData;
  }

  /**
   * Returns whether Demo Mode is currently active
   */
  public isDemoModeActive(): boolean {
    try {
      return localStorage.getItem('gst_practice_ai_demo_mode') === 'true';
    } catch {
      return false;
    }
  }

  /**
   * Explicitly loads sample demo clients, GSTINs, registers, and accounting data on user confirmation
   */
  public loadDemoDataset(): void {
    this.clients = JSON.parse(JSON.stringify(SAMPLE_DEMO_CLIENTS));
    this.gstins = JSON.parse(JSON.stringify(SAMPLE_DEMO_GSTINS));
    this.persistClients();
    this.persistGstins();
    credentialVaultService.loadDemoCredentials();
    try {
      localStorage.setItem('gst_practice_ai_demo_mode', 'true');
    } catch {}

    // Initialize demo data for primary demo client
    this.restoreDemoData('CLI-001', '27AABCT3419K1ZM', '04-2026');
  }

  /**
   * Completely purges all clients, GSTINs, registers, 2B, and accounting data across localStorage
   */
  public resetAllToEmpty(): void {
    this.clients = [];
    this.gstins = [];
    this.dataCache.clear();
    this.persistClients();
    this.persistGstins();
    credentialVaultService.resetToEmpty();
    try {
      localStorage.removeItem('gst_practice_ai_demo_mode');
      const keysToRemove: string[] = [];
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && (k.startsWith(DATA_PREFIX) || k.startsWith('gst_practice_ai_acc_') || k.startsWith('gst_practice_ai_credentials_vault_'))) {
          keysToRemove.push(k);
        }
      }
      keysToRemove.forEach(k => localStorage.removeItem(k));
    } catch {}
  }

  /**
   * Persists isolated client data to both memory cache and localStorage
   */
  public saveClientData(clientId: string, gstin: string, period: string, data: ClientIsolatedData): void {
    const key = `${DATA_PREFIX}${clientId}_${gstin}_${period}`;
    this.dataCache.set(key, data);
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      console.warn('Failed to save to localStorage, using in-memory cache:', e);
    }
  }

  /**
   * Explicitly resets a client workspace to empty slate and persists immediately
   */
  public resetClientWorkspace(clientId: string, gstin: string, period: string = '04-2026'): ClientIsolatedData {
    const emptyData: ClientIsolatedData = {
      sales: [],
      purchases: [],
      gstr2b: [],
      gstr2CrDrNotes: [],
      gstr1AdvanceTax: [],
      gstr2AdvanceTax: [],
      auditLogs: [
        {
          id: `log-${Date.now()}`,
          timestamp: new Date().toISOString(),
          actor: 'Compliance Officer',
          actorRole: 'USER',
          businessGstin: gstin,
          module: 'DATA_MANAGEMENT',
          action: 'Workspace Reset: Cleared to Empty Slate',
          details: `All sales, purchases, and GSTR-2B records reset to zero for ${gstin} (${period}).`,
          payloadHash: `SHA256:${Date.now().toString(16)}`
        }
      ],
      filingResult: null
    };
    this.saveClientData(clientId, gstin, period, emptyData);
    return emptyData;
  }

  /**
   * Clears sales register and immediately persists
   */
  public clearSales(clientId: string, gstin: string, period: string = '04-2026'): ClientIsolatedData {
    const current = this.getClientData(clientId, gstin, period);
    const updated: ClientIsolatedData = {
      ...current,
      sales: [],
      filingResult: null,
      auditLogs: [
        {
          id: `log-${Date.now()}`,
          timestamp: new Date().toISOString(),
          actor: 'Finance Executive',
          actorRole: 'USER',
          businessGstin: gstin,
          module: 'SALES_REGISTER',
          action: 'Cleared Sales Register',
          details: 'Sales register cleared to zero.',
          payloadHash: `SHA256:${Date.now().toString(16)}`
        },
        ...current.auditLogs
      ]
    };
    this.saveClientData(clientId, gstin, period, updated);
    return updated;
  }

  /**
   * Clears purchase register and immediately persists
   */
  public clearPurchases(clientId: string, gstin: string, period: string = '04-2026'): ClientIsolatedData {
    const current = this.getClientData(clientId, gstin, period);
    const updated: ClientIsolatedData = {
      ...current,
      purchases: [],
      filingResult: null,
      auditLogs: [
        {
          id: `log-${Date.now()}`,
          timestamp: new Date().toISOString(),
          actor: 'Accounts Payable',
          actorRole: 'USER',
          businessGstin: gstin,
          module: 'PURCHASE_REGISTER',
          action: 'Cleared Purchase Register',
          details: 'Purchase register cleared to zero.',
          payloadHash: `SHA256:${Date.now().toString(16)}`
        },
        ...current.auditLogs
      ]
    };
    this.saveClientData(clientId, gstin, period, updated);
    return updated;
  }

  /**
   * Clears GSTR-2B statement and immediately persists
   */
  public clearGstr2b(clientId: string, gstin: string, period: string = '04-2026'): ClientIsolatedData {
    const current = this.getClientData(clientId, gstin, period);
    const updated: ClientIsolatedData = {
      ...current,
      gstr2b: [],
      filingResult: null,
      auditLogs: [
        {
          id: `log-${Date.now()}`,
          timestamp: new Date().toISOString(),
          actor: 'Tax Auditor',
          actorRole: 'USER',
          businessGstin: gstin,
          module: 'RECONCILIATION',
          action: 'Cleared GSTR-2B Statement',
          details: 'GSTR-2B statement records cleared to zero.',
          payloadHash: `SHA256:${Date.now().toString(16)}`
        },
        ...current.auditLogs
      ]
    };
    this.saveClientData(clientId, gstin, period, updated);
    return updated;
  }

  /**
   * Restores initial demo dataset for benchmark testing
   */
  public restoreDemoData(clientId: string, gstin: string, period: string = '04-2026'): ClientIsolatedData {
    const demoData: ClientIsolatedData = {
      sales: INITIAL_SALES_REGISTER,
      purchases: INITIAL_PURCHASE_REGISTER,
      gstr2b: INITIAL_GSTR2B_RECORDS,
      gstr2CrDrNotes: DEMO_GSTR2_CR_DR_NOTES,
      gstr1AdvanceTax: DEMO_GSTR1_ADVANCE_TAX,
      gstr2AdvanceTax: DEMO_GSTR2_ADVANCE_TAX,
      auditLogs: [
        {
          id: `log-${Date.now()}`,
          timestamp: new Date().toISOString(),
          actor: 'System Initialization',
          actorRole: 'SYSTEM',
          businessGstin: gstin,
          module: 'DATA_MANAGEMENT',
          action: 'Reloaded Enterprise Benchmark Dataset',
          details: 'Restored 7 sales invoices, 6 purchase invoices, and GSTR-2B statement.',
          payloadHash: `SHA256:${Date.now().toString(16)}`
        }
      ],
      filingResult: null
    };
    this.saveClientData(clientId, gstin, period, demoData);
    return demoData;
  }
}

export const clientStorageService = new ClientStorageService();
