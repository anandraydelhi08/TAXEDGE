/**
 * Business Accounting Domain Types
 * Supports Professional Invoicing, Inventory, Party Management, Payments, Expenses, E-Invoicing & E-Way Bill
 */

export interface Party {
  id: string;
  clientId: string;
  gstinReference: string;
  type: 'CUSTOMER' | 'SUPPLIER' | 'BOTH';
  name: string;
  tradeName?: string;
  gstin?: string;
  pan?: string;
  state: string;
  stateCode: string;
  address: string;
  mobile: string;
  email: string;
  openingBalance: number; // Positive = Receivable from party, Negative = Payable to party
  currentBalance: number;
  creditLimit: number;
  paymentTermsDays: number;
  notes?: string;
  createdAt: string;
}

export interface PartyLedgerEntry {
  id: string;
  partyId: string;
  clientId: string;
  gstinReference: string;
  date: string;
  particulars: string;
  voucherType: 'SALES_INVOICE' | 'PURCHASE_BILL' | 'PAYMENT_IN' | 'PAYMENT_OUT' | 'CREDIT_NOTE' | 'DEBIT_NOTE' | 'OPENING_BALANCE';
  voucherNumber: string;
  debit: number;
  credit: number;
  balance: number;
}

export type PaymentMode = 'CASH' | 'BANK_TRANSFER' | 'UPI' | 'CHEQUE' | 'CARD' | 'OTHER';

export interface PaymentRecord {
  id: string;
  clientId: string;
  gstinReference: string;
  type: 'PAYMENT_IN' | 'PAYMENT_OUT';
  partyId: string;
  partyName: string;
  date: string;
  amount: number;
  paymentMode: PaymentMode;
  referenceNumber?: string;
  linkedInvoiceNumber?: string;
  notes?: string;
  createdAt: string;
}

export type ExpenseCategory =
  | 'RENT'
  | 'ELECTRICITY'
  | 'TELEPHONE_INTERNET'
  | 'OFFICE_STATIONERY'
  | 'LOGISTICS_TRANSPORT'
  | 'PROFESSIONAL_LEGAL_FEES'
  | 'SALARIES_WAGES'
  | 'MARKETING_ADVERTISING'
  | 'REPAIRS_MAINTENANCE'
  | 'OTHER_OVERHEADS';

export interface ExpenseRecord {
  id: string;
  clientId: string;
  gstinReference: string;
  date: string;
  category: ExpenseCategory;
  partyName?: string;
  partyGstin?: string;
  taxableAmount: number;
  gstRate: number;
  cgst: number;
  sgst: number;
  igst: number;
  totalAmount: number;
  paymentMode: PaymentMode;
  isItcEligible: boolean;
  notes?: string;
  createdAt: string;
}

export interface InventoryItem {
  id: string;
  clientId: string;
  gstinReference: string;
  name: string;
  sku: string;
  hsnSac: string;
  unit: 'PCS' | 'BOX' | 'KG' | 'MTR' | 'SET' | 'LTR' | 'BAG' | 'NOS';
  purchasePrice: number;
  salePrice: number;
  gstRate: number;
  openingStock: number;
  minStockAlert: number;
  currentStock: number;
  category?: string;
  createdAt: string;
}

export interface EInvoiceRecord {
  id: string;
  clientId: string;
  gstinReference: string;
  invoiceNumber: string;
  invoiceDate: string;
  recipientGstin: string;
  recipientName: string;
  totalAmount: number;
  taxableValue: number;
  totalTax: number;
  irn?: string;
  ackNumber?: string;
  ackDate?: string;
  signedQrPayload?: string;
  status: 'PENDING' | 'GENERATED' | 'CANCELLED' | 'TEST_MODE';
  errorDetails?: string;
}

export interface EWayBillRecord {
  id: string;
  clientId: string;
  gstinReference: string;
  invoiceNumber: string;
  invoiceDate: string;
  recipientGstin: string;
  recipientName: string;
  transporterId?: string;
  transporterName?: string;
  vehicleNumber?: string;
  distanceKm: number;
  ewbNumber?: string;
  validUntil?: string;
  status: 'PENDING' | 'ACTIVE' | 'EXPIRED' | 'CANCELLED' | 'TEST_MODE';
}
