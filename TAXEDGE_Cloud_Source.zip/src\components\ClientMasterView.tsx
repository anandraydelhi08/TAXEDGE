import React, { useState, useMemo } from 'react';
import {
  Users,
  Plus,
  Search,
  Filter,
  Download,
  Upload,
  Edit2,
  Trash2,
  Building2,
  MapPin,
  Mail,
  Phone,
  Calendar,
  CheckCircle2,
  AlertTriangle,
  X,
  FileSpreadsheet,
  Check,
  Shield,
  Layers,
  ArrowRight,
  KeyRound,
  ChevronDown,
  Lock,
  Eye,
  EyeOff,
  ShieldCheck
} from 'lucide-react';
import { ClientMaster, BusinessType, ReturnFrequency, ClientStatus } from '../types/client';
import { validateGstinFormat, INDIAN_STATES } from '../data/masterData';
import { validateBulkClients, downloadBulkTemplate } from '../utils/bulkImportValidator';
import { GstPortalCredentialsSection } from './GstPortalCredentialsSection';
import { credentialVaultService } from '../services/credentialVaultService';
import { clientStorageService } from '../services/clientStorageService';

interface ClientMasterViewProps {
  clients: ClientMaster[];
  onAddClient: (client: ClientMaster) => void;
  onUpdateClient: (client: ClientMaster) => void;
  onDeleteClient: (clientId: string) => void;
  onSelectClient: (clientId: string) => void;
  onOpenDemoConfirm?: () => void;
  isDemoMode?: boolean;
}

export const ClientMasterView: React.FC<ClientMasterViewProps> = ({
  clients,
  onAddClient,
  onUpdateClient,
  onDeleteClient,
  onSelectClient,
  onOpenDemoConfirm,
  isDemoMode = false
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('ALL');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [filterStaff, setFilterStaff] = useState<string>('ALL');
  const [expandedCredGstin, setExpandedCredGstin] = useState<string | null>(null);

  // Modal States
  const [isClientModalOpen, setIsClientModalOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<ClientMaster | null>(null);
  const [isBulkModalOpen, setIsBulkModalOpen] = useState(false);
  const [bulkCsvText, setBulkCsvText] = useState('');
  const [bulkResult, setBulkResult] = useState<any>(null);

  // Client Form State
  const [formData, setFormData] = useState<Partial<ClientMaster>>({
    id: '',
    name: '',
    tradeName: '',
    legalName: '',
    pan: '',
    primaryGstin: '',
    additionalGstins: [],
    businessType: 'Company',
    state: 'Maharashtra',
    registeredAddress: '',
    contactPerson: '',
    mobile: '',
    email: '',
    assignedStaff: 'CA Rahul Sharma',
    returnFrequency: 'Monthly',
    financialYear: '2026-27',
    status: 'Active',
    notes: ''
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  // Modal Portal Credentials State
  const [modalPortalUsername, setModalPortalUsername] = useState('');
  const [modalPortalPassword, setModalPortalPassword] = useState('');
  const [modalShowPassword, setModalShowPassword] = useState(false);
  const [modalIsCredSaved, setModalIsCredSaved] = useState(false);
  const [modalCredSuccess, setModalCredSuccess] = useState(false);

  const staffOptions = ['CA Rahul Sharma', 'Pooja Verma', 'Vikram Patel', 'Ananya Deshmukh', 'Rajesh Kulkarni'];

  const filteredClients = useMemo(() => {
    return clients.filter(c => {
      const q = searchQuery.toLowerCase();
      const matchSearch =
        !q ||
        c.name.toLowerCase().includes(q) ||
        c.tradeName.toLowerCase().includes(q) ||
        c.pan.toLowerCase().includes(q) ||
        c.primaryGstin.toLowerCase().includes(q) ||
        c.contactPerson.toLowerCase().includes(q);

      const matchType = filterType === 'ALL' || c.businessType === filterType;
      const matchStatus = filterStatus === 'ALL' || c.status === filterStatus;
      const matchStaff = filterStaff === 'ALL' || c.assignedStaff === filterStaff;

      return matchSearch && matchType && matchStatus && matchStaff;
    });
  }, [clients, searchQuery, filterType, filterStatus, filterStaff]);

  const openAddModal = () => {
    setEditingClient(null);
    const nextIdNum = clients.length + 101;
    setFormData({
      id: `CLI-${nextIdNum}`,
      name: '',
      tradeName: '',
      legalName: '',
      pan: '',
      primaryGstin: '',
      additionalGstins: [],
      businessType: 'Company',
      state: 'Maharashtra',
      registeredAddress: '',
      contactPerson: '',
      mobile: '+91 ',
      email: '',
      assignedStaff: 'CA Rahul Sharma',
      returnFrequency: 'Monthly',
      financialYear: '2026-27',
      status: 'Active',
      notes: ''
    });
    setFormErrors({});
    setModalPortalUsername('');
    setModalPortalPassword('');
    setModalShowPassword(false);
    setModalIsCredSaved(false);
    setModalCredSuccess(false);
    setIsClientModalOpen(true);
  };

  const openEditModal = (client: ClientMaster) => {
    setEditingClient(client);
    setFormData({ ...client });
    setFormErrors({});
    const existingCred = credentialVaultService.getCredential(client.primaryGstin);
    if (existingCred?.portalUsername) {
      setModalPortalUsername(existingCred.portalUsername);
      setModalPortalPassword('');
      setModalIsCredSaved(true);
    } else {
      setModalPortalUsername('');
      setModalPortalPassword('');
      setModalIsCredSaved(false);
    }
    setModalShowPassword(false);
    setModalCredSuccess(false);
    setIsClientModalOpen(true);
  };

  const handleSaveClient = (e: React.FormEvent) => {
    e.preventDefault();
    const errors: Record<string, string> = {};

    if (!formData.name?.trim()) errors.name = 'Client name is required';
    if (!formData.primaryGstin?.trim()) {
      errors.primaryGstin = 'Primary GSTIN is required';
    } else {
      const gVal = validateGstinFormat(formData.primaryGstin);
      if (!gVal.valid) {
        errors.primaryGstin = gVal.error || 'Invalid GSTIN format';
      }
    }

    if (!formData.pan?.trim()) {
      errors.pan = 'PAN is required';
    } else if (formData.pan.length !== 10) {
      errors.pan = 'PAN must be 10 characters';
    }

    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }

    const payload: ClientMaster = {
      id: formData.id || `CLI-${Date.now()}`,
      name: formData.name!.trim(),
      tradeName: formData.tradeName?.trim() || formData.name!.trim(),
      legalName: formData.legalName?.trim() || formData.name!.trim(),
      pan: formData.pan!.trim().toUpperCase(),
      primaryGstin: formData.primaryGstin!.trim().toUpperCase(),
      additionalGstins: formData.additionalGstins || [],
      businessType: formData.businessType as BusinessType || 'Company',
      state: formData.state || 'Maharashtra',
      registeredAddress: formData.registeredAddress?.trim() || '',
      contactPerson: formData.contactPerson?.trim() || 'Managing Director',
      mobile: formData.mobile?.trim() || '',
      email: formData.email?.trim() || '',
      assignedStaff: formData.assignedStaff || 'CA Rahul Sharma',
      returnFrequency: formData.returnFrequency as ReturnFrequency || 'Monthly',
      financialYear: formData.financialYear || '2026-27',
      status: formData.status as ClientStatus || 'Active',
      notes: formData.notes?.trim() || '',
      createdDate: editingClient ? editingClient.createdDate : new Date().toISOString().split('T')[0]
    };

    if (editingClient) {
      onUpdateClient(payload);
    } else {
      onAddClient(payload);
    }

    // Securely link & persist GST Portal Credentials
    if (modalPortalUsername.trim() && payload.primaryGstin) {
      const saved = credentialVaultService.saveCredential({
        gstin: payload.primaryGstin,
        clientId: payload.id,
        portalUsername: modalPortalUsername.trim(),
        plainPassword: modalPortalPassword.trim() || undefined
      });

      const allGstins = clientStorageService.getAllGstins();
      const gIndex = allGstins.findIndex(g => g.gstin.trim().toUpperCase() === payload.primaryGstin.trim().toUpperCase());
      if (gIndex >= 0) {
        allGstins[gIndex].portalUsername = saved.portalUsername;
        allGstins[gIndex].encryptedPasswordMask = saved.maskedPassword;
        allGstins[gIndex].credentialStatus = saved.credentialStatus;
        allGstins[gIndex].lastVerified = saved.lastVerified;
        clientStorageService.updateGstin(allGstins[gIndex]);
      }
    }

    setIsClientModalOpen(false);
  };

  const handleQuickSaveModalCredentials = (e?: React.MouseEvent) => {
    if (e) e.preventDefault();
    const gstin = formData.primaryGstin?.trim().toUpperCase();
    if (!gstin) {
      setFormErrors(prev => ({ ...prev, primaryGstin: 'Please enter Primary GSTIN before saving credentials' }));
      return;
    }
    if (!modalPortalUsername.trim()) {
      setFormErrors(prev => ({ ...prev, portalUsername: 'GST Portal Username is required' }));
      return;
    }

    const saved = credentialVaultService.saveCredential({
      gstin: gstin,
      clientId: formData.id || 'CLI-001',
      portalUsername: modalPortalUsername.trim(),
      plainPassword: modalPortalPassword.trim() || undefined
    });

    const allGstins = clientStorageService.getAllGstins();
    const gIndex = allGstins.findIndex(g => g.gstin.trim().toUpperCase() === gstin);
    if (gIndex >= 0) {
      allGstins[gIndex].portalUsername = saved.portalUsername;
      allGstins[gIndex].encryptedPasswordMask = saved.maskedPassword;
      allGstins[gIndex].credentialStatus = saved.credentialStatus;
      allGstins[gIndex].lastVerified = saved.lastVerified;
      clientStorageService.updateGstin(allGstins[gIndex]);
    }

    setModalIsCredSaved(true);
    setModalPortalPassword('');
    setModalShowPassword(false);
    setModalCredSuccess(true);
    setTimeout(() => setModalCredSuccess(false), 3000);
  };

  const handleExportClientsCsv = () => {
    const headers = [
      'Client ID',
      'Client Name',
      'Trade Name',
      'Legal Name',
      'PAN',
      'Primary GSTIN',
      'Business Type',
      'State',
      'Return Frequency',
      'Assigned Staff',
      'Contact Person',
      'Mobile',
      'Email',
      'Status'
    ];

    const rows = clients.map(c => [
      c.id,
      `"${c.name.replace(/"/g, '""')}"`,
      `"${c.tradeName.replace(/"/g, '""')}"`,
      `"${c.legalName.replace(/"/g, '""')}"`,
      c.pan,
      c.primaryGstin,
      c.businessType,
      c.state,
      c.returnFrequency,
      `"${c.assignedStaff}"`,
      `"${c.contactPerson}"`,
      c.mobile,
      c.email,
      c.status
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(r => r.join(','))].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `client_master_export_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleExecuteBulkImport = () => {
    const res = validateBulkClients(bulkCsvText, clients);
    setBulkResult(res);

    if (res.validClients.length > 0) {
      for (const c of res.validClients) {
        onAddClient(c);
      }
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Title & Top Action Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-[#E5E7EB] shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-[#176B4D]/10 border border-[#176B4D]/30 text-[#176B4D]">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-[#202124] tracking-tight flex items-center gap-2">
              Client Master Database
              <span className="text-xs px-2 py-0.5 rounded-full bg-[#176B4D]/20 text-[#176B4D] font-mono">
                {clients.length} Total Clients
              </span>
            </h1>
            <p className="text-xs text-[#6B7280]">
              Manage multi-entity taxpayer profiles, registered addresses, assigned CA staff, and return frequencies
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => {
              downloadBulkTemplate('CLIENT_MASTER');
            }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-[#E8F5EF] border border-[#176B4D]/40 text-[#176B4D] font-bold shadow-sm text-xs font-semibold shadow-sm transition"
          >
            <Download className="w-3.5 h-3.5 text-[#176B4D]" />
            <span>Download CSV Template</span>
          </button>

          <button
            onClick={() => {
              setBulkResult(null);
              setBulkCsvText('');
              setIsBulkModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white hover:bg-[#E8F5EF] border border-[#176B4D]/40 text-[#176B4D] font-bold shadow-sm text-xs font-semibold shadow-sm transition"
          >
            <Upload className="w-3.5 h-3.5 text-[#176B4D]" />
            <span>Bulk Import Clients</span>
          </button>

          <button
            onClick={handleExportClientsCsv}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-[#E8F5EF] border border-[#176B4D]/40 text-[#176B4D] font-bold shadow-sm text-xs font-bold shadow-sm transition"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-[#176B4D]" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={openAddModal}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#176B4D] hover:bg-[#12543B] text-white font-bold text-xs shadow-sm transition transform active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Add New Client</span>
          </button>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="p-4 rounded-xl bg-white border border-[#E5E7EB] flex flex-wrap items-center justify-between gap-3">
        <div className="flex-1 min-w-[260px] relative">
          <Search className="w-4 h-4 text-[#176B4D] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search by Client Name, PAN, Primary GSTIN, Contact..."
            className="w-full pl-9 pr-4 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-xs text-[#202124] placeholder-[#6B7280] focus:outline-none focus:border-[#176B4D]/30"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Entity Type */}
          <div className="flex items-center gap-1.5 text-xs text-[#6B7280] bg-[#F8F9FA] px-2.5 py-1.5 rounded-lg border border-[#E5E7EB]">
            <select
              value={filterType}
              onChange={e => setFilterType(e.target.value)}
              className="bg-transparent text-[#202124] text-xs focus:outline-none cursor-pointer"
            >
              <option value="ALL" className="bg-white">All Entity Types</option>
              <option value="Company" className="bg-white">Company</option>
              <option value="Partnership" className="bg-white">Partnership</option>
              <option value="LLP" className="bg-white">LLP</option>
              <option value="Proprietorship" className="bg-white">Proprietorship</option>
            </select>
          </div>

          {/* Assigned Staff */}
          <div className="flex items-center gap-1.5 text-xs text-[#6B7280] bg-[#F8F9FA] px-2.5 py-1.5 rounded-lg border border-[#E5E7EB]">
            <select
              value={filterStaff}
              onChange={e => setFilterStaff(e.target.value)}
              className="bg-transparent text-[#202124] text-xs focus:outline-none cursor-pointer"
            >
              <option value="ALL" className="bg-white">All Assigned Staff</option>
              {staffOptions.map(s => (
                <option key={s} value={s} className="bg-white">{s}</option>
              ))}
            </select>
          </div>

          {/* Status */}
          <div className="flex items-center gap-1.5 text-xs text-[#6B7280] bg-[#F8F9FA] px-2.5 py-1.5 rounded-lg border border-[#E5E7EB]">
            <select
              value={filterStatus}
              onChange={e => setFilterStatus(e.target.value)}
              className="bg-transparent text-[#202124] text-xs focus:outline-none cursor-pointer"
            >
              <option value="ALL" className="bg-white">All Statuses</option>
              <option value="Active" className="bg-white">Active</option>
              <option value="Archived" className="bg-white">Archived</option>
              <option value="Notice Received" className="bg-white">Notice Received</option>
            </select>
          </div>
        </div>
      </div>

      {/* Clients Grid / Cards or Empty State */}
      {filteredClients.length === 0 ? (
        <div className="p-12 rounded-2xl bg-white border border-[#E5E7EB] text-center space-y-4">
          <div className="w-12 h-12 rounded-xl bg-[#F8F9FA] border border-[#E5E7EB] text-[#6B7280] flex items-center justify-center mx-auto">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-[#202124]">No clients added yet</h3>
            <p className="text-xs text-[#6B7280] mt-1 max-w-sm mx-auto">
              Add your first client to create an isolated GSTIN workspace, or load sample demo data to explore the multi-client features.
            </p>
          </div>
          <div className="flex items-center justify-center gap-2 pt-2">
            <button
              onClick={openAddModal}
              className="px-4 py-2 rounded-xl bg-[#176B4D] hover:bg-[#176B4D] text-slate-950 font-bold text-xs shadow-md transition flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Add Your First Client</span>
            </button>
            {onOpenDemoConfirm && (
              <button
                onClick={onOpenDemoConfirm}
                className="px-4 py-2 rounded-xl bg-[#F8F9FA] hover:bg-slate-700 text-[#B7791F] font-bold text-xs border border-[#E5E7EB] transition"
              >
                Load Demo Data
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredClients.map(client => (
          <div
            key={client.id}
            className="p-5 rounded-2xl bg-white border border-[#E5E7EB] hover:border-[#E5E7EB] transition flex flex-col justify-between space-y-4 shadow-lg group"
          >
            <div>
              {/* Header Row */}
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#F8F9FA] border border-[#E5E7EB] flex items-center justify-center font-bold text-[#202124] font-mono text-sm group-hover:border-[#176B4D]/30 transition">
                    {client.id.split('-')[1] || '01'}
                  </div>
                  <div>
                    <h3 className="font-bold text-base text-[#202124] group-hover:text-[#176B4D] transition">
                      {client.name}
                    </h3>
                    <div className="text-xs text-[#6B7280] flex items-center gap-2">
                      <span>{client.tradeName || client.legalName}</span>
                      <span>•</span>
                      <span className="font-mono text-[#176B4D] font-semibold">{client.businessType}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => openEditModal(client)}
                    className="p-1.5 rounded-lg text-[#6B7280] hover:text-white hover:bg-[#F8F9FA] transition"
                    title="Edit Client"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onDeleteClient(client.id)}
                    className="p-1.5 rounded-lg text-[#6B7280] hover:text-[#C62828] hover:bg-[#F8F9FA] transition"
                    title="Delete / Archive Client"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Badges & Key Identifiers */}
              <div className="mt-3.5 flex flex-wrap items-center gap-2 text-xs">
                <div className="bg-[#F8F9FA] px-2 py-0.5 rounded text-[#176B4D] font-mono font-semibold">
                  GSTIN: {client.primaryGstin}
                </div>
                <div className="bg-[#F8F9FA] px-2 py-0.5 rounded text-[#6B7280] font-mono">
                  PAN: {client.pan}
                </div>
                <div className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                  client.returnFrequency === 'Monthly' ? 'bg-[#176B4D]/10 text-[#176B4D] border border-[#176B4D]/30' : 'bg-purple-500/10 text-purple-300 border border-purple-500/20'
                }`}>
                  {client.returnFrequency} Return
                </div>
                <div className="bg-[#F8F9FA] px-2 py-0.5 rounded text-[#6B7280] flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-[#6B7280]" />
                  <span>{client.state}</span>
                </div>
              </div>

              {/* Contact & Staff Row */}
              <div className="mt-3 pt-3 border-t border-[#E5E7EB] grid grid-cols-2 gap-2 text-xs text-[#6B7280]">
                <div className="space-y-0.5">
                  <div className="text-[10px] uppercase font-semibold text-[#6B7280]">Contact</div>
                  <div className="text-[#6B7280] truncate">{client.contactPerson}</div>
                  <div className="text-[11px] text-[#6B7280] font-mono">{client.mobile || 'No mobile'}</div>
                </div>
                <div className="space-y-0.5">
                  <div className="text-[10px] uppercase font-semibold text-[#6B7280]">CA Staff Assigned</div>
                  <div className="text-[#6B7280] font-medium truncate">{client.assignedStaff}</div>
                  <div className="text-[11px] text-[#6B7280] truncate">{client.email}</div>
                </div>
              </div>

              {client.notes && (
                <div className="mt-2.5 p-2 rounded-lg bg-[#FFFFFF]/60 text-[11px] text-[#6B7280] border border-[#E5E7EB]">
                  <span className="font-semibold text-[#6B7280]">Notes: </span>
                  {client.notes}
                </div>
              )}

              {/* Inside each GSTIN: GST Portal Credentials Section */}
              <div className="mt-2.5 pt-2.5 border-t border-[#E5E7EB] space-y-2">
                <div>
                  <button
                    type="button"
                    onClick={() => setExpandedCredGstin(expandedCredGstin === client.primaryGstin ? null : client.primaryGstin)}
                    className="w-full flex items-center justify-between text-xs py-1.5 px-2.5 rounded-lg bg-[#FFFFFF]/70 hover:bg-[#F8F9FA] border border-[#E5E7EB] text-[#6B7280] transition"
                  >
                    <div className="flex items-center gap-2">
                      <KeyRound className="w-3.5 h-3.5 text-[#B7791F]" />
                      <span className="font-semibold text-[#202124]">GST Portal Credentials</span>
                      <span className="font-mono text-[10px] text-[#176B4D] font-bold">({client.primaryGstin})</span>
                    </div>
                    <div className="flex items-center gap-1 text-[11px] text-[#6B7280] font-medium">
                      <span>{expandedCredGstin === client.primaryGstin ? 'Hide' : 'Configure / View'}</span>
                      <ChevronDown className={`w-3.5 h-3.5 transition-transform ${expandedCredGstin === client.primaryGstin ? 'rotate-180' : ''}`} />
                    </div>
                  </button>

                  {expandedCredGstin === client.primaryGstin && (
                    <div className="mt-2">
                      <GstPortalCredentialsSection
                        gstin={client.primaryGstin}
                        clientId={client.id}
                        compact={true}
                      />
                    </div>
                  )}
                </div>

                {client.additionalGstins && client.additionalGstins.map(addGstin => (
                  <div key={addGstin}>
                    <button
                      type="button"
                      onClick={() => setExpandedCredGstin(expandedCredGstin === addGstin ? null : addGstin)}
                      className="w-full flex items-center justify-between text-xs py-1.5 px-2.5 rounded-lg bg-[#FFFFFF]/70 hover:bg-[#F8F9FA] border border-[#E5E7EB] text-[#6B7280] transition"
                    >
                      <div className="flex items-center gap-2">
                        <KeyRound className="w-3.5 h-3.5 text-[#B7791F]" />
                        <span className="font-semibold text-[#202124]">GST Portal Credentials</span>
                        <span className="font-mono text-[10px] text-[#176B4D] font-bold">({addGstin})</span>
                      </div>
                      <div className="flex items-center gap-1 text-[11px] text-[#6B7280] font-medium">
                        <span>{expandedCredGstin === addGstin ? 'Hide' : 'Configure / View'}</span>
                        <ChevronDown className={`w-3.5 h-3.5 transition-transform ${expandedCredGstin === addGstin ? 'rotate-180' : ''}`} />
                      </div>
                    </button>

                    {expandedCredGstin === addGstin && (
                      <div className="mt-2">
                        <GstPortalCredentialsSection
                          gstin={addGstin}
                          clientId={client.id}
                          compact={true}
                        />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Bottom Open CTA */}
            <div className="pt-2 flex items-center justify-between border-t border-[#E5E7EB]">
              <span className="text-[10px] text-[#6B7280]">
                Created on {client.createdDate}
              </span>
              <button
                onClick={() => onSelectClient(client.id)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#176B4D]/10 hover:bg-[#176B4D]/20 border border-[#176B4D]/30 text-[#176B4D] text-xs font-semibold transition"
              >
                <span>Select & Switch Client</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        ))}
      </div>
      )}

      {/* Add / Edit Client Modal */}
      {isClientModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#FFFFFF]/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border border-[#E5E7EB] rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
              <h2 className="text-base font-bold text-[#202124]">
                {editingClient ? `Edit Client: ${editingClient.name}` : 'Add New Client Master Record'}
              </h2>
              <button
                onClick={() => setIsClientModalOpen(false)}
                className="text-[#6B7280] hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveClient} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#6B7280] font-semibold mb-1">Client ID</label>
                  <input
                    type="text"
                    value={formData.id}
                    onChange={e => setFormData({ ...formData, id: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-[#202124] font-mono"
                    placeholder="CLI-001"
                  />
                </div>
                <div>
                  <label className="block text-[#6B7280] font-semibold mb-1">Display Client Name *</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-[#202124]"
                    placeholder="e.g. Apex Technologies Pvt Ltd"
                  />
                  {formErrors.name && <p className="text-[#C62828] text-[10px] mt-0.5">{formErrors.name}</p>}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#6B7280] font-semibold mb-1">Legal Name</label>
                  <input
                    type="text"
                    value={formData.legalName}
                    onChange={e => setFormData({ ...formData, legalName: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-[#202124]"
                    placeholder="Official Registration Legal Name"
                  />
                </div>
                <div>
                  <label className="block text-[#6B7280] font-semibold mb-1">Trade Name</label>
                  <input
                    type="text"
                    value={formData.tradeName}
                    onChange={e => setFormData({ ...formData, tradeName: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-[#202124]"
                    placeholder="Brand / Commercial Trade Name"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#6B7280] font-semibold mb-1">Primary GSTIN *</label>
                  <input
                    type="text"
                    value={formData.primaryGstin}
                    onChange={e => {
                      const val = e.target.value.toUpperCase();
                      const panGuess = val.length >= 12 ? val.substring(2, 12) : formData.pan;
                      setFormData({ ...formData, primaryGstin: val, pan: panGuess });
                    }}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-[#202124] font-mono"
                    placeholder="27AABCT3419K1ZM"
                  />
                  {formErrors.primaryGstin && <p className="text-[#C62828] text-[10px] mt-0.5">{formErrors.primaryGstin}</p>}
                </div>
                <div>
                  <label className="block text-[#6B7280] font-semibold mb-1">Entity PAN *</label>
                  <input
                    type="text"
                    value={formData.pan}
                    onChange={e => setFormData({ ...formData, pan: e.target.value.toUpperCase() })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-[#202124] font-mono"
                    placeholder="AABCT3419K"
                  />
                  {formErrors.pan && <p className="text-[#C62828] text-[10px] mt-0.5">{formErrors.pan}</p>}
                </div>
              </div>

              {/* Inside GSTIN: GST Portal Credentials Section */}
              <div className="p-4 rounded-xl bg-[#FFFFFF]/80 border border-[#E5E7EB] space-y-3">
                <div className="flex items-center justify-between border-b border-[#E5E7EB] pb-2">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-lg bg-[#FFF8E1] text-[#B7791F] border border-amber-500/20 text-[#B7791F]">
                      <KeyRound className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-[#202124] flex items-center gap-1.5">
                        <span>GST Portal Credentials</span>
                        {formData.primaryGstin && (
                          <span className="font-mono text-[11px] text-[#176B4D] font-semibold">({formData.primaryGstin})</span>
                        )}
                      </h4>
                      <p className="text-[10px] text-[#6B7280]">
                        Encrypted credentials vault for automated 2B retrieval & return filing
                      </p>
                    </div>
                  </div>

                  {modalIsCredSaved ? (
                    <div className="flex items-center gap-1.5">
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-[#176B4D]/10 text-[#176B4D] border border-[#176B4D]/30">
                        <ShieldCheck className="w-3 h-3 text-[#176B4D]" />
                        Saved & Masked
                      </span>
                      <button
                        type="button"
                        onClick={() => setModalIsCredSaved(false)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white hover:bg-[#E8F5EF] text-[#176B4D] border border-[#176B4D]/40 font-bold shadow-sm text-[11px] font-semibold transition"
                        title="Edit or change GST portal username or password"
                      >
                        <Edit2 className="w-3 h-3 text-[#6B7280]" />
                        <span>Edit / Change Credentials</span>
                      </button>
                    </div>
                  ) : (
                    <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-[#F8F9FA] text-[#6B7280] border border-[#E5E7EB]">
                      Portal Login
                    </span>
                  )}
                </div>

                {modalCredSuccess && (
                  <div className="p-2 rounded-lg bg-[#176B4D]/10 border border-[#176B4D]/30 text-[#176B4D] text-xs flex items-center gap-2">
                    <Check className="w-4 h-4 text-[#176B4D] shrink-0" />
                    <span>Credentials saved securely and password encrypted.</span>
                  </div>
                )}

                {modalIsCredSaved ? (
                  /* Saved View: Masked password, never plaintext */
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 text-xs">
                    <div className="p-2.5 rounded-lg bg-white border border-[#E5E7EB]">
                      <span className="block text-[10px] uppercase font-semibold text-[#6B7280] mb-0.5">
                        GST Portal Username
                      </span>
                      <span className="font-mono font-medium text-[#202124] select-all">
                        {modalPortalUsername || 'Not configured'}
                      </span>
                    </div>

                    <div className="p-2.5 rounded-lg bg-white border border-[#E5E7EB]">
                      <span className="block text-[10px] uppercase font-semibold text-[#6B7280] mb-0.5">
                        GST Portal Password
                      </span>
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-[#6B7280] tracking-wider font-bold">
                          ••••••••••••
                        </span>
                        <span className="text-[10px] font-semibold text-[#176B4D] flex items-center gap-1">
                          <Lock className="w-3 h-3" />
                          Encrypted at rest
                        </span>
                      </div>
                    </div>
                  </div>
                ) : (
                  /* Entry Form */
                  <div className="space-y-3 pt-1 text-xs">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] font-semibold text-[#6B7280] mb-1">
                          GST Portal Username
                        </label>
                        <input
                          type="text"
                          value={modalPortalUsername}
                          onChange={e => {
                            setModalPortalUsername(e.target.value);
                            if (formErrors.portalUsername) {
                              setFormErrors(prev => ({ ...prev, portalUsername: '' }));
                            }
                          }}
                          placeholder="e.g. taxpayer_portal_id"
                          className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-[#202124] font-mono placeholder-slate-500 focus:outline-none focus:border-[#176B4D]/30 text-xs"
                        />
                        {formErrors.portalUsername && (
                          <p className="text-[#C62828] text-[10px] mt-0.5">{formErrors.portalUsername}</p>
                        )}
                      </div>

                      <div>
                        <label className="block text-[11px] font-semibold text-[#6B7280] mb-1">
                          GST Portal Password {modalPortalUsername && <span className="text-[#6B7280] text-[10px] font-normal">(Optional on setup)</span>}
                        </label>
                        <div className="relative">
                          <input
                            type={modalShowPassword ? 'text' : 'password'}
                            value={modalPortalPassword}
                            onChange={e => {
                              setModalPortalPassword(e.target.value);
                              if (formErrors.portalPassword) {
                                setFormErrors(prev => ({ ...prev, portalPassword: '' }));
                              }
                            }}
                            placeholder="Enter GST portal password"
                            className="w-full pl-3 pr-9 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-[#202124] font-mono placeholder-slate-500 focus:outline-none focus:border-[#176B4D]/30 text-xs"
                          />
                          <button
                            type="button"
                            onClick={() => setModalShowPassword(!modalShowPassword)}
                            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#6B7280] hover:text-white transition p-0.5"
                            title={modalShowPassword ? 'Hide password' : 'Show password'}
                          >
                            {modalShowPassword ? <EyeOff className="w-4 h-4 text-[#6B7280]" /> : <Eye className="w-4 h-4 text-[#176B4D]" />}
                          </button>
                        </div>
                        {formErrors.portalPassword && (
                          <p className="text-[#C62828] text-[10px] mt-0.5">{formErrors.portalPassword}</p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-1">
                      <span className="text-[10px] text-[#6B7280]">
                        Password is encrypted at rest and will remain masked after saving.
                      </span>
                      {modalPortalUsername.trim() && (
                        <button
                          type="button"
                          onClick={handleQuickSaveModalCredentials}
                          className="px-3.5 py-1.5 rounded-lg bg-[#176B4D] hover:bg-[#176B4D] text-slate-950 font-bold text-xs shadow-md transition flex items-center gap-1.5 active:scale-95"
                        >
                          <Lock className="w-3.5 h-3.5" />
                          <span>Save Credentials</span>
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-[#6B7280] font-semibold mb-1">Business Type</label>
                  <select
                    value={formData.businessType}
                    onChange={e => setFormData({ ...formData, businessType: e.target.value as BusinessType })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-[#202124]"
                  >
                    <option value="Company">Company</option>
                    <option value="Partnership">Partnership</option>
                    <option value="Proprietorship">Proprietorship</option>
                    <option value="LLP">LLP</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[#6B7280] font-semibold mb-1">State</label>
                  <select
                    value={formData.state}
                    onChange={e => setFormData({ ...formData, state: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-[#202124]"
                  >
                    {INDIAN_STATES.map(s => (
                      <option key={s.code} value={s.name}>{s.name} ({s.code})</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[#6B7280] font-semibold mb-1">Return Frequency</label>
                  <select
                    value={formData.returnFrequency}
                    onChange={e => setFormData({ ...formData, returnFrequency: e.target.value as ReturnFrequency })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-[#202124]"
                  >
                    <option value="Monthly">Monthly</option>
                    <option value="QRMP">QRMP (Quarterly)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-[#6B7280] font-semibold mb-1">Assigned CA/Staff</label>
                  <select
                    value={formData.assignedStaff}
                    onChange={e => setFormData({ ...formData, assignedStaff: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-[#202124]"
                  >
                    {staffOptions.map(s => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[#6B7280] font-semibold mb-1">Contact Person</label>
                  <input
                    type="text"
                    value={formData.contactPerson}
                    onChange={e => setFormData({ ...formData, contactPerson: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-[#202124]"
                    placeholder="Director / CFO Name"
                  />
                </div>
                <div>
                  <label className="block text-[#6B7280] font-semibold mb-1">Mobile / Phone</label>
                  <input
                    type="text"
                    value={formData.mobile}
                    onChange={e => setFormData({ ...formData, mobile: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-[#202124] font-mono"
                    placeholder="+91 98200 00000"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[#6B7280] font-semibold mb-1">Official Email Address</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={e => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-[#202124]"
                  placeholder="accounts@taxclient.in"
                />
              </div>

              <div>
                <label className="block text-[#6B7280] font-semibold mb-1">Compliance Notes</label>
                <textarea
                  rows={2}
                  value={formData.notes}
                  onChange={e => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-[#F8F9FA] border border-[#E5E7EB] text-[#202124]"
                  placeholder="Special instructions, e.g. RCM applicability, SEZ unit status, or LUT validity"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-[#E5E7EB]">
                <button
                  type="button"
                  onClick={() => setIsClientModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-[#F8F9FA] hover:bg-slate-700 text-[#6B7280] font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-[#176B4D] hover:bg-[#12543B] text-white font-bold shadow-md shadow-emerald-900/30"
                >
                  {editingClient ? 'Save Changes' : 'Create Client Record'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Bulk Import Modal */}
      {isBulkModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#FFFFFF]/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border border-[#E5E7EB] rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
              <div className="flex items-center gap-2">
                <Upload className="w-5 h-5 text-[#176B4D]" />
                <h2 className="text-base font-bold text-[#202124]">Bulk Client Master Import (CSV / Excel)</h2>
              </div>
              <button
                onClick={() => setIsBulkModalOpen(false)}
                className="text-[#6B7280] hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-[#6B7280]">
                Paste your CSV content or load sample rows. Every row is strictly validated against PAN & GSTIN checksum rules.
              </p>

              <div className="flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => {
                    const sample = [
                      'Client ID,Client Name,Legal Name,PAN,Primary GSTIN,State,Business Type,Return Frequency,Assigned Staff,Contact Person,Mobile,Email,Status',
                      'CLI-201,Sunrise Logistics Ltd,Sunrise Logistics Private Limited,AAACS8910M,27AAACS8910M1Z2,Maharashtra,Company,Monthly,CA Rahul Sharma,Rajesh Kulkarni,+91 98200 12345,finance@sunrise.in,Active',
                      'CLI-202,Kaveri Spinning Mills,Kaveri Spinning Mills LLP,AAACK4411Q,33AAACK4411Q1ZN,Tamil Nadu,LLP,Monthly,Pooja Verma,S. Meenakshi,+91 94440 67890,accounts@kaveri.in,Active',
                      'CLI-203,Gupta Electricals,Ramesh Gupta (Proprietor),AABHG1234R,07AABHG1234R1ZP,Delhi,Proprietorship,QRMP,Vikram Patel,Ramesh Gupta,+91 98101 99887,gupta.elec@gmail.com,Active'
                    ].join('\n');
                    setBulkCsvText(sample);
                  }}
                  className="px-2.5 py-1 rounded bg-[#F8F9FA] text-[#6B7280] hover:bg-slate-700 font-semibold"
                >
                  Load 3 Sample Rows
                </button>

                <button
                  type="button"
                  onClick={() => downloadBulkTemplate('CLIENT_MASTER')}
                  className="text-[#6B7280] hover:text-[#202124] flex items-center gap-1"
                >
                  <Download className="w-3 h-3 text-[#176B4D]" />
                  Download Empty Template (.CSV)
                </button>
              </div>

              <textarea
                rows={7}
                value={bulkCsvText}
                onChange={e => setBulkCsvText(e.target.value)}
                placeholder="Client ID,Client Name,Legal Name,PAN,Primary GSTIN,State,Business Type,Return Frequency,Assigned Staff,Contact Person,Mobile,Email,Status..."
                className="w-full p-3 rounded-xl bg-[#FFFFFF] font-mono text-[11px] text-[#6B7280] border border-[#E5E7EB] focus:outline-none focus:border-[#176B4D]/30"
              />

              {bulkResult && (
                <div className="p-4 rounded-xl bg-[#FFFFFF] border border-[#E5E7EB] space-y-2">
                  <div className="font-semibold text-[#202124] flex items-center justify-between">
                    <span>Validation Summary</span>
                    <span className="text-[#6B7280]">Total Rows: {bulkResult.result.totalRows}</span>
                  </div>
                  <div className="grid grid-cols-4 gap-2 text-center text-xs">
                    <div className="p-2 rounded bg-[#176B4D]/10 text-[#176B4D] border border-[#176B4D]/30">
                      <div className="font-bold text-base">{bulkResult.result.imported}</div>
                      <div className="text-[10px]">Imported</div>
                    </div>
                    <div className="p-2 rounded bg-[#FDECEC] text-[#C62828] text-[#C62828] border border-rose-500/20">
                      <div className="font-bold text-base">{bulkResult.result.failed}</div>
                      <div className="text-[10px]">Failed</div>
                    </div>
                    <div className="p-2 rounded bg-[#FFF8E1] text-[#B7791F] text-[#B7791F] border border-amber-500/20">
                      <div className="font-bold text-base">{bulkResult.result.duplicates}</div>
                      <div className="text-[10px]">Duplicates</div>
                    </div>
                    <div className="p-2 rounded bg-purple-500/10 text-purple-400 border border-purple-500/20">
                      <div className="font-bold text-base">{bulkResult.result.invalidGstin}</div>
                      <div className="text-[10px]">Invalid GSTIN</div>
                    </div>
                  </div>

                  {bulkResult.result.errors.length > 0 && (
                    <div className="mt-2 space-y-1 max-h-32 overflow-y-auto">
                      {bulkResult.result.errors.map((err: any, idx: number) => (
                        <div key={idx} className="text-[11px] text-rose-300 flex items-start gap-1">
                          <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5 text-[#C62828]" />
                          <span>
                            <strong>Row {err.row} ({err.identifier}):</strong> {err.reason}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-[#E5E7EB]">
                <button
                  type="button"
                  onClick={() => setIsBulkModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-[#F8F9FA] hover:bg-slate-700 text-[#6B7280] font-medium"
                >
                  Close
                </button>
                <button
                  type="button"
                  onClick={handleExecuteBulkImport}
                  className="px-5 py-2 rounded-lg bg-[#176B4D] hover:bg-[#12543B] text-white font-bold shadow-md"
                >
                  Validate & Import Rows
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
