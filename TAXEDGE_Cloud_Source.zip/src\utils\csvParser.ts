/**
 * CSV / Data Importer & Exporter Utility
 * Supports Sales Invoices, Purchase Invoices, GSTR-2B Records, and E-Commerce Reports
 * Includes Sample Templates Generator
 */

import { TransactionInvoice, GSTR2BRecord, ECommerceReport, DocumentType, GSTClassification } from '../types/gst';
import { calculateDeterministicTax } from './taxMath';
import { INDIAN_STATES } from '../data/masterData';
import { itcEngine } from '../services/itcEngine';
import { rcmEngine } from '../services/rcmEngine';
import { computeReturnPeriod } from '../services/returnPeriodService';
import { gstPortalCsvEngine, detectDelimiter, extractPosCode } from '../services/gstPortalCsvService';
import { gstExcelTemplateService } from '../services/gstExcelTemplateService';
import * as XLSX from 'xlsx';

export { detectDelimiter };

const DEFAULT_ENTITY = {
  gstin: '07ABFFB5922Q1Z0',
  legalName: 'Practice Taxpayer Entity',
  state: 'Delhi',
  stateCode: '07'
};

// Multi-delimiter CSV/TSV line splitter handling quoted strings, tabs (\t), semicolons (;), pipes (|), and commas (,)
export function parseCsvRows(csvText: string, explicitDelimiter?: string): string[][] {
  const delimiter = explicitDelimiter || detectDelimiter(csvText);
  const lines = csvText.split(/\r\n|\r|\n/).filter(line => line.trim().length > 0);
  return lines.map(line => {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;

    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"' || char === "'") {
        inQuotes = !inQuotes;
      } else if (char === delimiter && !inQuotes) {
        result.push(current.trim().replace(/^["']|["']$/g, ''));
        current = '';
      } else {
        current += char;
      }
    }
    result.push(current.trim().replace(/^["']|["']$/g, ''));
    return result;
  });
}

// Download helper (with UTF-8 BOM for Microsoft Excel compatibility)
export function triggerFileDownload(content: string, filename: string, mimeType = 'text/csv;charset=utf-8;') {
  const bom = '\uFEFF';
  const blob = new Blob([bom + content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// ==========================================
// 1. SAMPLE TEMPLATES (Official GST Portal Templates)
// ==========================================

export function getOfficialGstPortalB2bSample(): string {
  return [
    'GSTIN/UIN of Recipient,Receiver Name,Invoice Number,Invoice date,Invoice Value,Place Of Supply,Reverse Charge,Applicable % of Tax Rate,Invoice Type,E-Commerce GSTIN,Rate,Taxable Value,Cess Amount',
    '07AAAAA0000A1Z5,Apex Technologies Private Limited,INV/2026/001,15-Oct-26,413000.00,07-Delhi,N,,Regular B2B,,18,350000.00,0',
    '27AABCT3419K1ZM,Godrej Infotech Solutions Ltd,INV/2026/002,18-Oct-26,118000.00,27-Maharashtra,N,,Regular B2B,,18,100000.00,0'
  ].join('\n');
}

export function getOfficialGstPortalHsnSample(): string {
  return getOfficialGstPortalHsnB2bSample();
}

export function getOfficialGstPortalHsnB2bSample(): string {
  return [
    'HSN,Description,UQC,Total Quantity,Total Value,Taxable Value,Integrated Tax Amount,Central Tax Amount,State/UT Tax Amount,Cess Amount,Rate',
    '998313,Information technology consulting and support services,NA,0,413000.00,350000.00,0.00,31500.00,31500.00,0.00,18',
    '847130,Laptops and Microcomputers,NOS-NUMBERS,5,295000.00,250000.00,45000.00,0.00,0.00,0.00,18'
  ].join('\n');
}

export function getOfficialGstPortalHsnB2cSample(): string {
  return [
    'HSN,Description,UQC,Total Quantity,Total Value,Taxable Value,Integrated Tax Amount,Central Tax Amount,State/UT Tax Amount,Cess Amount,Rate',
    '998313,Consumer IT support services,NA,0,118000.00,100000.00,0.00,9000.00,9000.00,0.00,18',
    '847130,Microcomputer peripherals,NOS-NUMBERS,2,59000.00,50000.00,9000.00,0.00,0.00,0.00,18'
  ].join('\n');
}

export function getOfficialGstPortalB2csSample(): string {
  return [
    'Type,Place Of Supply,Rate,Applicable % of Tax Rate,Taxable Value,Cess Amount,E-Commerce GSTIN',
    'OE,07-Delhi,18,,350000.00,0,',
    'OE,27-Maharashtra,18,,150000.00,0,'
  ].join('\n');
}

export function getOfficialGstPortalDocsSample(): string {
  return [
    'Nature of Document,Sr. No. From,Sr. No. To,Total Number,Cancelled',
    'Invoices for outward supply,INV/2026/001,INV/2026/002,2,0',
    'Credit Note,CN/2026/001,CN/2026/001,1,0'
  ].join('\n');
}

export function getSampleSalesCsv(): string {
  return getOfficialGstPortalB2bSample();
}

export function getSamplePurchaseCsv(): string {
  return [
    'invoice_number,invoice_date,supplier_gstin,supplier_name,pos_code,hsn_sac,description,taxable_value,gst_rate,is_rcm,in_2b',
    'PUR/2026/501,2026-04-04,27AAACB2100P1Z0,Vodafone Idea Telecommunications Ltd,27,998411,Enterprise Internet Leased Line,80000,18,false,true',
    'PUR/2026/502,2026-04-07,29AAACC1206D1ZM,Dell International Services India Pvt Ltd,29,847130,Workstation Compute Laptops,350000,18,false,true',
    'PUR/2026/503,2026-04-11,27AAAFR8842K1Z9,Sharma & Co Legal Advocates,27,998211,Senior Legal Counsel Opinion,75000,18,true,true',
    'PUR/2026/504,2026-04-14,27AAACS1190B1Z4,Star Luxury Catering Services,27,996331,Staff Annual Gala Dinner,65000,18,false,true',
    'PUR/2026/505,2026-04-18,27AAACG5541L1Z8,Balaji Roadways GTA Logistics,27,996511,Interstate Freight Transportation,120000,5,true,true',
    'PUR/2026/506,2026-04-22,07AAACG9901M1Z1,Cloudflare Network India Pvt Ltd,07,998315,Security Web Application Firewall,110000,18,false,false'
  ].join('\n');
}

export function getSampleGstr2bCsv(): string {
  return [
    'supplier_gstin,supplier_name,invoice_number,invoice_date,invoice_type,taxable_value,igst,cgst,sgst,cess,itc_available,filing_date',
    '27AAACB2100P1Z0,Vodafone Idea Telecommunications Ltd,PUR/2026/501,2026-04-04,B2B,80000,0,7200,7200,0,Y,2026-05-11',
    '29AAACC1206D1ZM,Dell International Services India Pvt Ltd,PUR/2026/502,2026-04-07,B2B,350000,63000,0,0,0,Y,2026-05-12',
    '27AAAFR8842K1Z9,Sharma & Co Legal Advocates,PUR/2026/503,2026-04-11,B2B,75000,0,6750,6750,0,Y,2026-05-10',
    '27AAACS1190B1Z4,Star Luxury Catering Services,PUR/2026/504,2026-04-14,B2B,65000,0,5850,5850,0,Y,2026-05-11',
    '27AAACG5541L1Z8,Balaji Roadways GTA Logistics,PUR/2026/505,2026-04-18,B2B,120000,0,3000,3000,0,Y,2026-05-12',
    '27AAACT9900B1Z3,Unrecorded Vendor Supplies Ltd,PUR/EXTRA/901,2026-04-20,B2B,45000,0,4050,4050,0,Y,2026-05-11'
  ].join('\n');
}

export function getSampleGstr2bJson(): string {
  return JSON.stringify({
    gstin: DEFAULT_ENTITY.gstin,
    fp: "042026",
    data: {
      docdata: {
        b2b: [
          {
            ctin: "27AAACB2100P1Z0",
            trdnm: "Vodafone Idea Telecommunications Ltd",
            inv: [
              {
                inum: "PUR/2026/501",
                dt: "2026-04-04",
                val: 94400,
                pos: "27",
                rchrg: "N",
                itcavl: "Y",
                items: [{ num: 1, txval: 80000, rt: 18, camt: 7200, samt: 7200, iamt: 0, csamt: 0 }]
              }
            ]
          },
          {
            ctin: "29AAACC1206D1ZM",
            trdnm: "Dell International Services India Pvt Ltd",
            inv: [
              {
                inum: "PUR/2026/502",
                dt: "2026-04-07",
                val: 413000,
                pos: "29",
                rchrg: "N",
                itcavl: "Y",
                items: [{ num: 1, txval: 350000, rt: 18, camt: 0, samt: 0, iamt: 63000, csamt: 0 }]
              }
            ]
          },
          {
            ctin: "27AAAFR8842K1Z9",
            trdnm: "Sharma & Co Legal Advocates",
            inv: [
              {
                inum: "PUR/2026/503",
                dt: "2026-04-11",
                val: 88500,
                pos: "27",
                rchrg: "Y",
                itcavl: "Y",
                items: [{ num: 1, txval: 75000, rt: 18, camt: 6750, samt: 6750, iamt: 0, csamt: 0 }]
              }
            ]
          }
        ]
      }
    }
  }, null, 2);
}

export function downloadSalesTemplate() {
  triggerFileDownload(getOfficialGstPortalB2bSample(), 'b2b,sez,de.csv');
}

export function downloadGstPortalB2bTemplate() {
  triggerFileDownload(getOfficialGstPortalB2bSample(), 'b2b,sez,de.csv');
}

export function downloadGstPortalHsnTemplate() {
  triggerFileDownload(getOfficialGstPortalHsnB2bSample(), 'hsn.csv');
}

export function downloadGstPortalHsnB2bTemplate() {
  triggerFileDownload(getOfficialGstPortalHsnB2bSample(), 'hsn_b2b.csv');
}

export function downloadGstPortalHsnB2cTemplate() {
  triggerFileDownload(getOfficialGstPortalHsnB2cSample(), 'hsn_b2c.csv');
}

export function downloadGstPortalB2csTemplate() {
  triggerFileDownload(getOfficialGstPortalB2csSample(), 'b2cs.csv');
}

export function downloadGstPortalDocsTemplate() {
  triggerFileDownload(getOfficialGstPortalDocsSample(), 'docs.csv');
}

export function downloadGstPortalZipBundle() {
  const masterXlsxBytes = gstExcelTemplateService.exportToWebGstTemplate([], [], [], '07ABFFB5922Q1Z0');
  const files: { filename: string; content: string | Uint8Array }[] = [
    { filename: 'WEB_GST_Template.xlsx', content: masterXlsxBytes },
    { filename: 'b2b,sez,de.csv', content: getOfficialGstPortalB2bSample() },
    { filename: 'hsn_b2b.csv', content: getOfficialGstPortalHsnB2bSample() },
    { filename: 'hsn_b2c.csv', content: getOfficialGstPortalHsnB2cSample() },
    { filename: 'b2cs.csv', content: getOfficialGstPortalB2csSample() },
    { filename: 'docs.csv', content: getOfficialGstPortalDocsSample() }
  ];
  const zipBlob = gstPortalCsvEngine.createZipArchive(files);
  const url = URL.createObjectURL(zipBlob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'GST_Portal_GSTR1_Section_Wise_CSV_Templates.zip';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function downloadPurchaseTemplate() {
  triggerFileDownload(getSamplePurchaseCsv(), 'standard_purchase_register_template.csv');
}

export function downloadGstr2bCsvTemplate() {
  triggerFileDownload(getSampleGstr2bCsv(), 'standard_gstr2b_template.csv');
}

export function downloadGstr2bJsonTemplate() {
  triggerFileDownload(getSampleGstr2bJson(), 'standard_gstr2b_gstn_sample.json', 'application/json');
}

export function downloadAllStandardTemplates() {
  downloadSalesTemplate();
  setTimeout(() => downloadGstPortalHsnTemplate(), 200);
  setTimeout(() => downloadGstPortalDocsTemplate(), 400);
  setTimeout(() => downloadPurchaseTemplate(), 600);
  setTimeout(() => downloadGstr2bCsvTemplate(), 800);
}

export interface ColumnSchema {
  name: string;
  type: string;
  required: boolean;
  description: string;
  example: string;
}

export const STANDARDIZED_SCHEMAS: Record<'SALES' | 'PURCHASES' | 'GSTR2B', { title: string; filename: string; columns: ColumnSchema[] }> = {
  SALES: {
    title: 'Official GST Portal B2B Bills (Table 4 / b2b,sez,de.csv)',
    filename: 'b2b,sez,de.csv',
    columns: [
      { name: 'GSTIN/UIN of Recipient', type: 'GSTIN (15 chars)', required: true, description: '15-character GSTIN of registered buyer', example: '07AAAAA0000A1Z5' },
      { name: 'Receiver Name', type: 'String', required: false, description: 'Legal or trade name of recipient party', example: 'Apex Technologies Pvt Ltd' },
      { name: 'Invoice Number', type: 'String', required: true, description: 'Unique outward invoice number', example: 'INV/2026/001' },
      { name: 'Invoice date', type: 'DD-MMM-YY / DD-MM-YYYY', required: true, description: 'Date of invoice issue', example: '15-Oct-26' },
      { name: 'Invoice Value', type: 'Number', required: true, description: 'Total gross value including taxes', example: '413000.00' },
      { name: 'Place Of Supply', type: 'State Code-Name', required: true, description: 'e.g. 07-Delhi or 27-Maharashtra', example: '07-Delhi' },
      { name: 'Reverse Charge', type: 'Y or N', required: false, description: 'Reverse charge applicability (default N)', example: 'N' },
      { name: 'Invoice Type', type: 'String', required: false, description: 'Regular B2B / SEZ supplies with payment / Deemed Exp', example: 'Regular B2B' },
      { name: 'Rate', type: 'Number', required: true, description: 'Applicable GST slab (0, 5, 12, 18, 28)', example: '18' },
      { name: 'Taxable Value', type: 'Number', required: true, description: 'Taxable supply value before GST', example: '350000.00' },
      { name: 'Cess Amount', type: 'Number', required: false, description: 'Compensation cess if applicable', example: '0' }
    ]
  },
  PURCHASES: {
    title: 'Purchase Register (Inward Supplies / Books)',
    filename: 'standard_purchase_register_template.csv',
    columns: [
      { name: 'invoice_number', type: 'String', required: true, description: 'Supplier bill or invoice reference number', example: 'PUR/2026/501' },
      { name: 'invoice_date', type: 'YYYY-MM-DD', required: true, description: 'Date on vendor invoice', example: '2026-04-04' },
      { name: 'supplier_gstin', type: 'GSTIN (15 chars)', required: false, description: '15-digit GSTIN of supplier/vendor', example: '27AAACB2100P1Z0' },
      { name: 'supplier_name', type: 'String', required: false, description: 'Vendor company or trade legal name', example: 'Vodafone Idea Telecommunications Ltd' },
      { name: 'pos_code', type: 'State Code (2 digits)', required: false, description: 'Place of supply 2-digit code', example: '27' },
      { name: 'hsn_sac', type: '4-8 digits', required: false, description: 'HSN / SAC classification code', example: '998411' },
      { name: 'description', type: 'String', required: false, description: 'Nature of expense, goods or services', example: 'Enterprise Internet Leased Line' },
      { name: 'taxable_value', type: 'Number', required: true, description: 'Taxable amount eligible for expense/ITC', example: '80000' },
      { name: 'gst_rate', type: 'Percentage', required: false, description: 'Applicable GST rate slab', example: '18' },
      { name: 'is_rcm', type: 'Boolean (true/false)', required: false, description: 'True if Section 9(3) Reverse Charge applies', example: 'false' },
      { name: 'in_2b', type: 'Boolean (true/false)', required: false, description: 'Initial flag whether found in portal 2B', example: 'true' }
    ]
  },
  GSTR2B: {
    title: 'GSTR-2B Statement (GST Portal Auto-drafted)',
    filename: 'standard_gstr2b_template.csv',
    columns: [
      { name: 'supplier_gstin', type: 'GSTIN (15 chars)', required: true, description: '15-digit GSTIN of supplier filing GSTR-1', example: '27AAACB2100P1Z0' },
      { name: 'supplier_name', type: 'String', required: false, description: 'Trade name of the supplier', example: 'Vodafone Idea Telecommunications Ltd' },
      { name: 'invoice_number', type: 'String', required: true, description: 'Invoice number as reported on portal', example: 'PUR/2026/501' },
      { name: 'invoice_date', type: 'YYYY-MM-DD', required: true, description: 'Invoice date reported on portal', example: '2026-04-04' },
      { name: 'invoice_type', type: 'Enum', required: false, description: 'B2B, CDNR, or DE', example: 'B2B' },
      { name: 'taxable_value', type: 'Number', required: true, description: 'Taxable value auto-drafted', example: '80000' },
      { name: 'igst', type: 'Number', required: false, description: 'Integrated Tax amount in INR', example: '0' },
      { name: 'cgst', type: 'Number', required: false, description: 'Central Tax amount in INR', example: '7200' },
      { name: 'sgst', type: 'Number', required: false, description: 'State Tax amount in INR', example: '7200' },
      { name: 'cess', type: 'Number', required: false, description: 'Compensation Cess amount in INR', example: '0' },
      { name: 'itc_available', type: 'Y or N', required: false, description: 'Rule 36(4) ITC availability flag (Y or N)', example: 'Y' },
      { name: 'filing_date', type: 'YYYY-MM-DD', required: false, description: 'Date supplier filed their GSTR-1', example: '2026-05-11' }
    ]
  }
};

export function getSampleEcommerceCsv(): string {
  return [
    'platform,period,gross_sales,returns,net_taxable,gst_rate,cgst,sgst,igst,tcs_amount',
    'Amazon India,04-2026,1200000,120000,1080000,18,97200,97200,0,10800',
    'Flipkart Private Limited,04-2026,750000,65000,685000,18,61650,61650,0,6850',
    'Meesho Marketplace,04-2026,380000,30000,350000,18,0,0,63000,3500'
  ].join('\n');
}

// ==========================================
// 2. PARSERS TO SYSTEM ENTITIES
// ==========================================

export function parseSalesCsv(
  csvText: string,
  options?: {
    financialYear?: string;
    month?: string;
    defaultEntity?: { gstin?: string; legalName?: string; state?: string; stateCode?: string };
    fileName?: string;
    targetHsnCategory?: 'B2B' | 'B2C' | 'AUTO';
  }
): { success: boolean; data: TransactionInvoice[]; errors: string[]; detectedFormat?: string } {
  try {
    const trimmed = (csvText || '').trim();
    if (!trimmed) {
      return { success: false, data: [], errors: ['CSV or JSON input is empty.'] };
    }

    const entityGstin = (options?.defaultEntity?.gstin && options.defaultEntity.gstin.trim().length === 15)
      ? options.defaultEntity.gstin.trim()
      : (DEFAULT_ENTITY.gstin || '07ABFFB5922Q1Z0');

    // 0. Auto-detect if input is official GSTR-1 Offline JSON
    if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
      const jsonRes = gstPortalCsvEngine.parsePortalJson(trimmed, entityGstin);
      if (jsonRes.success && jsonRes.invoices.length > 0) {
        const tagged = jsonRes.invoices.map(inv => ({
          ...inv,
          supplierGstin: inv.supplierGstin && inv.supplierGstin.length === 15 ? inv.supplierGstin : entityGstin,
          financialYear: options?.financialYear || inv.financialYear,
          returnMonth: options?.month || inv.returnMonth
        }));
        return { success: true, data: tagged, errors: jsonRes.errors, detectedFormat: 'GST Portal GSTR-1 JSON' };
      }
      if (jsonRes.errors.length > 0) {
        return { success: false, data: [], errors: jsonRes.errors };
      }
    }

    // 1. Auto-detect if uploaded CSV is an Official GST Portal Section Template (hsn, docs, b2b, b2cl, b2cs, cdnr, exp, etc.)
    const portalType = gstPortalCsvEngine.detectPortalTemplateType(trimmed, options?.fileName);
    if (portalType !== 'GENERIC') {
      const portalRes = gstPortalCsvEngine.parsePortalCsv(trimmed, entityGstin, {
        fileName: options?.fileName,
        targetHsnCategory: options?.targetHsnCategory
      });
      if (portalRes.success && portalRes.invoices.length > 0) {
        const tagged = portalRes.invoices.map(inv => ({
          ...inv,
          supplierGstin: inv.supplierGstin && inv.supplierGstin.length === 15 ? inv.supplierGstin : entityGstin,
          financialYear: options?.financialYear || inv.financialYear,
          returnMonth: options?.month || inv.returnMonth
        }));
        return { success: true, data: tagged, errors: portalRes.errors, detectedFormat: `GST Portal Template (${portalType})` };
      }
      if (portalRes.errors.length > 0) {
        return { success: false, data: [], errors: portalRes.errors };
      }
    }

    const rows = parseCsvRows(trimmed);
    if (rows.length < 2) {
      return { success: false, data: [], errors: ['CSV file is empty or missing data rows.'] };
    }

    const header = rows[0].map(h => h.toLowerCase().replace(/[\s_-]+/g, ''));
    const getColIndex = (names: string[]) => {
      for (const name of names) {
        const idx = header.indexOf(name.toLowerCase().replace(/[\s_-]+/g, ''));
        if (idx !== -1) return idx;
      }
      return -1;
    };

    const invNumIdx = getColIndex(['invoicenumber', 'invoiceno', 'invno', 'invoicenum', 'billno']);
    const invDateIdx = getColIndex(['invoicedate', 'date', 'invdate', 'billdate']);
    const recGstinIdx = getColIndex(['recipientgstin', 'customergstin', 'gstin', 'buyer_gstin', 'buyergstin']);
    const recNameIdx = getColIndex(['recipientname', 'customername', 'buyername', 'partyname', 'name']);
    const posIdx = getColIndex(['poscode', 'pos', 'placeofsupply', 'statecode', 'state']);
    const hsnIdx = getColIndex(['hsnsac', 'hsn', 'sac', 'hsncode', 'itemhsn', 'itemcode', 'servicecode', 'productcode']);
    const descIdx = getColIndex(['description', 'itemname', 'particulars', 'desc', 'productdescription', 'itemdesc']);
    const uqcIdx = getColIndex(['uqc', 'unit', 'uom', 'unitquantitycode']);
    const qtyIdx = getColIndex(['quantity', 'qty', 'totalquantity', 'itemqty', 'pieces']);
    const taxableIdx = getColIndex(['taxablevalue', 'taxableamount', 'taxable', 'amount', 'value']);
    const rateIdx = getColIndex(['gstrate', 'rate', 'taxrate']);
    const docTypeIdx = getColIndex(['documenttype', 'doctype', 'type']);
    const invValIdx = getColIndex(['invoicevalue', 'totalvalue', 'totalamount', 'grandtotal', 'invval', 'val', 'total']);

    // Explicit tax columns (if present in custom accounting exports)
    const cgstIdx = getColIndex(['centraltaxamount', 'centraltax', 'cgstamount', 'cgst', 'camt', 'cgstamt']);
    const sgstIdx = getColIndex(['stateuttaxamount', 'statetaxamount', 'statetax', 'sgstamount', 'sgst', 'samt', 'utgst', 'sgstamt']);
    const igstIdx = getColIndex(['integratedtaxamount', 'integratedtax', 'igstamount', 'igst', 'iamt', 'igstamt']);
    const cessIdx = getColIndex(['cessamount', 'cess', 'csamt']);

    if (invNumIdx === -1 || taxableIdx === -1) {
      return {
        success: false,
        data: [],
        errors: ['Mandatory columns missing: "invoice_number" and "taxable_value" are required.']
      };
    }

    const entity = options?.defaultEntity || DEFAULT_ENTITY;
    const supplierStateCode = (entity.stateCode || DEFAULT_ENTITY.stateCode || '07').substring(0, 2);
    const periodInfo = computeReturnPeriod(options?.financialYear || '2026-27', options?.month || 'April');

    const invoices: TransactionInvoice[] = [];
    const errors: string[] = [];

    for (let r = 1; r < rows.length; r++) {
      const row = rows[r];
      if (row.length === 0 || (row.length === 1 && !row[0])) continue;

      const invNo = row[invNumIdx]?.trim() || `INV-AUTO-${r}`;
      let invDate = invDateIdx !== -1 && row[invDateIdx] ? row[invDateIdx].trim() : `${periodInfo.year}-${periodInfo.monthNumber}-15`;

      // Align date with selected FY & Month if period options were specified
      if (options?.financialYear && options?.month) {
        const dayMatch = invDate.match(/\d{4}-\d{2}-(\d{1,2})/) || invDate.match(/(\d{1,2})[-\/]\d{1,2}[-\/]\d{2,4}/);
        const day = dayMatch ? dayMatch[1].padStart(2, '0') : '15';
        invDate = `${periodInfo.year}-${periodInfo.monthNumber}-${day}`;
      }

      const recGstin = recGstinIdx !== -1 && row[recGstinIdx] ? row[recGstinIdx].trim() : 'URP';
      const recName = recNameIdx !== -1 && row[recNameIdx] ? row[recNameIdx].trim() : (recGstin === 'URP' ? 'Unregistered Buyer' : 'Registered Customer');
      
      const rawPos = posIdx !== -1 && row[posIdx] ? row[posIdx].trim() : undefined;
      const posCode = extractPosCode(rawPos, recGstin, supplierStateCode);
      
      const hsn = hsnIdx !== -1 && row[hsnIdx] ? row[hsnIdx].trim() : '998313';
      const desc = descIdx !== -1 && row[descIdx] ? row[descIdx].trim() : 'Commercial Business Supplies';
      const userUqc = uqcIdx !== -1 && row[uqcIdx] ? row[uqcIdx].trim() : '';
      const userQty = qtyIdx !== -1 && row[qtyIdx] ? (parseFloat(row[qtyIdx].replace(/[^0-9.-]+/g, '')) || 0) : 0;
      const taxable = parseFloat((row[taxableIdx] || '0').replace(/[^0-9.-]+/g, '')) || 0;
      const rate = rateIdx !== -1 ? parseFloat((row[rateIdx] || '18').replace(/[^0-9.]+/g, '')) || 18 : 18;

      const rawCgst = cgstIdx !== -1 && row[cgstIdx] ? parseFloat(row[cgstIdx].replace(/[^0-9.-]+/g, '')) : undefined;
      const rawSgst = sgstIdx !== -1 && row[sgstIdx] ? parseFloat(row[sgstIdx].replace(/[^0-9.-]+/g, '')) : undefined;
      const rawIgst = igstIdx !== -1 && row[igstIdx] ? parseFloat(row[igstIdx].replace(/[^0-9.-]+/g, '')) : undefined;
      const rawCess = cessIdx !== -1 && row[cessIdx] ? parseFloat(row[cessIdx].replace(/[^0-9.-]+/g, '')) : undefined;
      const rawInvVal = invValIdx !== -1 && row[invValIdx] ? parseFloat(row[invValIdx].replace(/[^0-9.-]+/g, '')) : undefined;

      let isInterState = posCode !== supplierStateCode;
      let finalCgst = 0;
      let finalSgst = 0;
      let finalIgst = 0;
      let finalCess = rawCess !== undefined ? rawCess : 0;

      // Priority 1: If file explicitly specifies CGST or SGST, it is 100% INTRA-STATE!
      if ((rawCgst !== undefined && rawCgst > 0) || (rawSgst !== undefined && rawSgst > 0)) {
        isInterState = false;
        finalCgst = rawCgst !== undefined ? rawCgst : Math.round((taxable * rate) / 2) / 100;
        finalSgst = rawSgst !== undefined ? rawSgst : Math.round((taxable * rate) / 2) / 100;
        finalIgst = 0;
      } else if (rawIgst !== undefined && rawIgst > 0 && (!rawCgst || rawCgst === 0) && (!rawSgst || rawSgst === 0)) {
        isInterState = true;
        finalIgst = rawIgst;
        finalCgst = 0;
        finalSgst = 0;
      } else {
        const taxCalc = calculateDeterministicTax(taxable, rate, isInterState);
        finalCgst = taxCalc.cgst;
        finalSgst = taxCalc.sgst;
        finalIgst = taxCalc.igst;
        if (finalCess === 0) finalCess = taxCalc.cess;
      }

      let docType: DocumentType = 'INVOICE';
      if (docTypeIdx !== -1 && row[docTypeIdx]) {
        const dt = row[docTypeIdx].toUpperCase();
        if (dt.includes('CREDIT') || dt.includes('CN')) docType = 'CREDIT_NOTE';
        else if (dt.includes('DEBIT') || dt.includes('DN')) docType = 'DEBIT_NOTE';
      }

      // Determine classification
      let classification: GSTClassification = 'B2B';
      let taxTreatment: any = 'TAXABLE';

      if (docType === 'CREDIT_NOTE' || docType === 'DEBIT_NOTE') {
        classification = recGstin === 'URP' || recGstin === '' ? 'B2C_SMALL' : 'B2B';
      } else if (recGstin === 'OVERSEAS') {
        classification = 'EXPORT_WITHOUT_PAYMENT';
        taxTreatment = 'ZERO_RATED';
      } else if (recGstin === 'URP' || recGstin === '') {
        if (isInterState && taxable > 250000) {
          classification = 'B2C_LARGE';
        } else {
          classification = 'B2C_SMALL';
        }
      } else {
        classification = 'B2B';
      }

      const targetState = INDIAN_STATES.find(s => s.code === posCode)?.name || 'Delhi';
      const totalAmount = rawInvVal || (Math.round((taxable + finalCgst + finalSgst + finalIgst + finalCess + Number.EPSILON) * 100) / 100);

      invoices.push({
        id: `SL-IMP-${Date.now()}-${r}`,
        invoiceNumber: invNo,
        invoiceDate: invDate,
        documentType: docType,
        supplierGstin: entity.gstin || DEFAULT_ENTITY.gstin,
        supplierName: entity.legalName || DEFAULT_ENTITY.legalName,
        supplierState: entity.state || DEFAULT_ENTITY.state,
        supplierStateCode: supplierStateCode,
        recipientGstin: recGstin,
        recipientName: recName,
        recipientState: targetState,
        recipientStateCode: posCode,
        placeOfSupply: `${posCode}-${targetState}`,
        placeOfSupplyCode: posCode,
        supplyType: isInterState ? 'INTER_STATE' : 'INTRA_STATE',
        classification,
        taxTreatment,
        hsnSacPrimary: hsn,
        descriptionPrimary: desc,
        taxableValue: taxable,
        gstRate: rate,
        cgst: finalCgst,
        sgst: finalSgst,
        igst: finalIgst,
        cess: finalCess,
        totalAmount,
        rcm: false,
        rcmStatus: 'NO',
        ecommerce: false,
        itcStatus: 'ELIGIBLE',
        itcEligibleAmount: 0,
        itcIneligibleAmount: 0,
        confidence: 1.0,
        reviewRequired: false,
        financialYear: periodInfo.financialYear,
        returnMonth: periodInfo.month,
        period: periodInfo.periodCode,
        gstr1UploadStatus: 'PENDING',
        uqc: userUqc || (hsn.startsWith('99') ? 'NA' : 'OTH'),
        totalQuantity: userQty || (hsn.startsWith('99') ? 0 : 1)
      });
    }

    return { success: true, data: invoices, errors };
  } catch (err: any) {
    return { success: false, data: [], errors: [err.message || 'Failed to parse Sales CSV'] };
  }
}

export interface ExcelWorkbookResult {
  success: boolean;
  sheetsFound: string[];
  invoices: TransactionInvoice[];
  errors: string[];
  summary: { count: number; totalTaxable: number; totalTax: number };
  detectedFormat: string;
}

/**
 * Directly parses Microsoft Excel Workbooks (.xlsx and .xls)
 * Compatible with official GST Returns Offline Tool Excel Template (sheets: b2b, hsn, docs, b2cs, cdnr, exp)
 * and generic multi-sheet / single-sheet accounting workbooks.
 */
export function parseExcelWorkbook(
  arrayBuffer: ArrayBuffer | Uint8Array,
  options?: {
    financialYear?: string;
    month?: string;
    defaultEntity?: { gstin?: string; legalName?: string; state?: string; stateCode?: string };
  }
): ExcelWorkbookResult {
  try {
    const workbook = XLSX.read(arrayBuffer, { type: 'array' });
    const sheetNames = workbook.SheetNames;
    if (!sheetNames || sheetNames.length === 0) {
      return {
        success: false,
        sheetsFound: [],
        invoices: [],
        errors: ['Excel file does not contain any worksheets.'],
        summary: { count: 0, totalTaxable: 0, totalTax: 0 },
        detectedFormat: 'Excel File'
      };
    }

    const entityGstin = options?.defaultEntity?.gstin || DEFAULT_ENTITY.gstin;
    const allInvoices: TransactionInvoice[] = [];
    const processedSheets: string[] = [];
    const allErrors: string[] = [];

    // GST Offline Tool Official Sheet Names (case-insensitive mapping)
    const officialSheetMap: Record<string, string> = {
      b2b: 'B2B',
      'b2b,sez,de': 'B2B',
      'b2b, sez, de': 'B2B',
      b2cl: 'B2CL',
      b2cs: 'B2CS',
      cdnr: 'CDNR',
      cdnur: 'CDNUR',
      exp: 'EXP',
      hsn: 'HSN',
      'hsn(b2b)': 'HSN',
      'hsn(b2c)': 'HSN',
      'hsn_b2b': 'HSN',
      'hsn_b2c': 'HSN',
      docs: 'DOCS',
      exemp: 'EXEMP'
    };

    // Check if workbook has any official GST portal sheets
    const hasOfficialSheets = sheetNames.some(s => officialSheetMap[s.toLowerCase().trim()]);

    if (hasOfficialSheets) {
      // Process each official sheet
      for (const sName of sheetNames) {
        const cleanName = sName.toLowerCase().trim();
        if (!officialSheetMap[cleanName]) continue;

        const sheet = workbook.Sheets[sName];
        if (!sheet) continue;

        // Convert sheet to CSV text
        const csvText = XLSX.utils.sheet_to_csv(sheet);
        if (!csvText || !csvText.trim()) continue;

        const isB2cHsn = cleanName.includes('b2c');
        const isB2bHsn = cleanName.includes('b2b');
        const portalRes = gstPortalCsvEngine.parsePortalCsv(csvText, entityGstin, {
          fileName: sName,
          targetHsnCategory: isB2cHsn ? 'B2C' : isB2bHsn ? 'B2B' : undefined
        });
        if (portalRes.success && portalRes.invoices.length > 0) {
          processedSheets.push(`${sName} (${portalRes.invoices.length})`);
          const tagged = portalRes.invoices.map(inv => ({
            ...inv,
            financialYear: options?.financialYear || inv.financialYear,
            returnMonth: options?.month || inv.returnMonth
          }));
          allInvoices.push(...tagged);
        }
        if (portalRes.errors.length > 0) {
          allErrors.push(...portalRes.errors.map(e => `[${sName}] ${e}`));
        }
      }
    } else {
      // Generic Excel workbook: process non-empty sheets (e.g. Sales, Invoices, Sheet1)
      for (const sName of sheetNames) {
        const sheet = workbook.Sheets[sName];
        if (!sheet) continue;

        const csvText = XLSX.utils.sheet_to_csv(sheet);
        if (!csvText || !csvText.trim()) continue;

        const salesRes = parseSalesCsv(csvText, options);
        if (salesRes.success && salesRes.data.length > 0) {
          processedSheets.push(`${sName} (${salesRes.data.length})`);
          allInvoices.push(...salesRes.data);
          break; // First sheet with valid sales invoices processed
        }
      }
    }

    if (allInvoices.length === 0) {
      return {
        success: false,
        sheetsFound: sheetNames,
        invoices: [],
        errors: allErrors.length > 0 ? allErrors : ['No valid invoices or summary rows found in Excel sheet(s).'],
        summary: { count: 0, totalTaxable: 0, totalTax: 0 },
        detectedFormat: 'Excel File'
      };
    }

    const totalTaxable = allInvoices.reduce((acc, curr) => acc + (curr.taxableValue || 0), 0);
    const totalTax = allInvoices.reduce((acc, curr) => acc + (curr.igst || 0) + (curr.cgst || 0) + (curr.sgst || 0) + (curr.cess || 0), 0);

    return {
      success: true,
      sheetsFound: processedSheets,
      invoices: allInvoices,
      errors: allErrors,
      summary: { count: allInvoices.length, totalTaxable, totalTax },
      detectedFormat: `Excel Workbook (${processedSheets.join(', ')})`
    };
  } catch (err: any) {
    return {
      success: false,
      sheetsFound: [],
      invoices: [],
      errors: [err.message || 'Failed to read Excel workbook'],
      summary: { count: 0, totalTaxable: 0, totalTax: 0 },
      detectedFormat: 'Excel File'
    };
  }
}

export function parsePurchaseCsv(csvText: string): { success: boolean; data: TransactionInvoice[]; errors: string[] } {
  try {
    const rows = parseCsvRows(csvText);
    if (rows.length < 2) {
      return { success: false, data: [], errors: ['CSV file is empty or missing data rows.'] };
    }

    const header = rows[0].map(h => h.toLowerCase().replace(/[\s_-]+/g, ''));
    const getColIndex = (names: string[]) => {
      for (const name of names) {
        const idx = header.indexOf(name.toLowerCase().replace(/[\s_-]+/g, ''));
        if (idx !== -1) return idx;
      }
      return -1;
    };

    const invNumIdx = getColIndex(['invoicenumber', 'invoiceno', 'invno', 'billno']);
    const invDateIdx = getColIndex(['invoicedate', 'date', 'invdate']);
    const supGstinIdx = getColIndex(['suppliergstin', 'vendorgstin', 'gstin']);
    const supNameIdx = getColIndex(['suppliername', 'vendorname', 'partyname', 'name']);
    const posIdx = getColIndex(['poscode', 'pos', 'placeofsupply', 'statecode']);
    const hsnIdx = getColIndex(['hsnsac', 'hsn', 'sac', 'hsncode']);
    const descIdx = getColIndex(['description', 'itemname', 'particulars']);
    const taxableIdx = getColIndex(['taxablevalue', 'taxableamount', 'taxable', 'amount']);
    const rateIdx = getColIndex(['gstrate', 'rate']);
    const rcmIdx = getColIndex(['isrcm', 'rcm', 'reversecharge']);
    const in2bIdx = getColIndex(['in2b', 'isin2b', 'gstr2b']);

    if (invNumIdx === -1 || taxableIdx === -1) {
      return {
        success: false,
        data: [],
        errors: ['Mandatory columns missing: "invoice_number" and "taxable_value" are required.']
      };
    }

    const invoices: TransactionInvoice[] = [];
    const errors: string[] = [];

    for (let r = 1; r < rows.length; r++) {
      const row = rows[r];
      if (row.length === 0 || (row.length === 1 && !row[0])) continue;

      const invNo = row[invNumIdx]?.trim() || `PUR-AUTO-${r}`;
      const invDate = invDateIdx !== -1 && row[invDateIdx] ? row[invDateIdx].trim() : '2026-04-10';
      const supGstin = supGstinIdx !== -1 && row[supGstinIdx] ? row[supGstinIdx].trim() : '27AAACB2100P1Z0';
      const supName = supNameIdx !== -1 && row[supNameIdx] ? row[supNameIdx].trim() : 'Vendor Corporation';
      
      let posCode = posIdx !== -1 && row[posIdx] ? row[posIdx].trim() : DEFAULT_ENTITY.stateCode;
      if (posCode.length === 1) posCode = '0' + posCode;

      const hsn = hsnIdx !== -1 && row[hsnIdx] ? row[hsnIdx].trim() : '998411';
      const desc = descIdx !== -1 && row[descIdx] ? row[descIdx].trim() : 'Business Consumables / Services';
      const taxable = parseFloat((row[taxableIdx] || '0').replace(/[^0-9.-]+/g, '')) || 0;
      const rate = rateIdx !== -1 ? parseFloat((row[rateIdx] || '18').replace(/[^0-9.]+/g, '')) || 18 : 18;
      
      const explicitRcm = rcmIdx !== -1 ? row[rcmIdx]?.toLowerCase() === 'true' || row[rcmIdx]?.toLowerCase() === 'yes' || row[rcmIdx] === '1' : false;
      const isIn2B = in2bIdx !== -1 ? row[in2bIdx]?.toLowerCase() === 'true' || row[in2bIdx]?.toLowerCase() === 'yes' || row[in2bIdx] === '1' || row[in2bIdx] === 'y' : true;

      const isInterState = posCode !== DEFAULT_ENTITY.stateCode;
      const taxCalc = calculateDeterministicTax(taxable, rate, isInterState);

      // Automated Rule Engine validation
      const rcmCheck = explicitRcm
        ? { isRcm: true, rcmStatus: 'YES' as const, rcmCategory: 'LEGAL_ADVOCATE_SERVICES' as const, reviewRequired: false }
        : rcmEngine.evaluateRCM({
            supplierGstin: supGstin,
            recipientGstin: DEFAULT_ENTITY.gstin,
            hsnSac: hsn,
            description: desc,
            taxableValue: taxable,
            isInterState,
            date: invDate
          });

      const itcCheck = itcEngine.evaluateITC({
        invoiceDate: invDate,
        hsnSac: hsn,
        description: desc,
        taxableValue: taxable,
        totalTax: taxCalc.totalTax,
        isRcm: rcmCheck.isRcm,
        hasInvoiceCopy: true,
        goodsReceived: true,
        isIn2B
      });

      const supState = INDIAN_STATES.find(s => s.code === posCode)?.name || 'Maharashtra';

      invoices.push({
        id: `PR-IMP-${Date.now()}-${r}`,
        invoiceNumber: invNo,
        invoiceDate: invDate,
        documentType: 'INVOICE',
        supplierGstin: supGstin,
        supplierName: supName,
        supplierState: supState,
        supplierStateCode: posCode,
        recipientGstin: DEFAULT_ENTITY.gstin,
        recipientName: DEFAULT_ENTITY.legalName,
        recipientState: DEFAULT_ENTITY.state,
        recipientStateCode: DEFAULT_ENTITY.stateCode,
        placeOfSupply: DEFAULT_ENTITY.state,
        placeOfSupplyCode: DEFAULT_ENTITY.stateCode,
        supplyType: isInterState ? 'INTER_STATE' : 'INTRA_STATE',
        classification: 'B2B',
        taxTreatment: 'TAXABLE',
        hsnSacPrimary: hsn,
        descriptionPrimary: desc,
        taxableValue: taxable,
        gstRate: rate,
        cgst: taxCalc.cgst,
        sgst: taxCalc.sgst,
        igst: taxCalc.igst,
        cess: taxCalc.cess,
        totalAmount: taxCalc.totalAmount,
        rcm: rcmCheck.isRcm,
        rcmStatus: rcmCheck.rcmStatus,
        rcmCategory: rcmCheck.rcmCategory,
        rcmCashPaid: rcmCheck.isRcm,
        ecommerce: false,
        itcStatus: itcCheck.itcStatus,
        blockedCreditReason: itcCheck.blockedReason,
        itcEligibleAmount: itcCheck.eligibleAmount,
        itcIneligibleAmount: itcCheck.ineligibleAmount,
        reconciliationStatus: isIn2B ? 'EXACT_MATCH' : 'MISSING_IN_2B',
        confidence: 1.0,
        reviewRequired: itcCheck.reviewRequired || rcmCheck.reviewRequired
      });
    }

    return { success: true, data: invoices, errors };
  } catch (err: any) {
    return { success: false, data: [], errors: [err.message || 'Failed to parse Purchase CSV'] };
  }
}

export function parseGstr2bCsv(csvText: string): { success: boolean; data: GSTR2BRecord[]; errors: string[] } {
  try {
    const trimmed = csvText.trim();
    // Support official GST portal JSON download and JSON arrays
    if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
      try {
        const parsed = JSON.parse(trimmed);
        const records: GSTR2BRecord[] = [];
        
        // Handle official GSTN portal GSTR-2B format { data: { docdata: { b2b: [...] } } } or { b2b: [...] }
        const b2bList = parsed.data?.docdata?.b2b || parsed.b2b || (Array.isArray(parsed) ? parsed : null);
        if (b2bList && Array.isArray(b2bList)) {
          let rowIdx = 1;
          for (const item of b2bList) {
            // Check if item is vendor grouping with invoices: { ctin, trdnm, inv: [...] }
            if (item.inv && Array.isArray(item.inv)) {
              const supGstin = item.ctin || item.supplierGstin || '27AAACB2100P1Z0';
              const supName = item.trdnm || item.legalName || item.supplierName || 'Auto Vendor';
              for (const inv of item.inv) {
                const invNo = inv.inum || inv.invoiceNumber || `2B-INV-${rowIdx}`;
                const invDate = inv.dt || inv.invoiceDate || '2026-04-10';
                const totalTaxable = inv.items?.reduce((acc: number, it: any) => acc + (it.txval || 0), 0) || inv.val || 0;
                const igst = inv.items?.reduce((acc: number, it: any) => acc + (it.iamt || 0), 0) || 0;
                const cgst = inv.items?.reduce((acc: number, it: any) => acc + (it.camt || 0), 0) || 0;
                const sgst = inv.items?.reduce((acc: number, it: any) => acc + (it.samt || 0), 0) || 0;
                const cess = inv.items?.reduce((acc: number, it: any) => acc + (it.csamt || 0), 0) || 0;
                const itcAvailable = inv.itcavl !== 'N';

                records.push({
                  id: `2B-JSON-${Date.now()}-${rowIdx++}`,
                  supplierGstin: supGstin,
                  supplierName: supName,
                  invoiceNumber: invNo,
                  invoiceDate: invDate,
                  invoiceType: 'B2B',
                  invoiceValue: inv.val || (totalTaxable + igst + cgst + sgst + cess),
                  placeOfSupply: inv.pos ? `${inv.pos}` : '27-Maharashtra',
                  reverseCharge: inv.rchrg === 'Y',
                  taxableValue: totalTaxable,
                  igst,
                  cgst,
                  sgst,
                  cess,
                  itcAvailable,
                  period: '042026',
                  filingDate: '2026-05-11'
                });
              }
            } else if (item.invoiceNumber || item.taxableValue) {
              // Flat record array
              records.push({
                id: `2B-JSON-${Date.now()}-${rowIdx++}`,
                supplierGstin: item.supplierGstin || item.ctin || '27AAACB2100P1Z0',
                supplierName: item.supplierName || item.trdnm || 'Vendor',
                invoiceNumber: item.invoiceNumber || item.inum || `2B-${rowIdx}`,
                invoiceDate: item.invoiceDate || item.dt || '2026-04-10',
                invoiceType: item.invoiceType || 'B2B',
                invoiceValue: item.invoiceValue || (item.taxableValue + (item.igst || 0) + (item.cgst || 0) + (item.sgst || 0)),
                placeOfSupply: item.placeOfSupply || '27-Maharashtra',
                reverseCharge: Boolean(item.reverseCharge),
                taxableValue: Number(item.taxableValue || 0),
                igst: Number(item.igst || 0),
                cgst: Number(item.cgst || 0),
                sgst: Number(item.sgst || 0),
                cess: Number(item.cess || 0),
                itcAvailable: item.itcAvailable !== false,
                period: '042026',
                filingDate: item.filingDate || '2026-05-11'
              });
            }
          }

          if (records.length > 0) {
            return { success: true, data: records, errors: [] };
          }
        }
      } catch (jsonErr) {
        // Fall back to CSV parsing
      }
    }

    const rows = parseCsvRows(csvText);
    if (rows.length < 2) {
      return { success: false, data: [], errors: ['GSTR-2B CSV/JSON file is empty or missing data rows.'] };
    }

    const header = rows[0].map(h => h.toLowerCase().replace(/[\s_-]+/g, ''));
    const getColIndex = (names: string[]) => {
      for (const name of names) {
        const idx = header.indexOf(name.toLowerCase().replace(/[\s_-]+/g, ''));
        if (idx !== -1) return idx;
      }
      return -1;
    };

    const supGstinIdx = getColIndex(['suppliergstin', 'vendorgstin', 'ctin', 'gstin']);
    const supNameIdx = getColIndex(['suppliername', 'tradenamed', 'legalname', 'partyname', 'name']);
    const invNoIdx = getColIndex(['invoicenumber', 'invoiceno', 'docnum', 'invno', 'billno']);
    const invDateIdx = getColIndex(['invoicedate', 'docdate', 'invdate', 'date']);
    const taxableIdx = getColIndex(['taxablevalue', 'taxable', 'taxableamount', 'value']);
    const igstIdx = getColIndex(['igst', 'integratedtax']);
    const cgstIdx = getColIndex(['cgst', 'centraltax']);
    const sgstIdx = getColIndex(['sgst', 'statetax']);
    const cessIdx = getColIndex(['cess']);
    const itcAvailIdx = getColIndex(['itcavailable', 'itcavail', 'itc']);
    const fileDateIdx = getColIndex(['filingdate', 'filedate', 'gstr1filingdate']);

    if (invNoIdx === -1 || taxableIdx === -1) {
      return {
        success: false,
        data: [],
        errors: ['Mandatory columns missing: "invoice_number" and "taxable_value" are required.']
      };
    }

    const records: GSTR2BRecord[] = [];
    for (let r = 1; r < rows.length; r++) {
      const row = rows[r];
      if (row.length === 0 || (row.length === 1 && !row[0])) continue;

      const supGstin = supGstinIdx !== -1 && row[supGstinIdx] ? row[supGstinIdx].trim() : '27AAACB2100P1Z0';
      const supName = supNameIdx !== -1 && row[supNameIdx] ? row[supNameIdx].trim() : 'Auto Vendor';
      const invNo = row[invNoIdx]?.trim() || `2B-INV-${r}`;
      const invDate = invDateIdx !== -1 && row[invDateIdx] ? row[invDateIdx].trim() : '2026-04-10';
      const taxable = parseFloat((row[taxableIdx] || '0').replace(/[^0-9.-]+/g, '')) || 0;
      const igst = igstIdx !== -1 ? parseFloat((row[igstIdx] || '0').replace(/[^0-9.-]+/g, '')) || 0 : 0;
      const cgst = cgstIdx !== -1 ? parseFloat((row[cgstIdx] || '0').replace(/[^0-9.-]+/g, '')) || 0 : 0;
      const sgst = sgstIdx !== -1 ? parseFloat((row[sgstIdx] || '0').replace(/[^0-9.-]+/g, '')) || 0 : 0;
      const cess = cessIdx !== -1 ? parseFloat((row[cessIdx] || '0').replace(/[^0-9.-]+/g, '')) || 0 : 0;
      const itcAvailable = itcAvailIdx !== -1 ? row[itcAvailIdx]?.toUpperCase() !== 'N' : true;
      const filingDate = fileDateIdx !== -1 && row[fileDateIdx] ? row[fileDateIdx].trim() : '2026-05-11';

      records.push({
        id: `2B-IMP-${Date.now()}-${r}`,
        supplierGstin: supGstin,
        supplierName: supName,
        invoiceNumber: invNo,
        invoiceDate: invDate,
        invoiceType: 'B2B',
        invoiceValue: taxable + igst + cgst + sgst + cess,
        placeOfSupply: '27-Maharashtra',
        reverseCharge: false,
        taxableValue: taxable,
        igst,
        cgst,
        sgst,
        cess,
        itcAvailable,
        period: '042026',
        filingDate
      });
    }

    return { success: true, data: records, errors: [] };
  } catch (err: any) {
    return { success: false, data: [], errors: [err.message || 'Failed to parse GSTR-2B CSV'] };
  }
}
