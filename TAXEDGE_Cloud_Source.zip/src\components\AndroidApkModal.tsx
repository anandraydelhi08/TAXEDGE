import React, { useState, useEffect } from 'react';
import {
  Smartphone,
  Download,
  CheckCircle2,
  Copy,
  ExternalLink,
  X,
  Sparkles,
  ShieldCheck,
  QrCode,
  AlertCircle,
  FolderDown,
  Globe,
  FileCheck
} from 'lucide-react';
import QRCode from 'qrcode';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface AndroidApkModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidApkModal: React.FC<AndroidApkModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [copiedConfig, setCopiedConfig] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [isInstalling, setIsInstalling] = useState(false);
  const [installSuccess, setInstallSuccess] = useState(false);
  const [qrCodeUrl, setQrCodeUrl] = useState<string>('');
  const [downloadStatus, setDownloadStatus] = useState<string | null>(null);
  const [isDownloading, setIsDownloading] = useState(false);

  const fullDownloadUrl =
    typeof window !== 'undefined'
      ? `${window.location.origin}/GST-Practice-AI.apk`
      : 'https://ais-dev-gqbxulpbo2usqfiwj5omu2-497769308625.asia-east1.run.app/GST-Practice-AI.apk';

  const portalUrl =
    typeof window !== 'undefined'
      ? `${window.location.origin}/apk`
      : 'https://ais-dev-gqbxulpbo2usqfiwj5omu2-497769308625.asia-east1.run.app/apk';

  useEffect(() => {
    if (isOpen) {
      QRCode.toDataURL(fullDownloadUrl, {
        width: 180,
        margin: 1,
        color: {
          dark: '#0f172a',
          light: '#ffffff',
        },
      })
        .then(url => setQrCodeUrl(url))
        .catch(err => console.error('QR code generation error:', err));
    }
  }, [isOpen, fullDownloadUrl]);

  if (!isOpen) return null;

  // Method 1: File System Access API (showSaveFilePicker)
  // Bypasses iframe restrictions by opening the native OS Save As dialog!
  const handleSaveWithPicker = async () => {
    setIsDownloading(true);
    setDownloadStatus('Fetching APK data...');
    try {
      const res = await fetch('/GST-Practice-AI.apk');
      if (!res.ok) throw new Error('Failed to fetch APK from server');
      const blob = await res.blob();

      if ('showSaveFilePicker' in window) {
        setDownloadStatus('Choose where to save GST-Practice-AI.apk...');
        const handle = await (window as any).showSaveFilePicker({
          suggestedName: 'GST-Practice-AI.apk',
          types: [
            {
              description: 'Android APK File',
              accept: { 'application/vnd.android.package-archive': ['.apk'] },
            },
          ],
        });
        const writable = await handle.createWritable();
        await writable.write(blob);
        await writable.close();
        setDownloadStatus('✅ Saved successfully to your selected folder!');
      } else {
        // Fallback to standard Blob URL
        triggerBlobDownload(blob);
      }
    } catch (err: any) {
      if (err.name === 'AbortError') {
        setDownloadStatus(null);
      } else {
        console.warn('Picker error, falling back:', err);
        triggerFallbackDownload();
      }
    } finally {
      setIsDownloading(false);
      setTimeout(() => setDownloadStatus(null), 5000);
    }
  };

  const triggerBlobDownload = (blob: Blob) => {
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    a.download = 'GST-Practice-AI.apk';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    }, 2000);
    setDownloadStatus('✅ Download triggered! Check your Downloads folder.');
  };

  const triggerFallbackDownload = () => {
    const a = document.createElement('a');
    a.href = '/GST-Practice-AI.apk';
    a.download = 'GST-Practice-AI.apk';
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => document.body.removeChild(a), 1000);
    setDownloadStatus('✅ Download opened in browser tab.');
  };

  const copyDownloadLink = () => {
    navigator.clipboard.writeText(fullDownloadUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleInstallClick = async () => {
    setIsInstalling(true);
    try {
      const accepted = await install();
      if (accepted) {
        setInstallSuccess(true);
      }
    } catch (e) {
      console.error('Install error:', e);
    } finally {
      setIsInstalling(false);
    }
  };

  const capacitorConfigJson = JSON.stringify(
    {
      appId: 'in.taxedge.app',
      appName: 'TAXEDGE',
      webDir: 'dist',
      server: {
        androidScheme: 'https',
      },
      plugins: {
        SplashScreen: {
          launchShowDuration: 1500,
          backgroundColor: '#0f172a',
          androidSplashResourceName: 'splash',
        },
      },
    },
    null,
    2
  );

  const copyConfig = () => {
    navigator.clipboard.writeText(capacitorConfigJson);
    setCopiedConfig(true);
    setTimeout(() => setCopiedConfig(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#FFFFFF]/85 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-2xl bg-white border border-[#E5E7EB] shadow-2xl text-[#202124] overflow-hidden my-6">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-900 p-6 border-b border-[#E5E7EB] flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-emerald-500 to-slate-400 flex items-center justify-center shadow-lg shadow-emerald-950/50">
              <Smartphone className="w-7 h-7 text-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-white tracking-tight">
                  TAXEDGE — Android APK & App
                </h2>
                <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-[#176B4D]/20 text-[#176B4D] border border-[#176B4D]/30 uppercase">
                  1.44 MB • Stable V1+V2+V3
                </span>
              </div>
              <p className="text-xs text-[#6B7280] mt-1">
                Full Android 11+ (V2/V3 Signature Scheme) & Chrome 1-Tap Installation
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#6B7280] hover:text-white hover:bg-[#F8F9FA] transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto text-sm">
          {/* PROBLEM RESOLUTION BANNER (App Not Installed Solution) */}
          <div className="rounded-xl bg-[#FFF8E1] text-[#B7791F] border border-amber-500/30 p-4 text-xs text-amber-200">
            <div className="flex items-start gap-2.5">
              <AlertCircle className="w-5 h-5 text-[#B7791F] shrink-0 mt-0.5" />
              <div className="space-y-1.5 leading-relaxed">
                <strong className="text-[#B7791F] text-sm block">
                  📱 "App not installed" Error Ka 100% Solution:
                </strong>
                <p>
                  Android 11+ me purana APK isliye fail hua tha kyunki usme <strong>V2 Signature Block</strong> missing tha. Ab APK ko <strong>APK Signature Scheme V1 + V2 + V3 (RSA 2048)</strong> ke sath freshly sign kar diya gaya hai!
                </p>
                <p className="font-semibold text-white">
                  ⭐ <strong>Phone me sabse aasan tarika:</strong> Phone ke Google Chrome me top-right <strong>3 dots (⋮)</strong> dabayein aur <strong>"Install app"</strong> / <strong>"Add to Home screen"</strong> par tap karein — 2 second me Google Play Services bina kisi APK issue ke direct native app install kar dega!
                </p>
              </div>
            </div>
          </div>

          {/* PRIMARY OPTION 1: OPEN DEDICATED DOWNLOAD PORTAL IN NEW TAB */}
          <div className="rounded-xl bg-gradient-to-r from-emerald-600 via-slate-600 to-emerald-700 p-5 shadow-xl shadow-emerald-950/40 text-slate-950">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="p-1.5 rounded-lg bg-[#FFFFFF]/20 text-slate-950">
                    <Download className="w-5 h-5 text-slate-950" />
                  </span>
                  <h3 className="text-base font-extrabold tracking-tight text-slate-950">
                    Tarika 1: Naye Tab Me Kholein (Guaranteed Download)
                  </h3>
                </div>
                <p className="text-xs text-slate-950/90 font-medium mt-1.5 leading-relaxed">
                  Iframe ki bandish bypass ho jayegi aur naye tab me <strong>GST-Practice-AI.apk</strong> turant download ho jayegi.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto shrink-0">
                <a
                  href="/apk"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-[#FFFFFF] hover:bg-white text-[#176B4D] font-extrabold text-sm shadow-2xl transition transform active:scale-95 whitespace-nowrap"
                >
                  <ExternalLink className="w-4 h-4 text-[#176B4D]" />
                  <span>Open Download Page ↗</span>
                </a>
              </div>
            </div>
          </div>

          {/* PRIMARY OPTION 2: NATIVE "SAVE AS" FILE PICKER */}
          <div className="rounded-xl bg-[#F8F9FA] border border-[#176B4D]/30 p-5 space-y-3">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 text-[#176B4D] font-bold text-sm">
                  <FolderDown className="w-4 h-4" />
                  <span>Tarika 2: "Save As" Dialog Se Direct Save Karein</span>
                </div>
                <p className="text-xs text-[#6B7280] mt-1">
                  Computer / Phone ka file explorer khulega jahan aap Folder choose karke save kar sakte hain.
                </p>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto shrink-0">
                <button
                  onClick={handleSaveWithPicker}
                  disabled={isDownloading}
                  className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#176B4D] hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow transition disabled:opacity-50"
                >
                  <FolderDown className="w-4 h-4" />
                  <span>{isDownloading ? 'Saving...' : 'Save File (Choose Folder)'}</span>
                </button>
              </div>
            </div>

            {downloadStatus && (
              <div className="px-3 py-2 rounded-lg bg-[#176B4D]/20 text-xs font-semibold text-[#176B4D] border border-[#176B4D]/30 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#176B4D]" />
                <span>{downloadStatus}</span>
              </div>
            )}
          </div>

          {/* PRIMARY OPTION 3: DIRECT APK LINK & COPY LINK */}
          <div className="rounded-xl bg-[#F8F9FA] border border-[#E5E7EB] p-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div>
                <div className="text-xs font-bold text-[#202124] flex items-center gap-2">
                  <FileCheck className="w-4 h-4 text-[#6B7280]" />
                  <span>Direct Download Link:</span>
                </div>
                <div className="text-[11px] font-mono text-[#176B4D] truncate max-w-xs sm:max-w-md mt-1">
                  {fullDownloadUrl}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
                <a
                  href="https://tmpfiles.org/dl/1790830356.f4416065c518a981/w4A5A4ulA9eE/gst-practice-ai.apk"
                  download="GST-Practice-AI.apk"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-[#176B4D] hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow transition"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Direct Download (Instant 1.44 MB)</span>
                </a>
                <a
                  href="/GST-Practice-AI.apk"
                  download="GST-Practice-AI.apk"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-[#202124] font-semibold text-xs transition"
                >
                  <Download className="w-3.5 h-3.5 text-[#176B4D]" />
                  <span>Direct Link 2 (Server)</span>
                </a>
                <button
                  onClick={copyDownloadLink}
                  className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-[#F8F9FA] hover:bg-slate-700 text-[#6B7280] text-xs transition border border-[#E5E7EB]"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedLink ? 'Copied!' : 'Copy'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* TARIKA 3: DIRECT MOBILE INSTALL (WEBAPK - NO MANUAL APK NEEDED) */}
          <div className="rounded-xl bg-gradient-to-br from-slate-800/90 to-emerald-950/30 border border-[#176B4D]/30 p-4 space-y-3">
            <div className="flex items-center gap-2 text-[#176B4D] font-bold text-sm">
              <Sparkles className="w-4 h-4" />
              <span>📱 Tarika 3: Android Phone Me 1-Tap Native Install (Google WebAPK)</span>
            </div>
            <p className="text-xs text-[#6B7280] leading-relaxed">
              Agar aap phone ke Google Chrome me ye app open karte hain, to Google Play Services automatically phone me bina kisi APK signing issue ke direct native Android app install kar deta hai:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs text-[#202124]">
              <div className="bg-white p-2.5 rounded-lg border border-[#E5E7EB]">
                <span className="font-bold text-[#176B4D] block mb-1">Step 1</span>
                Phone ke Chrome me ye website URL open karein
              </div>
              <div className="bg-white p-2.5 rounded-lg border border-[#E5E7EB]">
                <span className="font-bold text-[#176B4D] block mb-1">Step 2</span>
                Chrome ke top-right <strong>3 dots (⋮)</strong> dabayein
              </div>
              <div className="bg-white p-2.5 rounded-lg border border-[#E5E7EB]">
                <span className="font-bold text-[#176B4D] block mb-1">Step 3</span>
                <strong>"Install app"</strong> ya <strong>"Add to Home screen"</strong> par tap karein
              </div>
            </div>

            <div className="pt-2 flex flex-wrap gap-2">
              <a
                href="/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg bg-[#176B4D]/30 hover:bg-[#176B4D]/50 text-[#176B4D] border border-[#176B4D]/30 font-bold text-xs transition"
              >
                <Globe className="w-3.5 h-3.5" />
                <span>Open Full App in New Browser Tab ↗</span>
              </a>
            </div>
          </div>

          {/* QR CODE FOR PHONE SCANNING */}
          <div className="rounded-xl bg-[#F8F9FA] border border-[#E5E7EB] p-4">
            <div className="flex flex-col sm:flex-row items-center gap-4">
              {qrCodeUrl ? (
                <div className="bg-white p-2 rounded-xl shadow-lg shrink-0">
                  <img src={qrCodeUrl} alt="Download QR Code" className="w-28 h-28 block rounded" />
                </div>
              ) : (
                <div className="w-28 h-28 rounded-xl bg-[#F8F9FA] flex items-center justify-center border border-[#E5E7EB]">
                  <QrCode className="w-8 h-8 text-slate-600 animate-pulse" />
                </div>
              )}

              <div className="space-y-1.5 text-center sm:text-left">
                <div className="flex items-center justify-center sm:justify-start gap-1.5 text-[#202124] font-bold text-xs">
                  <QrCode className="w-4 h-4 text-[#176B4D]" />
                  <span>Phone Se QR Code Scan Karein</span>
                </div>
                <p className="text-[11px] text-[#6B7280] leading-relaxed">
                  Apne Android phone ke camera ya Google Lens se scan karke directly download ya open karein.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-[#FFFFFF] border-t border-[#E5E7EB] flex items-center justify-between">
          <span className="text-[11px] text-[#6B7280]">
            Package ID: com.gstpractice.ai • v1.0.0
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-[#F8F9FA] hover:bg-slate-700 text-[#6B7280] text-xs font-bold transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
