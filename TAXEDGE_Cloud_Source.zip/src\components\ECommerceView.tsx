import React from 'react';
import { ShoppingBag, CheckCircle2, AlertTriangle, Download, ArrowUpRight, ShieldCheck, DollarSign } from 'lucide-react';
import { ECommerceReport } from '../types/gst';
import { formatINR } from '../utils/taxMath';
import { ecommerceEngine } from '../services/ecommerceEngine';

interface ECommerceViewProps {
  reports: ECommerceReport[];
  onOpenAI: (prompt: string) => void;
}

export const ECommerceView: React.FC<ECommerceViewProps> = ({ reports, onOpenAI }) => {
  const summary = ecommerceEngine.summarizeReports(reports);

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-[#202124] flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[#176B4D]" />
              E-Commerce & TCS Reconciliation Engine
            </h2>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#176B4D]/20 text-[#176B4D] font-bold border border-[#176B4D]/30">
              Section 52 & GSTR-8 Reconciled
            </span>
          </div>
          <p className="text-xs text-[#6B7280] mt-1">
            Reconciling Amazon, Flipkart, and Swiggy merchant statements against GSTR-8 TCS credits.
          </p>
        </div>

        <button
          onClick={() => onOpenAI('Explain Section 52 TCS reconciliation and GSTR-8 credit mechanism in Bare Law April 2026')}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white hover:bg-[#E8F5EF] text-[#176B4D] border border-[#176B4D]/40 shadow-sm text-xs font-bold transition"
        >
          <span>Section 52 Bare Law Citations</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-[#E5E7EB] rounded-xl p-4">
          <div className="text-[11px] text-[#6B7280] font-medium">Gross Platform Sales</div>
          <div className="text-xl font-bold text-[#202124] mt-1 font-mono">{formatINR(summary.totalGrossSales)}</div>
          <div className="text-[10px] text-[#6B7280] mt-1">Before returns & discounts</div>
        </div>

        <div className="bg-white border border-[#E5E7EB] rounded-xl p-4">
          <div className="text-[11px] text-[#6B7280] font-medium">Net Taxable Turnover</div>
          <div className="text-xl font-bold text-[#176B4D] mt-1">{formatINR(summary.totalNetTaxable)}</div>
          <div className="text-[10px] text-[#6B7280] mt-1">Reported in GSTR-1 Table 4C/7</div>
        </div>

        <div className="bg-white border border-slate-500/30 rounded-xl p-4 bg-[#FFFFFF]/10">
          <div className="text-[11px] text-[#6B7280] font-medium">TCS Deducted (1% Sec 52)</div>
          <div className="text-xl font-bold text-[#6B7280] mt-1">{formatINR(summary.totalTcsDeducted)}</div>
          <div className="text-[10px] text-[#6B7280]/80 mt-1">Credited in Electronic Cash Ledger</div>
        </div>

        <div className="bg-white border border-[#E5E7EB] rounded-xl p-4">
          <div className="text-[11px] text-[#6B7280] font-medium">Net Settlement Received</div>
          <div className="text-xl font-bold text-[#202124] mt-1 font-mono">{formatINR(summary.totalNetSettlement)}</div>
          <div className="text-[10px] text-[#6B7280] mt-1">Post platform commission</div>
        </div>
      </div>

      {/* Platform Reports Table */}
      <div className="bg-white border border-[#E5E7EB] rounded-xl overflow-hidden shadow-lg p-5 space-y-4">
        <h3 className="text-sm font-bold text-[#202124] flex items-center gap-2">
          <ShoppingBag className="w-4 h-4 text-[#176B4D]" />
          E-Commerce Operator Monthly Statements
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#6B7280]">
            <thead className="bg-[#F8F9FA] text-[#6B7280] text-[11px] uppercase font-semibold">
              <tr>
                <th className="px-4 py-3">Platform</th>
                <th className="px-3 py-3">Operator GSTIN</th>
                <th className="px-3 py-3 text-right">Gross Sales</th>
                <th className="px-3 py-3 text-right">Returns</th>
                <th className="px-3 py-3 text-right">Net Taxable</th>
                <th className="px-3 py-3 text-right">GST Collected</th>
                <th className="px-3 py-3 text-right">TCS (1%)</th>
                <th className="px-3 py-3 text-right">Commission</th>
                <th className="px-3 py-3 text-right">Net Payout</th>
                <th className="px-3 py-3 text-center">GSTR-8 Match</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 font-mono">
              {reports.map(r => (
                <tr key={r.id} className="hover:bg-[#F8F9FA]">
                  <td className="px-4 py-3 font-sans font-bold text-[#202124] flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                    {r.platform}
                  </td>
                  <td className="px-3 py-3 text-[#6B7280]">{r.operatorGstin}</td>
                  <td className="px-3 py-3 text-right">{formatINR(r.grossSales)}</td>
                  <td className="px-3 py-3 text-right text-[#C62828]">-{formatINR(r.salesReturn)}</td>
                  <td className="px-3 py-3 text-right text-[#202124] font-semibold">{formatINR(r.netTaxableSales)}</td>
                  <td className="px-3 py-3 text-right text-[#176B4D]">{formatINR(r.totalTax)}</td>
                  <td className="px-3 py-3 text-right text-[#6B7280] font-bold">{formatINR(r.tcsDeductedSection52)}</td>
                  <td className="px-3 py-3 text-right text-[#6B7280]">-{formatINR(r.commissionDeducted)}</td>
                  <td className="px-3 py-3 text-right text-[#176B4D] font-bold">{formatINR(r.netSettlementAmount)}</td>
                  <td className="px-3 py-3 text-center">
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded bg-[#176B4D]/20 text-[#176B4D] border border-[#176B4D]/30">
                      <CheckCircle2 className="w-3 h-3" /> MATCHED
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
