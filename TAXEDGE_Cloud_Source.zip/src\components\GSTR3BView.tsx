import React, { useState } from 'react';
import { FileSpreadsheet, ShieldAlert, CheckCircle2, AlertTriangle, Layers, Wallet, GitCompare, Download } from 'lucide-react';
import { GSTR3BSummary, GSTR1Summary, TransactionInvoice, GSTR2BRecord } from '../types/gst';
import { formatINR } from '../utils/taxMath';
import { gstr3bEngine } from '../services/gstr3bEngine';

interface GSTR3BViewProps {
  gstr3b: GSTR3BSummary;
  gstr1: GSTR1Summary;
  sales: TransactionInvoice[];
  purchases: TransactionInvoice[];
  gstr2b: GSTR2BRecord[];
}

export const GSTR3BView: React.FC<GSTR3BViewProps> = ({
  gstr3b,
  gstr1,
  sales,
  purchases,
  gstr2b
}) => {
  const [activeTab, setActiveTab] = useState<'table31' | 'table4' | 'table61' | 'reconciliation4way'>('table61');

  const fourWay = gstr3bEngine.generate4WayReconciliation(sales, purchases, gstr1, gstr2b, gstr3b);

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-black text-slate-900 flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5 text-[#0B1F44]" />
              GSTR-3B Monthly Return & Tax Settlement Engine
            </h2>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-800 font-bold border border-amber-200">
              Section 39 & Rule 61 / 88A
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Auto-calculated summary return for {gstr3b.period} • GSTIN: {gstr3b.gstin}
          </p>
        </div>
      </div>

      {/* Zero Data Empty State Guard */}
      {sales.length === 0 && purchases.length === 0 && (
        <div className="p-8 sm:p-12 rounded-3xl bg-white border border-slate-200/90 shadow-sm text-center space-y-4 max-w-2xl mx-auto my-6">
          <div className="w-16 h-16 rounded-2xl bg-amber-50 text-[#D4A24C] border border-amber-200 flex items-center justify-center mx-auto shadow-2xs">
            <FileSpreadsheet className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-lg font-black text-slate-900 tracking-tight">
              No Data Uploaded for GSTR-3B Computation
            </h3>
            <p className="text-xs text-slate-500 mt-1.5 max-w-md mx-auto leading-relaxed">
              GSTR-3B monthly return and Rule 88A tax set-off require outward turnover (Table 3.1) and inward ITC records (Table 4). Please upload your sales and purchase registers to auto-calculate tax liability.
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <a
              href="/TAXEDGE_GST_TEMPLATE.xlsx"
              download="TAXEDGE_GST_TEMPLATE.xlsx"
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#0B1F44] hover:bg-[#152e61] text-white text-xs font-bold transition shadow-sm active:scale-95"
            >
              <Download className="w-4 h-4 text-[#D4A24C]" />
              <span>Download Master Template (.xlsx)</span>
            </a>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto">
        {[
          { id: 'table61', label: 'Table 6.1: Payment of Tax (Rule 88A Set-Off)' },
          { id: 'table31', label: 'Table 3.1: Outward Supplies & RCM Inward' },
          { id: 'table4', label: 'Table 4: Eligible & Ineligible ITC' },
          { id: 'reconciliation4way', label: '4-Way Reconciliation (Books vs 1 vs 2B vs 3B)' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
              activeTab === tab.id
                ? 'bg-[#0B1F44] text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab 1: Table 6.1 Payment of Tax */}
      {activeTab === 'table61' && (
        <div className="space-y-6">
          {/* Executive Summary Card */}
          <div className="bg-white border border-[#E5E7EB] rounded-2xl p-6 shadow-xl grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <div className="text-xs text-[#6B7280] font-medium">Total Gross Tax Payable</div>
              <div className="text-2xl font-black text-[#202124] mt-1">
                {formatINR(
                  gstr3b.table6_1_PaymentOfTax.taxPayable.igst +
                  gstr3b.table6_1_PaymentOfTax.taxPayable.cgst +
                  gstr3b.table6_1_PaymentOfTax.taxPayable.sgst +
                  (gstr3b.table6_1_PaymentOfTax.taxPayable.cess || 0)
                )}
              </div>
              <div className="text-[11px] text-[#6B7280] mt-1">Includes forward liability + Section 9(3) RCM + Cess</div>
            </div>

            <div>
              <div className="text-xs text-[#6B7280] font-medium">Discharged via ITC Credit (Rule 88A)</div>
              <div className="text-2xl font-black text-[#176B4D] mt-1">
                {formatINR(
                  gstr3b.table6_1_PaymentOfTax.paidThroughITC.igstPaidFromIgst +
                  gstr3b.table6_1_PaymentOfTax.paidThroughITC.cgstPaidFromCgst +
                  gstr3b.table6_1_PaymentOfTax.paidThroughITC.sgstPaidFromSgst +
                  gstr3b.table6_1_PaymentOfTax.paidThroughITC.cgstPaidFromIgst +
                  gstr3b.table6_1_PaymentOfTax.paidThroughITC.sgstPaidFromIgst +
                  (gstr3b.table6_1_PaymentOfTax.paidThroughITC.cessPaidFromCess || 0)
                )}
              </div>
              <div className="text-[11px] text-[#176B4D] mt-1">IGST credit exhausted 100% first</div>
            </div>

            <div>
              <div className="text-xs text-[#B7791F] font-medium">Net Tax to be Paid in CASH</div>
              <div className="text-2xl font-black text-[#B7791F] mt-1">
                {formatINR(gstr3b.table6_1_PaymentOfTax.totalCashPayable)}
              </div>
              <div className="text-[11px] text-amber-500 mt-1">Electronic Cash Ledger debit required</div>
            </div>
          </div>

          {/* Table 6.1 Detailed Ledger Grid */}
          <div className="bg-white border border-[#E5E7EB] rounded-xl overflow-hidden shadow-lg p-5 space-y-4">
            <h3 className="text-sm font-bold text-[#202124] flex items-center gap-2">
              <Wallet className="w-4 h-4 text-[#176B4D]" />
              Table 6.1: Detailed Payment of Tax Ledger (Statutory Set-Off Matrix)
            </h3>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-[#6B7280]">
                <thead className="bg-[#F8F9FA] text-[#6B7280] text-[11px] uppercase font-semibold">
                  <tr>
                    <th className="px-3 py-2.5">Tax Head</th>
                    <th className="px-3 py-2.5 text-right">Tax Payable</th>
                    <th className="px-3 py-2.5 text-right">Paid via IGST Credit</th>
                    <th className="px-3 py-2.5 text-right">Paid via CGST Credit</th>
                    <th className="px-3 py-2.5 text-right">Paid via SGST Credit</th>
                    <th className="px-3 py-2.5 text-right">Tax Paid in Cash</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E5E7EB] font-mono">
                  <tr>
                    <td className="px-3 py-2.5 font-sans font-bold text-[#176B4D]">Integrated Tax (IGST)</td>
                    <td className="px-3 py-2.5 text-right font-bold text-[#202124]">
                      {formatINR(gstr3b.table6_1_PaymentOfTax.taxPayable.igst)}
                    </td>
                    <td className="px-3 py-2.5 text-right text-[#176B4D]">
                      {formatINR(gstr3b.table6_1_PaymentOfTax.paidThroughITC.igstPaidFromIgst)}
                    </td>
                    <td className="px-3 py-2.5 text-right text-[#6B7280]">₹0.00</td>
                    <td className="px-3 py-2.5 text-right text-[#6B7280]">₹0.00</td>
                    <td className="px-3 py-2.5 text-right font-bold text-[#B7791F]">
                      {formatINR(gstr3b.table6_1_PaymentOfTax.taxPaidInCash.igst)}
                    </td>
                  </tr>

                  <tr>
                    <td className="px-3 py-2.5 font-sans font-bold text-[#176B4D]">Central Tax (CGST)</td>
                    <td className="px-3 py-2.5 text-right font-bold text-[#202124]">
                      {formatINR(gstr3b.table6_1_PaymentOfTax.taxPayable.cgst)}
                    </td>
                    <td className="px-3 py-2.5 text-right text-[#176B4D]">
                      {formatINR(gstr3b.table6_1_PaymentOfTax.paidThroughITC.cgstPaidFromIgst)}
                    </td>
                    <td className="px-3 py-2.5 text-right text-[#176B4D]">
                      {formatINR(gstr3b.table6_1_PaymentOfTax.paidThroughITC.cgstPaidFromCgst)}
                    </td>
                    <td className="px-3 py-2.5 text-right text-rose-500 text-[10px] font-sans font-bold">
                      PROHIBITED
                    </td>
                    <td className="px-3 py-2.5 text-right font-bold text-[#B7791F]">
                      {formatINR(gstr3b.table6_1_PaymentOfTax.taxPaidInCash.cgst)}
                    </td>
                  </tr>

                  <tr>
                    <td className="px-3 py-2.5 font-sans font-bold text-[#176B4D]">State Tax (SGST)</td>
                    <td className="px-3 py-2.5 text-right font-bold text-[#202124]">
                      {formatINR(gstr3b.table6_1_PaymentOfTax.taxPayable.sgst)}
                    </td>
                    <td className="px-3 py-2.5 text-right text-[#176B4D]">
                      {formatINR(gstr3b.table6_1_PaymentOfTax.paidThroughITC.sgstPaidFromIgst)}
                    </td>
                    <td className="px-3 py-2.5 text-right text-rose-500 text-[10px] font-sans font-bold">
                      PROHIBITED
                    </td>
                    <td className="px-3 py-2.5 text-right text-[#176B4D]">
                      {formatINR(gstr3b.table6_1_PaymentOfTax.paidThroughITC.sgstPaidFromSgst)}
                    </td>
                    <td className="px-3 py-2.5 text-right font-bold text-[#B7791F]">
                      {formatINR(gstr3b.table6_1_PaymentOfTax.taxPaidInCash.sgst)}
                    </td>
                  </tr>

                  {(gstr3b.table6_1_PaymentOfTax.taxPayable.cess > 0 || (gstr3b.table6_1_PaymentOfTax.taxPaidInCash.cess || 0) > 0) && (
                    <tr>
                      <td className="px-3 py-2.5 font-sans font-bold text-amber-700">Compensation Cess</td>
                      <td className="px-3 py-2.5 text-right font-bold text-[#202124]">
                        {formatINR(gstr3b.table6_1_PaymentOfTax.taxPayable.cess)}
                      </td>
                      <td className="px-3 py-2.5 text-right text-[#6B7280]">PROHIBITED</td>
                      <td className="px-3 py-2.5 text-right text-[#6B7280]">PROHIBITED</td>
                      <td className="px-3 py-2.5 text-right text-[#6B7280]">PROHIBITED</td>
                      <td className="px-3 py-2.5 text-right font-bold text-[#B7791F]">
                        {formatINR(gstr3b.table6_1_PaymentOfTax.taxPaidInCash.cess || 0)}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <div className="p-3 rounded-lg bg-amber-950/20 border border-amber-900/40 text-xs text-[#B7791F]">
              <strong>Statutory Set-Off Note:</strong> Section 49B & Rule 88A mandates that CGST and SGST cannot cross-utilize under any circumstance. Central Tax has been set off against CGST liability, and State Tax against SGST liability.
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Table 3.1 Outward & RCM */}
      {activeTab === 'table31' && (
        <div className="bg-white border border-[#E5E7EB] rounded-xl overflow-hidden shadow-lg p-5 space-y-4">
          <h3 className="text-sm font-bold text-[#202124]">
            Table 3.1: Details of Outward Supplies and Inward Supplies Liable to Reverse Charge
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-[#6B7280]">
              <thead className="bg-[#F8F9FA] text-[#6B7280] text-[11px] uppercase font-semibold">
                <tr>
                  <th className="px-4 py-3">Nature of Supplies</th>
                  <th className="px-4 py-3 text-right">Total Taxable Value</th>
                  <th className="px-4 py-3 text-right">IGST</th>
                  <th className="px-4 py-3 text-right">CGST</th>
                  <th className="px-4 py-3 text-right">SGST</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E5E7EB] font-mono">
                <tr>
                  <td className="px-4 py-3 font-sans text-[#202124] font-medium">
                    (a) Outward taxable supplies (other than zero rated, nil and exempted)
                  </td>
                  <td className="px-4 py-3 text-right text-[#202124] font-bold">{formatINR(gstr3b.table3_1.outwardTaxable.taxable)}</td>
                  <td className="px-4 py-3 text-right text-[#176B4D]">{formatINR(gstr3b.table3_1.outwardTaxable.igst)}</td>
                  <td className="px-4 py-3 text-right text-[#176B4D]">{formatINR(gstr3b.table3_1.outwardTaxable.cgst)}</td>
                  <td className="px-4 py-3 text-right text-[#176B4D]">{formatINR(gstr3b.table3_1.outwardTaxable.sgst)}</td>
                </tr>

                <tr>
                  <td className="px-4 py-3 font-sans text-[#202124] font-medium">
                    (b) Outward taxable supplies (zero rated exports / SEZ)
                  </td>
                  <td className="px-4 py-3 text-right text-[#202124] font-bold">{formatINR(gstr3b.table3_1.outwardZeroRated.taxable)}</td>
                  <td className="px-4 py-3 text-right text-[#176B4D]">{formatINR(gstr3b.table3_1.outwardZeroRated.igst)}</td>
                  <td className="px-4 py-3 text-right text-[#6B7280]">—</td>
                  <td className="px-4 py-3 text-right text-[#6B7280]">—</td>
                </tr>

                <tr>
                  <td className="px-4 py-3 font-sans text-[#202124] font-medium">
                    (c) Other outward supplies (Nil rated, exempted)
                  </td>
                  <td className="px-4 py-3 text-right text-[#202124] font-bold">{formatINR(gstr3b.table3_1.otherOutwardNilExempt?.taxable || 0)}</td>
                  <td className="px-4 py-3 text-right text-[#6B7280]">—</td>
                  <td className="px-4 py-3 text-right text-[#6B7280]">—</td>
                  <td className="px-4 py-3 text-right text-[#6B7280]">—</td>
                </tr>

                <tr>
                  <td className="px-4 py-3 font-sans text-[#202124] font-medium">
                    (d) Inward supplies liable to reverse charge (Section 9(3))
                  </td>
                  <td className="px-4 py-3 text-right text-purple-700 font-bold">{formatINR(gstr3b.table3_1.inwardRCM.taxable)}</td>
                  <td className="px-4 py-3 text-right text-purple-700">{formatINR(gstr3b.table3_1.inwardRCM.igst)}</td>
                  <td className="px-4 py-3 text-right text-purple-700">{formatINR(gstr3b.table3_1.inwardRCM.cgst)}</td>
                  <td className="px-4 py-3 text-right text-purple-700">{formatINR(gstr3b.table3_1.inwardRCM.sgst)}</td>
                </tr>

                <tr>
                  <td className="px-4 py-3 font-sans text-[#202124] font-medium">
                    (e) Non-GST outward supplies
                  </td>
                  <td className="px-4 py-3 text-right text-[#202124] font-bold">{formatINR(gstr3b.table3_1.nonGstOutward?.taxable || 0)}</td>
                  <td className="px-4 py-3 text-right text-[#6B7280]">—</td>
                  <td className="px-4 py-3 text-right text-[#6B7280]">—</td>
                  <td className="px-4 py-3 text-right text-[#6B7280]">—</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: Table 4 Eligible ITC */}
      {activeTab === 'table4' && (
        <div className="bg-white border border-[#E5E7EB] rounded-xl overflow-hidden shadow-lg p-5 space-y-4">
          <h3 className="text-sm font-bold text-[#202124]">Table 4: Eligible Input Tax Credit (ITC) Summary</h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-[#6B7280]">
              <thead className="bg-[#F8F9FA] text-[#6B7280] text-[11px] uppercase font-semibold">
                <tr>
                  <th className="px-4 py-3">Details</th>
                  <th className="px-4 py-3 text-right">IGST</th>
                  <th className="px-4 py-3 text-right">CGST</th>
                  <th className="px-4 py-3 text-right">SGST</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E5E7EB] font-mono">
                <tr>
                  <td className="px-4 py-3 font-sans font-semibold text-[#176B4D]">(A) ITC Available (whether in full or part)</td>
                  <td colSpan={3}></td>
                </tr>
                <tr>
                  <td className="px-4 py-2 font-sans pl-8 text-[#6B7280]">(3) Inward supplies liable to reverse charge</td>
                  <td className="px-4 py-2 text-right">{formatINR(gstr3b.table4_ITC.itcAvailable.inwardRCM.igst)}</td>
                  <td className="px-4 py-2 text-right">{formatINR(gstr3b.table4_ITC.itcAvailable.inwardRCM.cgst)}</td>
                  <td className="px-4 py-2 text-right">{formatINR(gstr3b.table4_ITC.itcAvailable.inwardRCM.sgst)}</td>
                </tr>
                <tr>
                  <td className="px-4 py-2 font-sans pl-8 text-[#6B7280]">(5) All other ITC (Gross)</td>
                  <td className="px-4 py-2 text-right text-[#176B4D]">{formatINR(gstr3b.table4_ITC.itcAvailable.allOtherITC.igst)}</td>
                  <td className="px-4 py-2 text-right text-[#176B4D]">{formatINR(gstr3b.table4_ITC.itcAvailable.allOtherITC.cgst)}</td>
                  <td className="px-4 py-2 text-right text-[#176B4D]">{formatINR(gstr3b.table4_ITC.itcAvailable.allOtherITC.sgst)}</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 font-sans font-semibold text-[#C62828]">(B) ITC Reversed</td>
                  <td colSpan={3}></td>
                </tr>
                <tr>
                  <td className="px-4 py-2 font-sans pl-8 text-[#6B7280]">(1) As per rules 38, 42 and 43 & section 17(5)</td>
                  <td className="px-4 py-2 text-right text-[#C62828]">{formatINR(gstr3b.table4_ITC.itcReversed.asPerRules38_42_43_and_17_5.igst)}</td>
                  <td className="px-4 py-2 text-right text-[#C62828]">{formatINR(gstr3b.table4_ITC.itcReversed.asPerRules38_42_43_and_17_5.cgst)}</td>
                  <td className="px-4 py-2 text-right text-[#C62828]">{formatINR(gstr3b.table4_ITC.itcReversed.asPerRules38_42_43_and_17_5.sgst)}</td>
                </tr>
                <tr>
                  <td className="px-4 py-2 font-sans pl-8 text-[#6B7280]">(2) Others (Rule 37 / reclaimable)</td>
                  <td className="px-4 py-2 text-right text-[#C62828]">{formatINR(gstr3b.table4_ITC.itcReversed.others?.igst || 0)}</td>
                  <td className="px-4 py-2 text-right text-[#C62828]">{formatINR(gstr3b.table4_ITC.itcReversed.others?.cgst || 0)}</td>
                  <td className="px-4 py-2 text-right text-[#C62828]">{formatINR(gstr3b.table4_ITC.itcReversed.others?.sgst || 0)}</td>
                </tr>
                <tr className="bg-[#F8F9FA]">
                  <td className="px-4 py-3 font-sans font-bold text-[#202124]">(C) Net ITC Available (A) - (B)</td>
                  <td className="px-4 py-3 text-right font-bold text-[#176B4D]">{formatINR(gstr3b.table4_ITC.netITCAvailable.igst)}</td>
                  <td className="px-4 py-3 text-right font-bold text-[#176B4D]">{formatINR(gstr3b.table4_ITC.netITCAvailable.cgst)}</td>
                  <td className="px-4 py-3 text-right font-bold text-[#176B4D]">{formatINR(gstr3b.table4_ITC.netITCAvailable.sgst)}</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 font-sans font-semibold text-slate-700">(D) Other Details (Ineligible ITC)</td>
                  <td colSpan={3}></td>
                </tr>
                <tr>
                  <td className="px-4 py-2 font-sans pl-8 text-[#6B7280]">(1) ITC reclaimed which was reversed earlier</td>
                  <td className="px-4 py-2 text-right text-slate-600">{formatINR(gstr3b.table4_ITC.ineligibleITC?.asPerSection16_4?.igst || 0)}</td>
                  <td className="px-4 py-2 text-right text-slate-600">{formatINR(gstr3b.table4_ITC.ineligibleITC?.asPerSection16_4?.cgst || 0)}</td>
                  <td className="px-4 py-2 text-right text-slate-600">{formatINR(gstr3b.table4_ITC.ineligibleITC?.asPerSection16_4?.sgst || 0)}</td>
                </tr>
                <tr>
                  <td className="px-4 py-2 font-sans pl-8 text-[#6B7280]">(2) Ineligible ITC u/s 16(4) / POS restriction</td>
                  <td className="px-4 py-2 text-right text-slate-600">{formatINR(gstr3b.table4_ITC.ineligibleITC?.others?.igst || 0)}</td>
                  <td className="px-4 py-2 text-right text-slate-600">{formatINR(gstr3b.table4_ITC.ineligibleITC?.others?.cgst || 0)}</td>
                  <td className="px-4 py-2 text-right text-slate-600">{formatINR(gstr3b.table4_ITC.ineligibleITC?.others?.sgst || 0)}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 4: 4-Way Reconciliation */}
      {activeTab === 'reconciliation4way' && (
        <div className="bg-white border border-[#E5E7EB] rounded-xl overflow-hidden shadow-lg p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-[#202124] flex items-center gap-2">
              <GitCompare className="w-4 h-4 text-[#176B4D]" />
              4-Way Cross-Reconciliation (Books vs GSTR-1 vs GSTR-2B vs GSTR-3B)
            </h3>
            <span className="text-xs text-[#176B4D] font-semibold">Rule 88C & 88D Audited</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-[#6B7280]">
              <thead className="bg-[#F8F9FA] text-[#6B7280] text-[11px] uppercase font-semibold">
                <tr>
                  <th className="px-4 py-3">Reporting Stream</th>
                  <th className="px-3 py-3 text-right">Financial Books</th>
                  <th className="px-3 py-3 text-right">GSTR-1</th>
                  <th className="px-3 py-3 text-right">GSTR-2B</th>
                  <th className="px-3 py-3 text-right">GSTR-3B</th>
                  <th className="px-3 py-3 text-center">Audit Status</th>
                  <th className="px-4 py-3">Audit Observation</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E5E7EB] font-mono">
                {fourWay.map((row, idx) => (
                  <tr key={idx} className="hover:bg-[#F8F9FA]">
                    <td className="px-4 py-3 font-sans font-medium text-[#202124]">{row.stream}</td>
                    <td className="px-3 py-3 text-right">{formatINR(row.books)}</td>
                    <td className="px-3 py-3 text-right text-[#176B4D]">{row.gstr1 !== null ? formatINR(row.gstr1) : '—'}</td>
                    <td className="px-3 py-3 text-right text-[#6B7280]">{row.gstr2b !== null ? formatINR(row.gstr2b) : '—'}</td>
                    <td className="px-3 py-3 text-right text-[#176B4D] font-bold">{formatINR(row.gstr3b)}</td>
                    <td className="px-3 py-3 text-center">
                      <span className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        row.status === 'MATCHED'
                          ? 'bg-[#176B4D]/20 text-[#176B4D] border border-[#176B4D]/30'
                          : 'bg-[#FFF8E1] text-[#B7791F] border border-amber-500/30'
                      }`}>
                        {row.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-sans text-[11px] text-[#6B7280]">{row.note}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
