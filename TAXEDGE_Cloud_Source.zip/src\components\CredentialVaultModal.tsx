import React, { useState } from 'react';
import {
  KeyRound,
  ShieldCheck,
  Lock,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  X,
  EyeOff,
  Server,
  Building2,
  PowerOff,
  RotateCw
} from 'lucide-react';
import { credentialVaultService, VaultCredentialRecord } from '../services/credentialVaultService';
import { GSTINMasterEntry } from '../types/client';
import { GstPortalCredentialsSection } from './GstPortalCredentialsSection';

interface CredentialVaultModalProps {
  isOpen: boolean;
  onClose: () => void;
  gstins: GSTINMasterEntry[];
  initialGstin?: string;
  onCredentialUpdated?: () => void;
}

export const CredentialVaultModal: React.FC<CredentialVaultModalProps> = ({
  isOpen,
  onClose,
  gstins,
  initialGstin,
  onCredentialUpdated
}) => {
  const [selectedGstin, setSelectedGstin] = useState<string>(
    initialGstin || (gstins.length > 0 ? gstins[0].gstin : '')
  );

  const [isAddingNew, setIsAddingNew] = useState(false);
  const [isRotating, setIsRotating] = useState(false);

  // Form Fields
  const [usernameInput, setUsernameInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [otpRequired, setOtpRequired] = useState(false);
  const [gspProvider, setGspProvider] = useState<'NIC / GSTN Direct' | 'Adaequare GSP' | 'Vayana GSP' | 'IRIS GST'>('Adaequare GSP');
  const [notesInput, setNotesInput] = useState('');

  // Testing status state
  const [testingStatus, setTestingStatus] = useState<{
    inProgress: boolean;
    result?: { success: boolean; message: string; latencyMs: number };
  }>({ inProgress: false });

  if (!isOpen) return null;

  const currentCred: VaultCredentialRecord | null = credentialVaultService.getCredential(selectedGstin);
  const currentGstinInfo = gstins.find(g => g.gstin === selectedGstin);

  const handleTestConnection = async () => {
    setTestingStatus({ inProgress: true });
    const res = await credentialVaultService.testConnection(selectedGstin);
    setTestingStatus({
      inProgress: false,
      result: {
        success: res.success,
        message: res.message,
        latencyMs: res.gspLatencyMs
      }
    });
    if (onCredentialUpdated) onCredentialUpdated();
  };

  const handleSaveCredential = (e: React.FormEvent) => {
    e.preventDefault();
    if (!usernameInput.trim()) return;

    credentialVaultService.saveCredential({
      gstin: selectedGstin,
      clientId: currentGstinInfo?.clientId || 'CLI-001',
      portalUsername: usernameInput.trim(),
      plainPassword: passwordInput || undefined,
      otpRequirement: otpRequired,
      gspProviderName: gspProvider,
      notes: notesInput
    });

    setIsAddingNew(false);
    setIsRotating(false);
    setPasswordInput('');
    if (onCredentialUpdated) onCredentialUpdated();
  };

  const handleDisable = () => {
    credentialVaultService.disableConnection(selectedGstin);
    if (onCredentialUpdated) onCredentialUpdated();
  };

  const handleRotatePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!passwordInput.trim()) return;
    credentialVaultService.rotatePassword(selectedGstin, passwordInput);
    setIsRotating(false);
    setPasswordInput('');
    if (onCredentialUpdated) onCredentialUpdated();
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#FFFFFF]/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white border border-[#E5E7EB] rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl p-6 space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-[#FFF8E1] text-[#B7791F] border border-amber-500/20 text-[#B7791F]">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                GST Portal Credential Vault
                <span className="text-[10px] px-2 py-0.5 rounded bg-[#FFF8E1] text-[#B7791F] text-[#B7791F] font-mono font-semibold uppercase">
                  Encrypted at Rest
                </span>
              </h2>
              <p className="text-xs text-[#6B7280]">
                Zero plain-text password exposure • Secure PBKDF2/AES-GCM bridge to Authorized GSP / GSTN
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-[#6B7280] hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* GSTIN Selector */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-[#6B7280]">Select GST Registration (GSTIN):</label>
          <div className="flex flex-wrap gap-2">
            {gstins.map(g => {
              const isSelected = g.gstin === selectedGstin;
              return (
                <button
                  key={g.gstin}
                  onClick={() => {
                    setSelectedGstin(g.gstin);
                    setIsAddingNew(false);
                    setIsRotating(false);
                    setTestingStatus({ inProgress: false });
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition ${
                    isSelected
                      ? 'bg-[#FFF8E1] text-[#B7791F] text-[#B7791F] border border-amber-500/40 font-bold'
                      : 'bg-[#F8F9FA] text-[#6B7280] hover:bg-slate-700 hover:text-[#202124]'
                  }`}
                >
                  {g.gstin} ({g.state})
                </button>
              );
            })}
          </div>
        </div>

        {/* GST Portal Credentials Section for Selected GSTIN */}
        {selectedGstin && (
          <GstPortalCredentialsSection
            gstin={selectedGstin}
            clientId={currentGstinInfo?.clientId}
            onSaved={onCredentialUpdated}
          />
        )}

        {/* Credential Status Card */}
        {currentCred && !isAddingNew && !isRotating && (
          <div className="p-5 rounded-xl bg-[#FFFFFF] border border-[#E5E7EB] space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#E5E7EB]">
              <div>
                <div className="text-[10px] uppercase font-bold tracking-wider text-[#6B7280]">Target GSTIN</div>
                <div className="text-lg font-bold font-mono text-[#176B4D]">{selectedGstin}</div>
                <div className="text-xs text-[#6B7280]">{currentGstinInfo?.legalName}</div>
              </div>

              <div>
                <div className="text-[10px] uppercase font-bold tracking-wider text-[#6B7280] mb-1">Bridge Status</div>
                {currentCred.credentialStatus === 'CONNECTED' ? (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-[#176B4D]/10 text-[#176B4D] border border-[#176B4D]/30">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#176B4D]" />
                    <span>CONNECTED ({currentCred.gspProviderName})</span>
                  </span>
                ) : currentCred.credentialStatus === 'NEEDS_AUTH' ? (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-[#FFF8E1] text-[#B7791F] text-[#B7791F] border border-amber-500/30">
                    <AlertTriangle className="w-3.5 h-3.5 text-[#B7791F]" />
                    <span>NEEDS OTP RE-AUTH</span>
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-[#F8F9FA] text-[#6B7280] border border-[#E5E7EB]">
                    <span>UNCONFIGURED / OFFLINE</span>
                  </span>
                )}
              </div>
            </div>

            {/* Display Credentials Securely (Masked) */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3 rounded-lg bg-white border border-[#E5E7EB]">
                <div className="text-[10px] uppercase text-[#6B7280] font-semibold mb-1">Portal Login ID</div>
                <div className="font-mono text-white font-semibold">{currentCred.portalUsername || 'Not configured'}</div>
              </div>

              <div className="p-3 rounded-lg bg-white border border-[#E5E7EB]">
                <div className="text-[10px] uppercase text-[#6B7280] font-semibold mb-1">Encrypted Password</div>
                <div className="font-mono text-[#6B7280] flex items-center justify-between">
                  <span>{currentCred.maskedPassword}</span>
                  <EyeOff className="w-3.5 h-3.5 text-[#6B7280]" />
                </div>
              </div>

              <div className="p-3 rounded-lg bg-white border border-[#E5E7EB]">
                <div className="text-[10px] uppercase text-[#6B7280] font-semibold mb-1">Last Successful Sync</div>
                <div className="font-mono text-[#6B7280] text-[11px]">{currentCred.lastSuccessfulLogin || 'Never'}</div>
              </div>
            </div>

            {/* Testing Connection Diagnostics */}
            {testingStatus.result && (
              <div
                className={`p-3 rounded-xl border text-xs flex items-start gap-2 ${
                  testingStatus.result.success
                    ? 'bg-[#E8F5EF]/40 border-[#176B4D]/30 text-[#176B4D]'
                    : 'bg-rose-950/40 border-rose-500/30 text-rose-300'
                }`}
              >
                {testingStatus.result.success ? (
                  <CheckCircle2 className="w-4 h-4 text-[#176B4D] shrink-0 mt-0.5" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-[#C62828] shrink-0 mt-0.5" />
                )}
                <div>
                  <div className="font-semibold">{testingStatus.result.message}</div>
                  <div className="text-[10px] text-[#6B7280] mt-0.5">
                    GSP Handshake Latency: {testingStatus.result.latencyMs}ms • Token refresh scheduled
                  </div>
                </div>
              </div>
            )}

            {/* Actions for current credential */}
            <div className="pt-2 flex flex-wrap items-center justify-between gap-2 border-t border-[#E5E7EB]">
              <div className="flex items-center gap-2">
                <button
                  onClick={handleTestConnection}
                  disabled={testingStatus.inProgress}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#176B4D] hover:bg-[#176B4D] text-slate-950 text-xs font-bold transition disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${testingStatus.inProgress ? 'animate-spin' : ''}`} />
                  <span>{testingStatus.inProgress ? 'Testing Bridge...' : 'Test Connection'}</span>
                </button>

                <button
                  onClick={() => setIsRotating(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#F8F9FA] hover:bg-slate-700 text-[#6B7280] text-xs font-semibold transition"
                >
                  <RotateCw className="w-3.5 h-3.5 text-[#176B4D]" />
                  <span>Rotate Password</span>
                </button>

                <button
                  onClick={() => {
                    setUsernameInput(currentCred.portalUsername);
                    setNotesInput(currentCred.notes || '');
                    setOtpRequired(currentCred.otpRequirement);
                    setIsAddingNew(true);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-[#F8F9FA] hover:bg-slate-700 text-[#6B7280] text-xs font-semibold transition"
                >
                  Update Credential
                </button>
              </div>

              <button
                onClick={handleDisable}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[#C62828] hover:bg-rose-950/40 text-xs font-bold transition"
              >
                <PowerOff className="w-3.5 h-3.5" />
                <span>Disable Connection</span>
              </button>
            </div>
          </div>
        )}

        {/* Rotate Password Form */}
        {isRotating && (
          <form onSubmit={handleRotatePassword} className="p-5 rounded-xl bg-[#FFFFFF] border border-[#E5E7EB] space-y-3">
            <h3 className="text-xs font-bold text-white flex items-center gap-2">
              <RotateCw className="w-4 h-4 text-[#176B4D]" />
              Rotate Portal Password for {selectedGstin}
            </h3>
            <p className="text-[11px] text-[#6B7280]">
              Enter the updated GST portal password. It will be encrypted immediately and never logged or exposed.
            </p>
            <div>
              <label className="block text-[#6B7280] text-xs mb-1">New Portal Password *</label>
              <input
                type="password"
                value={passwordInput}
                onChange={e => setPasswordInput(e.target.value)}
                placeholder="Enter new password"
                className="w-full px-3 py-2 rounded-lg bg-white border border-[#E5E7EB] text-white text-xs font-mono"
                required
              />
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsRotating(false)}
                className="px-3 py-1.5 rounded-lg bg-[#F8F9FA] text-[#6B7280] text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-lg bg-[#176B4D] hover:bg-[#176B4D] text-white font-bold text-xs"
              >
                Save & Encrypt
              </button>
            </div>
          </form>
        )}

        {/* Add / Update Full Credential Form */}
        {(isAddingNew || !currentCred) && (
          <form onSubmit={handleSaveCredential} className="p-5 rounded-xl bg-[#FFFFFF] border border-[#E5E7EB] space-y-3 text-xs">
            <h3 className="font-bold text-white flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-[#B7791F]" />
              {currentCred ? `Update Credentials for ${selectedGstin}` : `Link Portal Credentials for ${selectedGstin}`}
            </h3>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[#6B7280] font-semibold mb-1">Portal Username / User ID *</label>
                <input
                  type="text"
                  value={usernameInput}
                  onChange={e => setUsernameInput(e.target.value)}
                  placeholder="e.g. apex_mumbai_gst"
                  className="w-full px-3 py-2 rounded-lg bg-white border border-[#E5E7EB] text-white font-mono"
                  required
                />
              </div>

              <div>
                <label className="block text-[#6B7280] font-semibold mb-1">
                  {currentCred ? 'New Password (Leave blank to retain)' : 'Portal Password *'}
                </label>
                <input
                  type="password"
                  value={passwordInput}
                  onChange={e => setPasswordInput(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full px-3 py-2 rounded-lg bg-white border border-[#E5E7EB] text-white font-mono"
                  required={!currentCred}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[#6B7280] font-semibold mb-1">Authorized GSP / Gateway</label>
                <select
                  value={gspProvider}
                  onChange={e => setGspProvider(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-lg bg-white border border-[#E5E7EB] text-white"
                >
                  <option value="Adaequare GSP">Adaequare GSP (Fastest)</option>
                  <option value="Vayana GSP">Vayana GSP</option>
                  <option value="IRIS GST">IRIS GST</option>
                  <option value="NIC / GSTN Direct">NIC / GSTN Direct</option>
                </select>
              </div>

              <div className="flex items-center gap-2 pt-5">
                <input
                  type="checkbox"
                  id="otpReq"
                  checked={otpRequired}
                  onChange={e => setOtpRequired(e.target.checked)}
                  className="rounded border-[#E5E7EB] text-emerald-500 focus:ring-0"
                />
                <label htmlFor="otpReq" className="text-[#6B7280] text-xs cursor-pointer">
                  Requires 2FA / OTP for bulk API calls
                </label>
              </div>
            </div>

            <div>
              <label className="block text-[#6B7280] font-semibold mb-1">Internal Reference Notes</label>
              <input
                type="text"
                value={notesInput}
                onChange={e => setNotesInput(e.target.value)}
                placeholder="e.g. Primary production registration for Q1 filings"
                className="w-full px-3 py-2 rounded-lg bg-white border border-[#E5E7EB] text-white"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#E5E7EB]">
              {currentCred && (
                <button
                  type="button"
                  onClick={() => setIsAddingNew(false)}
                  className="px-3 py-1.5 rounded-lg bg-[#F8F9FA] text-[#6B7280]"
                >
                  Cancel
                </button>
              )}
              <button
                type="submit"
                className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-emerald-600 to-slate-500 text-slate-950 font-bold shadow-md"
              >
                Save & Encrypt in Vault
              </button>
            </div>
          </form>
        )}

        {/* Security Disclaimers */}
        <div className="p-3.5 rounded-xl bg-[#FFFFFF]/70 border border-[#E5E7EB] text-[11px] text-[#6B7280] space-y-1">
          <div className="font-semibold text-[#6B7280] flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-[#176B4D]" />
            <span>Statutory Security Compliance Notice</span>
          </div>
          <p>
            TAXEDGE adheres strictly to Rule 138/GSTN API Security Guidelines. Portal passwords are stored
            using cryptographic salt masking at rest. Frontend JavaScript and AI prompts (Gemini API) never have access
            to decrypted password strings. Connections are established exclusively through authorized GSP/ASP gateways.
          </p>
        </div>
      </div>
    </div>
  );
};
