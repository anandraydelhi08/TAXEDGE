import { GSTR1Summary, TransactionInvoice } from '../types/gst';
import { gstnSchemaEngine } from './gstnSchemaEngine';
import { extractPosCode } from './gstPortalCsvService';

const GSTIN_REGEX = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;

export class GSTR1Engine {
  /**
   * Prepares GSTR-1 summary from sales invoices.
   */
  public prepareGSTR1(
    sales: TransactionInvoice[],
    period: string = '10-2026',
    gstin?: string,
    legalName?: string
  ): GSTR1Summary {
    const detectedGstin = Array.isArray(sales)
      ? sales.find(s => s.supplierGstin && s.supplierGstin.trim().length === 15)?.supplierGstin
      : undefined;
    const cleanGstin = (gstin && gstin.trim().length === 15)
      ? gstin.trim()
      : (detectedGstin || '07ABFFB5922Q1Z0');
    const cleanLegalName = legalName ? legalName.trim() : 'Practice Taxpayer Entity';
    return this.buildSummary(sales, period, cleanGstin, cleanLegalName);
  }

  /**
   * Builds GSTR-1 summary from sales invoices, strictly adhering to GSTN offline schema rules.
   */
  public buildSummary(sales: TransactionInvoice[], period: string, gstin: string, legalName: string): GSTR1Summary {
    const cleanGstin = (gstin && gstin.trim().length === 15) ? gstin.trim() : '07ABFFB5922Q1Z0';
    const supplierState = cleanGstin.substring(0, 2);
    const safeSales = Array.isArray(sales) ? sales : [];
    let grossTurnover = 0;
    let b2bTaxable = 0;
    let b2bCount = 0;
    let b2bCgst = 0;
    let b2bSgst = 0;
    let b2bIgst = 0;
    let b2bCess = 0;

    let b2clTaxable = 0;
    let b2clCount = 0;
    let b2clIgst = 0;

    let b2csTaxable = 0;
    let b2csCount = 0;
    let b2csCgst = 0;
    let b2csSgst = 0;
    let b2csIgst = 0;

    let exportsTaxable = 0;
    let exportsCount = 0;
    let exportsIgst = 0;

    let nilExemptTurnover = 0;
    let creditNotesTaxable = 0;
    let creditNotesTax = 0;

    const table4_B2B: any[] = [];
    const table5_B2CLarge: any[] = [];
    const table6_Exports: any[] = [];
    const table7_B2CSmall: any[] = [];
    const table8_NilExempt: any[] = [];
    const table9B_CreditDebitNotes: any[] = [];

    const hsnB2bMap = new Map<string, any>();
    const hsnB2cMap = new Map<string, any>();

    const hasExplicitB2bHsn = safeSales.some((s: any) =>
      (s.isHsnSummary || s.id?.startsWith('PORTAL-HSN')) &&
      (s.hsnCategory === 'B2B' || s.classification === 'B2B' || (!s.hsnCategory && s.classification !== 'B2C_SMALL'))
    );
    const hasExplicitB2cHsn = safeSales.some((s: any) =>
      (s.isHsnSummary || s.id?.startsWith('PORTAL-HSN')) &&
      (s.hsnCategory === 'B2C' || s.classification === 'B2C_SMALL' || s.classification === 'B2C_LARGE')
    );

    const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

    for (const inv of safeSales) {
      // Table 13 Document Series records are return metadata, not taxable turnover line items
      if ((inv as any).isDocSummary || inv.id?.startsWith('PORTAL-DOC') || ((inv as any).fromSerial && (inv as any).totalNumber !== undefined)) {
        continue;
      }

      // Table 12 HSN Summary records are return metadata, not individual sales turnover invoices
      if ((inv as any).isHsnSummary || inv.id?.startsWith('PORTAL-HSN')) {
        const isB2b = (inv as any).hsnCategory === 'B2B' || inv.classification === 'B2B' || (!((inv as any).hsnCategory) && inv.classification !== 'B2C_SMALL');
        const hsn = String(inv.hsnSacPrimary || (inv as any).hsnSac || '998313').trim();
        const isService = hsn.startsWith('99');
        const rawUqc = String((inv as any).uqc || 'OTH').split('-')[0].trim().toUpperCase();
        const uqc = isService ? 'NA' : (rawUqc || 'OTH');
        const qty = isService ? 0 : Number((inv as any).totalQuantity ?? (inv as any).quantity ?? 0);
        const rate = inv.gstRate || 18;
        const key = `${hsn}_${uqc}_${rate}`;

        const mapTarget = isB2b ? hsnB2bMap : hsnB2cMap;
        const existing = mapTarget.get(key) || {
          hsnSac: hsn,
          description: inv.descriptionPrimary || (isService ? 'Information technology consulting and support services' : 'Outward Taxable Supply'),
          uqc,
          rate,
          totalQuantity: 0,
          totalValue: 0,
          taxableValue: 0,
          igst: 0,
          cgst: 0,
          sgst: 0,
          cess: 0
        };

        const totalInvVal = inv.totalAmount || round2(inv.taxableValue + inv.cgst + inv.sgst + inv.igst + inv.cess);
        existing.totalQuantity = isService ? 0 : round2(existing.totalQuantity + qty);
        existing.totalValue = round2(existing.totalValue + totalInvVal);
        existing.taxableValue = round2(existing.taxableValue + inv.taxableValue);
        existing.igst = round2(existing.igst + inv.igst);
        existing.cgst = round2(existing.cgst + inv.cgst);
        existing.sgst = round2(existing.sgst + inv.sgst);
        existing.cess = round2(existing.cess + inv.cess);
        mapTarget.set(key, existing);
        continue; // Skip sales invoice processing for HSN summary rows
      }

      const isCreditNote = inv.documentType === 'CREDIT_NOTE';
      const isDebitNote = inv.documentType === 'DEBIT_NOTE';

      const taxable = round2(inv.taxableValue);
      const cgst = round2(inv.cgst);
      const sgst = round2(inv.sgst);
      const igst = round2(inv.igst);
      const cess = round2(inv.cess);
      const totalTax = round2(cgst + sgst + igst + cess);

      if (!isCreditNote) {
        grossTurnover = round2(grossTurnover + taxable);
      }

      // Determine effective classification robustly
      let cls = inv.classification;
      const isRegisteredRecipient = Boolean(inv.recipientGstin) && GSTIN_REGEX.test(String(inv.recipientGstin).trim());
      if (!cls) {
        if (isRegisteredRecipient) {
          cls = 'B2B';
        } else if ((inv.totalAmount || inv.taxableValue || 0) > 250000 && inv.supplyType === 'INTER_STATE') {
          cls = 'B2C_LARGE';
        } else if ((inv as any).exportType || inv.shippingBillNumber) {
          cls = 'EXPORT_WITHOUT_PAYMENT';
        } else {
          cls = 'B2C_SMALL';
        }
      }

      const isB2bInvoice = cls === 'B2B' || (isRegisteredRecipient && cls !== 'B2C_LARGE' && cls !== 'B2C_SMALL' && !cls?.startsWith('EXPORT'));

      // 1. Credit & Debit Notes Table 9B
      if (isCreditNote || isDebitNote) {
        creditNotesTaxable = round2(creditNotesTaxable + taxable);
        creditNotesTax = round2(creditNotesTax + totalTax);
        table9B_CreditDebitNotes.push({
          noteNumber: inv.invoiceNumber,
          noteDate: inv.invoiceDate,
          noteType: isCreditNote ? 'C' : 'D',
          recipientGstin: inv.recipientGstin || '',
          recipientName: inv.recipientName || 'Recipient Party',
          pos: extractPosCode(inv.placeOfSupplyCode || inv.placeOfSupply, inv.recipientGstin, supplierState),
          taxableValue: taxable,
          gstRate: inv.gstRate || 18,
          cgst,
          sgst,
          igst,
          cess,
          reason: inv.notes || 'Post-sales adjustment under Section 34'
        });
      }
      // 2. Table 4: B2B Invoices (Registered Recipients)
      else if (isB2bInvoice) {
        b2bTaxable = round2(b2bTaxable + taxable);
        b2bCgst = round2(b2bCgst + cgst);
        b2bSgst = round2(b2bSgst + sgst);
        b2bIgst = round2(b2bIgst + igst);
        b2bCess = round2(b2bCess + cess);
        b2bCount++;
        table4_B2B.push({
          invoiceNumber: inv.invoiceNumber,
          invoiceDate: inv.invoiceDate,
          recipientGstin: inv.recipientGstin || '',
          recipientName: inv.recipientName || 'Registered Recipient',
          pos: extractPosCode(inv.placeOfSupplyCode || inv.placeOfSupply, inv.recipientGstin, supplierState),
          reverseCharge: inv.rcm ? 'Y' : 'N',
          invoiceType: 'Regular',
          taxableValue: taxable,
          gstRate: inv.gstRate || 18,
          cgst,
          sgst,
          igst,
          cess,
          totalValue: inv.totalAmount || (inv as any).totalValue || round2(taxable + totalTax),
          hsnSac: inv.hsnSacPrimary || (inv as any).hsnSac || '',
          description: inv.descriptionPrimary || (inv as any).description || '',
          uqc: (inv as any).uqc || 'OTH',
          totalQuantity: Number((inv as any).totalQuantity ?? (inv as any).quantity ?? 1)
        });
      }
      // 3. Table 5: B2C Large
      else if (cls === 'B2C_LARGE') {
        b2clTaxable = round2(b2clTaxable + taxable);
        b2clIgst = round2(b2clIgst + igst);
        b2clCount++;
        table5_B2CLarge.push({
          invoiceNumber: inv.invoiceNumber,
          invoiceDate: inv.invoiceDate,
          pos: extractPosCode(inv.placeOfSupplyCode || inv.placeOfSupply, undefined, supplierState === '07' ? '27' : '07'),
          taxableValue: taxable,
          gstRate: inv.gstRate || 18,
          igst,
          totalValue: inv.totalAmount || (inv as any).totalValue || round2(taxable + totalTax)
        });
      }
      // 4. Table 6: Exports & SEZ
      else if (cls?.startsWith('EXPORT') || cls?.startsWith('SEZ')) {
        exportsTaxable = round2(exportsTaxable + taxable);
        exportsIgst = round2(exportsIgst + igst);
        exportsCount++;
        table6_Exports.push({
          invoiceNumber: inv.invoiceNumber,
          invoiceDate: inv.invoiceDate,
          exportType: cls === 'EXPORT_WITHOUT_PAYMENT' ? 'WOPAY' : 'WPAY',
          shippingBillNumber: inv.shippingBillNumber || 'SB-882910',
          shippingBillDate: inv.shippingBillDate || inv.invoiceDate,
          taxableValue: taxable,
          igst,
          totalValue: inv.totalAmount || (inv as any).totalValue || round2(taxable + totalTax)
        });
      }
      // 5. Table 7: B2C Small
      else if (cls === 'B2C_SMALL') {
        const pos = extractPosCode(inv.placeOfSupplyCode || inv.placeOfSupply, undefined, supplierState);
        const isIntra = pos === supplierState || inv.supplyType === 'INTRA_STATE' || (cgst > 0 && igst === 0);
        b2csTaxable = round2(b2csTaxable + taxable);
        b2csCgst = round2(b2csCgst + (isIntra ? cgst : 0));
        b2csSgst = round2(b2csSgst + (isIntra ? sgst : 0));
        b2csIgst = round2(b2csIgst + (isIntra ? 0 : igst));
        b2csCount++;
        table7_B2CSmall.push({
          type: isIntra ? 'INTRA' : 'INTER',
          pos: pos,
          gstRate: inv.gstRate || 18,
          taxableValue: taxable,
          cgst: isIntra ? cgst : 0,
          sgst: isIntra ? sgst : 0,
          igst: isIntra ? 0 : igst,
          cess
        });
      }
      // 6. Table 8: Nil / Exempt
      else if (cls === 'NIL_RATED' || cls === 'EXEMPT' || cls === 'NON_GST') {
        nilExemptTurnover = round2(nilExemptTurnover + taxable);
        table8_NilExempt.push({
          description: inv.descriptionPrimary || 'Exempt Supply',
          nilRatedAmount: cls === 'NIL_RATED' ? taxable : 0,
          exemptAmount: cls === 'EXEMPT' ? taxable : 0,
          nonGstAmount: cls === 'NON_GST' ? taxable : 0
        });
      } else {
        const pos = extractPosCode(inv.placeOfSupplyCode || inv.placeOfSupply, undefined, supplierState);
        const isIntra = pos === supplierState || inv.supplyType === 'INTRA_STATE' || (cgst > 0 && igst === 0);
        b2csTaxable = round2(b2csTaxable + taxable);
        b2csCgst = round2(b2csCgst + (isIntra ? cgst : 0));
        b2csSgst = round2(b2csSgst + (isIntra ? sgst : 0));
        b2csIgst = round2(b2csIgst + (isIntra ? 0 : igst));
        b2csCount++;
        table7_B2CSmall.push({
          type: isIntra ? 'INTRA' : 'INTER',
          pos: pos,
          gstRate: inv.gstRate || 18,
          taxableValue: taxable,
          cgst: isIntra ? cgst : 0,
          sgst: isIntra ? sgst : 0,
          igst: isIntra ? 0 : igst,
          cess
        });
      }

      // Table 12: Bifurcated HSN Summary Aggregation (B2B vs B2C) grouped by HSN + UQC + Rate
      // Synthesize outward invoices independently for B2B vs B2C if not explicitly imported
      const shouldSynthesizeHsn = isB2bInvoice ? !hasExplicitB2bHsn : !hasExplicitB2cHsn;
      if (shouldSynthesizeHsn && !isCreditNote && !isDebitNote) {
        const isB2b = isB2bInvoice;
        const hsn = String(inv.hsnSacPrimary || (inv as any).hsnSac || '998313').trim();
        const isService = hsn.startsWith('99');
        const rawUqc = String((inv as any).uqc || 'OTH').split('-')[0].trim().toUpperCase();
        const uqc = isService ? 'NA' : (rawUqc || 'OTH');
        const invoiceQty = isService ? 0 : Number((inv as any).totalQuantity ?? (inv as any).quantity ?? (inv as any).qty ?? 1);
        const rate = inv.gstRate || 18;
        const key = `${hsn}_${uqc}_${rate}`;

        const mapTarget = isB2b ? hsnB2bMap : hsnB2cMap;
        const existing = mapTarget.get(key) || {
          hsnSac: hsn,
          description: inv.descriptionPrimary || (isService ? 'Information technology consulting and support services' : 'Outward Taxable Supply'),
          uqc,
          rate,
          totalQuantity: 0,
          totalValue: 0,
          taxableValue: 0,
          igst: 0,
          cgst: 0,
          sgst: 0,
          cess: 0
        };

        const totalInvVal = inv.totalAmount || (inv as any).totalValue || round2(taxable + totalTax);
        existing.totalQuantity = isService ? 0 : round2(existing.totalQuantity + invoiceQty);
        existing.totalValue = round2(existing.totalValue + totalInvVal);
        existing.taxableValue = round2(existing.taxableValue + taxable);
        existing.igst = round2(existing.igst + igst);
        existing.cgst = round2(existing.cgst + cgst);
        existing.sgst = round2(existing.sgst + sgst);
        existing.cess = round2(existing.cess + cess);
        mapTarget.set(key, existing);
      }
    }

    const table12_HSNSummary_B2B = Array.from(hsnB2bMap.values());
    const table12_HSNSummary_C2B = Array.from(hsnB2cMap.values());
    const table12_HSNSummary = [...table12_HSNSummary_B2B, ...table12_HSNSummary_C2B];

    const b2bHsnTaxable = round2(table12_HSNSummary_B2B.reduce((acc, h) => acc + h.taxableValue, 0));
    const b2cHsnTaxable = round2(table12_HSNSummary_C2B.reduce((acc, h) => acc + h.taxableValue, 0));

    const totalTaxLiability = round2(
      b2bCgst + b2bSgst + b2bIgst + b2bCess +
      b2clIgst +
      b2csCgst + b2csSgst + b2csIgst +
      exportsIgst +
      creditNotesTax
    );

    const docSummaryItems = sales.filter((s: any) => s.isDocSummary || s.id?.startsWith('PORTAL-DOC') || ((s as any).fromSerial && (s as any).totalNumber !== undefined));

    const table13_DocsIssued: any[] = [];
    if (docSummaryItems.length > 0) {
      // Use imported Table 13 document summary items directly
      docSummaryItems.forEach((d: any) => {
        const tot = Number((d as any).totalNumber ?? (d as any).totnum ?? 0);
        const can = Number((d as any).cancelled ?? (d as any).cancel ?? 0);
        const fromVal = String((d as any).fromSerial || d.invoiceNumber || '').trim();
        const toVal = String((d as any).toSerial || fromVal).trim();
        table13_DocsIssued.push({
          docType: (d as any).docNature || d.descriptionPrimary || 'Invoices for outward supply',
          fromSerial: fromVal || '1',
          toSerial: toVal || fromVal || '1',
          totalNumber: tot > 0 ? tot : 1,
          cancelled: can,
          netIssued: Math.max(0, (tot > 0 ? tot : 1) - can)
        });
      });
    } else {
      // Fallback: Synthesize Table 13 from regular invoices, credit notes, and debit notes ONLY
      // Strictly exclude B2C Small summaries, HSN summaries, and placeholder rows without real invoice numbers
      const isGenuineDoc = (s: any) =>
        !s.isDocSummary &&
        !s.id?.startsWith('PORTAL-DOC') &&
        !s.isHsnSummary &&
        !s.id?.startsWith('PORTAL-HSN') &&
        !s.isB2csSummary &&
        !s.id?.startsWith('PORTAL-B2CS') &&
        Boolean(s.invoiceNumber && s.invoiceNumber.trim() && !s.invoiceNumber.startsWith('B2CS/') && !s.invoiceNumber.startsWith('INV/HSN/'));

      const regularInvoices = sales.filter(s => s.documentType === 'INVOICE' && isGenuineDoc(s));
      const creditNotes = sales.filter(s => s.documentType === 'CREDIT_NOTE' && isGenuineDoc(s));
      const debitNotes = sales.filter(s => s.documentType === 'DEBIT_NOTE' && isGenuineDoc(s));

      if (regularInvoices.length > 0) {
        table13_DocsIssued.push({
          docType: 'Invoices for outward supply',
          fromSerial: regularInvoices[0].invoiceNumber,
          toSerial: regularInvoices[regularInvoices.length - 1].invoiceNumber,
          totalNumber: regularInvoices.length,
          cancelled: 0,
          netIssued: regularInvoices.length
        });
      }
      if (creditNotes.length > 0) {
        table13_DocsIssued.push({
          docType: 'Credit Note',
          fromSerial: creditNotes[0].invoiceNumber,
          toSerial: creditNotes[creditNotes.length - 1].invoiceNumber,
          totalNumber: creditNotes.length,
          cancelled: 0,
          netIssued: creditNotes.length
        });
      }
      if (debitNotes.length > 0) {
        table13_DocsIssued.push({
          docType: 'Debit Note',
          fromSerial: debitNotes[0].invoiceNumber,
          toSerial: debitNotes[debitNotes.length - 1].invoiceNumber,
          totalNumber: debitNotes.length,
          cancelled: 0,
          netIssued: debitNotes.length
        });
      }
    }

    return {
      period,
      gstin: cleanGstin,
      legalName: legalName || 'Apex Technologies Private Limited',
      grossTurnover,
      b2bTaxable,
      b2bCount,
      b2bCgst,
      b2bSgst,
      b2bIgst,
      b2bCess,
      b2clTaxable,
      b2clCount,
      b2clIgst,
      b2csTaxable,
      b2csCount,
      b2csCgst,
      b2csSgst,
      b2csIgst,
      exportsTaxable,
      exportsCount,
      exportsIgst,
      nilExemptTurnover,
      creditNotesTaxable,
      creditNotesTax,
      hsnSummaryCount: table12_HSNSummary.length,
      b2bHsnTaxable,
      b2cHsnTaxable,
      totalTaxLiability,
      tables: {
        table4_B2B,
        table5_B2CLarge,
        table6_Exports,
        table7_B2CSmall,
        table8_NilExempt,
        table9B_CreditDebitNotes,
        table12_HSNSummary,
        table12_HSNSummary_B2B,
        table12_HSNSummary_C2B,
        table12_HSNSummary_B2C: table12_HSNSummary_C2B,
        table13_DocsIssued
      }
    };
  }

  /**
   * Generates official GST Portal JSON payload using schema-first GstnSchemaEngine (v1.1)
   */
  public generateGSTNJsonPayload(summary: GSTR1Summary): string {
    const payload = gstnSchemaEngine.serializeToGstnPayload(summary);
    return JSON.stringify(payload, null, 2);
  }
}

export const gstr1Engine = new GSTR1Engine();
