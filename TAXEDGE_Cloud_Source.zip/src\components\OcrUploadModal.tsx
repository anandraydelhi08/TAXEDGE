import React, { useState } from 'react';
import { FileUp, X, CheckCircle2, AlertTriangle, ShieldCheck, FileText, ArrowRight, Eye } from 'lucide-react';
import { ocrEngine, ExtractedOcrInvoice } from '../services/ocrEngine';
import { TransactionInvoice } from '../types/gst';
import { formatINR } from '../utils/taxMath';

interface OcrUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportInvoice: (inv: TransactionInvoice, targetRegister: 'SALES' | 'PURCHASE') => void;
}

export const OcrUploadModal: React.FC<OcrUploadModalProps> = ({
  isOpen,
  onClose,
  onImportInvoice
}) => {
  const [targetRegister, setTargetRegister] = useState<'PURCHASE' | 'SALES'>('PURCHASE');
  const [extractedData, setExtractedData] = useState<ExtractedOcrInvoice | null>(null);
  const [fileName, setFileName] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    setIsProcessing(true);

    setTimeout(() => {
      const ocrResult = ocrEngine.processUploadedDocument({
        name: file.name,
        size: file.size,
        type: file.type
      });
      setExtractedData(ocrResult);
      setIsProcessing(false);
    }, 600);
  };

  const handleLoadSample = (sampleType: 'DELL_CAPITAL' | 'LEGAL_RCM' | 'SALES_B2B') => {
    setIsProcessing(true);
    setTimeout(() => {
      let name = 'Dell_Server_TaxInvoice_2026.pdf';
      if (sampleType === 'LEGAL_RCM') name = 'Advocate_Deshmukh_LegalFees_RCM.pdf';
      if (sampleType === 'SALES_B2B') name = 'TechNova_Outward_B2B_ClientInvoice.pdf';

      setFileName(name);
      const res = ocrEngine.processUploadedDocument({
        name,
        size: 245000,
        type: 'application/pdf'
      });
      setExtractedData(res);
      setIsProcessing(false);
    }, 400);
  };

  const handleConfirmImport = () => {
    if (!extractedData) return;
    const inv = ocrEngine.convertToTransactionInvoice(extractedData, 'B2B');
    onImportInvoice(inv, targetRegister);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-white border border-[#E5E7EB] rounded-3xl w-full max-w-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 bg-[#F8F9FA] border-b border-[#E5E7EB] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#176B4D]/20 text-[#176B4D] flex items-center justify-center border border-[#176B4D]/30">
              <FileUp className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Invoice OCR & Intelligence Engine</h3>
              <p className="text-[11px] text-[#6B7280]">PDF, PNG, JPG, Excel & CSV Multi-Format Ingestion</p>
            </div>
          </div>
          <button onClick={onClose} className="text-[#6B7280] hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs">
          {/* Target Selection */}
          <div className="flex items-center gap-4 p-3 bg-[#FFFFFF] rounded-xl border border-[#E5E7EB]">
            <span className="text-[#6B7280] font-semibold">Import Into:</span>
            <label className="flex items-center gap-2 text-[#202124] cursor-pointer">
              <input
                type="radio"
                name="targetRegister"
                checked={targetRegister === 'PURCHASE'}
                onChange={() => setTargetRegister('PURCHASE')}
                className="text-[#6B7280]"
              />
              <span>Inward Purchase Register</span>
            </label>
            <label className="flex items-center gap-2 text-[#202124] cursor-pointer">
              <input
                type="radio"
                name="targetRegister"
                checked={targetRegister === 'SALES'}
                onChange={() => setTargetRegister('SALES')}
                className="text-emerald-500"
              />
              <span>Outward Sales Register</span>
            </label>
          </div>

          {/* Upload Dropzone */}
          <div className="border-2 border-dashed border-[#E5E7EB] hover:border-slate-500 rounded-2xl p-8 text-center bg-[#F8F9FA] relative">
            <input
              type="file"
              accept=".pdf,.png,.jpg,.jpeg,.xlsx,.xls,.csv"
              onChange={handleFileUpload}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
            <FileUp className="w-10 h-10 text-[#6B7280] mx-auto mb-2" />
            <div className="font-semibold text-white text-sm">
              Click to browse or drop invoice file here
            </div>
            <div className="text-[#6B7280] text-xs mt-1">
              Supports Tax Invoice PDF, scanned PNG/JPG receipts, Excel bill summaries
            </div>

            {/* Quick Demo Pre-load buttons */}
            <div className="mt-4 pt-4 border-t border-[#E5E7EB] flex flex-wrap items-center justify-center gap-2">
              <span className="text-[11px] text-[#6B7280]">Or load sample document:</span>
              <button
                type="button"
                onClick={() => handleLoadSample('DELL_CAPITAL')}
                className="px-2.5 py-1 rounded bg-[#F8F9FA] hover:bg-slate-700 text-[#202124] text-[11px] border border-[#E5E7EB] transition"
              >
                Sample Dell Laptops (PDF)
              </button>
              <button
                type="button"
                onClick={() => handleLoadSample('LEGAL_RCM')}
                className="px-2.5 py-1 rounded bg-[#F8F9FA] hover:bg-slate-700 text-purple-300 text-[11px] border border-[#E5E7EB] transition"
              >
                Sample Advocate Fees (RCM)
              </button>
            </div>
          </div>

          {/* Extracted Data Inspection Box */}
          {extractedData && (
            <div className="bg-[#FFFFFF] border border-[#E5E7EB] rounded-2xl p-5 space-y-4">
              <div className="flex items-center justify-between border-b border-[#E5E7EB] pb-3">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#176B4D]" />
                  <span className="font-bold text-white text-sm">OCR Extracted Data</span>
                  <span className="text-[10px] font-mono text-[#176B4D] bg-[#E8F5EF] px-2 py-0.5 rounded font-bold">
                    {(extractedData.overallConfidence * 100).toFixed(0)}% Confidence
                  </span>
                </div>
                <span className="font-mono text-[10px] text-[#6B7280]">
                  {extractedData.documentHash.substring(0, 24)}...
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div className="p-2.5 rounded-lg bg-white border border-[#E5E7EB]">
                  <div className="text-[10px] text-[#6B7280] uppercase">Invoice Number</div>
                  <div className="font-mono font-bold text-white mt-0.5">{extractedData.invoiceNumber.value}</div>
                  <div className="text-[9px] text-[#176B4D]">Confidence: {(extractedData.invoiceNumber.confidence * 100).toFixed(0)}%</div>
                </div>

                <div className="p-2.5 rounded-lg bg-white border border-[#E5E7EB]">
                  <div className="text-[10px] text-[#6B7280] uppercase">Invoice Date</div>
                  <div className="font-medium text-white mt-0.5">{extractedData.invoiceDate.value}</div>
                  <div className="text-[9px] text-[#176B4D]">Confidence: {(extractedData.invoiceDate.confidence * 100).toFixed(0)}%</div>
                </div>

                <div className="p-2.5 rounded-lg bg-white border border-[#E5E7EB]">
                  <div className="text-[10px] text-[#6B7280] uppercase">Supplier GSTIN</div>
                  <div className="font-mono font-bold text-[#176B4D] mt-0.5">{extractedData.supplierGstin.value}</div>
                  <div className="text-[9px] text-[#176B4D]">Confidence: {(extractedData.supplierGstin.confidence * 100).toFixed(0)}%</div>
                </div>

                <div className="p-2.5 rounded-lg bg-white border border-[#E5E7EB] sm:col-span-2">
                  <div className="text-[10px] text-[#6B7280] uppercase">Supplier Name</div>
                  <div className="font-semibold text-white mt-0.5">{extractedData.supplierName.value}</div>
                </div>

                <div className="p-2.5 rounded-lg bg-white border border-[#E5E7EB]">
                  <div className="text-[10px] text-[#6B7280] uppercase">HSN / SAC</div>
                  <div className="font-mono font-bold text-white mt-0.5">{extractedData.hsnSac.value}</div>
                </div>

                <div className="p-2.5 rounded-lg bg-white border border-[#E5E7EB]">
                  <div className="text-[10px] text-[#6B7280] uppercase">Taxable Value</div>
                  <div className="font-mono font-bold text-white mt-0.5">{formatINR(extractedData.taxableValue.value)}</div>
                </div>

                <div className="p-2.5 rounded-lg bg-white border border-[#E5E7EB]">
                  <div className="text-[10px] text-[#6B7280] uppercase">Total GST Amount</div>
                  <div className="font-mono font-bold text-[#6B7280] mt-0.5">
                    {formatINR(extractedData.cgst.value + extractedData.sgst.value + extractedData.igst.value)}
                  </div>
                </div>

                <div className="p-2.5 rounded-lg bg-white border border-[#E5E7EB]">
                  <div className="text-[10px] text-[#6B7280] uppercase">Invoice Gross Total</div>
                  <div className="font-mono font-black text-[#176B4D] mt-0.5">{formatINR(extractedData.totalAmount.value)}</div>
                </div>
              </div>

              {extractedData.isRcm.value && (
                <div className="p-3 rounded-lg bg-purple-950/30 border border-purple-800/40 text-purple-300">
                  <strong>RCM Indicator Detected:</strong> This transaction will be marked for mandatory cash payment under Section 9(3) CGST Act.
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={handleConfirmImport}
                  className="px-5 py-2 rounded-xl bg-[#176B4D] hover:bg-emerald-400 text-slate-950 font-bold transition shadow-md shadow-emerald-950/40"
                >
                  Confirm & Import into {targetRegister === 'PURCHASE' ? 'Purchase Register' : 'Sales Register'}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
