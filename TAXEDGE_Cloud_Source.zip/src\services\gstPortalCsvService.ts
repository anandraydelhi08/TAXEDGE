/**
 * Official GST Portal Section-wise CSV Engine & Importer/Exporter
 * Strictly aligned with GST Returns Offline Tool v3.2.4 & GST Portal Official Section-Wise Templates
 * Located at: GST TEMPLATE/Section_wise_CSV_files/GSTR1
 *
 * Supported Sections:
 * 1. b2b,sez,de.csv  - Table 4 (B2B, SEZ supplies with/without payment, Deemed Exports)
 * 2. b2cl.csv        - Table 5 (B2C Large inter-state invoices > 2.5L to unregistered)
 * 3. b2cs.csv        - Table 7 (B2C Small supplies, aggregated by type/POS/rate)
 * 4. cdnr.csv        - Table 9B (Credit / Debit Notes to registered persons)
 * 5. cdnur.csv       - Table 9B (Credit / Debit Notes to unregistered persons)
 * 6. exp.csv         - Table 6A (Exports with/without payment)
 * 7. hsn.csv         - Table 12 (HSN/SAC summary of outward supplies)
 * 8. docs.csv        - Table 13 (Documents issued during the tax period)
 * 9. exemp.csv       - Table 8 (Nil-rated, exempted, and non-GST outward supplies)
 * 10. eco.csv        - Table 14 (Supplies made through E-Commerce Operators u/s 52 & 9(5))
 * 11. at.csv         - Table 11A (Advances received during tax period)
 * 12. atadj.csv      - Table 11B (Advances adjusted during tax period)
 */

import { TransactionInvoice, GSTR1Summary, DocumentType, GSTClassification } from '../types/gst';
import { round2, calculateDeterministicTax } from '../utils/taxMath';
import { gstExcelTemplateService } from './gstExcelTemplateService';

/**
 * Sanitizes invoice numbers according to GSTN schema Rule 46(b)
 * (Max 16 characters, only alphanumeric, hyphen, forward slash. No spaces/special chars)
 */
export function sanitizeGstnInvoiceNumber(num: string | undefined | null): string {
  if (!num) return 'INV-001';
  const cleaned = String(num).trim().replace(/[^A-Za-z0-9\/-]/g, '-');
  return cleaned.slice(0, 16) || 'INV-001';
}

// Canonical GST Portal POS Mapping (Code-State format as required by GSTN Offline Tool)
export const GST_PORTAL_STATE_MAP: Record<string, string> = {
  '01': '01-Jammu & Kashmir',
  '02': '02-Himachal Pradesh',
  '03': '03-Punjab',
  '04': '04-Chandigarh',
  '05': '05-Uttarakhand',
  '06': '06-Haryana',
  '07': '07-Delhi',
  '08': '08-Rajasthan',
  '09': '09-Uttar Pradesh',
  '10': '10-Bihar',
  '11': '11-Sikkim',
  '12': '12-Arunachal Pradesh',
  '13': '13-Nagaland',
  '14': '14-Manipur',
  '15': '15-Mizoram',
  '16': '16-Tripura',
  '17': '17-Meghalaya',
  '18': '18-Assam',
  '19': '19-West Bengal',
  '20': '20-Jharkhand',
  '21': '21-Odisha',
  '22': '22-Chhattisgarh',
  '23': '23-Madhya Pradesh',
  '24': '24-Gujarat',
  '25': '25-Daman & Diu',
  '26': '26-Dadra & Nagar Haveli and Daman & Diu',
  '27': '27-Maharashtra',
  '28': '28-Andhra Pradesh(Before Division)',
  '29': '29-Karnataka',
  '30': '30-Goa',
  '31': '31-Lakshadweep',
  '32': '32-Kerala',
  '33': '33-Tamil Nadu',
  '34': '34-Puducherry',
  '35': '35-Andaman and Nicobar Islands',
  '36': '36-Telangana',
  '37': '37-Andhra Pradesh',
  '38': '38-Ladakh',
  '97': '97-Other Territory'
};

const MONTH_NAMES = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/**
 * Formats date into official GST Portal CSV format (e.g. "14-Jul-17" or "05-Apr-26")
 */
export function formatGstPortalDate(dateStr: string | undefined): string {
  if (!dateStr) return '01-Apr-26';
  const clean = String(dateStr).trim();

  // If already in DD-MMM-YY or DD-MMM-YYYY format
  if (/^\d{1,2}-[A-Za-z]{3}-\d{2,4}$/.test(clean)) {
    return clean;
  }

  // YYYY-MM-DD
  if (/^\d{4}-\d{2}-\d{2}$/.test(clean)) {
    const [yyyy, mm, dd] = clean.split('-');
    const mIdx = parseInt(mm, 10) - 1;
    const mName = MONTH_NAMES[mIdx] || 'Apr';
    const yr = yyyy.slice(-2);
    return `${parseInt(dd, 10)}-${mName}-${yr}`;
  }

  // DD/MM/YYYY or DD-MM-YYYY
  if (/^\d{1,2}[\/\-]\d{1,2}[\/\-]\d{4}$/.test(clean)) {
    const parts = clean.split(/[\/\-]/);
    const dd = parseInt(parts[0], 10);
    const mIdx = parseInt(parts[1], 10) - 1;
    const mName = MONTH_NAMES[mIdx] || 'Apr';
    const yr = parts[2].slice(-2);
    return `${dd}-${mName}-${yr}`;
  }

  return clean;
}

/**
 * Parses GST Portal date string ("14-Jul-17", "14-Jul-2026", "14-07-2026") into ISO "YYYY-MM-DD"
 */
export function parseGstPortalDate(dateStr: string | undefined): string {
  if (!dateStr) return new Date().toISOString().split('T')[0];
  const clean = dateStr.trim();
  const months: Record<string, string> = {
    jan: '01', feb: '02', mar: '03', apr: '04', may: '05', jun: '06',
    jul: '07', aug: '08', sep: '09', oct: '10', nov: '11', dec: '12'
  };

  const mmmMatch = clean.match(/^(\d{1,2})-([A-Za-z]{3})-(\d{2,4})$/i);
  if (mmmMatch) {
    const dd = mmmMatch[1].padStart(2, '0');
    const mon = months[mmmMatch[2].toLowerCase()] || '04';
    let yyyy = mmmMatch[3];
    if (yyyy.length === 2) {
      yyyy = parseInt(yyyy, 10) < 50 ? `20${yyyy}` : `19${yyyy}`;
    }
    return `${yyyy}-${mon}-${dd}`;
  }

  const numMatch = clean.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/);
  if (numMatch) {
    return `${numMatch[3]}-${numMatch[2].padStart(2, '0')}-${numMatch[1].padStart(2, '0')}`;
  }

  if (/^\d{4}-\d{2}-\d{2}$/.test(clean)) {
    return clean;
  }

  return new Date().toISOString().split('T')[0];
}

/**
 * Returns canonical POS formatted as "StateCode-StateName" (e.g. "27-Maharashtra")
 */
export function formatGstPortalPos(posCodeOrStr: string | undefined): string {
  if (!posCodeOrStr) return '27-Maharashtra';
  const clean = String(posCodeOrStr).trim();
  const code = clean.substring(0, 2);
  return GST_PORTAL_STATE_MAP[code] || (code.length === 2 ? `${code}-State` : '27-Maharashtra');
}

/**
 * Extracts 2-digit code from Place of Supply string with robust matching for:
 * - Code-State (e.g. "07-Delhi", " 07 - Delhi ", "07-DELHI")
 * - Standalone numbers (e.g. "07", "7", "Delhi (07)")
 * - Full/partial State Names (e.g. "Delhi", "Maharashtra", "Punjab", "Haryana", "Karnataka", "UP", "DL")
 * - Fallback to recipient GSTIN state code (Section 12(2)(a) IGST Act)
 * - Fallback to supplier state code (defaults to intra-state, avoiding erroneous IGST conversion)
 */
export function extractPosCode(
  posStr: string | undefined | null,
  recipientGstin?: string,
  fallbackSupplierState: string = '07'
): string {
  if (posStr !== undefined && posStr !== null) {
    const s = String(posStr).trim();
    if (s.length > 0) {
      // 1. Check if string starts with or contains 1-2 digits (e.g. "07-Delhi", " 07 - Delhi", "7", "07", "Delhi (07)")
      const match = s.match(/\b\d{1,2}\b/) || s.match(/^\d{1,2}/) || s.match(/\d{2}/);
      if (match) {
        const code = match[0].padStart(2, '0');
        if (GST_PORTAL_STATE_MAP[code]) {
          return code;
        }
      }

      // 2. Check if string matches any State Name in GST_PORTAL_STATE_MAP
      const lower = s.toLowerCase().replace(/[^a-z]/g, '');
      if (lower.length >= 2) {
        for (const [code, fullName] of Object.entries(GST_PORTAL_STATE_MAP)) {
          const cleanName = fullName.toLowerCase().replace(/[^a-z]/g, '');
          if (cleanName === lower || cleanName.includes(lower) || (lower.length >= 4 && lower.includes(cleanName))) {
            return code;
          }
        }
        // Common state abbreviations
        const abbrevMap: Record<string, string> = {
          dl: '07', delhi: '07',
          mh: '27', maharashtra: '27',
          ka: '29', karnataka: '29',
          up: '09', uttarpradesh: '09',
          hr: '06', haryana: '06',
          pb: '03', punjab: '03',
          rj: '08', rajasthan: '08',
          gj: '24', gujarat: '24',
          tn: '33', tamilnadu: '33',
          ts: '36', telangana: '36',
          ap: '37', andhrapradesh: '37',
          wb: '19', westbengal: '19',
          mp: '23', madhyapradesh: '23',
          br: '10', bihar: '10',
          kl: '32', kerala: '32',
          uk: '05', uttarakhand: '05',
          ch: '04', chandigarh: '04',
          jk: '01', jammukashmir: '01',
          ga: '30', goa: '30'
        };
        if (abbrevMap[lower]) {
          return abbrevMap[lower];
        }
      }
    }
  }

  // 3. Fallback to recipient GSTIN's first 2 digits (B2B default rule Section 12(2) IGST Act)
  if (recipientGstin) {
    const cleanGst = String(recipientGstin).trim().toUpperCase();
    if (cleanGst.length >= 2 && /^\d{2}/.test(cleanGst)) {
      const recState = cleanGst.substring(0, 2);
      if (GST_PORTAL_STATE_MAP[recState]) {
        return recState;
      }
    }
  }

  // 4. Fallback to supplier's state code (intra-state default, never arbitrary '27'!)
  return fallbackSupplierState || '07';
}

/**
 * Escapes CSV field value handling commas, quotes, and newlines
 */
export function escapeCsvField(val: any): string {
  if (val === null || val === undefined) return '';
  const s = String(val).trim();
  if (s.includes(',') || s.includes('"') || s.includes('\n') || s.includes('\r')) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

// ============================================================================
// OFFICIAL GST PORTAL CSV EXPORT ENGINE
// ============================================================================
// AUTO-DETECT DELIMITER (CSV, TSV, SEMICOLON, PIPE)
// ============================================================================

/**
 * Auto-detects the delimiter in tabular text:
 * Supports comma (,), tab (\t - Excel copy-paste), semicolon (;), and pipe (|)
 */
export function detectDelimiter(text: string): string {
  const lines = text.split(/\r\n|\r|\n/).filter(l => l.trim().length > 0).slice(0, 5);
  if (lines.length === 0) return ',';

  let commaCount = 0;
  let tabCount = 0;
  let semicolonCount = 0;
  let pipeCount = 0;

  for (const line of lines) {
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const c = line[i];
      if (c === '"' || c === "'") inQuotes = !inQuotes;
      else if (!inQuotes) {
        if (c === ',') commaCount++;
        else if (c === '\t') tabCount++;
        else if (c === ';') semicolonCount++;
        else if (c === '|') pipeCount++;
      }
    }
  }

  if (tabCount > commaCount && tabCount >= semicolonCount && tabCount >= pipeCount) return '\t';
  if (semicolonCount > commaCount && semicolonCount >= tabCount && semicolonCount >= pipeCount) return ';';
  if (pipeCount > commaCount && pipeCount >= tabCount && pipeCount >= semicolonCount) return '|';
  return ',';
}

export interface SectionCsvBundle {
  filename: string;
  sectionTitle: string;
  tableNumber: string;
  recordCount: number;
  taxableValue: number;
  totalTax: number;
  csvContent: string;
  isExcel?: boolean;
  fileBytes?: Uint8Array;
}

export class GSTPortalCsvEngine {
  /**
   * 1. Table 4: b2b,sez,de.csv
   * Header: GSTIN/UIN of Recipient,Receiver Name,Invoice Number,Invoice date,Invoice Value,Place Of Supply,Reverse Charge,Applicable % of Tax Rate,Invoice Type,E-Commerce GSTIN,Rate,Taxable Value,Cess Amount
   */
  public generateB2bCsv(sales: TransactionInvoice[]): SectionCsvBundle {
    const header = 'GSTIN/UIN of Recipient,Receiver Name,Invoice Number,Invoice date,Invoice Value,Place Of Supply,Reverse Charge,Applicable % of Tax Rate,Invoice Type,E-Commerce GSTIN,Rate,Taxable Value,Cess Amount';
    const rows: string[] = [header];

    let count = 0;
    let totalTaxable = 0;
    let totalTax = 0;

    const b2bInvoices = sales.filter(inv => {
      if ((inv as any).isHsnSummary || inv.id?.startsWith('PORTAL-HSN')) return false;
      if ((inv as any).isDocSummary || inv.id?.startsWith('PORTAL-DOC')) return false;
      if ((inv as any).isB2csSummary || inv.id?.startsWith('PORTAL-B2CS')) return false;
      const isCnDn = inv.documentType === 'CREDIT_NOTE' || inv.documentType === 'DEBIT_NOTE';
      if (isCnDn) return false;
      const isRegistered = inv.recipientGstin && inv.recipientGstin.length === 15 && inv.recipientGstin !== 'URP';
      const isSezOrDe = inv.classification?.startsWith('SEZ') || inv.classification === 'DEEMED_EXPORT';
      return (inv.classification === 'B2B' && isRegistered) || isSezOrDe;
    });

    for (const inv of b2bInvoices) {
      let invType = 'Regular B2B';
      if (inv.classification === 'DEEMED_EXPORT') invType = 'Deemed Exp';
      else if (inv.classification === 'SEZ_WITH_PAYMENT') invType = 'SEZ supplies with payment';
      else if (inv.classification === 'SEZ_WITHOUT_PAYMENT') invType = 'SEZ supplies without payment';
      else if (inv.supplyType === 'INTRA_STATE' && inv.igst > 0) invType = 'Intra-State supplies attracting IGST';

      const pos = formatGstPortalPos(inv.placeOfSupplyCode || inv.recipientGstin?.substring(0, 2));
      const row = [
        escapeCsvField(inv.recipientGstin),
        escapeCsvField(inv.recipientName || 'Registered Buyer'),
        escapeCsvField(sanitizeGstnInvoiceNumber(inv.invoiceNumber)),
        formatGstPortalDate(inv.invoiceDate),
        inv.totalAmount.toFixed(2),
        pos,
        inv.rcm ? 'Y' : 'N',
        inv.applicableTaxRatePercent ? String(inv.applicableTaxRatePercent) : '',
        invType,
        escapeCsvField(inv.ecommerceGstin || ''),
        inv.gstRate,
        inv.taxableValue.toFixed(2),
        inv.cess ? inv.cess.toFixed(2) : ''
      ].join(',');

      rows.push(row);
      count++;
      totalTaxable = round2(totalTaxable + inv.taxableValue);
      totalTax = round2(totalTax + inv.igst + inv.cgst + inv.sgst + inv.cess);
    }

    return {
      filename: 'b2b,sez,de.csv',
      sectionTitle: 'B2B, SEZ Supplies & Deemed Exports',
      tableNumber: 'Table 4',
      recordCount: count,
      taxableValue: totalTaxable,
      totalTax,
      csvContent: rows.join('\r\n')
    };
  }

  /**
   * 2. Table 5: b2cl.csv
   * Header: Invoice Number,Invoice date,Invoice Value,Place Of Supply,Applicable % of Tax Rate,Rate,Taxable Value,Cess Amount,E-Commerce GSTIN
   */
  public generateB2clCsv(sales: TransactionInvoice[]): SectionCsvBundle {
    const header = 'Invoice Number,Invoice date,Invoice Value,Place Of Supply,Applicable % of Tax Rate,Rate,Taxable Value,Cess Amount,E-Commerce GSTIN';
    const rows: string[] = [header];

    let count = 0;
    let totalTaxable = 0;
    let totalTax = 0;

    const b2clInvoices = sales.filter(inv => {
      if ((inv as any).isHsnSummary || inv.id?.startsWith('PORTAL-HSN')) return false;
      if ((inv as any).isDocSummary || inv.id?.startsWith('PORTAL-DOC')) return false;
      if ((inv as any).isB2csSummary || inv.id?.startsWith('PORTAL-B2CS')) return false;
      const isCnDn = inv.documentType === 'CREDIT_NOTE' || inv.documentType === 'DEBIT_NOTE';
      if (isCnDn) return false;
      return inv.classification === 'B2C_LARGE' || (!inv.recipientGstin || inv.recipientGstin === 'URP') && inv.supplyType === 'INTER_STATE' && inv.totalAmount > 250000;
    });

    for (const inv of b2clInvoices) {
      const pos = formatGstPortalPos(inv.placeOfSupplyCode);
      const row = [
        escapeCsvField(sanitizeGstnInvoiceNumber(inv.invoiceNumber)),
        formatGstPortalDate(inv.invoiceDate),
        inv.totalAmount.toFixed(2),
        pos,
        inv.applicableTaxRatePercent ? String(inv.applicableTaxRatePercent) : '',
        inv.gstRate,
        inv.taxableValue.toFixed(2),
        inv.cess ? inv.cess.toFixed(2) : '',
        escapeCsvField(inv.ecommerceGstin || '')
      ].join(',');

      rows.push(row);
      count++;
      totalTaxable = round2(totalTaxable + inv.taxableValue);
      totalTax = round2(totalTax + inv.igst + inv.cess);
    }

    return {
      filename: 'b2cl.csv',
      sectionTitle: 'B2C Large Invoices (Inter-State > ₹2.5L)',
      tableNumber: 'Table 5',
      recordCount: count,
      taxableValue: totalTaxable,
      totalTax,
      csvContent: rows.join('\r\n')
    };
  }

  /**
   * 3. Table 7: b2cs.csv
   * Header: Type,Place Of Supply,Rate,Applicable % of Tax Rate,Taxable Value,Cess Amount,E-Commerce GSTIN
   * Note: In GSTR-1 Table 7, supplies are aggregated by Type, POS, and Rate.
   */
  public generateB2csCsv(sales: TransactionInvoice[]): SectionCsvBundle {
    const header = 'Type,Place Of Supply,Rate,Applicable % of Tax Rate,Taxable Value,Cess Amount,E-Commerce GSTIN';
    const rows: string[] = [header];

    let totalTaxable = 0;
    let totalTax = 0;

    const b2csInvoices = sales.filter(inv => {
      if ((inv as any).isHsnSummary || inv.id?.startsWith('PORTAL-HSN')) return false;
      if ((inv as any).isDocSummary || inv.id?.startsWith('PORTAL-DOC')) return false;
      const isCnDn = inv.documentType === 'CREDIT_NOTE' || inv.documentType === 'DEBIT_NOTE';
      if (isCnDn) return false;
      return inv.classification === 'B2C_SMALL' || (inv as any).isB2csSummary || ((!inv.recipientGstin || inv.recipientGstin === 'URP') && (inv.supplyType === 'INTRA_STATE' || inv.totalAmount <= 250000));
    });

    // Grouping by Type (E / OE) + POS + Rate + E-Commerce GSTIN
    const map = new Map<string, { type: 'E' | 'OE'; pos: string; rate: number; taxableValue: number; cess: number; ecoGstin: string; tax: number }>();

    for (const inv of b2csInvoices) {
      const type: 'E' | 'OE' = inv.ecommerceGstin ? 'E' : 'OE';
      const pos = formatGstPortalPos(inv.placeOfSupplyCode);
      const rate = inv.gstRate;
      const ecoGstin = inv.ecommerceGstin || '';
      const key = `${type}_${pos}_${rate}_${ecoGstin}`;

      const existing = map.get(key) || { type, pos, rate, taxableValue: 0, cess: 0, ecoGstin, tax: 0 };
      existing.taxableValue = round2(existing.taxableValue + inv.taxableValue);
      existing.cess = round2(existing.cess + inv.cess);
      existing.tax = round2(existing.tax + inv.igst + inv.cgst + inv.sgst + inv.cess);
      map.set(key, existing);

      totalTaxable = round2(totalTaxable + inv.taxableValue);
      totalTax = round2(totalTax + inv.igst + inv.cgst + inv.sgst + inv.cess);
    }

    for (const item of map.values()) {
      const row = [
        item.type,
        item.pos,
        item.rate,
        '', // Applicable % of Tax Rate
        item.taxableValue.toFixed(2),
        item.cess ? item.cess.toFixed(2) : '',
        escapeCsvField(item.ecoGstin)
      ].join(',');
      rows.push(row);
    }

    return {
      filename: 'b2cs.csv',
      sectionTitle: 'B2C Small Supplies (Net Aggregated)',
      tableNumber: 'Table 7',
      recordCount: map.size,
      taxableValue: totalTaxable,
      totalTax,
      csvContent: rows.join('\r\n')
    };
  }

  /**
   * 4. Table 9B: cdnr.csv
   * Header: GSTIN/UIN of Recipient,Receiver Name,Note Number,Note Date,Note Type,Place Of Supply,Reverse Charge,Note Supply Type,Note Value,Applicable % of Tax Rate,Rate,Taxable Value,Cess Amount
   */
  public generateCdnrCsv(sales: TransactionInvoice[]): SectionCsvBundle {
    const header = 'GSTIN/UIN of Recipient,Receiver Name,Note Number,Note Date,Note Type,Place Of Supply,Reverse Charge,Note Supply Type,Note Value,Applicable % of Tax Rate,Rate,Taxable Value,Cess Amount';
    const rows: string[] = [header];

    let count = 0;
    let totalTaxable = 0;
    let totalTax = 0;

    const cdnrInvoices = sales.filter(inv => {
      const isCnDn = inv.documentType === 'CREDIT_NOTE' || inv.documentType === 'DEBIT_NOTE';
      const isRegistered = inv.recipientGstin && inv.recipientGstin.length === 15 && inv.recipientGstin !== 'URP';
      return isCnDn && isRegistered;
    });

    for (const inv of cdnrInvoices) {
      const pos = formatGstPortalPos(inv.placeOfSupplyCode || inv.recipientGstin?.substring(0, 2));
      const noteType = inv.documentType === 'CREDIT_NOTE' ? 'C' : 'D';
      const row = [
        escapeCsvField(inv.recipientGstin),
        escapeCsvField(inv.recipientName || 'Registered Recipient'),
        escapeCsvField(sanitizeGstnInvoiceNumber(inv.invoiceNumber)),
        formatGstPortalDate(inv.invoiceDate),
        noteType,
        pos,
        inv.rcm ? 'Y' : 'N',
        'Regular B2B',
        inv.totalAmount.toFixed(2),
        inv.applicableTaxRatePercent ? String(inv.applicableTaxRatePercent) : '',
        inv.gstRate,
        inv.taxableValue.toFixed(2),
        inv.cess ? inv.cess.toFixed(2) : ''
      ].join(',');

      rows.push(row);
      count++;
      totalTaxable = round2(totalTaxable + inv.taxableValue);
      totalTax = round2(totalTax + inv.igst + inv.cgst + inv.sgst + inv.cess);
    }

    return {
      filename: 'cdnr.csv',
      sectionTitle: 'Credit/Debit Notes (Registered)',
      tableNumber: 'Table 9B',
      recordCount: count,
      taxableValue: totalTaxable,
      totalTax,
      csvContent: rows.join('\r\n')
    };
  }

  /**
   * 5. Table 9B: cdnur.csv
   * Header: UR Type,Note Number,Note Date,Note Type,Place Of Supply,Note Value,Applicable % of Tax Rate,Rate,Taxable Value,Cess Amount
   */
  public generateCdnurCsv(sales: TransactionInvoice[]): SectionCsvBundle {
    const header = 'UR Type,Note Number,Note Date,Note Type,Place Of Supply,Note Value,Applicable % of Tax Rate,Rate,Taxable Value,Cess Amount';
    const rows: string[] = [header];

    let count = 0;
    let totalTaxable = 0;
    let totalTax = 0;

    const cdnurInvoices = sales.filter(inv => {
      const isCnDn = inv.documentType === 'CREDIT_NOTE' || inv.documentType === 'DEBIT_NOTE';
      const isUnregistered = !inv.recipientGstin || inv.recipientGstin.length !== 15 || inv.recipientGstin === 'URP';
      return isCnDn && isUnregistered;
    });

    for (const inv of cdnurInvoices) {
      let urType = 'B2CL';
      if (inv.classification === 'EXPORT_WITH_PAYMENT') urType = 'EXPWP';
      else if (inv.classification === 'EXPORT_WITHOUT_PAYMENT') urType = 'EXPWOP';

      const pos = formatGstPortalPos(inv.placeOfSupplyCode);
      const noteType = inv.documentType === 'CREDIT_NOTE' ? 'C' : 'D';
      const row = [
        urType,
        escapeCsvField(sanitizeGstnInvoiceNumber(inv.invoiceNumber)),
        formatGstPortalDate(inv.invoiceDate),
        noteType,
        pos,
        inv.totalAmount.toFixed(2),
        inv.applicableTaxRatePercent ? String(inv.applicableTaxRatePercent) : '',
        inv.gstRate,
        inv.taxableValue.toFixed(2),
        inv.cess ? inv.cess.toFixed(2) : ''
      ].join(',');

      rows.push(row);
      count++;
      totalTaxable = round2(totalTaxable + inv.taxableValue);
      totalTax = round2(totalTax + inv.igst + inv.cgst + inv.sgst + inv.cess);
    }

    return {
      filename: 'cdnur.csv',
      sectionTitle: 'Credit/Debit Notes (Unregistered)',
      tableNumber: 'Table 9B',
      recordCount: count,
      taxableValue: totalTaxable,
      totalTax,
      csvContent: rows.join('\r\n')
    };
  }

  /**
   * 6. Table 6A: exp.csv
   * Header: Export Type,Invoice Number,Invoice date,Invoice Value,Port Code,Shipping Bill Number,Shipping Bill Date,Rate,Taxable Value,Cess Amount
   */
  public generateExpCsv(sales: TransactionInvoice[]): SectionCsvBundle {
    const header = 'Export Type,Invoice Number,Invoice date,Invoice Value,Port Code,Shipping Bill Number,Shipping Bill Date,Rate,Taxable Value,Cess Amount';
    const rows: string[] = [header];

    let count = 0;
    let totalTaxable = 0;
    let totalTax = 0;

    const expInvoices = sales.filter(inv => {
      const isCnDn = inv.documentType === 'CREDIT_NOTE' || inv.documentType === 'DEBIT_NOTE';
      return !isCnDn && (inv.classification?.startsWith('EXPORT') || inv.classification === 'ZERO_RATED');
    });

    for (const inv of expInvoices) {
      const expType = inv.classification === 'EXPORT_WITHOUT_PAYMENT' ? 'WOPAY' : 'WPAY';
      const row = [
        expType,
        escapeCsvField(sanitizeGstnInvoiceNumber(inv.invoiceNumber)),
        formatGstPortalDate(inv.invoiceDate),
        inv.totalAmount.toFixed(2),
        escapeCsvField(inv.portCode || 'INB995'),
        escapeCsvField(inv.shippingBillNumber || '184298'),
        formatGstPortalDate(inv.shippingBillDate || inv.invoiceDate),
        inv.gstRate,
        inv.taxableValue.toFixed(2),
        inv.cess ? inv.cess.toFixed(2) : ''
      ].join(',');

      rows.push(row);
      count++;
      totalTaxable = round2(totalTaxable + inv.taxableValue);
      totalTax = round2(totalTax + inv.igst + inv.cess);
    }

    return {
      filename: 'exp.csv',
      sectionTitle: 'Export Invoices',
      tableNumber: 'Table 6A',
      recordCount: count,
      taxableValue: totalTaxable,
      totalTax,
      csvContent: rows.join('\r\n')
    };
  }

  /**
   * 7A. Table 12: hsn_b2b.csv (Official GST Offline Tool Format for Registered B2B Supplies)
   * Header: HSN,Description,UQC,Total Quantity,Total Value,Taxable Value,Integrated Tax Amount,Central Tax Amount,State/UT Tax Amount,Cess Amount,Rate
   */
  public generateHsnB2bCsv(sales: TransactionInvoice[]): SectionCsvBundle {
    const header = 'HSN,Description,UQC,Total Quantity,Total Value,Taxable Value,Integrated Tax Amount,Central Tax Amount,State/UT Tax Amount,Cess Amount,Rate';
    const rows: string[] = [header];

    let totalTaxable = 0;
    let totalTax = 0;

    const explicitB2bHsn = sales.filter((s: any) =>
      (s.isHsnSummary || s.id?.startsWith('PORTAL-HSN')) &&
      (s.hsnCategory === 'B2B' || s.classification === 'B2B' || (!s.hsnCategory && s.classification !== 'B2C_SMALL'))
    );

    if (explicitB2bHsn.length > 0) {
      for (const inv of explicitB2bHsn) {
        const hsn = inv.hsnSacPrimary || (inv as any).hsnSac || '998313';
        const isService = hsn.startsWith('99');
        const cleanRawUqc = String((inv as any).uqc || '').split('-')[0].trim().toUpperCase();
        const uqc = isService ? 'NA' : (cleanRawUqc && cleanRawUqc !== 'NA' ? cleanRawUqc : 'OTH');
        const qty = isService ? 0 : Number((inv as any).totalQuantity ?? (inv as any).quantity ?? 0);
        const desc = inv.descriptionPrimary || (isService ? 'Information technology consulting and support services' : 'Outward Taxable Supply');
        const txval = round2(inv.taxableValue || 0);
        const totVal = round2(inv.totalAmount || (txval + inv.igst + inv.cgst + inv.sgst + inv.cess));
        const row = [
          escapeCsvField(hsn),
          escapeCsvField(desc),
          uqc,
          isService ? '' : qty,
          totVal.toFixed(2),
          txval.toFixed(2),
          inv.igst.toFixed(2),
          inv.cgst.toFixed(2),
          inv.sgst.toFixed(2),
          inv.cess ? inv.cess.toFixed(2) : '',
          inv.gstRate
        ].join(',');
        rows.push(row);
        totalTaxable = round2(totalTaxable + txval);
        totalTax = round2(totalTax + inv.igst + inv.cgst + inv.sgst + inv.cess);
      }
      return {
        filename: 'hsn_b2b.csv',
        sectionTitle: 'Table 12: HSN/SAC Summary (B2B - Registered Supplies)',
        tableNumber: 'Table 12 (B2B)',
        recordCount: explicitB2bHsn.length,
        taxableValue: totalTaxable,
        totalTax,
        csvContent: rows.join('\r\n')
      };
    }

    // Fallback: Group B2B outward supplies by HSN + UQC + Rate
    const hsnMap = new Map<string, {
      hsn: string;
      desc: string;
      uqc: string;
      qty: number;
      val: number;
      txval: number;
      iamt: number;
      camt: number;
      samt: number;
      csamt: number;
      rt: number;
    }>();

    const b2bInvoices = sales.filter(inv => {
      if ((inv as any).isDocSummary || inv.id?.startsWith('PORTAL-DOC')) return false;
      if ((inv as any).isHsnSummary || inv.id?.startsWith('PORTAL-HSN')) return false;
      if (inv.documentType === 'CREDIT_NOTE' || inv.documentType === 'DEBIT_NOTE') return false;
      const isRegistered = Boolean(inv.recipientGstin) && inv.recipientGstin.length === 15 && inv.recipientGstin !== 'URP';
      return inv.classification === 'B2B' || isRegistered;
    });

    for (const inv of b2bInvoices) {
      const hsn = inv.hsnSacPrimary || (inv as any).hsnSac || '998313';
      const isService = hsn.startsWith('99');
      const rawUqc = String((inv as any).uqc || 'OTH').split('-')[0].trim().toUpperCase();
      const uqc = isService ? 'NA' : (rawUqc || 'OTH');
      const qty = isService ? 0 : Number((inv as any).totalQuantity ?? (inv as any).quantity ?? 1);
      const rt = inv.gstRate || 18;
      const key = `${hsn}_${uqc}_${rt}`;

      const existing = hsnMap.get(key) || {
        hsn,
        desc: inv.descriptionPrimary || (isService ? 'Information technology consulting and support services' : 'Outward Taxable Supply'),
        uqc,
        qty: 0,
        val: 0,
        txval: 0,
        iamt: 0,
        camt: 0,
        samt: 0,
        csamt: 0,
        rt
      };

      existing.val = round2(existing.val + (inv.totalAmount || (inv.taxableValue + inv.cgst + inv.sgst + inv.igst + inv.cess)));
      existing.txval = round2(existing.txval + inv.taxableValue);
      existing.iamt = round2(existing.iamt + inv.igst);
      existing.camt = round2(existing.camt + inv.cgst);
      existing.samt = round2(existing.samt + inv.sgst);
      existing.csamt = round2(existing.csamt + inv.cess);
      existing.qty = isService ? 0 : round2(existing.qty + qty);
      hsnMap.set(key, existing);

      totalTaxable = round2(totalTaxable + inv.taxableValue);
      totalTax = round2(totalTax + inv.igst + inv.cgst + inv.sgst + inv.cess);
    }

    for (const item of hsnMap.values()) {
      const isService = item.hsn.startsWith('99');
      const row = [
        escapeCsvField(item.hsn),
        escapeCsvField(item.desc),
        item.uqc,
        isService ? '' : item.qty,
        item.val.toFixed(2),
        item.txval.toFixed(2),
        item.iamt.toFixed(2),
        item.camt.toFixed(2),
        item.samt.toFixed(2),
        item.csamt.toFixed(2),
        item.rt
      ].join(',');
      rows.push(row);
    }

    return {
      filename: 'hsn_b2b.csv',
      sectionTitle: 'Table 12: HSN/SAC Summary (B2B - Registered Supplies)',
      tableNumber: 'Table 12 (B2B)',
      recordCount: hsnMap.size,
      taxableValue: totalTaxable,
      totalTax,
      csvContent: rows.join('\r\n')
    };
  }

  /**
   * 7B. Table 12: hsn_b2c.csv (Official GST Offline Tool Format for Consumer B2C Supplies)
   * Header: HSN,Description,UQC,Total Quantity,Total Value,Taxable Value,Integrated Tax Amount,Central Tax Amount,State/UT Tax Amount,Cess Amount,Rate
   */
  public generateHsnB2cCsv(sales: TransactionInvoice[]): SectionCsvBundle {
    const header = 'HSN,Description,UQC,Total Quantity,Total Value,Taxable Value,Integrated Tax Amount,Central Tax Amount,State/UT Tax Amount,Cess Amount,Rate';
    const rows: string[] = [header];

    let totalTaxable = 0;
    let totalTax = 0;

    const explicitB2cHsn = sales.filter((s: any) =>
      (s.isHsnSummary || s.id?.startsWith('PORTAL-HSN')) &&
      (s.hsnCategory === 'B2C' || s.classification === 'B2C_SMALL' || s.classification === 'B2C_LARGE')
    );

    if (explicitB2cHsn.length > 0) {
      for (const inv of explicitB2cHsn) {
        const hsn = inv.hsnSacPrimary || (inv as any).hsnSac || '998313';
        const isService = hsn.startsWith('99');
        const cleanRawUqc = String((inv as any).uqc || '').split('-')[0].trim().toUpperCase();
        const uqc = isService ? 'NA' : (cleanRawUqc && cleanRawUqc !== 'NA' ? cleanRawUqc : 'OTH');
        const qty = isService ? 0 : Number((inv as any).totalQuantity ?? (inv as any).quantity ?? 0);
        const desc = inv.descriptionPrimary || (isService ? 'Information technology consulting and support services' : 'Outward Taxable Supply');
        const txval = round2(inv.taxableValue || 0);
        const totVal = round2(inv.totalAmount || (txval + inv.igst + inv.cgst + inv.sgst + inv.cess));
        const row = [
          escapeCsvField(hsn),
          escapeCsvField(desc),
          uqc,
          isService ? '' : qty,
          totVal.toFixed(2),
          txval.toFixed(2),
          inv.igst.toFixed(2),
          inv.cgst.toFixed(2),
          inv.sgst.toFixed(2),
          inv.cess ? inv.cess.toFixed(2) : '',
          inv.gstRate
        ].join(',');
        rows.push(row);
        totalTaxable = round2(totalTaxable + txval);
        totalTax = round2(totalTax + inv.igst + inv.cgst + inv.sgst + inv.cess);
      }
      return {
        filename: 'hsn_b2c.csv',
        sectionTitle: 'Table 12: HSN/SAC Summary (B2C - Unregistered Supplies)',
        tableNumber: 'Table 12 (B2C)',
        recordCount: explicitB2cHsn.length,
        taxableValue: totalTaxable,
        totalTax,
        csvContent: rows.join('\r\n')
      };
    }

    // Fallback: Group B2C outward supplies by HSN + UQC + Rate
    const hsnMap = new Map<string, {
      hsn: string;
      desc: string;
      uqc: string;
      qty: number;
      val: number;
      txval: number;
      iamt: number;
      camt: number;
      samt: number;
      csamt: number;
      rt: number;
    }>();

    const b2cInvoices = sales.filter(inv => {
      if ((inv as any).isDocSummary || inv.id?.startsWith('PORTAL-DOC')) return false;
      if ((inv as any).isHsnSummary || inv.id?.startsWith('PORTAL-HSN')) return false;
      if (inv.documentType === 'CREDIT_NOTE' || inv.documentType === 'DEBIT_NOTE') return false;
      const isUnregistered = !inv.recipientGstin || inv.recipientGstin === 'URP';
      return inv.classification === 'B2C_SMALL' || inv.classification === 'B2C_LARGE' || (inv as any).isB2csSummary || isUnregistered;
    });

    for (const inv of b2cInvoices) {
      const hsn = inv.hsnSacPrimary || (inv as any).hsnSac || '998313';
      const isService = hsn.startsWith('99');
      const rawUqc = String((inv as any).uqc || 'OTH').split('-')[0].trim().toUpperCase();
      const uqc = isService ? 'NA' : (rawUqc || 'OTH');
      const qty = isService ? 0 : Number((inv as any).totalQuantity ?? (inv as any).quantity ?? 1);
      const rt = inv.gstRate || 18;
      const key = `${hsn}_${uqc}_${rt}`;

      const existing = hsnMap.get(key) || {
        hsn,
        desc: inv.descriptionPrimary || (isService ? 'Information technology consulting and support services' : 'Outward Taxable Supply'),
        uqc,
        qty: 0,
        val: 0,
        txval: 0,
        iamt: 0,
        camt: 0,
        samt: 0,
        csamt: 0,
        rt
      };

      existing.val = round2(existing.val + (inv.totalAmount || (inv.taxableValue + inv.cgst + inv.sgst + inv.igst + inv.cess)));
      existing.txval = round2(existing.txval + inv.taxableValue);
      existing.iamt = round2(existing.iamt + inv.igst);
      existing.camt = round2(existing.camt + inv.cgst);
      existing.samt = round2(existing.samt + inv.sgst);
      existing.csamt = round2(existing.csamt + inv.cess);
      existing.qty = isService ? 0 : round2(existing.qty + qty);
      hsnMap.set(key, existing);

      totalTaxable = round2(totalTaxable + inv.taxableValue);
      totalTax = round2(totalTax + inv.igst + inv.cgst + inv.sgst + inv.cess);
    }

    for (const item of hsnMap.values()) {
      const isService = item.hsn.startsWith('99');
      const row = [
        escapeCsvField(item.hsn),
        escapeCsvField(item.desc),
        item.uqc,
        isService ? '' : item.qty,
        item.val.toFixed(2),
        item.txval.toFixed(2),
        item.iamt.toFixed(2),
        item.camt.toFixed(2),
        item.samt.toFixed(2),
        item.csamt.toFixed(2),
        item.rt
      ].join(',');
      rows.push(row);
    }

    return {
      filename: 'hsn_b2c.csv',
      sectionTitle: 'Table 12: HSN/SAC Summary (B2C - Unregistered Supplies)',
      tableNumber: 'Table 12 (B2C)',
      recordCount: hsnMap.size,
      taxableValue: totalTaxable,
      totalTax,
      csvContent: rows.join('\r\n')
    };
  }

  /**
   * 7C. Table 12: hsn.csv (Consolidated Outward HSN Summary)
   * Header: HSN,Description,UQC,Total Quantity,Total Value,Taxable Value,Integrated Tax Amount,Central Tax Amount,State/UT Tax Amount,Cess Amount,Rate
   */
  public generateHsnCsv(sales: TransactionInvoice[]): SectionCsvBundle {
    const header = 'HSN,Description,UQC,Total Quantity,Total Value,Taxable Value,Integrated Tax Amount,Central Tax Amount,State/UT Tax Amount,Cess Amount,Rate';
    const rows: string[] = [header];

    let totalTaxable = 0;
    let totalTax = 0;

    const explicitHsn = sales.filter((s: any) => s.isHsnSummary || s.id?.startsWith('PORTAL-HSN'));
    if (explicitHsn.length > 0) {
      for (const inv of explicitHsn) {
        const hsn = inv.hsnSacPrimary || (inv as any).hsnSac || '998313';
        const isService = hsn.startsWith('99');
        const cleanRawUqc = String((inv as any).uqc || '').split('-')[0].trim().toUpperCase();
        const uqc = isService ? 'NA' : (cleanRawUqc && cleanRawUqc !== 'NA' ? cleanRawUqc : 'OTH');
        const qty = isService ? 0 : Number((inv as any).totalQuantity ?? (inv as any).quantity ?? 0);
        const desc = inv.descriptionPrimary || (isService ? 'Information technology consulting and support services' : 'Outward Taxable Supply');
        const txval = round2(inv.taxableValue || 0);
        const totVal = round2(inv.totalAmount || (txval + inv.igst + inv.cgst + inv.sgst + inv.cess));
        const row = [
          escapeCsvField(hsn),
          escapeCsvField(desc),
          uqc,
          isService ? '' : qty,
          totVal.toFixed(2),
          txval.toFixed(2),
          inv.igst.toFixed(2),
          inv.cgst.toFixed(2),
          inv.sgst.toFixed(2),
          inv.cess ? inv.cess.toFixed(2) : '',
          inv.gstRate
        ].join(',');
        rows.push(row);
        totalTaxable = round2(totalTaxable + txval);
        totalTax = round2(totalTax + inv.igst + inv.cgst + inv.sgst + inv.cess);
      }
      return {
        filename: 'hsn.csv',
        sectionTitle: 'HSN / SAC Summary of Outward Supplies',
        tableNumber: 'Table 12',
        recordCount: explicitHsn.length,
        taxableValue: totalTaxable,
        totalTax,
        csvContent: rows.join('\r\n')
      };
    }

    // Fallback: Group outward supplies by HSN + UQC + Rate
    const hsnMap = new Map<string, {
      hsn: string;
      desc: string;
      uqc: string;
      qty: number;
      val: number;
      txval: number;
      iamt: number;
      camt: number;
      samt: number;
      csamt: number;
      rt: number;
    }>();

    for (const inv of sales) {
      if ((inv as any).isDocSummary || inv.id?.startsWith('PORTAL-DOC')) continue;
      if (inv.documentType === 'CREDIT_NOTE' || inv.documentType === 'DEBIT_NOTE') continue;
      const hsn = inv.hsnSacPrimary || (inv as any).hsnSac || '998313';
      const isService = hsn.startsWith('99');
      const rawUqc = String((inv as any).uqc || 'OTH').split('-')[0].trim().toUpperCase();
      const uqc = isService ? 'NA' : (rawUqc || 'OTH');
      const qty = isService ? 0 : Number((inv as any).totalQuantity ?? (inv as any).quantity ?? (inv as any).qty ?? 1);
      const rt = inv.gstRate || 18;
      const key = `${hsn}_${uqc}_${rt}`;

      const existing = hsnMap.get(key) || {
        hsn,
        desc: inv.descriptionPrimary || (isService ? 'Information technology consulting and support services' : 'Outward Taxable Supply'),
        uqc,
        qty: 0,
        val: 0,
        txval: 0,
        iamt: 0,
        camt: 0,
        samt: 0,
        csamt: 0,
        rt
      };

      existing.val = round2(existing.val + (inv.totalAmount || (inv.taxableValue + inv.cgst + inv.sgst + inv.igst + inv.cess)));
      existing.txval = round2(existing.txval + inv.taxableValue);
      existing.iamt = round2(existing.iamt + inv.igst);
      existing.camt = round2(existing.camt + inv.cgst);
      existing.samt = round2(existing.samt + inv.sgst);
      existing.csamt = round2(existing.csamt + inv.cess);
      existing.qty = isService ? 0 : round2(existing.qty + qty);
      hsnMap.set(key, existing);

      totalTaxable = round2(totalTaxable + inv.taxableValue);
      totalTax = round2(totalTax + inv.igst + inv.cgst + inv.sgst + inv.cess);
    }

    for (const item of hsnMap.values()) {
      const isService = item.hsn.startsWith('99');
      const row = [
        escapeCsvField(item.hsn),
        escapeCsvField(item.desc),
        item.uqc,
        isService ? '' : item.qty,
        item.val.toFixed(2),
        item.txval.toFixed(2),
        item.iamt.toFixed(2),
        item.camt.toFixed(2),
        item.samt.toFixed(2),
        item.csamt.toFixed(2),
        item.rt
      ].join(',');
      rows.push(row);
    }

    return {
      filename: 'hsn.csv',
      sectionTitle: 'HSN / SAC Summary of Outward Supplies',
      tableNumber: 'Table 12',
      recordCount: hsnMap.size,
      taxableValue: totalTaxable,
      totalTax,
      csvContent: rows.join('\r\n')
    };
  }

  /**
   * 8. Table 13: docs.csv
   * Header: Nature of Document,Sr. No. From,Sr. No. To,Total Number,Cancelled
   */
  public generateDocsCsv(sales: TransactionInvoice[]): SectionCsvBundle {
    const header = 'Nature of Document,Sr. No. From,Sr. No. To,Total Number,Cancelled';
    const rows: string[] = [header];

    const docSummaryItems = sales.filter((s: any) => s.isDocSummary || s.id?.startsWith('PORTAL-DOC') || ((s as any).fromSerial && (s as any).totalNumber !== undefined));

    if (docSummaryItems.length > 0) {
      for (const d of docSummaryItems) {
        const tot = Number((d as any).totalNumber ?? (d as any).totnum ?? 0);
        const can = Number((d as any).cancelled ?? (d as any).cancel ?? 0);
        const fromVal = String((d as any).fromSerial || d.invoiceNumber || '').trim();
        const toVal = String((d as any).toSerial || fromVal).trim();
        rows.push([
          escapeCsvField((d as any).docNature || d.descriptionPrimary || 'Invoices for outward supply'),
          escapeCsvField(fromVal),
          escapeCsvField(toVal),
          tot > 0 ? tot : 1,
          can
        ].join(','));
      }
    } else {
      const isGenuineDoc = (s: any) =>
        !s.isDocSummary &&
        !s.id?.startsWith('PORTAL-DOC') &&
        !s.isHsnSummary &&
        !s.id?.startsWith('PORTAL-HSN') &&
        !s.isB2csSummary &&
        !s.id?.startsWith('PORTAL-B2CS') &&
        Boolean(s.invoiceNumber && s.invoiceNumber.trim() && !s.invoiceNumber.startsWith('B2CS/') && !s.invoiceNumber.startsWith('INV/HSN/'));

      const regularInvoices = sales.filter(s => s.documentType === 'INVOICE' && isGenuineDoc(s));
      const creditNotes = sales.filter(s => s.documentType === 'CREDIT_NOTE' && isGenuineDoc(s));
      const debitNotes = sales.filter(s => s.documentType === 'DEBIT_NOTE' && isGenuineDoc(s));

      if (regularInvoices.length > 0) {
        const first = sanitizeGstnInvoiceNumber(regularInvoices[0].invoiceNumber);
        const last = sanitizeGstnInvoiceNumber(regularInvoices[regularInvoices.length - 1].invoiceNumber);
        rows.push([
          'Invoices for outward supply',
          escapeCsvField(first),
          escapeCsvField(last),
          regularInvoices.length,
          0
        ].join(','));
      }

      if (creditNotes.length > 0) {
        const first = sanitizeGstnInvoiceNumber(creditNotes[0].invoiceNumber);
        const last = sanitizeGstnInvoiceNumber(creditNotes[creditNotes.length - 1].invoiceNumber);
        rows.push([
          'Credit Note',
          escapeCsvField(first),
          escapeCsvField(last),
          creditNotes.length,
          0
        ].join(','));
      }

      if (debitNotes.length > 0) {
        const first = sanitizeGstnInvoiceNumber(debitNotes[0].invoiceNumber);
        const last = sanitizeGstnInvoiceNumber(debitNotes[debitNotes.length - 1].invoiceNumber);
        rows.push([
          'Debit Note',
          escapeCsvField(first),
          escapeCsvField(last),
          debitNotes.length,
          0
        ].join(','));
      }
    }

    return {
      filename: 'docs.csv',
      sectionTitle: 'Documents Issued Summary',
      tableNumber: 'Table 13',
      recordCount: rows.length - 1,
      taxableValue: 0,
      totalTax: 0,
      csvContent: rows.join('\r\n')
    };
  }

  /**
   * 9. Table 8: exemp.csv
   * Header: Description,Nil Rated Supplies,Exempted(other than nil rated/non GST supply),Non-GST Supplies
   */
  public generateExempCsv(sales: TransactionInvoice[]): SectionCsvBundle {
    const header = 'Description,Nil Rated Supplies,Exempted(other than nil rated/non GST supply),Non-GST Supplies';
    const rows: string[] = [header];

    let interRegNil = 0, interRegExempt = 0, interRegNonGst = 0;
    let intraRegNil = 0, intraRegExempt = 0, intraRegNonGst = 0;
    let interUnregNil = 0, interUnregExempt = 0, interUnregNonGst = 0;
    let intraUnregNil = 0, intraUnregExempt = 0, intraUnregNonGst = 0;

    for (const inv of sales) {
      const isExempt = inv.classification === 'EXEMPT';
      const isNil = inv.classification === 'NIL_RATED';
      const isNonGst = inv.classification === 'NON_GST';
      if (!isExempt && !isNil && !isNonGst) continue;

      const isRegistered = inv.recipientGstin && inv.recipientGstin.length === 15 && inv.recipientGstin !== 'URP';
      const isInter = inv.supplyType === 'INTER_STATE';

      if (isInter && isRegistered) {
        if (isNil) interRegNil += inv.taxableValue;
        if (isExempt) interRegExempt += inv.taxableValue;
        if (isNonGst) interRegNonGst += inv.taxableValue;
      } else if (!isInter && isRegistered) {
        if (isNil) intraRegNil += inv.taxableValue;
        if (isExempt) intraRegExempt += inv.taxableValue;
        if (isNonGst) intraRegNonGst += inv.taxableValue;
      } else if (isInter && !isRegistered) {
        if (isNil) interUnregNil += inv.taxableValue;
        if (isExempt) interUnregExempt += inv.taxableValue;
        if (isNonGst) interUnregNonGst += inv.taxableValue;
      } else {
        if (isNil) intraUnregNil += inv.taxableValue;
        if (isExempt) intraUnregExempt += inv.taxableValue;
        if (isNonGst) intraUnregNonGst += inv.taxableValue;
      }
    }

    rows.push(['Inter-State supplies to registered persons', interRegNil.toFixed(2), interRegExempt.toFixed(2), interRegNonGst.toFixed(2)].join(','));
    rows.push(['Intra-State supplies to registered persons', intraRegNil.toFixed(2), intraRegExempt.toFixed(2), intraRegNonGst.toFixed(2)].join(','));
    rows.push(['Inter-State supplies to unregistered persons', interUnregNil.toFixed(2), interUnregExempt.toFixed(2), interUnregNonGst.toFixed(2)].join(','));
    rows.push(['Intra-State supplies to unregistered persons', intraUnregNil.toFixed(2), intraUnregExempt.toFixed(2), intraUnregNonGst.toFixed(2)].join(','));

    const totalTurnover = round2(interRegNil + interRegExempt + interRegNonGst + intraRegNil + intraRegExempt + intraRegNonGst + interUnregNil + interUnregExempt + interUnregNonGst + intraUnregNil + intraUnregExempt + intraUnregNonGst);

    return {
      filename: 'exemp.csv',
      sectionTitle: 'Nil Rated, Exempted & Non-GST Supplies',
      tableNumber: 'Table 8',
      recordCount: 4,
      taxableValue: totalTurnover,
      totalTax: 0,
      csvContent: rows.join('\r\n')
    };
  }

  /**
   * 10. Table 14: eco.csv
   * Header: Nature of Supply,GSTIN of E-Commerce Operator,E-Commerce Operator Name,Net value of supplies,Integrated tax,Central tax,State/UT tax,Cess
   */
  public generateEcoCsv(sales: TransactionInvoice[], ecoReports: any[] = []): SectionCsvBundle {
    const header = 'Nature of Supply,GSTIN of E-Commerce Operator,E-Commerce Operator Name,Net value of supplies,Integrated tax,Central tax,State/UT tax,Cess';
    const rows: string[] = [header];

    let totalTaxable = 0;
    let totalTax = 0;

    const ecoSales = sales.filter(s => s.ecommerceGstin && s.ecommerceGstin.length === 15);

    // Grouping by ECO GSTIN + Nature
    const map = new Map<string, { nature: string; gstin: string; name: string; val: number; iamt: number; camt: number; samt: number; csamt: number }>();

    for (const inv of ecoSales) {
      const nature = 'Liable to collect tax u/s 52(TCS)';
      const gstin = inv.ecommerceGstin || '';
      const key = `${nature}_${gstin}`;

      const existing = map.get(key) || {
        nature,
        gstin,
        name: inv.ecommerceOperatorName || 'E-Commerce Marketplace Operator',
        val: 0,
        iamt: 0,
        camt: 0,
        samt: 0,
        csamt: 0
      };

      existing.val = round2(existing.val + inv.taxableValue);
      existing.iamt = round2(existing.iamt + inv.igst);
      existing.camt = round2(existing.camt + inv.cgst);
      existing.samt = round2(existing.samt + inv.sgst);
      existing.csamt = round2(existing.csamt + inv.cess);
      map.set(key, existing);

      totalTaxable = round2(totalTaxable + inv.taxableValue);
      totalTax = round2(totalTax + inv.igst + inv.cgst + inv.sgst + inv.cess);
    }

    // Also include reports if present
    for (const r of ecoReports) {
      if (r.operatorGstin && !map.has(`Liable to collect tax u/s 52(TCS)_${r.operatorGstin}`)) {
        map.set(`Liable to collect tax u/s 52(TCS)_${r.operatorGstin}`, {
          nature: 'Liable to collect tax u/s 52(TCS)',
          gstin: r.operatorGstin,
          name: r.operatorName || 'E-Commerce Operator',
          val: round2(r.grossSupplies || 0),
          iamt: round2(r.tcsIgst || 0),
          camt: round2(r.tcsCgst || 0),
          samt: round2(r.tcsSgst || 0),
          csamt: 0
        });
      }
    }

    for (const item of map.values()) {
      const row = [
        escapeCsvField(item.nature),
        escapeCsvField(item.gstin),
        escapeCsvField(item.name),
        item.val.toFixed(2),
        item.iamt.toFixed(2),
        item.camt.toFixed(2),
        item.samt.toFixed(2),
        item.csamt.toFixed(2)
      ].join(',');
      rows.push(row);
    }

    return {
      filename: 'eco.csv',
      sectionTitle: 'Supplies through E-Commerce Operator (Table 14)',
      tableNumber: 'Table 14',
      recordCount: map.size,
      taxableValue: totalTaxable,
      totalTax,
      csvContent: rows.join('\r\n')
    };
  }

  /**
   * Generates all official GST Portal section CSV files in a unified bundle
   */
  public generateAllSections(sales: TransactionInvoice[], ecoReports: any[] = []): SectionCsvBundle[] {
    return [
      this.generateB2bCsv(sales),
      this.generateB2clCsv(sales),
      this.generateB2csCsv(sales),
      this.generateCdnrCsv(sales),
      this.generateCdnurCsv(sales),
      this.generateExpCsv(sales),
      this.generateHsnB2bCsv(sales),
      this.generateHsnB2cCsv(sales),
      this.generateDocsCsv(sales),
      this.generateExempCsv(sales),
      this.generateEcoCsv(sales, ecoReports)
    ];
  }

  public generateMasterWorkbookBundle(
    sales: TransactionInvoice[],
    activeGstin: string = '07ABFFB5922Q1Z0',
    purchases: TransactionInvoice[] = []
  ): SectionCsvBundle {
    const creditDebitNotes = sales.filter(s => s.documentType === 'CREDIT_NOTE' || s.documentType === 'DEBIT_NOTE');
    const regularSales = sales.filter(s => s.documentType !== 'CREDIT_NOTE' && s.documentType !== 'DEBIT_NOTE');
    const bytes = gstExcelTemplateService.exportToWebGstTemplate(regularSales, purchases, creditDebitNotes, activeGstin);
    const taxableValue = sales.reduce((acc, s) => acc + (s.taxableValue || 0), 0);
    const totalTax = sales.reduce((acc, s) => acc + (s.igst || 0) + (s.cgst || 0) + (s.sgst || 0) + (s.cess || 0), 0);

    return {
      filename: 'WEB_GST_Template.xlsx',
      sectionTitle: 'Official Master All-in-One Template (SALE, PURCHASE, CR/DR NOTE & Masters)',
      tableNumber: 'MASTER',
      recordCount: sales.length,
      taxableValue: round2(taxableValue),
      totalTax: round2(totalTax),
      csvContent: '',
      isExcel: true,
      fileBytes: bytes
    };
  }

  // ============================================================================
  // PURE CLIENT-SIDE MULTI-FILE ZIP GENERATOR (NO EXTERNAL DEPENDENCY REQUIRED)
  // Implements standard PK\x03\x04 APPNOTE format with CRC-32 checksum calculation
  // ============================================================================
  public createZipArchive(files: { filename: string; content: string | Uint8Array }[]): Blob {
    // CRC-32 table generator
    const crcTable = new Uint32Array(256);
    for (let i = 0; i < 256; i++) {
      let c = i;
      for (let k = 0; k < 8; k++) {
        c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      }
      crcTable[i] = c >>> 0;
    }

    function calculateCrc32(bytes: Uint8Array): number {
      let crc = 0xFFFFFFFF;
      for (let i = 0; i < bytes.length; i++) {
        crc = crcTable[(crc ^ bytes[i]) & 0xFF] ^ (crc >>> 8);
      }
      return (crc ^ 0xFFFFFFFF) >>> 0;
    }

    const encoder = new TextEncoder();
    const localHeaders: Uint8Array[] = [];
    const centralHeaders: Uint8Array[] = [];
    let offset = 0;

    for (const f of files) {
      let fileBytes: Uint8Array;
      if (typeof f.content === 'string') {
        // Add UTF-8 BOM for Microsoft Excel compatibility
        const bom = new Uint8Array([0xEF, 0xBB, 0xBF]);
        const fileTextBytes = encoder.encode(f.content);
        fileBytes = new Uint8Array(bom.length + fileTextBytes.length);
        fileBytes.set(bom, 0);
        fileBytes.set(fileTextBytes, bom.length);
      } else {
        fileBytes = f.content;
      }

      const nameBytes = encoder.encode(f.filename);
      const crc = calculateCrc32(fileBytes);
      const size = fileBytes.length;

      // Local File Header (30 bytes + name length)
      const lfh = new Uint8Array(30 + nameBytes.length);
      const lfhView = new DataView(lfh.buffer);
      lfhView.setUint32(0, 0x04034B50, true); // Local file header signature
      lfhView.setUint16(4, 20, true);         // Version needed: 2.0
      lfhView.setUint16(6, 0x0800, true);     // General purpose bit flag (UTF-8 filename)
      lfhView.setUint16(8, 0, true);          // Compression method: 0 (Stored/No compression)
      lfhView.setUint16(10, 0x54A0, true);    // Last mod file time
      lfhView.setUint16(12, 0x5C8B, true);    // Last mod file date (2026-04-11)
      lfhView.setUint32(14, crc, true);       // CRC-32
      lfhView.setUint32(18, size, true);      // Compressed size
      lfhView.setUint32(22, size, true);      // Uncompressed size
      lfhView.setUint16(26, nameBytes.length, true); // File name length
      lfhView.setUint16(28, 0, true);         // Extra field length
      lfh.set(nameBytes, 30);

      localHeaders.push(lfh);
      localHeaders.push(fileBytes);

      // Central Directory Header (46 bytes + name length)
      const cdh = new Uint8Array(46 + nameBytes.length);
      const cdhView = new DataView(cdh.buffer);
      cdhView.setUint32(0, 0x02014B50, true); // Central file header signature
      cdhView.setUint16(4, 20, true);         // Version made by
      cdhView.setUint16(6, 20, true);         // Version needed
      cdhView.setUint16(8, 0x0800, true);     // Bit flag (UTF-8)
      cdhView.setUint16(10, 0, true);         // Compression method (0 = Stored)
      cdhView.setUint16(12, 0x54A0, true);    // Last mod time
      cdhView.setUint16(14, 0x5C8B, true);    // Last mod date
      cdhView.setUint32(16, crc, true);       // CRC-32
      cdhView.setUint32(20, size, true);      // Compressed size
      cdhView.setUint32(24, size, true);      // Uncompressed size
      cdhView.setUint16(28, nameBytes.length, true); // File name length
      cdhView.setUint16(30, 0, true);         // Extra field length
      cdhView.setUint16(32, 0, true);         // File comment length
      cdhView.setUint16(34, 0, true);         // Disk number start
      cdhView.setUint16(36, 0, true);         // Internal file attributes
      cdhView.setUint32(38, 0, true);         // External file attributes
      cdhView.setUint32(42, offset, true);    // Relative offset of local header
      cdh.set(nameBytes, 46);

      centralHeaders.push(cdh);
      offset += lfh.length + size;
    }

    const centralDirectorySize = centralHeaders.reduce((s, h) => s + h.length, 0);

    // End of Central Directory Record (22 bytes)
    const eocd = new Uint8Array(22);
    const eocdView = new DataView(eocd.buffer);
    eocdView.setUint32(0, 0x06054B50, true); // End of central dir signature
    eocdView.setUint16(4, 0, true);          // Number of this disk
    eocdView.setUint16(6, 0, true);          // Disk with central dir
    eocdView.setUint16(8, files.length, true);  // Number of entries on this disk
    eocdView.setUint16(10, files.length, true); // Total number of entries
    eocdView.setUint32(12, centralDirectorySize, true); // Central dir size
    eocdView.setUint32(16, offset, true);    // Offset of central dir
    eocdView.setUint16(20, 0, true);         // Comment length

    // Assemble final ZIP blob
    const allParts: any[] = [...localHeaders, ...centralHeaders, eocd];
    return new Blob(allParts, { type: 'application/zip' });
  }

  // ============================================================================
  // OFFICIAL GST PORTAL CSV IMPORTER ENGINE
  // Automatically detects GST Portal template structure and imports into TransactionInvoice[]
  // ============================================================================

  public detectDelimiter(text: string): string {
    return detectDelimiter(text);
  }

  /**
   * Auto-detects GST Portal template format based on CSV headers
   */
  public detectPortalTemplateType(
    csvContent: string,
    fileName?: string
  ): 'B2B' | 'B2CL' | 'B2CS' | 'CDNR' | 'CDNUR' | 'EXP' | 'HSN' | 'HSN_B2B' | 'HSN_B2C' | 'DOCS' | 'EXEMP' | 'GENERIC' {
    const firstLine = (csvContent.split(/\r\n|\r|\n/)[0] || '').toLowerCase();
    const cleanFileName = (fileName || '').toLowerCase();
    
    // 1. Table 4: B2B, SEZ, Deemed Exports (b2b,sez,de.csv, b2b.csv, b2ba.csv)
    if (firstLine.includes('gstin/uin of recipient') && (firstLine.includes('invoice number') || firstLine.includes('invoice value') || firstLine.includes('receiver name'))) return 'B2B';
    // 2. Table 9B: CDNR (cdnr.csv, cdnra.csv)
    if (firstLine.includes('gstin/uin of recipient') && (firstLine.includes('note number') || firstLine.includes('refund voucher number'))) return 'CDNR';
    // 3. Table 9B: CDNUR (cdnur.csv, cdnura.csv)
    if (firstLine.includes('ur type') && (firstLine.includes('note number') || firstLine.includes('refund voucher number'))) return 'CDNUR';
    // 4. Table 6A: Exports (exp.csv, expa.csv)
    if (firstLine.includes('export type') || (firstLine.includes('shipping bill') && firstLine.includes('port code'))) return 'EXP';
    // 5. Table 13: Documents Issued (docs.csv)
    if (firstLine.includes('nature of document') || (firstLine.includes('sr. no. from') && firstLine.includes('total number'))) return 'DOCS';
    // 6. Table 5: B2C Large (b2cl.csv, b2cla.csv)
    if (firstLine.includes('invoice value') && firstLine.includes('place of supply') && !firstLine.includes('gstin/uin')) return 'B2CL';
    // 7. Table 7: B2C Small (b2cs.csv, b2csa.csv)
    if (firstLine.includes('place of supply') && firstLine.includes('taxable value') && (firstLine.includes('type') || firstLine.includes('e-commerce gstin')) && !firstLine.includes('invoice number')) return 'B2CS';
    // 8. Table 12: HSN Summary (hsn.csv, hsn_b2b.csv, hsn(b2b).csv, hsn_b2c.csv, hsn(b2c).csv)
    if (firstLine.includes('hsn') && !firstLine.includes('invoice number') && !firstLine.includes('gstin/uin') && (firstLine.includes('uqc') || firstLine.includes('total quantity') || firstLine.includes('taxable value') || firstLine.includes('description'))) {
      if (cleanFileName.includes('b2c') || firstLine.includes('b2c')) return 'HSN_B2C';
      if (cleanFileName.includes('b2b') || firstLine.includes('b2b')) return 'HSN_B2B';
      return 'HSN';
    }
    // 9. Table 8: Nil / Exempt (exemp.csv)
    if (firstLine.includes('nil rated') || firstLine.includes('exempted') || firstLine.includes('non-gst')) return 'EXEMP';
    return 'GENERIC';
  }

  /**
   * Parses official GST Portal CSV files directly into TransactionInvoice records
   */
  public parsePortalCsv(
    csvContent: string,
    supplierGstin: string = '07ABFFB5922Q1Z0',
    options?: {
      fileName?: string;
      targetHsnCategory?: 'B2B' | 'B2C' | 'AUTO';
    }
  ): {
    success: boolean;
    templateType: string;
    invoices: TransactionInvoice[];
    errors: string[];
    summary: { count: number; totalTaxable: number; totalTax: number };
  } {
    const delimiter = detectDelimiter(csvContent);
    const rawTemplateType = this.detectPortalTemplateType(csvContent, options?.fileName);
    let templateType: string = rawTemplateType;
    const lines = csvContent.split(/\r\n|\r|\n/).filter(l => l.trim().length > 0);
    if (lines.length < 2) {
      return {
        success: false,
        templateType,
        invoices: [],
        errors: ['CSV file is empty or missing data rows.'],
        summary: { count: 0, totalTaxable: 0, totalTax: 0 }
      };
    }

    const header = lines[0].split(delimiter).map(h => h.trim().replace(/^["']|["']$/g, '').toLowerCase());
    const headerCols = lines[0].split(delimiter).map(h => h.trim().replace(/^["']|["']$/g, '').toLowerCase().replace(/[\s_\-\/]+/g, ''));
    const getIdx = (candidates: string[]): number => {
      for (const cand of candidates) {
        const cleanCand = cand.toLowerCase().replace(/[\s_\-\/]+/g, '');
        const idx = headerCols.indexOf(cleanCand);
        if (idx !== -1) return idx;
      }
      return -1;
    };

    const invoices: TransactionInvoice[] = [];
    const errors: string[] = [];
    let totalTaxable = 0;
    let totalTax = 0;

    const cleanSupplierGstin = (supplierGstin && supplierGstin.trim().length === 15)
      ? supplierGstin.trim()
      : '07ABFFB5922Q1Z0';
    const supplierStateCode = cleanSupplierGstin.substring(0, 2);

    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;

      // Handle quoted delimiter
      const cols: string[] = [];
      let cur = '';
      let inQuotes = false;
      for (let c = 0; c < line.length; c++) {
        const char = line[c];
        if (char === '"' || char === "'") inQuotes = !inQuotes;
        else if (char === delimiter && !inQuotes) {
          cols.push(cur.trim().replace(/^["']|["']$/g, ''));
          cur = '';
        } else {
          cur += char;
        }
      }
      cols.push(cur.trim().replace(/^["']|["']$/g, ''));

      try {
        if (rawTemplateType === 'HSN' || rawTemplateType === 'HSN_B2B' || rawTemplateType === 'HSN_B2C') {
          // Table 12 HSN Summary (hsn.csv, hsn_b2b.csv, hsn(b2b).csv, hsn_b2c.csv, hsn(b2c).csv)
          // Header: HSN,Description,UQC,Total Quantity,Total Value,Taxable Value,Integrated Tax Amount,Central Tax Amount,State/UT Tax Amount,Cess Amount,Rate
          const hIdx = getIdx(['hsn', 'hsnsc', 'hsncode', 'sac']) !== -1 ? getIdx(['hsn', 'hsnsc', 'hsncode', 'sac']) : 0;
          const dIdx = getIdx(['description', 'desc', 'userdesc', 'descriptionasperhsncode']) !== -1 ? getIdx(['description', 'desc', 'userdesc', 'descriptionasperhsncode']) : 1;
          const uIdx = getIdx(['uqc', 'unit', 'uom']) !== -1 ? getIdx(['uqc', 'unit', 'uom']) : 2;
          const qIdx = getIdx(['totalquantity', 'quantity', 'qty']) !== -1 ? getIdx(['totalquantity', 'quantity', 'qty']) : 3;
          const vIdx = getIdx(['totalvalue', 'invoicevalue', 'value', 'val']) !== -1 ? getIdx(['totalvalue', 'invoicevalue', 'value', 'val']) : 4;
          const tIdx = getIdx(['taxablevalue', 'taxableamount', 'txval']) !== -1 ? getIdx(['taxablevalue', 'taxableamount', 'txval']) : 5;
          const iIdx = getIdx(['integratedtaxamount', 'integratedtax', 'igst', 'iamt']) !== -1 ? getIdx(['integratedtaxamount', 'integratedtax', 'igst', 'iamt']) : 6;
          const cIdx = getIdx(['centraltaxamount', 'centraltax', 'cgst', 'camt']) !== -1 ? getIdx(['centraltaxamount', 'centraltax', 'cgst', 'camt']) : 7;
          const sIdx = getIdx(['stateuttaxamount', 'statetaxamount', 'statetax', 'sgst', 'samt']) !== -1 ? getIdx(['stateuttaxamount', 'statetaxamount', 'statetax', 'sgst', 'samt']) : 8;
          const csIdx = getIdx(['cessamount', 'cess', 'csamt']) !== -1 ? getIdx(['cessamount', 'cess', 'csamt']) : 9;
          const rIdx = getIdx(['rate', 'gstrate', 'taxrate', 'rt']) !== -1 ? getIdx(['rate', 'gstrate', 'taxrate', 'rt']) : 10;

          const hsnCode = String(cols[hIdx] || '998313').trim();
          const desc = String(cols[dIdx] || 'Outward Taxable Supply').trim();
          const rawUqc = String(cols[uIdx] || 'OTH-OTHERS').trim();
          const isService = hsnCode.startsWith('99');
          const cleanUqc = isService ? 'NA' : rawUqc.split('-')[0].trim();
          const qty = isService ? 0 : (parseFloat(cols[qIdx]?.replace(/,/g, '') || '0') || 0);
          const totalVal = parseFloat(cols[vIdx]?.replace(/,/g, '') || '0') || 0;
          const txval = parseFloat(cols[tIdx]?.replace(/,/g, '') || '0') || 0;
          const iamt = parseFloat(cols[iIdx]?.replace(/,/g, '') || '0') || 0;
          const camt = parseFloat(cols[cIdx]?.replace(/,/g, '') || '0') || 0;
          const samt = parseFloat(cols[sIdx]?.replace(/,/g, '') || '0') || 0;
          const cess = parseFloat(cols[csIdx]?.replace(/,/g, '') || '0') || 0;
          const rate = parseFloat(cols[rIdx]?.replace(/,/g, '') || '18') || 18;

          if (txval <= 0 && totalVal <= 0) continue;

          const isInter = iamt > 0;
          const pos = isInter ? '27' : supplierStateCode;

          // Determine HSN category: B2B vs B2C
          // 1. Check Row-Level Classification/Category Column FIRST!
          let rowCategory: 'B2B' | 'B2C' | null = null;
          const catIdx = getIdx([
            'classification', 'category', 'type', 'recipienttype', 'supplytype',
            'splyty', 'b2b_b2c', 'b2bb2c', 'nature', 'section', 'table', 'target',
            'supply', 'partytype', 'customertype', 'buyertype', 'gsttype'
          ]);

          if (catIdx !== -1 && cols[catIdx]) {
            const catVal = cols[catIdx].toLowerCase().trim();
            if (
              catVal.includes('b2c') ||
              catVal.includes('b2cs') ||
              catVal.includes('b2cl') ||
              catVal.includes('unregistered') ||
              catVal.includes('consumer') ||
              catVal.includes('retail') ||
              catVal.includes('urp')
            ) {
              rowCategory = 'B2C';
            } else if (
              catVal.includes('b2b') ||
              catVal.includes('registered') ||
              catVal.includes('sez') ||
              catVal.includes('deemed') ||
              catVal.includes('wholesale')
            ) {
              rowCategory = 'B2B';
            }
          }

          // Also scan any extra columns (beyond standard 10 columns) if rowCategory still not resolved
          if (!rowCategory && cols.length > 10) {
            for (let c = 10; c < cols.length; c++) {
              const val = (cols[c] || '').toLowerCase().trim();
              if (
                val.includes('b2c') ||
                val.includes('b2cs') ||
                val.includes('b2cl') ||
                val.includes('consumer') ||
                val.includes('unregistered')
              ) {
                rowCategory = 'B2C';
                break;
              } else if (
                val.includes('b2b') ||
                val.includes('registered') ||
                val.includes('sez') ||
                val.includes('deemed')
              ) {
                rowCategory = 'B2B';
                break;
              }
            }
          }

          // 2. Decide final category: row-level category takes highest priority
          let isB2c = false;
          if (rowCategory === 'B2C') {
            isB2c = true;
          } else if (rowCategory === 'B2B') {
            isB2c = false;
          } else if (options?.targetHsnCategory === 'B2C') {
            isB2c = true;
          } else if (options?.targetHsnCategory === 'B2B') {
            isB2c = false;
          } else if (rawTemplateType === 'HSN_B2C') {
            isB2c = true;
          } else if (rawTemplateType === 'HSN_B2B') {
            isB2c = false;
          } else {
            const fileNameLower = (options?.fileName || '').toLowerCase();
            if (fileNameLower.includes('b2c')) {
              isB2c = true;
            } else if (fileNameLower.includes('b2b')) {
              isB2c = false;
            } else if (header.some(h => h.includes('b2c'))) {
              isB2c = true;
            } else {
              isB2c = false;
            }
          }
          const isB2b = !isB2c;

          const inv: TransactionInvoice = {
            id: `PORTAL-HSN-${isB2b ? 'B2B' : 'B2C'}-${Date.now()}-${i}`,
            invoiceNumber: '', // Empty: Table 12 HSN Summary has NO invoice number!
            invoiceDate: '2026-10-15',
            documentType: 'INVOICE',
            supplyType: isInter ? 'INTER_STATE' : 'INTRA_STATE',
            classification: isB2b ? 'B2B' : 'B2C_SMALL',
            taxTreatment: 'TAXABLE',
            supplierGstin: cleanSupplierGstin,
            supplierName: 'Taxpayer Entity',
            supplierState: 'Delhi',
            supplierStateCode: supplierStateCode,
            recipientGstin: isB2b ? `${supplierStateCode}AAAAA0000A1Z5` : 'URP',
            recipientName: isB2b ? 'Registered Recipient (HSN B2B Summary)' : 'Unregistered Consumer (HSN B2C Summary)',
            recipientState: 'State',
            recipientStateCode: pos,
            placeOfSupply: pos,
            placeOfSupplyCode: pos,
            taxableValue: txval,
            gstRate: rate,
            cgst: camt,
            sgst: samt,
            igst: iamt,
            cess,
            totalAmount: totalVal || (txval + camt + samt + iamt + cess),
            rcm: false,
            ecommerce: false,
            itcStatus: 'INELIGIBLE',
            itcEligibleAmount: 0,
            itcIneligibleAmount: 0,
            confidence: 1.0,
            reviewRequired: false,
            hsnSacPrimary: hsnCode,
            descriptionPrimary: desc,
            notes: `Imported from GST Portal ${isB2b ? 'Table 12 HSN (B2B)' : 'Table 12 HSN (B2C)'} Template (${hsnCode}, Rate: ${rate}%, UQC: ${cleanUqc})`
          };
          (inv as any).isHsnSummary = true;
          (inv as any).hsnCategory = isB2b ? 'B2B' : 'B2C';
          (inv as any).uqc = cleanUqc;
          (inv as any).totalQuantity = qty;

          invoices.push(inv);
          totalTaxable = round2(totalTaxable + txval);
          totalTax = round2(totalTax + camt + samt + iamt + cess);
        } else if (templateType === 'DOCS') {
          // Table 13 Documents Issued (docs.csv)
          // Header: Nature of Document,Sr. No. From,Sr. No. To,Total Number,Cancelled
          const natIdx = getIdx(['natureofdocument', 'nature', 'doctype']) !== -1 ? getIdx(['natureofdocument', 'nature', 'doctype']) : 0;
          const fromIdx = getIdx(['srnofrom', 'from', 'serialfrom', 'fromserial']) !== -1 ? getIdx(['srnofrom', 'from', 'serialfrom', 'fromserial']) : 1;
          const toIdx = getIdx(['srnoto', 'to', 'serialto', 'toserial']) !== -1 ? getIdx(['srnoto', 'to', 'serialto', 'toserial']) : 2;
          const totIdx = getIdx(['totalnumber', 'totnum', 'total', 'count']) !== -1 ? getIdx(['totalnumber', 'totnum', 'total', 'count']) : 3;
          const canIdx = getIdx(['cancelled', 'cancel', 'canc']) !== -1 ? getIdx(['cancelled', 'cancel', 'canc']) : 4;

          const docNature = String(cols[natIdx] || 'Invoices for outward supply').trim();
          const fromSerial = String(cols[fromIdx] || '').trim();
          const toSerial = String(cols[toIdx] || fromSerial).trim();
          const totNum = parseInt(cols[totIdx]?.replace(/,/g, '') || '0', 10) || 0;
          const cancelled = parseInt(cols[canIdx]?.replace(/,/g, '') || '0', 10) || 0;

          // Skip empty template placeholder rows where both serial and total are blank/zero
          if (!fromSerial && totNum === 0) continue;

          const isCN = docNature.toLowerCase().includes('credit');
          const isDN = docNature.toLowerCase().includes('debit');

          const inv: TransactionInvoice = {
            id: `PORTAL-DOC-${Date.now()}-${i}`,
            invoiceNumber: fromSerial && toSerial && fromSerial !== toSerial ? `${fromSerial} - ${toSerial}` : (fromSerial || `DOC-${i}`),
            invoiceDate: '2026-10-15',
            documentType: isCN ? 'CREDIT_NOTE' : isDN ? 'DEBIT_NOTE' : 'INVOICE',
            supplyType: 'INTRA_STATE',
            classification: 'B2C_SMALL',
            taxTreatment: 'TAXABLE',
            supplierGstin: cleanSupplierGstin,
            supplierName: 'Taxpayer Entity',
            supplierState: 'Delhi',
            supplierStateCode: supplierStateCode,
            recipientGstin: 'URP',
            recipientName: docNature,
            recipientState: 'Delhi',
            recipientStateCode: supplierStateCode,
            placeOfSupply: supplierStateCode,
            placeOfSupplyCode: supplierStateCode,
            taxableValue: 0,
            gstRate: 0,
            cgst: 0,
            sgst: 0,
            igst: 0,
            cess: 0,
            totalAmount: 0,
            rcm: false,
            ecommerce: false,
            itcStatus: 'INELIGIBLE',
            itcEligibleAmount: 0,
            itcIneligibleAmount: 0,
            confidence: 1.0,
            reviewRequired: false,
            hsnSacPrimary: '998313',
            descriptionPrimary: docNature,
            notes: `GST Portal Docs Summary: ${docNature} (From: ${fromSerial} To: ${toSerial}, Total: ${totNum}, Cancelled: ${cancelled})`
          };
          (inv as any).isDocSummary = true;
          (inv as any).docNature = docNature;
          (inv as any).fromSerial = fromSerial;
          (inv as any).toSerial = toSerial;
          (inv as any).totalNumber = totNum;
          (inv as any).cancelled = cancelled;
          (inv as any).netIssued = Math.max(0, totNum - cancelled);

          invoices.push(inv);
        } else if (templateType === 'B2B') {
          // Table 4: B2B, SEZ, DE (b2b,sez,de.csv, b2b.csv)
          // Header: GSTIN/UIN of Recipient,Receiver Name,Invoice Number,Invoice date,Invoice Value,Place Of Supply,Reverse Charge,Applicable % of Tax Rate,Invoice Type,E-Commerce GSTIN,Rate,Taxable Value,Cess Amount
          const ctinIdx = getIdx(['gstinuinofrecipient', 'recipientgstin', 'ctin', 'customergstin', 'buyergstin']) !== -1 ? getIdx(['gstinuinofrecipient', 'recipientgstin', 'ctin', 'customergstin', 'buyergstin']) : 0;
          const rNameIdx = getIdx(['receivername', 'recipientname', 'partyname', 'customername', 'buyername']) !== -1 ? getIdx(['receivername', 'recipientname', 'partyname', 'customername', 'buyername']) : 1;
          const invNumIdx = getIdx(['invoicenumber', 'invoiceno', 'invno', 'billno', 'invoicenum']) !== -1 ? getIdx(['invoicenumber', 'invoiceno', 'invno', 'billno', 'invoicenum']) : 2;
          const invDtIdx = getIdx(['invoicedate', 'date', 'invdate', 'billdate']) !== -1 ? getIdx(['invoicedate', 'date', 'invdate', 'billdate']) : 3;
          const invValIdx = getIdx(['invoicevalue', 'totalvalue', 'totalamount', 'grandtotal', 'val']) !== -1 ? getIdx(['invoicevalue', 'totalvalue', 'totalamount', 'grandtotal', 'val']) : 4;
          const posIdx = getIdx(['placeofsupply', 'pos', 'poscode', 'statecode']) !== -1 ? getIdx(['placeofsupply', 'pos', 'poscode', 'statecode']) : 5;
          const rchrgIdx = getIdx(['reversecharge', 'rchrg', 'rcm']) !== -1 ? getIdx(['reversecharge', 'rchrg', 'rcm']) : 6;
          const invTypIdx = getIdx(['invoicetype', 'invtyp', 'type']) !== -1 ? getIdx(['invoicetype', 'invtyp', 'type']) : 8;
          const rateIdx = getIdx(['rate', 'rt', 'gstrate', 'taxrate']) !== -1 ? getIdx(['rate', 'rt', 'gstrate', 'taxrate']) : 10;
          const txvalIdx = getIdx(['taxablevalue', 'taxableamount', 'taxable', 'txval', 'amount']) !== -1 ? getIdx(['taxablevalue', 'taxableamount', 'taxable', 'txval', 'amount']) : 11;
          const cessIdx = getIdx(['cessamount', 'cess', 'csamt']) !== -1 ? getIdx(['cessamount', 'cess', 'csamt']) : 12;

          // Also check for explicit CGST, SGST, IGST columns if present in file
          const cgstIdx = getIdx(['centraltaxamount', 'centraltax', 'cgstamount', 'cgst', 'camt', 'cgstamt']);
          const sgstIdx = getIdx(['stateuttaxamount', 'statetaxamount', 'statetax', 'sgstamount', 'sgst', 'samt', 'utgst', 'sgstamt']);
          const igstIdx = getIdx(['integratedtaxamount', 'integratedtax', 'igstamount', 'igst', 'iamt', 'igstamt']);

          // Also check for item-level HSN, description, UQC, quantity if present in accounting CSV
          const hsnIdx = getIdx(['hsn', 'hsnsac', 'hsncode', 'sac', 'itemhsn', 'itemcode', 'servicecode', 'productcode']);
          const descIdx = getIdx(['description', 'itemname', 'particulars', 'desc', 'productdescription', 'itemdesc']);
          const uqcIdx = getIdx(['uqc', 'unit', 'uom', 'unitquantitycode']);
          const qtyIdx = getIdx(['quantity', 'qty', 'totalquantity', 'itemqty', 'pieces']);

          const ctin = cols[ctinIdx] || '07AAAAA0000A1Z5';
          const rName = cols[rNameIdx] || 'Registered Recipient';
          const invNum = cols[invNumIdx] || `INV-B2B-${i}`;
          const invDate = parseGstPortalDate(cols[invDtIdx]);
          const invVal = parseFloat(cols[invValIdx]?.replace(/,/g, '') || '0') || 0;
          const pos = extractPosCode(cols[posIdx], ctin, supplierStateCode);
          const rchrg = (cols[rchrgIdx] || 'N').toUpperCase() === 'Y';
          const invTypStr = cols[invTypIdx] || 'Regular B2B';
          const rate = parseFloat(cols[rateIdx]?.replace(/,/g, '') || '18') || 18;
          const txval = parseFloat(cols[txvalIdx]?.replace(/,/g, '') || '0') || 0;
          const cess = parseFloat(cols[cessIdx]?.replace(/,/g, '') || '0') || 0;

          const userHsn = hsnIdx !== -1 && cols[hsnIdx] ? cols[hsnIdx].trim() : '';
          const userDesc = descIdx !== -1 && cols[descIdx] ? cols[descIdx].trim() : '';
          const userUqc = uqcIdx !== -1 && cols[uqcIdx] ? cols[uqcIdx].trim() : '';
          const userQty = qtyIdx !== -1 && cols[qtyIdx] ? (parseFloat(cols[qtyIdx].replace(/,/g, '')) || 0) : 0;

          const rawCgst = cgstIdx !== -1 && cols[cgstIdx] ? parseFloat(cols[cgstIdx].replace(/,/g, '')) : undefined;
          const rawSgst = sgstIdx !== -1 && cols[sgstIdx] ? parseFloat(cols[sgstIdx].replace(/,/g, '')) : undefined;
          const rawIgst = igstIdx !== -1 && cols[igstIdx] ? parseFloat(cols[igstIdx].replace(/,/g, '')) : undefined;

          let isInter = pos !== supplierStateCode;
          let finalCgst = 0;
          let finalSgst = 0;
          let finalIgst = 0;

          // Priority 1: If file has explicit CGST/SGST amounts, preserve them as INTRA-STATE!
          if ((rawCgst !== undefined && rawCgst > 0) || (rawSgst !== undefined && rawSgst > 0)) {
            isInter = false;
            finalCgst = Number(round2(rawCgst || 0));
            finalSgst = Number(round2(rawSgst || 0));
            finalIgst = 0;
          } else if (rawIgst !== undefined && rawIgst > 0 && (!rawCgst || rawCgst === 0) && (!rawSgst || rawSgst === 0)) {
            isInter = true;
            finalIgst = Number(round2(rawIgst));
            finalCgst = 0;
            finalSgst = 0;
          } else {
            // Priority 2: Deterministic calculation based on POS vs Supplier State
            const taxCalc = calculateDeterministicTax(txval, rate, isInter, rchrg, 0);
            finalCgst = taxCalc.cgst;
            finalSgst = taxCalc.sgst;
            finalIgst = taxCalc.igst;
          }

          let classification: GSTClassification = 'B2B';
          if (invTypStr.toLowerCase().includes('deemed')) classification = 'DEEMED_EXPORT';
          else if (invTypStr.toLowerCase().includes('without payment')) classification = 'SEZ_WITHOUT_PAYMENT';
          else if (invTypStr.toLowerCase().includes('sez')) classification = 'SEZ_WITH_PAYMENT';

          const totalInvTax = round2(finalCgst + finalSgst + finalIgst + cess);
          const totalAmount = invVal || round2(txval + totalInvTax);
          const posStateName = GST_PORTAL_STATE_MAP[pos] || `${pos}-State`;
          const supplierStateName = GST_PORTAL_STATE_MAP[supplierStateCode]?.split('-')[1] || 'Delhi';

          const inv: TransactionInvoice = {
            id: `PORTAL-B2B-${Date.now()}-${i}`,
            invoiceNumber: invNum,
            invoiceDate: invDate,
            documentType: 'INVOICE',
            supplyType: isInter ? 'INTER_STATE' : 'INTRA_STATE',
            classification,
            taxTreatment: 'TAXABLE',
            supplierGstin: cleanSupplierGstin,
            supplierName: 'Taxpayer Entity',
            supplierState: supplierStateName,
            supplierStateCode: supplierStateCode,
            recipientGstin: ctin,
            recipientName: rName,
            recipientState: posStateName.split('-')[1] || 'State',
            recipientStateCode: pos,
            placeOfSupply: posStateName,
            placeOfSupplyCode: pos,
            taxableValue: txval,
            gstRate: rate,
            cgst: finalCgst,
            sgst: finalSgst,
            igst: finalIgst,
            cess,
            totalAmount,
            rcm: rchrg,
            ecommerce: false,
            itcStatus: 'ELIGIBLE',
            itcEligibleAmount: 0,
            itcIneligibleAmount: 0,
            confidence: 1.0,
            reviewRequired: false,
            hsnSacPrimary: userHsn || '998313',
            descriptionPrimary: userDesc || `${invTypStr} Outward Supply`,
            notes: `Imported from Official GST Portal B2B CSV (${invNum})`
          };
          if (userUqc) (inv as any).uqc = userUqc;
          if (userQty) (inv as any).totalQuantity = userQty;

          invoices.push(inv);
          totalTaxable = round2(totalTaxable + txval);
          totalTax = round2(totalTax + totalInvTax);
        } else if (templateType === 'B2CL') {
          // Table 5: B2C Large (b2cl.csv)
          // Header: Invoice Number,Invoice date,Invoice Value,Place Of Supply,Applicable % of Tax Rate,Rate,Taxable Value,Cess Amount,E-Commerce GSTIN
          const numIdx = getIdx(['invoicenumber', 'invoiceno', 'invno']) !== -1 ? getIdx(['invoicenumber', 'invoiceno', 'invno']) : 0;
          const dtIdx = getIdx(['invoicedate', 'date', 'invdate']) !== -1 ? getIdx(['invoicedate', 'date', 'invdate']) : 1;
          const valIdx = getIdx(['invoicevalue', 'totalvalue', 'val']) !== -1 ? getIdx(['invoicevalue', 'totalvalue', 'val']) : 2;
          const posIdx = getIdx(['placeofsupply', 'pos']) !== -1 ? getIdx(['placeofsupply', 'pos']) : 3;
          const rateIdx = getIdx(['rate', 'rt', 'gstrate']) !== -1 ? getIdx(['rate', 'rt', 'gstrate']) : 5;
          const txvalIdx = getIdx(['taxablevalue', 'taxableamount', 'txval']) !== -1 ? getIdx(['taxablevalue', 'taxableamount', 'txval']) : 6;
          const cessIdx = getIdx(['cessamount', 'cess']) !== -1 ? getIdx(['cessamount', 'cess']) : 7;
          const ecoIdx = getIdx(['ecommercegstin', 'ecogstin']) !== -1 ? getIdx(['ecommercegstin', 'ecogstin']) : 8;

          const invNum = cols[numIdx] || `INV-B2CL-${i}`;
          const invDate = parseGstPortalDate(cols[dtIdx]);
          const invVal = parseFloat(cols[valIdx]?.replace(/,/g, '') || '0') || 0;
          const pos = extractPosCode(cols[posIdx], undefined, supplierStateCode);
          const rate = parseFloat(cols[rateIdx]?.replace(/,/g, '') || '18') || 18;
          const txval = parseFloat(cols[txvalIdx]?.replace(/,/g, '') || '0') || 0;
          const cess = parseFloat(cols[cessIdx]?.replace(/,/g, '') || '0') || 0;

          const igst = round2((txval * rate) / 100);

          const inv: TransactionInvoice = {
            id: `PORTAL-B2CL-${Date.now()}-${i}`,
            invoiceNumber: invNum,
            invoiceDate: invDate,
            documentType: 'INVOICE',
            supplyType: 'INTER_STATE',
            classification: 'B2C_LARGE',
            taxTreatment: 'TAXABLE',
            supplierGstin: cleanSupplierGstin,
            supplierName: 'Taxpayer Entity',
            supplierState: 'Delhi',
            supplierStateCode: supplierStateCode,
            recipientGstin: 'URP',
            recipientName: 'Unregistered Consumer (Large)',
            recipientState: 'State',
            recipientStateCode: pos,
            placeOfSupply: pos,
            placeOfSupplyCode: pos,
            taxableValue: txval,
            gstRate: rate,
            cgst: 0,
            sgst: 0,
            igst,
            cess,
            totalAmount: invVal || (txval + igst + cess),
            rcm: false,
            ecommerce: Boolean(cols[ecoIdx]),
            itcStatus: 'INELIGIBLE',
            itcEligibleAmount: 0,
            itcIneligibleAmount: 0,
            confidence: 1.0,
            reviewRequired: false,
            hsnSacPrimary: '847130',
            descriptionPrimary: 'B2C Large Outward Supply',
            notes: `Imported from GST Portal B2CL CSV (${invNum}, POS: ${pos})`
          };

          invoices.push(inv);
          totalTaxable = round2(totalTaxable + txval);
          totalTax = round2(totalTax + igst + cess);
        } else if (templateType === 'B2CS') {
          // Table 7: B2C Small (b2cs.csv)
          // Header: Type,Place Of Supply,Rate,Applicable % of Tax Rate,Taxable Value,Cess Amount,E-Commerce GSTIN
          const typIdx = getIdx(['type', 'splyty', 'supplytype']) !== -1 ? getIdx(['type', 'splyty', 'supplytype']) : 0;
          const posIdx = getIdx(['placeofsupply', 'pos', 'statecode']) !== -1 ? getIdx(['placeofsupply', 'pos', 'statecode']) : 1;
          const rateIdx = getIdx(['rate', 'rt', 'gstrate']) !== -1 ? getIdx(['rate', 'rt', 'gstrate']) : 2;
          const txvalIdx = getIdx(['taxablevalue', 'taxableamount', 'txval']) !== -1 ? getIdx(['taxablevalue', 'taxableamount', 'txval']) : 4;
          const cessIdx = getIdx(['cessamount', 'cess', 'csamt']) !== -1 ? getIdx(['cessamount', 'cess', 'csamt']) : 5;
          const ecoIdx = getIdx(['ecommercegstin', 'ecogstin', 'etin']) !== -1 ? getIdx(['ecommercegstin', 'ecogstin', 'etin']) : 6;

          const rawType = String(cols[typIdx] || 'OE').trim().toUpperCase();
          const pos = extractPosCode(cols[posIdx], undefined, supplierStateCode);
          const rate = parseFloat(cols[rateIdx]?.replace(/,/g, '') || '18') || 18;
          const txval = parseFloat(cols[txvalIdx]?.replace(/,/g, '') || '0') || 0;
          const cess = parseFloat(cols[cessIdx]?.replace(/,/g, '') || '0') || 0;
          const ecoGstin = String(cols[ecoIdx] || '').trim();

          const isInter = pos !== supplierStateCode;
          const taxCalc = calculateDeterministicTax(Math.abs(txval), rate, isInter, false, 0);

          const hsnIdx = getIdx(['hsn', 'hsnsac', 'hsncode', 'sac', 'itemhsn', 'itemcode']);
          const userHsn = hsnIdx !== -1 && cols[hsnIdx] ? cols[hsnIdx].trim() : '998313';

          const inv: TransactionInvoice = {
            id: `PORTAL-B2CS-${Date.now()}-${i}`,
            invoiceNumber: '', // Empty: Table 7 B2CS is a consolidated summary without invoice numbers
            invoiceDate: '2026-10-15',
            documentType: txval < 0 ? 'CREDIT_NOTE' : 'INVOICE',
            supplyType: isInter ? 'INTER_STATE' : 'INTRA_STATE',
            classification: 'B2C_SMALL',
            taxTreatment: 'TAXABLE',
            supplierGstin: cleanSupplierGstin,
            supplierName: 'Taxpayer Entity',
            supplierState: 'Delhi',
            supplierStateCode: supplierStateCode,
            recipientGstin: 'URP',
            recipientName: 'Unregistered Consumer (B2C Small)',
            recipientState: 'State',
            recipientStateCode: pos,
            placeOfSupply: pos,
            placeOfSupplyCode: pos,
            taxableValue: Math.abs(txval),
            gstRate: rate,
            cgst: taxCalc.cgst,
            sgst: taxCalc.sgst,
            igst: taxCalc.igst,
            cess,
            totalAmount: Math.abs(txval) + taxCalc.totalTax + cess,
            rcm: false,
            ecommerce: rawType === 'E' || Boolean(ecoGstin),
            itcStatus: 'INELIGIBLE',
            itcEligibleAmount: 0,
            itcIneligibleAmount: 0,
            confidence: 1.0,
            reviewRequired: false,
            hsnSacPrimary: userHsn,
            descriptionPrimary: 'B2C Small Consolidated Supply',
            notes: `Imported from GST Portal B2CS CSV (Type: ${rawType}, POS: ${pos}, Rate: ${rate}%)`
          };
          (inv as any).isB2csSummary = true;

          invoices.push(inv);
          totalTaxable = round2(totalTaxable + Math.abs(txval));
          totalTax = round2(totalTax + taxCalc.totalTax + cess);
        } else if (templateType === 'CDNR') {
          // Table 9B: CDNR (cdnr.csv)
          const ctin = cols[0] || '07AAAAA0000A1Z5';
          const rName = cols[1] || 'Registered Recipient';
          const noteNum = cols[2] || `CN-${i}`;
          const noteDate = parseGstPortalDate(cols[3]);
          const noteType = (cols[4] || 'C').toUpperCase();
          const pos = extractPosCode(cols[5], ctin, supplierStateCode);
          const rchrg = (cols[6] || 'N').toUpperCase() === 'Y';
          const noteVal = parseFloat(cols[8]?.replace(/,/g, '') || '0') || 0;
          const rate = parseFloat(cols[10]?.replace(/,/g, '') || '18') || 18;
          const txval = parseFloat(cols[11]?.replace(/,/g, '') || '0') || 0;
          const cess = parseFloat(cols[12]?.replace(/,/g, '') || '0') || 0;

          const isInter = pos !== supplierStateCode;
          const taxCalc = calculateDeterministicTax(txval, rate, isInter, rchrg, 0);

          const inv: TransactionInvoice = {
            id: `PORTAL-CDNR-${Date.now()}-${i}`,
            invoiceNumber: noteNum,
            invoiceDate: noteDate,
            documentType: noteType === 'D' ? 'DEBIT_NOTE' : 'CREDIT_NOTE',
            supplyType: isInter ? 'INTER_STATE' : 'INTRA_STATE',
            classification: 'B2B',
            taxTreatment: 'TAXABLE',
            supplierGstin: cleanSupplierGstin,
            supplierName: 'Taxpayer Entity',
            supplierState: 'Delhi',
            supplierStateCode: supplierStateCode,
            recipientGstin: ctin,
            recipientName: rName,
            recipientState: 'State',
            recipientStateCode: pos,
            placeOfSupply: pos,
            placeOfSupplyCode: pos,
            taxableValue: txval,
            gstRate: rate,
            cgst: taxCalc.cgst,
            sgst: taxCalc.sgst,
            igst: taxCalc.igst,
            cess,
            totalAmount: noteVal || (txval + taxCalc.totalTax + cess),
            rcm: rchrg,
            ecommerce: false,
            itcStatus: 'ELIGIBLE',
            itcEligibleAmount: 0,
            itcIneligibleAmount: 0,
            confidence: 1.0,
            reviewRequired: false,
            hsnSacPrimary: '998313',
            descriptionPrimary: `${noteType === 'D' ? 'Debit' : 'Credit'} Note Adjustment`,
            notes: `Imported from Official GST Portal CDNR CSV (${noteNum})`
          };

          invoices.push(inv);
          totalTaxable = round2(totalTaxable + txval);
          totalTax = round2(totalTax + taxCalc.totalTax + cess);
        } else if (templateType === 'CDNUR') {
          // Table 9B: CDNUR (cdnur.csv)
          const noteNum = cols[1] || `CNUR-${i}`;
          const noteDate = parseGstPortalDate(cols[2]);
          const docType = (cols[3] || 'C').toUpperCase();
          const pos = extractPosCode(cols[7], undefined, supplierStateCode);
          const noteVal = parseFloat(cols[8]?.replace(/,/g, '') || '0') || 0;
          const rate = parseFloat(cols[10]?.replace(/,/g, '') || '18') || 18;
          const txval = parseFloat(cols[11]?.replace(/,/g, '') || '0') || 0;
          const cess = parseFloat(cols[12]?.replace(/,/g, '') || '0') || 0;

          const isInter = pos !== supplierStateCode;
          const taxCalc = calculateDeterministicTax(txval, rate, isInter, false, 0);

          const inv: TransactionInvoice = {
            id: `PORTAL-CDNUR-${Date.now()}-${i}`,
            invoiceNumber: noteNum,
            invoiceDate: noteDate,
            documentType: docType === 'D' ? 'DEBIT_NOTE' : 'CREDIT_NOTE',
            supplyType: isInter ? 'INTER_STATE' : 'INTRA_STATE',
            classification: 'B2C_LARGE',
            taxTreatment: 'TAXABLE',
            supplierGstin: cleanSupplierGstin,
            supplierName: 'Taxpayer Entity',
            supplierState: 'Delhi',
            supplierStateCode: supplierStateCode,
            recipientGstin: 'URP',
            recipientName: 'Unregistered Person',
            recipientState: 'State',
            recipientStateCode: pos,
            placeOfSupply: pos,
            placeOfSupplyCode: pos,
            taxableValue: txval,
            gstRate: rate,
            cgst: taxCalc.cgst,
            sgst: taxCalc.sgst,
            igst: taxCalc.igst,
            cess,
            totalAmount: noteVal || (txval + taxCalc.totalTax + cess),
            rcm: false,
            ecommerce: false,
            itcStatus: 'INELIGIBLE',
            itcEligibleAmount: 0,
            itcIneligibleAmount: 0,
            confidence: 1.0,
            reviewRequired: false,
            hsnSacPrimary: '998313',
            descriptionPrimary: `${docType === 'D' ? 'Debit' : 'Credit'} Note (Unregistered)`,
            notes: `Imported from GST Portal CDNUR CSV (${noteNum})`
          };

          invoices.push(inv);
          totalTaxable = round2(totalTaxable + txval);
          totalTax = round2(totalTax + taxCalc.totalTax + cess);
        } else if (templateType === 'EXP') {
          // Table 6A: Exports (exp.csv)
          const expType = cols[0] || 'WPAY';
          const invNum = cols[1] || `EXP-${i}`;
          const invDate = parseGstPortalDate(cols[2]);
          const invVal = parseFloat(cols[3]?.replace(/,/g, '') || '0') || 0;
          const portCode = cols[4] || 'INB995';
          const sbNum = cols[5] || '184298';
          const sbDate = parseGstPortalDate(cols[6]);
          const rate = parseFloat(cols[7]?.replace(/,/g, '') || '0') || 0;
          const txval = parseFloat(cols[8]?.replace(/,/g, '') || '0') || 0;
          const cess = parseFloat(cols[9]?.replace(/,/g, '') || '0') || 0;

          const isWithPay = expType.toUpperCase() === 'WPAY';
          const igst = isWithPay ? round2(txval * (rate / 100)) : 0;

          const inv: TransactionInvoice = {
            id: `PORTAL-EXP-${Date.now()}-${i}`,
            invoiceNumber: invNum,
            invoiceDate: invDate,
            documentType: 'INVOICE',
            supplyType: 'INTER_STATE',
            classification: isWithPay ? 'EXPORT_WITH_PAYMENT' : 'EXPORT_WITHOUT_PAYMENT',
            taxTreatment: 'ZERO_RATED',
            supplierGstin: cleanSupplierGstin,
            supplierName: 'Taxpayer Entity',
            supplierState: 'Delhi',
            supplierStateCode: supplierStateCode,
            recipientGstin: 'OVERSEAS',
            recipientName: 'Foreign Overseas Buyer',
            recipientState: 'Other Territory',
            recipientStateCode: '97',
            placeOfSupply: '97',
            placeOfSupplyCode: '97',
            taxableValue: txval,
            gstRate: rate,
            cgst: 0,
            sgst: 0,
            igst,
            cess,
            totalAmount: invVal || (txval + igst + cess),
            rcm: false,
            ecommerce: false,
            itcStatus: 'ELIGIBLE',
            itcEligibleAmount: 0,
            itcIneligibleAmount: 0,
            confidence: 1.0,
            reviewRequired: false,
            portCode,
            shippingBillNumber: sbNum,
            shippingBillDate: sbDate,
            hsnSacPrimary: '998313',
            descriptionPrimary: `Export of Goods/Services (${expType})`,
            notes: `Imported from Official GST Portal EXP CSV (${invNum})`
          };

          invoices.push(inv);
          totalTaxable = round2(totalTaxable + txval);
          totalTax = round2(totalTax + igst + cess);
        } else {
          // Fallback generic parsing for B2CL/B2CS
          const invNum = cols[0] || `PORTAL-INV-${i}`;
          const invDate = parseGstPortalDate(cols[1]);
          const invVal = parseFloat(cols[2]?.replace(/,/g, '') || '0') || 0;
          const pos = extractPosCode(cols[3]);
          const rate = parseFloat(cols[5]?.replace(/,/g, '') || '18') || 18;
          const txval = parseFloat(cols[6]?.replace(/,/g, '') || '0') || 0;
          const cess = parseFloat(cols[7]?.replace(/,/g, '') || '0') || 0;

          const isInter = pos !== supplierStateCode;
          const taxCalc = calculateDeterministicTax(txval, rate, isInter, false, 0);

          const inv: TransactionInvoice = {
            id: `PORTAL-GEN-${Date.now()}-${i}`,
            invoiceNumber: invNum,
            invoiceDate: invDate,
            documentType: 'INVOICE',
            supplyType: isInter ? 'INTER_STATE' : 'INTRA_STATE',
            classification: txval > 250000 && isInter ? 'B2C_LARGE' : 'B2C_SMALL',
            taxTreatment: 'TAXABLE',
            supplierGstin: cleanSupplierGstin,
            supplierName: 'Taxpayer Entity',
            supplierState: 'Delhi',
            supplierStateCode: supplierStateCode,
            recipientGstin: 'URP',
            recipientName: 'Unregistered Consumer',
            recipientState: 'State',
            recipientStateCode: pos,
            placeOfSupply: pos,
            placeOfSupplyCode: pos,
            taxableValue: txval,
            gstRate: rate,
            cgst: taxCalc.cgst,
            sgst: taxCalc.sgst,
            igst: taxCalc.igst,
            cess,
            totalAmount: invVal || (txval + taxCalc.totalTax + cess),
            rcm: false,
            ecommerce: false,
            itcStatus: 'INELIGIBLE',
            itcEligibleAmount: 0,
            itcIneligibleAmount: 0,
            confidence: 1.0,
            reviewRequired: false,
            hsnSacPrimary: '847130',
            descriptionPrimary: 'Consumer Supply',
            notes: 'Imported from Official GST Portal CSV'
          };

          invoices.push(inv);
          totalTaxable = round2(totalTaxable + txval);
          totalTax = round2(totalTax + taxCalc.totalTax + cess);
        }
      } catch (err: any) {
        errors.push(`Row ${i + 1}: ${err.message || 'Parsing error'}`);
      }
    }

    if (rawTemplateType.startsWith('HSN')) {
      const hasB2bHsn = invoices.some(inv => (inv as any).isHsnSummary && (inv as any).hsnCategory === 'B2B');
      const hasB2cHsn = invoices.some(inv => (inv as any).isHsnSummary && (inv as any).hsnCategory === 'B2C');

      if (hasB2bHsn && hasB2cHsn) {
        templateType = 'HSN (B2B & B2C)';
      } else if (hasB2bHsn) {
        templateType = 'HSN (B2B)';
      } else if (hasB2cHsn) {
        templateType = 'HSN (B2C)';
      }
    }

    return {
      success: invoices.length > 0,
      templateType,
      invoices,
      errors,
      summary: {
        count: invoices.length,
        totalTaxable,
        totalTax
      }
    };
  }

  /**
   * Parses official GSTR-1 Offline JSON files directly into TransactionInvoice records
   */
  public parsePortalJson(
    jsonContent: string,
    supplierGstin: string = '07ABFFB5922Q1Z0'
  ): {
    success: boolean;
    templateType: string;
    invoices: TransactionInvoice[];
    gstin?: string;
    fp?: string;
    errors: string[];
    summary: { count: number; totalTaxable: number; totalTax: number };
  } {
    try {
      const data = JSON.parse(jsonContent);
      const rootGstin = (data.gstin && String(data.gstin).trim().length === 15)
        ? String(data.gstin).trim()
        : ((supplierGstin && supplierGstin.trim().length === 15) ? supplierGstin.trim() : '07ABFFB5922Q1Z0');
      const rootFp = data.fp || '102026';
      const supplierStateCode = rootGstin ? rootGstin.substring(0, 2) : '07';
      const invoices: TransactionInvoice[] = [];
      let totalTaxable = 0;
      let totalTax = 0;

      // 1. Table 4: B2B
      if (Array.isArray(data.b2b)) {
        data.b2b.forEach((b: any, bIdx: number) => {
          const ctin = b.ctin || '07AAAAA0000A1Z5';
          (b.inv || []).forEach((i: any, iIdx: number) => {
            const inum = i.inum || `INV-B2B-${bIdx}-${iIdx}`;
            const idt = parseGstPortalDate(i.idt);
            const pos = extractPosCode(i.pos, ctin, supplierStateCode);
            const rchrg = i.rchrg === 'Y';
            const invVal = Number(i.val || 0);
            const invTyp = i.inv_typ === 'DE' ? 'DEEMED_EXPORT' : i.inv_typ === 'SEZWP' ? 'SEZ_WITH_PAYMENT' : i.inv_typ === 'SEZWOP' ? 'SEZ_WITHOUT_PAYMENT' : 'B2B';

            (i.itms || []).forEach((itm: any, itmIdx: number) => {
              const det = itm.itm_det || {};
              const rt = Number(det.rt || 18);
              const txval = Number(det.txval || 0);
              const camt = Number(det.camt || 0);
              const samt = Number(det.samt || 0);
              const iamt = Number(det.iamt || 0);
              const csamt = Number(det.csamt || 0);
              const isInter = (camt > 0 || samt > 0) ? false : (iamt > 0 ? true : pos !== supplierStateCode);

              invoices.push({
                id: `JSON-B2B-${bIdx}-${iIdx}-${itmIdx}`,
                invoiceNumber: inum,
                invoiceDate: idt,
                documentType: 'INVOICE',
                supplyType: isInter ? 'INTER_STATE' : 'INTRA_STATE',
                classification: invTyp as GSTClassification,
                taxTreatment: 'TAXABLE',
                supplierGstin: rootGstin,
                supplierName: 'Taxpayer Entity',
                supplierState: 'Delhi',
                supplierStateCode,
                recipientGstin: ctin,
                recipientName: 'Registered Recipient',
                recipientState: 'State',
                recipientStateCode: pos,
                placeOfSupply: pos,
                placeOfSupplyCode: pos,
                taxableValue: txval,
                gstRate: rt,
                cgst: camt,
                sgst: samt,
                igst: iamt,
                cess: csamt,
                totalAmount: invVal || (txval + camt + samt + iamt + csamt),
                rcm: rchrg,
                ecommerce: false,
                itcStatus: 'ELIGIBLE',
                itcEligibleAmount: 0,
                itcIneligibleAmount: 0,
                confidence: 1.0,
                reviewRequired: false,
                hsnSacPrimary: '998313',
                descriptionPrimary: 'B2B Taxable Supply',
                notes: `Imported from GSTR-1 JSON (Table 4 B2B, Recipient: ${ctin})`
              });

              totalTaxable = round2(totalTaxable + txval);
              totalTax = round2(totalTax + camt + samt + iamt + csamt);
            });
          });
        });
      }

      // 2. Table 5: B2CL
      if (Array.isArray(data.b2cl)) {
        data.b2cl.forEach((b: any, bIdx: number) => {
          const pos = extractPosCode(b.pos || '27');
          (b.inv || []).forEach((i: any, iIdx: number) => {
            const inum = i.inum || `INV-B2CL-${bIdx}-${iIdx}`;
            const idt = parseGstPortalDate(i.idt);
            const invVal = Number(i.val || 0);
            (i.itms || []).forEach((itm: any, itmIdx: number) => {
              const det = itm.itm_det || {};
              const rt = Number(det.rt || 18);
              const txval = Number(det.txval || 0);
              const iamt = Number(det.iamt || 0);
              const csamt = Number(det.csamt || 0);

              invoices.push({
                id: `JSON-B2CL-${bIdx}-${iIdx}-${itmIdx}`,
                invoiceNumber: inum,
                invoiceDate: idt,
                documentType: 'INVOICE',
                supplyType: 'INTER_STATE',
                classification: 'B2C_LARGE',
                taxTreatment: 'TAXABLE',
                supplierGstin: rootGstin,
                supplierName: 'Taxpayer Entity',
                supplierState: 'Delhi',
                supplierStateCode,
                recipientGstin: 'URP',
                recipientName: 'Unregistered Consumer (Large)',
                recipientState: 'State',
                recipientStateCode: pos,
                placeOfSupply: pos,
                placeOfSupplyCode: pos,
                taxableValue: txval,
                gstRate: rt,
                cgst: 0,
                sgst: 0,
                igst: iamt,
                cess: csamt,
                totalAmount: invVal || (txval + iamt + csamt),
                rcm: false,
                ecommerce: false,
                itcStatus: 'INELIGIBLE',
                itcEligibleAmount: 0,
                itcIneligibleAmount: 0,
                confidence: 1.0,
                reviewRequired: false,
                hsnSacPrimary: '847130',
                descriptionPrimary: 'B2C Large Outward Supply',
                notes: `Imported from GSTR-1 JSON (Table 5 B2CL)`
              });

              totalTaxable = round2(totalTaxable + txval);
              totalTax = round2(totalTax + iamt + csamt);
            });
          });
        });
      }

      // 3. Table 7: B2CS
      if (Array.isArray(data.b2cs)) {
        data.b2cs.forEach((s: any, idx: number) => {
          const pos = extractPosCode(s.pos, undefined, supplierStateCode);
          const rt = Number(s.rt || 18);
          const txval = Number(s.txval || 0);
          const camt = Number(s.camt || 0);
          const samt = Number(s.samt || 0);
          const iamt = Number(s.iamt || 0);
          const csamt = Number(s.csamt || 0);
          const isInter = (camt > 0 || samt > 0) ? false : (iamt > 0 ? true : (s.sply_ty === 'INTER' || pos !== supplierStateCode));

          const b2csInv: any = {
            id: `JSON-B2CS-${idx}`,
            invoiceNumber: '', // Empty: Table 7 B2CS is a consolidated summary without invoice numbers
            invoiceDate: '2026-10-15',
            documentType: 'INVOICE',
            supplyType: isInter ? 'INTER_STATE' : 'INTRA_STATE',
            classification: 'B2C_SMALL',
            taxTreatment: 'TAXABLE',
            supplierGstin: rootGstin,
            supplierName: 'Taxpayer Entity',
            supplierState: 'Delhi',
            supplierStateCode,
            recipientGstin: 'URP',
            recipientName: 'Unregistered Consumer (B2C Small)',
            recipientState: 'State',
            recipientStateCode: pos,
            placeOfSupply: pos,
            placeOfSupplyCode: pos,
            taxableValue: txval,
            gstRate: rt,
            cgst: camt,
            sgst: samt,
            igst: iamt,
            cess: csamt,
            totalAmount: txval + camt + samt + iamt + csamt,
            rcm: false,
            ecommerce: s.typ === 'E',
            itcStatus: 'INELIGIBLE',
            itcEligibleAmount: 0,
            itcIneligibleAmount: 0,
            confidence: 1.0,
            reviewRequired: false,
            hsnSacPrimary: '998313',
            descriptionPrimary: 'B2C Small Consolidated Supply',
            notes: `Imported from GSTR-1 JSON (Table 7 B2CS, POS: ${pos})`,
            isB2csSummary: true
          };
          invoices.push(b2csInv);

          totalTaxable = round2(totalTaxable + txval);
          totalTax = round2(totalTax + camt + samt + iamt + csamt);
        });
      }

      // 4. Table 12: HSN (Import standalone or alongside invoices)
      if (data.hsn) {
        const hsnB2b = data.hsn.hsn_b2b || [];
        const hsnB2c = data.hsn.hsn_b2c || data.hsn.data || [];
        const processHsn = (list: any[], isB2b: boolean) => {
          list.forEach((h: any, idx: number) => {
            const hsnCode = String(h.hsn_sc || '998313').trim();
            const desc = String(h.desc || (hsnCode.startsWith('99') ? 'Services' : 'Goods / Supplies')).trim();
            const isService = hsnCode.startsWith('99');
            const uqc = isService ? 'NA' : String(h.uqc || 'OTH').split('-')[0].trim();
            const qty = isService ? 0 : Number(h.qty || 0);
            const rt = Number(h.rt || 18);
            const txval = Number(h.txval || 0);
            const camt = Number(h.camt || 0);
            const samt = Number(h.samt || 0);
            const iamt = Number(h.iamt || 0);
            const csamt = Number(h.csamt || 0);
            const isInter = iamt > 0;
            const pos = isInter ? '27' : supplierStateCode;

            const hsnInv: any = {
              id: `JSON-HSN-${isB2b ? 'B2B' : 'B2C'}-${idx}`,
              invoiceNumber: '',
              invoiceDate: '2026-10-15',
              documentType: 'INVOICE',
              supplyType: isInter ? 'INTER_STATE' : 'INTRA_STATE',
              classification: isB2b ? 'B2B' : 'B2C_SMALL',
              taxTreatment: 'TAXABLE',
              supplierGstin: rootGstin,
              supplierName: 'Taxpayer Entity',
              supplierState: 'Delhi',
              supplierStateCode,
              recipientGstin: isB2b ? `${supplierStateCode}AAAAA0000A1Z5` : 'URP',
              recipientName: isB2b ? 'Registered Recipient (HSN Summary)' : 'Unregistered Consumer (HSN Summary)',
              recipientState: 'State',
              recipientStateCode: pos,
              placeOfSupply: pos,
              placeOfSupplyCode: pos,
              taxableValue: txval,
              gstRate: rt,
              cgst: camt,
              sgst: samt,
              igst: iamt,
              cess: csamt,
              totalAmount: txval + camt + samt + iamt + csamt,
              rcm: false,
              ecommerce: false,
              itcStatus: 'INELIGIBLE',
              itcEligibleAmount: 0,
              itcIneligibleAmount: 0,
              confidence: 1.0,
              reviewRequired: false,
              hsnSacPrimary: hsnCode,
              descriptionPrimary: desc,
              notes: `Imported from GSTR-1 JSON (Table 12 HSN: ${hsnCode})`,
              isHsnSummary: true,
              hsnCategory: isB2b ? 'B2B' : 'B2C',
              uqc,
              totalQuantity: qty
            };
            invoices.push(hsnInv);
          });
        };
        processHsn(hsnB2b, true);
        processHsn(hsnB2c, false);
      }

      return {
        success: invoices.length > 0,
        templateType: 'JSON',
        invoices,
        gstin: rootGstin,
        fp: rootFp,
        errors: invoices.length === 0 ? ['No valid invoice or HSN records found in GSTR-1 JSON payload'] : [],
        summary: {
          count: invoices.length,
          totalTaxable,
          totalTax
        }
      };
    } catch (e: any) {
      return {
        success: false,
        templateType: 'JSON',
        invoices: [],
        errors: [`Invalid GSTR-1 JSON syntax: ${e.message}`],
        summary: { count: 0, totalTaxable: 0, totalTax: 0 }
      };
    }
  }
}

export const gstPortalCsvEngine = new GSTPortalCsvEngine();
