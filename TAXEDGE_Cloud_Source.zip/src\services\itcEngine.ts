/**
 * Input Tax Credit (ITC) Engine
 * Legal Basis: Section 16 & Section 17(5) of CGST Act, 2017 & CGST Rules 36, 37, 37A, 42, 43
 */

import { ITCStatus, BlockedCreditReason } from '../types/gst';
import { round2 } from '../utils/taxMath';

export interface ITCEvaluationResult {
  itcStatus: ITCStatus;
  eligibleAmount: number;
  ineligibleAmount: number;
  blockedReason: BlockedCreditReason;
  legalProvision: string;
  sourceCitation: string;
  reason: string;
  actionRequired: string;
  reviewRequired: boolean;
}

export class ITCEngine {
  /**
   * Evaluates ITC eligibility for an inward purchase invoice
   */
  public evaluateITC(invoice: {
    invoiceDate: string;
    hsnSac: string;
    description: string;
    taxableValue: number;
    totalTax: number;
    isRcm: boolean;
    hasInvoiceCopy: boolean;
    goodsReceived: boolean;
    isIn2B: boolean;
    vendorPaidWithin180Days?: boolean;
    daysSinceInvoice?: number;
    businessUseOnly?: boolean;
  }): ITCEvaluationResult {
    const totalTax = round2(invoice.totalTax);
    const desc = (invoice.description || '').toLowerCase();
    const hsn = (invoice.hsnSac || '').trim();

    // 1. Check Section 17(5)(a) & 17(5)(ab): Motor Vehicles & Vehicle Repairs/Insurance
    if (
      hsn.startsWith('8703') ||
      desc.includes('car') ||
      desc.includes('motor vehicle') ||
      desc.includes('hyundai') ||
      desc.includes('maruti') ||
      desc.includes('vehicle repair') ||
      desc.includes('engine overhaul') ||
      desc.includes('motor car')
    ) {
      return {
        itcStatus: 'INELIGIBLE',
        eligibleAmount: 0.0,
        ineligibleAmount: totalTax,
        blockedReason: 'SEC_17_5_A_MOTOR_VEHICLES',
        legalProvision: 'Section 17(5)(a) & Section 17(5)(ab) CGST Act, 2017',
        sourceCitation: 'ICAI Bare Law (April 2026 Edition), Page 40',
        reason: 'Motor vehicles for transportation of persons having approved seating capacity of <= 13 persons, and related repair/insurance, are statutory blocked credits.',
        actionRequired: 'Report in Table 4(D)(1) or Table 4(B)(1) as ineligible ITC. Do not avail in Table 4(A)(5).',
        reviewRequired: false
      };
    }

    // 2. Check Section 17(5)(b): Food, Beverages, Outdoor Catering, Club Memberships
    if (
      hsn === '996331' ||
      desc.includes('catering') ||
      desc.includes('food and beverage') ||
      desc.includes('buffet') ||
      desc.includes('restaurant') ||
      desc.includes('club membership') ||
      desc.includes('health fitness') ||
      desc.includes('annual dinner')
    ) {
      return {
        itcStatus: 'INELIGIBLE',
        eligibleAmount: 0.0,
        ineligibleAmount: totalTax,
        blockedReason: 'SEC_17_5_B_FOOD_BEVERAGE_CATERING_HEALTH',
        legalProvision: 'Section 17(5)(b)(i) & 17(5)(b)(ii) CGST Act, 2017',
        sourceCitation: 'ICAI Bare Law (April 2026 Edition), Page 41',
        reason: 'Food and beverages, outdoor catering, beauty treatment, and club memberships are blocked credits under Section 17(5)(b).',
        actionRequired: 'Expense full invoice gross amount including tax in books of accounts.',
        reviewRequired: false
      };
    }

    // 3. Check Section 17(5)(fa): Corporate Social Responsibility (CSR)
    if (desc.includes('csr') || desc.includes('corporate social responsibility') || desc.includes('donation')) {
      return {
        itcStatus: 'INELIGIBLE',
        eligibleAmount: 0.0,
        ineligibleAmount: totalTax,
        blockedReason: 'SEC_17_5_FA_CSR_EXPENDITURE',
        legalProvision: 'Section 17(5)(fa) CGST Act, 2017 (Finance Act 2023 amendment)',
        sourceCitation: 'ICAI Bare Law (April 2026 Edition), Page 41',
        reason: 'Goods or services received by a taxable person used for CSR obligations under Section 135 of the Companies Act, 2013 are non-creditable.',
        actionRequired: 'Exclude from eligible ITC ledger in GSTR-3B Table 4.',
        reviewRequired: false
      };
    }

    // 4. Check Section 17(5)(h): Free Samples / Gifts / Lost / Destroyed Goods
    if (desc.includes('free sample') || desc.includes('gift') || desc.includes('written off') || desc.includes('lost goods')) {
      return {
        itcStatus: 'INELIGIBLE',
        eligibleAmount: 0.0,
        ineligibleAmount: totalTax,
        blockedReason: 'SEC_17_5_H_LOST_STOLEN_DESTROYED_GIFT_SAMPLES',
        legalProvision: 'Section 17(5)(h) CGST Act, 2017',
        sourceCitation: 'ICAI Bare Law (April 2026 Edition), Page 42',
        reason: 'Goods lost, stolen, destroyed, written off or disposed of by way of gift or free samples are statutory blocked credits.',
        actionRequired: 'Reverse corresponding input tax credit in Table 4(B)(2) of GSTR-3B.',
        reviewRequired: false
      };
    }

    // 5. Check Rule 36(4): 2B Match Requirement
    if (!invoice.isIn2B && !invoice.isRcm) {
      return {
        itcStatus: 'REVIEW',
        eligibleAmount: 0.0,
        ineligibleAmount: totalTax,
        blockedReason: 'RULE_36_4_RESTRICTED_2B_MISSING',
        legalProvision: 'Section 16(2)(aa) & Rule 36(4) of CGST Rules, 2017',
        sourceCitation: 'ICAI Bare Law (April 2026 Edition), Page 36 & Page 182',
        reason: 'Invoice not communicated in auto-drafted statement GSTR-2B. Under Rule 36(4), no ITC can be availed if invoice is absent from 2B.',
        actionRequired: 'Follow up with vendor to file GSTR-1. Defer ITC claim to next tax period.',
        reviewRequired: true
      };
    }

    // 6. Check Rule 37: 180 Days Non-Payment Rule
    if (invoice.daysSinceInvoice && invoice.daysSinceInvoice > 180 && invoice.vendorPaidWithin180Days === false && !invoice.isRcm) {
      return {
        itcStatus: 'INELIGIBLE',
        eligibleAmount: 0.0,
        ineligibleAmount: totalTax,
        blockedReason: 'RULE_37_180_DAYS_NON_PAYMENT',
        legalProvision: 'Second Proviso to Section 16(2) Read with Rule 37 CGST Rules',
        sourceCitation: 'ICAI Bare Law (April 2026 Edition), Page 37 & Page 185',
        reason: 'Vendor consideration remains unpaid beyond 180 days from the invoice date.',
        actionRequired: 'Reverse ITC in Table 4(B)(2) along with 18% p.a. interest under Section 50. Re-avail in Table 4(A)(5) once payment is released.',
        reviewRequired: true
      };
    }

    // 7. General Section 16 Eligibility
    return {
      itcStatus: 'ELIGIBLE',
      eligibleAmount: totalTax,
      ineligibleAmount: 0.0,
      blockedReason: 'NONE',
      legalProvision: 'Section 16(1) & 16(2) of CGST Act, 2017',
      sourceCitation: 'ICAI Bare Law (April 2026 Edition), Page 35',
      reason: 'Satisfies all Section 16 conditions: Valid tax invoice, goods/services received, communicated in GSTR-2B, and used in furtherance of business.',
      actionRequired: 'Include in Table 4(A)(5) of GSTR-3B.',
      reviewRequired: false
    };
  }
}

export const itcEngine = new ITCEngine();
