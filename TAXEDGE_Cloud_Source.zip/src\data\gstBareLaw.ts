/**
 * GST Act(s) and Rule(s) - Bare Law (April 2026 Edition)
 * Primary Legal Reference: Revised 12th Edition, Institute of Chartered Accountants of India (ICAI)
 * Incorporating amendments up to 31 March 2026 (Finance Act 2026 and GST Council Notifications)
 */

import { GSTLawProvision } from '../types/gst';

export const GST_BARE_LAW_KNOWLEDGE_BASE: GSTLawProvision[] = [
  // --- CGST ACT: CHAPTER III — LEVY AND COLLECTION ---
  {
    id: 'CGST-SEC-07',
    act: 'CGST_ACT',
    chapter: 'Chapter III: Levy and Collection of Tax',
    sectionNumber: '7',
    title: 'Scope of supply',
    subSection: '(1)',
    clauses: [
      '(a) all forms of supply of goods or services or both such as sale, transfer, barter, exchange, licence, rental, lease or disposal made or agreed to be made for a consideration by a person in the course or furtherance of business;',
      '(aa) the activities or transactions, by a person, other than an individual, to its members or constituents or vice-versa, for cash, deferred payment or other valuable consideration;',
      '(b) import of services for a consideration whether or not in the course or furtherance of business; and',
      '(c) the activities specified in Schedule I, made or agreed to be made without a consideration.'
    ],
    provisos: [
      'Provided that any supply of goods or services specified in Schedule III shall be treated neither as a supply of goods nor a supply of services.'
    ],
    explanations: [
      'Explanation.—For the purposes of clause (aa), notwithstanding anything contained in any other law for the time being in force, the person and its members or constituents shall be deemed to be two separate persons and the supply of activities or transactions shall be deemed to take place from one such person to another.'
    ],
    relatedRules: ['Rule 27', 'Rule 28'],
    fullText: 'Section 7 outlines the complete boundary of taxable transactions under GST. Includes all forms of supply for consideration in course/furtherance of business, import of services, Schedule I deemed supplies without consideration, and excludes Schedule III non-taxable transactions.',
    summary: 'Defines what constitutes a supply under GST including goods, services, consideration, and business furtherance test.',
    amendmentDate: '2026-03-31',
    effectiveFrom: '2017-07-01',
    sourceDocument: 'GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)',
    sourcePage: 14,
    tags: ['supply', 'scope of supply', 'schedule I', 'schedule III', 'consideration', 'business furtherance']
  },
  {
    id: 'CGST-SEC-08',
    act: 'CGST_ACT',
    chapter: 'Chapter III: Levy and Collection of Tax',
    sectionNumber: '8',
    title: 'Tax liability on composite and mixed supplies',
    clauses: [
      '(a) a composite supply comprising two or more supplies, one of which is a principal supply, shall be treated as a supply of such principal supply; and',
      '(b) a mixed supply comprising two or more supplies shall be treated as a supply of that particular supply which attracts the highest rate of tax.'
    ],
    fullText: 'Section 8 determines the tax treatment for bundled transactions: Composite supplies (naturally bundled with a principal supply) are taxed at the rate of the principal supply. Mixed supplies (artificially bundled for single price) attract the highest tax rate among the bundled items.',
    summary: 'Tax rate determination for bundled goods/services: Composite (principal supply rate) vs Mixed (highest applicable rate).',
    amendmentDate: '2026-03-31',
    effectiveFrom: '2017-07-01',
    sourceDocument: 'GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)',
    sourcePage: 17,
    tags: ['composite supply', 'mixed supply', 'principal supply', 'highest tax rate']
  },
  {
    id: 'CGST-SEC-09',
    act: 'CGST_ACT',
    chapter: 'Chapter III: Levy and Collection of Tax',
    sectionNumber: '9',
    title: 'Levy and collection',
    subSection: '(1), (3), (4)',
    clauses: [
      '(1) Subject to the provisions of sub-section (2), there shall be levied a tax called the central goods and services tax on all intra-State supplies of goods or services or both, except on the supply of alcoholic liquor for human consumption, on the value determined under section 15 and at such rates, not exceeding twenty per cent., as may be notified by the Government on the recommendations of the Council...',
      '(3) The Government may, on the recommendations of the Council, by notification, specify categories of supply of goods or services or both, the tax on which shall be paid on reverse charge basis by the recipient of such goods or services or both and all the provisions of this Act shall apply to such recipient as if he is the person liable for paying the tax in relation to the supply...',
      '(4) The Government may, by notification, specify a class of registered persons who shall, in respect of supply of specified categories of goods or services or both received from an unregistered supplier, pay the tax on reverse charge basis as the recipient.'
    ],
    provisos: [
      'Provided that tax on reverse charge under section 9(3) and 9(4) shall be discharged strictly in CASH through the Electronic Cash Ledger and cannot be set off against Input Tax Credit balance.'
    ],
    relatedRules: ['Rule 36', 'Rule 39', 'Notification 13/2017-CT(R)'],
    relatedSections: ['Section 49(4)'],
    fullText: 'Section 9 governs the fundamental levy of CGST on intra-state supplies, and establishes the Reverse Charge Mechanism (RCM) under Section 9(3) for notified goods/services (like GTA, Advocate fees, Director remuneration) and 9(4) for supplies from unregistered persons.',
    summary: 'Levy of CGST and Reverse Charge Mechanism (RCM) empowering government to shift tax liability onto recipient payable in cash.',
    amendmentDate: '2026-03-31',
    effectiveFrom: '2017-07-01',
    sourceDocument: 'GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)',
    sourcePage: 18,
    tags: ['levy', 'rcm', 'reverse charge', 'section 9(3)', 'section 9(4)', 'cash ledger']
  },

  // --- CGST ACT: CHAPTER IV — TIME AND VALUE OF SUPPLY ---
  {
    id: 'CGST-SEC-12',
    act: 'CGST_ACT',
    chapter: 'Chapter IV: Time and Value of Supply',
    sectionNumber: '12',
    title: 'Time of supply of goods',
    subSection: '(1), (2)',
    clauses: [
      '(2) The time of supply of goods shall be the earlier of the following dates: (a) the date of issue of invoice by the supplier or the last date on which he is required, under section 31, to issue the invoice; or (b) the date on which the supplier receives the payment.'
    ],
    provisos: [
      'Provided that under Notification No. 66/2017-CT, registered persons not opting for composition levy are exempted from paying tax at the time of receipt of advance for goods.'
    ],
    fullText: 'Governs when tax liability arises on supply of goods. Generally date of issue of invoice or last date of invoice under Section 31.',
    summary: 'Point of taxation for goods: Earliest of invoice date or statutory invoice deadline under Section 31.',
    amendmentDate: '2026-03-31',
    effectiveFrom: '2017-07-01',
    sourceDocument: 'GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)',
    sourcePage: 23,
    tags: ['time of supply', 'goods', 'invoice date', 'advance exemption']
  },
  {
    id: 'CGST-SEC-13',
    act: 'CGST_ACT',
    chapter: 'Chapter IV: Time and Value of Supply',
    sectionNumber: '13',
    title: 'Time of supply of services',
    subSection: '(1), (2)',
    clauses: [
      '(2) The time of supply of services shall be: (a) the date of issue of invoice by the supplier if issued within period under section 31(2) or date of receipt of payment, whichever is earlier; or (b) date of provision of service if invoice is not issued within 30 days.'
    ],
    fullText: 'Governs time of supply for services. Tax liability arises on receipt of advance or invoice issue, whichever occurs earlier.',
    summary: 'Point of taxation for services: Advance receipt or invoice date (provided invoice is issued within 30 days of completion).',
    amendmentDate: '2026-03-31',
    effectiveFrom: '2017-07-01',
    sourceDocument: 'GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)',
    sourcePage: 26,
    tags: ['time of supply', 'services', 'advances', '30 days rule']
  },
  {
    id: 'CGST-SEC-15',
    act: 'CGST_ACT',
    chapter: 'Chapter IV: Time and Value of Supply',
    sectionNumber: '15',
    title: 'Value of taxable supply',
    subSection: '(1), (2), (3)',
    clauses: [
      '(1) The value of a supply of goods or services or both shall be the transaction value, which is the price actually paid or payable for the said supply where the supplier and recipient are not related and price is sole consideration.',
      '(2) The value shall include: taxes/duties other than GST, amounts incurred by recipient on behalf of supplier, incidental expenses including commission and packing, interest or late fee for delayed payment, subsidies linked directly to price.',
      '(3) The value shall not include any discount given before or at the time of supply, or post-supply discounts established in terms of agreement.'
    ],
    relatedRules: ['Rule 27', 'Rule 28', 'Rule 29', 'Rule 30', 'Rule 31'],
    fullText: 'Section 15 establishes transaction value as the primary base for GST calculation, detailing inclusions (incidental charges, interest for delayed payment) and statutory conditions for excluding discounts.',
    summary: 'Transaction value rules, additions (charges, non-GST taxes) and deductions (trade discounts agreed prior to supply).',
    amendmentDate: '2026-03-31',
    effectiveFrom: '2017-07-01',
    sourceDocument: 'GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)',
    sourcePage: 31,
    tags: ['valuation', 'transaction value', 'discounts', 'incidental expenses']
  },

  // --- CGST ACT: CHAPTER V — INPUT TAX CREDIT (SECTIONS 16–21) ---
  {
    id: 'CGST-SEC-16',
    act: 'CGST_ACT',
    chapter: 'Chapter V: Input Tax Credit',
    sectionNumber: '16',
    title: 'Eligibility and conditions for taking input tax credit',
    subSection: '(1), (2), (3), (4)',
    clauses: [
      '(1) Every registered person shall, subject to such conditions and restrictions as may be prescribed and in the manner specified in section 49, be entitled to take credit of input tax charged on any supply of goods or services or both to him which are used or intended to be used in the course or furtherance of his business...',
      '(2) Notwithstanding anything contained in this section, no registered person shall be entitled to the credit of any input tax in respect of any supply of goods or services or both to him unless,—',
      '(a) he is in possession of a tax invoice or debit note issued by a supplier registered under this Act, or such other tax paying documents as may be prescribed;',
      '(aa) the details of the invoice or debit note has been furnished by the supplier in the statement of outward supplies and such details have been communicated to the recipient of such invoice or debit note in the manner specified under section 38 (GSTR-2B);',
      '(b) he has received the goods or services or both;',
      '(ba) the details of input tax credit in respect of the said supply communicated to such registered person under section 38 has not been restricted;',
      '(c) subject to the provisions of section 41, the tax charged in respect of such supply has been actually paid to the Government, either in cash or through utilisation of input tax credit admissible in respect of the said supply; and',
      '(d) he has furnished the return under section 39.'
    ],
    provisos: [
      'Second Proviso to Sec 16(2): Where a recipient fails to pay to the supplier the amount towards the value of supply along with tax payable thereon within a period of one hundred and eighty days (180 days) from the date of issue of invoice by the supplier, an amount equal to the input tax credit availed by the recipient shall be paid by him along with interest payable under section 50, in the manner as may be prescribed.',
      'Third Proviso to Sec 16(2): The recipient shall be entitled to avail of the credit of input tax on payment made by him of the amount towards the value of supply of goods or services or both along with tax payable thereon.'
    ],
    relatedRules: ['Rule 36', 'Rule 37', 'Rule 37A', 'Rule 60'],
    relatedSections: ['Section 38', 'Section 39', 'Section 41', 'Section 50'],
    fullText: 'Section 16 sets forth the 5 mandatory cumulative conditions for taking ITC: (a) Possession of tax invoice, (aa) Invoice reflected in GSTR-2B under Section 38, (b) Physical receipt of goods/services, (c) Tax actually paid to government by supplier, (d) Valid GSTR-3B return furnished. Also enforces the 180-day recipient payment rule and time-limit under 16(4) (30th November following financial year).',
    summary: 'Core ITC Eligibility: Tax invoice + GSTR-2B reflection + actual receipt + tax deposited + 39 return + 180 days payment test.',
    amendmentDate: '2026-03-31',
    effectiveFrom: '2017-07-01',
    sourceDocument: 'GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)',
    sourcePage: 35,
    tags: ['itc', 'eligibility', 'section 16', 'gstr-2b', '180 days rule', 'time barred 16(4)']
  },
  {
    id: 'CGST-SEC-17',
    act: 'CGST_ACT',
    chapter: 'Chapter V: Input Tax Credit',
    sectionNumber: '17',
    title: 'Apportionment of credit and blocked credits',
    subSection: '(1), (2), (5)',
    clauses: [
      '(1) Where the goods or services or both are used by the registered person partly for the purpose of any business and partly for other purposes, the amount of credit shall be restricted to so much of the input tax as is attributable to the purposes of his business.',
      '(2) Where the goods or services or both are used by the registered person partly for effecting taxable supplies including zero-rated supplies and partly for effecting exempt supplies, credit restricted to taxable supplies.',
      '(5) Notwithstanding anything contained in sub-section (1) of section 16 and subsection (1) of section 18, input tax credit SHALL NOT BE AVAILABLE in respect of the following, namely:—',
      '(a) motor vehicles for transportation of persons having approved seating capacity of not more than thirteen persons (including the driver), except when used for making taxable supplies of further supply, transportation of passengers, or imparting training;',
      '(aa) vessels and aircraft (with specified exceptions);',
      '(ab) services of general insurance, servicing, repair and maintenance in so far as they relate to motor vehicles, vessels or aircraft referred to in clause (a) or clause (aa);',
      '(b) (i) food and beverages, outdoor catering, beauty treatment, health services, cosmetic and plastic surgery, leasing, renting or hiring of motor vehicles, life insurance and health insurance (except where inward supply is used for making outward taxable supply of same category or statutory obligation); (ii) membership of a club, health and fitness centre; (iii) travel benefits extended to employees on vacation;',
      '(c) works contract services when supplied for construction of an immovable property (other than plant and machinery) except where it is an input service for further supply of works contract service;',
      '(d) goods or services or both received by a taxable person for construction of an immovable property (other than plant or machinery) on his own account including when used in furtherance of business;',
      '(fa) goods or services or both received by a taxable person, which are used or intended to be used for activities relating to the obligations under corporate social responsibility (CSR) referred to in section 135 of the Companies Act, 2013;',
      '(h) goods lost, stolen, destroyed, written off or disposed of by way of gift or free samples; and',
      '(i) any tax paid in accordance with the provisions of sections 74, 129 and 130.'
    ],
    explanations: [
      'Explanation.—For the purposes of clauses (c) and (d), the expression "construction" includes re-construction, renovation, additions or alterations or repairs, to the extent of capitalisation, to the said immovable property.'
    ],
    relatedRules: ['Rule 42', 'Rule 43'],
    fullText: 'Section 17 governs credit apportionment and contains Section 17(5) "Blocked Credits" where ITC is strictly prohibited regardless of business use. Specifically blocks passenger motor vehicles (seating <=13), motor vehicle repair/insurance, food & beverages, outdoor catering, employee club membership, construction/works contract of immovable property capitalized in balance sheet, CSR expenses under Section 135, and lost/stolen goods or free samples.',
    summary: 'Statutory Blocked Credits under 17(5): Cars, Food/Catering, Immovable property construction, Gifts/Free samples, CSR expenses.',
    amendmentDate: '2026-03-31',
    effectiveFrom: '2017-07-01',
    sourceDocument: 'GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)',
    sourcePage: 40,
    tags: ['blocked credit', 'section 17(5)', 'motor vehicle', 'food beverages', 'construction', 'free samples', 'csr']
  },

  // --- CGST ACT: CHAPTER VII — TAX INVOICE, CREDIT AND DEBIT NOTES ---
  {
    id: 'CGST-SEC-31',
    act: 'CGST_ACT',
    chapter: 'Chapter VII: Tax Invoice, Credit and Debit Notes',
    sectionNumber: '31',
    title: 'Tax invoice',
    subSection: '(1), (2), (3)',
    clauses: [
      '(1) A registered person supplying taxable goods shall, before or at the time of,— (a) removal of goods for supply to the recipient, where the supply involves movement of goods; or (b) delivery of goods or making available thereof to the recipient, in any other case, issue a tax invoice showing the description, quantity and value of goods, the tax charged thereon and such other particulars as may be prescribed.',
      '(2) A registered person supplying taxable services shall, before or after the provision of service but within a prescribed period, issue a tax invoice...',
      '(3)(f) A registered person who is liable to pay tax under sub-section (3) or sub-section (4) of section 9 shall issue an invoice in respect of goods or services or both received by him from the supplier who is not registered on the date of receipt of goods or services or both (Self-Invoice under RCM).'
    ],
    relatedRules: ['Rule 46', 'Rule 47', 'Rule 48', 'Rule 54'],
    fullText: 'Section 31 prescribes the issuance of tax invoices, bills of supply, receipt vouchers, and mandatory self-invoicing for RCM supplies received from unregistered vendors.',
    summary: 'Tax invoice rules, time limits (within 30 days for services), and RCM self-invoicing obligations.',
    amendmentDate: '2026-03-31',
    effectiveFrom: '2017-07-01',
    sourceDocument: 'GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)',
    sourcePage: 55,
    tags: ['tax invoice', 'section 31', 'rule 46', 'self invoice', 'rcm invoice']
  },
  {
    id: 'CGST-SEC-34',
    act: 'CGST_ACT',
    chapter: 'Chapter VII: Tax Invoice, Credit and Debit Notes',
    sectionNumber: '34',
    title: 'Credit and debit notes',
    subSection: '(1), (2), (3), (4)',
    clauses: [
      '(1) Where one or more tax invoices have been issued for supply of any goods or services or both and the taxable value or tax charged in that tax invoice is found to exceed the taxable value or tax payable in respect of such supply, or where the goods supplied are returned by the recipient, or where goods or services or both supplied are found to be deficient, the registered person, who has supplied such goods or services or both, may issue to the recipient one or more credit notes for supplies made in a financial year...',
      '(2) Any registered person who issues a credit note in relation to a supply of goods or services or both shall declare the details of such credit note in the return for the month during which such credit note has been issued but not later than the thirtieth day of November following the end of the financial year in which such supply was made, or the date of furnishing of the relevant annual return, whichever is earlier, and the tax liability shall be adjusted in such manner as may be prescribed.'
    ],
    provisos: [
      'Provided that no reduction in output tax liability of the supplier shall be permitted, if the incidence of tax and interest on such supply has been passed on to any other person.'
    ],
    relatedRules: ['Rule 53'],
    fullText: 'Section 34 governs the issuance and declaration of Credit Notes (reducing tax liability) and Debit Notes (increasing tax liability). Details must be declared in GSTR-1 Table 9B before 30th November following financial year end.',
    summary: 'Credit and debit note conditions, linkage to original invoices, and deadline for output tax liability reduction.',
    amendmentDate: '2026-03-31',
    effectiveFrom: '2017-07-01',
    sourceDocument: 'GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)',
    sourcePage: 59,
    tags: ['credit note', 'debit note', 'section 34', 'table 9B', 'reduction in liability']
  },

  // --- CGST ACT: CHAPTER IX — RETURNS (SECTIONS 37–48) ---
  {
    id: 'CGST-SEC-37',
    act: 'CGST_ACT',
    chapter: 'Chapter IX: Returns',
    sectionNumber: '37',
    title: 'Furnishing details of outward supplies (GSTR-1)',
    subSection: '(1), (2), (3)',
    clauses: [
      '(1) Every registered person, other than an Input Service Distributor, a non-resident taxable person and a person paying tax under the provisions of section 10 or section 51 or section 52, shall furnish, electronically, subject to such conditions and restrictions and in such form and manner as may be prescribed, the details of outward supplies of goods or services or both effected during a tax period on or before the eleventh day of the month succeeding the said tax period...'
    ],
    relatedRules: ['Rule 59'],
    fullText: 'Section 37 mandates filing of GSTR-1/IFF by the 11th of succeeding month, containing invoice-level data for B2B, interstate B2CL, exports, credit/debit notes, and summary for B2C small and HSN summary (Table 12).',
    summary: 'Statutory mandate for GSTR-1: Outward supplies reporting, due date 11th, sequential filing restriction.',
    amendmentDate: '2026-03-31',
    effectiveFrom: '2017-07-01',
    sourceDocument: 'GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)',
    sourcePage: 63,
    tags: ['gstr-1', 'section 37', 'outward supplies', 'rule 59', 'b2b', 'hsn summary']
  },
  {
    id: 'CGST-SEC-38',
    act: 'CGST_ACT',
    chapter: 'Chapter IX: Returns',
    sectionNumber: '38',
    title: 'Communication of details of inward supplies and input tax credit (GSTR-2B)',
    subSection: '(1), (2)',
    clauses: [
      '(1) The details of outward supplies furnished by the registered persons under sub-section (1) of section 37 and of such other supplies as may be prescribed, and an auto-generated statement containing the details of input tax credit shall be made available electronically to the recipients of such supplies in such form and manner, within such time, and subject to such conditions and restrictions as may be prescribed.',
      '(2) The auto-generated statement (GSTR-2B) shall consist of two parts: (a) details of inward supplies in respect of which credit of input tax may be available to the recipient; and (b) details of supplies in respect of which such credit cannot be availed, whether wholly or partly, by the recipient.'
    ],
    relatedRules: ['Rule 60'],
    fullText: 'Section 38 establishes GSTR-2B as the statutory dynamic auto-generated statement communicating eligible and ineligible ITC to recipients based on suppliers GSTR-1 filings.',
    summary: 'Statutory basis for GSTR-2B: Auto-drafted statement segregating eligible and restricted/ineligible ITC.',
    amendmentDate: '2026-03-31',
    effectiveFrom: '2022-10-01',
    sourceDocument: 'GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)',
    sourcePage: 66,
    tags: ['gstr-2b', 'section 38', 'rule 60', 'inward supplies', 'auto-generated statement']
  },
  {
    id: 'CGST-SEC-39',
    act: 'CGST_ACT',
    chapter: 'Chapter IX: Returns',
    sectionNumber: '39',
    title: 'Furnishing of returns (GSTR-3B)',
    subSection: '(1), (7)',
    clauses: [
      '(1) Every registered person shall, for every calendar month or part thereof, furnish, in such form and manner as may be prescribed, a return, electronically, of inward and outward supplies of goods or services or both, input tax credit availed, tax payable, tax paid and such other particulars, on or before the twentieth day of the month succeeding such calendar month or part thereof.',
      '(7) Every registered person who is required to furnish a return under sub-section (1) shall pay to the Government the tax due as per such return not later than the last date on which he is required to furnish such return.'
    ],
    relatedRules: ['Rule 61', 'Rule 88C', 'Rule 88D'],
    fullText: 'Section 39 mandates the monthly self-assessed summary return GSTR-3B by the 20th of succeeding month, discharge of outward tax liability and RCM liability, and availment/reversal of ITC.',
    summary: 'Statutory basis for GSTR-3B: Monthly summary return, tax payment by 20th, ITC availment and reversal.',
    amendmentDate: '2026-03-31',
    effectiveFrom: '2017-07-01',
    sourceDocument: 'GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)',
    sourcePage: 68,
    tags: ['gstr-3b', 'section 39', 'rule 61', 'return filing', 'payment of tax']
  },

  // --- CGST ACT: CHAPTER X — PAYMENT OF TAX (SECTIONS 49–53) ---
  {
    id: 'CGST-SEC-49',
    act: 'CGST_ACT',
    chapter: 'Chapter X: Payment of Tax',
    sectionNumber: '49',
    title: 'Payment of tax, interest, penalty and other amounts',
    subSection: '(1), (2), (3), (4), (5)',
    clauses: [
      '(4) The amount available in the electronic credit ledger may be used for making any payment towards output tax under this Act or under the Integrated Goods and Services Tax Act in such manner and subject to such conditions and restrictions and within such time as may be prescribed.',
      '(5) The amount of input tax credit available in the electronic credit ledger of the registered person on account of central tax, state tax, integrated tax shall be utilised as per Section 49A and 49B.'
    ],
    provisos: [
      'Explanation to Sec 49(4): Output tax does not include tax payable on reverse charge basis under Section 9(3) and 9(4). Hence, RCM liability CANNOT be paid through Electronic Credit Ledger.'
    ],
    relatedSections: ['Section 49A', 'Section 49B'],
    relatedRules: ['Rule 85', 'Rule 86', 'Rule 88A'],
    fullText: 'Section 49 provides the mechanism for Electronic Cash Ledger and Electronic Credit Ledger. Prohibits credit ledger usage for RCM liabilities and sets the stage for mandatory ITC set-off ordering.',
    summary: 'Payment mechanism: Cash Ledger vs Credit Ledger. Prohibits using ITC for RCM liabilities.',
    amendmentDate: '2026-03-31',
    effectiveFrom: '2017-07-01',
    sourceDocument: 'GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)',
    sourcePage: 78,
    tags: ['payment of tax', 'section 49', 'cash ledger', 'credit ledger', 'rcm cash payment']
  },
  {
    id: 'CGST-SEC-49A-49B',
    act: 'CGST_ACT',
    chapter: 'Chapter X: Payment of Tax',
    sectionNumber: '49A & 49B',
    title: 'Utilisation of input tax credit and order of utilisation (Rule 88A)',
    clauses: [
      'Section 49A: Notwithstanding anything contained in section 49, the input tax credit on account of central tax, State tax or Union territory tax shall be utilised towards payment of integrated tax, central tax, State tax or Union territory tax, as the case may be, only after the input tax credit available on account of integrated tax has first been utilised fully towards such payment.',
      'Section 49B: Order of utilisation: 1. IGST credit is first fully exhausted against IGST, then CGST and SGST in any order/proportion. 2. Central Tax credit is utilised against CGST, then IGST. 3. State Tax credit is utilised against SGST, then IGST. 4. Cross-utilisation of CGST against SGST or SGST against CGST is strictly prohibited!'
    ],
    relatedRules: ['Rule 88A'],
    fullText: 'Mandates the strict statutory hierarchy of ITC set-off: IGST credit must be 100% exhausted first before touching CGST or SGST credit. Cross-utilisation of CGST and SGST is illegal.',
    summary: 'Statutory Order of ITC Utilisation (Rule 88A): Exhaust IGST first; never cross-utilize CGST & SGST.',
    amendmentDate: '2026-03-31',
    effectiveFrom: '2019-02-01',
    sourceDocument: 'GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)',
    sourcePage: 82,
    tags: ['itc set off', 'rule 88a', 'section 49a', 'section 49b', 'order of utilisation']
  },
  {
    id: 'CGST-SEC-50',
    act: 'CGST_ACT',
    chapter: 'Chapter X: Payment of Tax',
    sectionNumber: '50',
    title: 'Interest on delayed payment of tax',
    subSection: '(1), (3)',
    clauses: [
      '(1) Every person who is liable to pay tax in accordance with the provisions of this Act or the rules made thereunder, but fails to pay the tax or any part thereof to the Government within the period prescribed, shall for the period for which the tax or any part thereof remains unpaid, pay, on his own, interest at such rate, not exceeding eighteen per cent. (18% p.a.)...',
      'Proviso to Sec 50(1): Provided that the interest on tax payable in respect of supplies declared in the return for a tax period furnished after the due date in accordance with the provisions of section 39, except where such return is furnished after commencement of any proceedings under section 73 or section 74 in respect of the said period, shall be payable on that portion of the tax which is paid by debiting the electronic cash ledger (Net Tax Liability principle).'
    ],
    fullText: 'Section 50 governs interest at 18% p.a. for delayed tax payment calculated on NET cash tax liability, and 24% p.a. for fraudulent/inadmissible ITC availed and utilized.',
    summary: 'Interest on delayed tax payment: 18% per annum calculated strictly on net cash liability.',
    amendmentDate: '2026-03-31',
    effectiveFrom: '2017-07-01',
    sourceDocument: 'GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)',
    sourcePage: 84,
    tags: ['interest', 'section 50', '18 percent', 'net cash liability']
  },
  {
    id: 'CGST-SEC-52',
    act: 'CGST_ACT',
    chapter: 'Chapter X: Payment of Tax',
    sectionNumber: '52',
    title: 'Collection of tax at source (TCS by E-Commerce Operators)',
    subSection: '(1), (3), (4)',
    clauses: [
      '(1) Notwithstanding anything to the contrary contained in this Act, every electronic commerce operator, not being an agent, shall collect an amount calculated at such rate not exceeding one per cent., as may be notified by the Government on the recommendations of the Council, of the net value of taxable supplies made through it by other suppliers where the consideration with respect to such supplies is to be collected by the operator.',
      '(3) The amount collected under sub-section (1) shall be paid to the Government by the operator within ten days after the end of the month in which such collection is made, in such manner as may be prescribed (GSTR-8).'
    ],
    relatedRules: ['Rule 67'],
    fullText: 'Section 52 governs Tax Collection at Source (TCS) by e-commerce operators (Amazon, Flipkart, Swiggy, Zomato, etc.) at 1% (0.5% CGST + 0.5% SGST or 1% IGST) on net taxable supplies, which appears as credit in seller’s Electronic Cash Ledger via GSTR-8.',
    summary: 'E-commerce TCS at 1% of net taxable turnover, credited into merchant cash ledger via GSTR-8.',
    amendmentDate: '2026-03-31',
    effectiveFrom: '2018-10-01',
    sourceDocument: 'GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)',
    sourcePage: 88,
    tags: ['tcs', 'e-commerce', 'section 52', 'gstr-8', 'amazon', 'flipkart']
  },

  // --- IGST ACT PROVISIONS (SECTIONS 5, 7, 8, 10, 12, 13) ---
  {
    id: 'IGST-SEC-07',
    act: 'IGST_ACT',
    chapter: 'Chapter IV: Determination of Nature of Supply',
    sectionNumber: '7',
    title: 'Inter-State supply',
    subSection: '(1), (3), (5)',
    clauses: [
      '(1) Subject to the provisions of section 10, supply of goods, where the location of the supplier and the place of supply are in: (a) two different States; (b) two different Union territories; or (c) a State and a Union territory, shall be treated as a supply of goods in the course of inter-State trade or commerce.',
      '(3) Subject to the provisions of section 12, supply of services, where location of supplier and place of supply are in different States/UTs, treated as inter-State supply.',
      '(5) Supply of goods or services or both,— (a) when the supplier is located in India and the place of supply is outside India; (b) to or by a Special Economic Zone developer or a Special Economic Zone unit; shall be treated to be a supply of goods or services or both in the course of inter-State trade or commerce.'
    ],
    fullText: 'Defines inter-state supplies requiring IGST levy: When location of supplier and place of supply are in different states, imports, exports, and supplies to/by SEZ developers/units.',
    summary: 'Inter-state supply definition: Supplier location and POS in different states, or exports/SEZ, attracting IGST.',
    amendmentDate: '2026-03-31',
    effectiveFrom: '2017-07-01',
    sourceDocument: 'GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)',
    sourcePage: 122,
    tags: ['igst', 'inter-state supply', 'section 7 igst', 'sez', 'exports']
  },
  {
    id: 'IGST-SEC-08',
    act: 'IGST_ACT',
    chapter: 'Chapter IV: Determination of Nature of Supply',
    sectionNumber: '8',
    title: 'Intra-State supply',
    subSection: '(1), (2)',
    clauses: [
      '(1) Subject to the provisions of section 10, supply of goods where the location of the supplier and the place of supply of goods are in the same State or same Union territory shall be treated as intra-State supply.',
      '(2) Subject to the provisions of section 12, supply of services where the location of the supplier and the place of supply of services are in the same State or same Union territory shall be treated as intra-State supply.'
    ],
    fullText: 'Defines intra-state supplies requiring equal CGST + SGST (or UTGST): Where location of supplier and place of supply are in the same State/Union Territory.',
    summary: 'Intra-state supply definition: Location of supplier and POS in same State, attracting CGST + SGST.',
    amendmentDate: '2026-03-31',
    effectiveFrom: '2017-07-01',
    sourceDocument: 'GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)',
    sourcePage: 124,
    tags: ['cgst', 'sgst', 'intra-state supply', 'section 8 igst', 'same state']
  },
  {
    id: 'IGST-SEC-10',
    act: 'IGST_ACT',
    chapter: 'Chapter V: Place of Supply of Goods and Services',
    sectionNumber: '10',
    title: 'Place of supply of goods other than supply of goods imported into, or exported from, India',
    subSection: '(1)',
    clauses: [
      '(a) where the supply involves movement of goods, whether by the supplier or the recipient or by any other person, the place of supply of such goods shall be the location of the goods at the time at which the movement of goods terminates for delivery to the recipient;',
      '(b) where the goods are delivered by the supplier to a recipient or any other person on the direction of a third person (Bill-to Ship-to model), it shall be deemed that the said third person has received the goods and the place of supply of such goods shall be the principal place of business of such person;',
      '(c) where the supply does not involve movement of goods, whether by the supplier or the recipient, the place of supply shall be the location of such goods at the time of the delivery to the recipient.'
    ],
    fullText: 'Section 10 determines Place of Supply (POS) for goods: Destination where movement terminates, or third party principal place in Bill-to Ship-to transactions.',
    summary: 'POS of goods: Location where delivery terminates or principal place of 3rd party in Bill-to Ship-to.',
    amendmentDate: '2026-03-31',
    effectiveFrom: '2017-07-01',
    sourceDocument: 'GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)',
    sourcePage: 127,
    tags: ['place of supply', 'pos goods', 'section 10 igst', 'bill to ship to']
  },
  {
    id: 'IGST-SEC-12',
    act: 'IGST_ACT',
    chapter: 'Chapter V: Place of Supply of Goods and Services',
    sectionNumber: '12',
    title: 'Place of supply of services where location of supplier and recipient is in India',
    subSection: '(2)',
    clauses: [
      '(2) The place of supply of services, except the services specified in sub-sections (3) to (14),— (a) made to a registered person shall be the location of such person; (b) made to any person other than a registered person shall be: (i) the location of the recipient where the address on record exists; and (ii) the location of the supplier of services in other cases.'
    ],
    fullText: 'Section 12 provides the general and specific rules for Place of Supply of services within India. B2B default is the registered location of recipient; B2C default is recipient address on record.',
    summary: 'POS of services within India: Location of registered recipient (B2B) or address on record (B2C).',
    amendmentDate: '2026-03-31',
    effectiveFrom: '2017-07-01',
    sourceDocument: 'GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)',
    sourcePage: 130,
    tags: ['place of supply', 'pos services', 'section 12 igst', 'b2b pos']
  },

  // --- CGST RULES KNOWLEDGE BASE ---
  {
    id: 'CGST-RULE-36',
    act: 'CGST_RULES',
    chapter: 'Chapter V: Input Tax Credit',
    ruleNumber: '36',
    title: 'Documentary requirements and conditions for claiming input tax credit',
    subSection: '(1), (4)',
    clauses: [
      '(1) The input tax credit shall be availed by a registered person on the basis of any of the following documents: (a) an invoice issued by the supplier of goods or services under section 31; (b) an invoice issued in accordance with section 31(3)(f) (RCM Self-Invoice); (c) a debit note; (d) a bill of entry...',
      '(4) No input tax credit shall be availed by a registered person in respect of invoices or debit notes the details of which are required to be furnished under sub-section (1) of section 37 unless,— (a) the details of such invoices or debit notes have been furnished by the suppliers in the statement of outward supplies in FORM GSTR-1 or using invoice furnishing facility; and (b) the details of input tax credit in respect of such invoices or debit notes have been communicated to the registered person in FORM GSTR-2B under sub-rule (7) of rule 60.'
    ],
    fullText: 'Rule 36(4) strictly limits ITC availment in GSTR-3B to only those invoices that appear in auto-drafted GSTR-2B. Unmatched or provisional ITC claims are 100% prohibited.',
    summary: 'Rule 36(4): ITC strictly restricted to invoices reflected in GSTR-2B. Zero provisional credit allowed.',
    amendmentDate: '2026-03-31',
    effectiveFrom: '2022-01-01',
    sourceDocument: 'GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)',
    sourcePage: 182,
    tags: ['rule 36(4)', 'gstr-2b mandate', 'ineligible itc', 'provisional credit']
  },
  {
    id: 'CGST-RULE-37',
    act: 'CGST_RULES',
    chapter: 'Chapter V: Input Tax Credit',
    ruleNumber: '37',
    title: 'Reversal of input tax credit in the case of non-payment of consideration',
    subSection: '(1), (2)',
    clauses: [
      '(1) A registered person, who has availed of input tax credit on any inward supply of goods or services or both, other than the supplies on which tax is payable on reverse charge basis, but fails to pay to the supplier thereof, the amount towards the value of such supply along with the tax payable thereon, within the time limit specified in the second proviso to sub-section (2) of section 16, shall pay an amount equal to the input tax credit availed, proportionate to the amount not paid to the supplier, along with interest payable thereon under section 50, while furnishing the return in FORM GSTR-3B for the tax period immediately following the period of one hundred and eighty days (180 days).'
    ],
    fullText: 'Rule 37 governs the mandatory reversal in Table 4(B)(2) of GSTR-3B when payment to vendor is overdue beyond 180 days from invoice date, with interest at 18% under Section 50.',
    summary: 'Rule 37: 180-day vendor non-payment requires proportionate ITC reversal with interest in GSTR-3B.',
    amendmentDate: '2026-03-31',
    effectiveFrom: '2022-10-01',
    sourceDocument: 'GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)',
    sourcePage: 185,
    tags: ['rule 37', '180 days non payment', 'itc reversal', 'section 16 second proviso']
  },
  {
    id: 'CGST-RULE-88C',
    act: 'CGST_RULES',
    chapter: 'Chapter IX: Payment of Tax',
    ruleNumber: '88C',
    title: 'Manner of dealing with difference in liability reported in statement of outward supplies (GSTR-1) and return (GSTR-3B) — Form GST DRC-01B',
    clauses: [
      '(1) Where the tax payable by a registered person in GSTR-1 exceeds the amount of tax paid in GSTR-3B by such percentage and amount as may be recommended by the Council, the registered person shall be intimated of such difference in Part A of FORM GST DRC-01B.',
      '(2) The registered person shall within 7 days either: (a) pay the differential tax along with interest under section 50 in Part B of DRC-01B; or (b) explain the reasons for the unpaid difference.'
    ],
    fullText: 'Rule 88C enforces algorithmic scrutiny of GSTR-1 vs GSTR-3B outward tax differences. Discrepancies generate automated DRC-01B notice and block subsequent period GSTR-1 filing.',
    summary: 'Rule 88C: Automated DRC-01B notice when GSTR-1 output tax exceeds GSTR-3B by > ₹25 Lakhs or > 20%.',
    amendmentDate: '2026-03-31',
    effectiveFrom: '2022-12-26',
    sourceDocument: 'GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)',
    sourcePage: 236,
    tags: ['rule 88c', 'drc-01b', 'gstr-1 vs gstr-3b', 'turnover mismatch', 'scrutiny']
  },
  {
    id: 'CGST-RULE-88D',
    act: 'CGST_RULES',
    chapter: 'Chapter IX: Payment of Tax',
    ruleNumber: '88D',
    title: 'Manner of dealing with difference in input tax credit available in auto-generated statement (GSTR-2B) and availed in return (GSTR-3B) — Form GST DRC-01C',
    clauses: [
      '(1) Where the input tax credit availed in GSTR-3B exceeds the input tax credit available in GSTR-2B by such percentage and amount as recommended by Council, intimation in Part A of FORM GST DRC-01C shall be sent.',
      '(2) Recipient must within 7 days pay differential ITC along with interest under Section 50 or submit justification in Part B of DRC-01C.'
    ],
    fullText: 'Rule 88D monitors excess ITC claimed in GSTR-3B compared to GSTR-2B. Triggers automated DRC-01C notices and blocks subsequent GSTR-1/IFF filings until resolved.',
    summary: 'Rule 88D: Automated DRC-01C notice when GSTR-3B ITC claimed exceeds GSTR-2B statement.',
    amendmentDate: '2026-03-31',
    effectiveFrom: '2023-08-04',
    sourceDocument: 'GST Act(s) and Rule(s) - Bare Law (April 2026 Edition, ICAI)',
    sourcePage: 238,
    tags: ['rule 88d', 'drc-01c', 'gstr-2b vs gstr-3b', 'excess itc claim', 'scrutiny']
  }
];
