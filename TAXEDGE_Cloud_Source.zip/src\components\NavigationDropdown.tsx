import React, { useState, useRef, useEffect } from 'react';
import {
  LayoutDashboard,
  ArrowUpRight,
  ArrowDownLeft,
  GitCompare,
  FileCheck2,
  FileSpreadsheet,
  Layers,
  Repeat,
  ShoppingBag,
  BookOpen,
  AlertOctagon,
  Send,
  FlaskConical,
  History,
  Briefcase,
  Users,
  ChevronDown,
  Search,
  Check,
  Compass,
  Sliders
} from 'lucide-react';
import { NavTab } from './Sidebar';

export interface NavigationDropdownProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  salesCount?: number;
  purchaseCount?: number;
  exceptionsCount?: number;
  matchRate?: number;
  className?: string;
}

interface NavItem {
  id: NavTab;
  label: string;
  shortDesc: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string | number;
  badgeColor?: string;
  isPopular?: boolean;
}

interface NavGroup {
  groupName: string;
  items: NavItem[];
}

export const NavigationDropdown: React.FC<NavigationDropdownProps> = ({
  activeTab,
  onTabChange,
  salesCount = 0,
  purchaseCount = 0,
  exceptionsCount = 0,
  matchRate = 0,
  className = ''
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const dropdownRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Group definitions strictly covering sales register, purchase register and all software modules
  const navGroups: NavGroup[] = [
    {
      groupName: 'Core Registers & Ledgers',
      items: [
        {
          id: 'sales',
          label: 'Sales Register',
          shortDesc: 'Outward supplies, B2B, B2C & CSV Hub',
          icon: ArrowUpRight,
          badge: salesCount > 0 ? `${salesCount} Invoices` : undefined,
          badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-300',
          isPopular: true
        },
        {
          id: 'purchases',
          label: 'Purchase Register',
          shortDesc: 'Inward supplies, bills, vendor expenses',
          icon: ArrowDownLeft,
          badge: purchaseCount > 0 ? `${purchaseCount} Invoices` : undefined,
          badgeColor: 'bg-blue-100 text-blue-800 border-blue-300',
          isPopular: true
        },
        {
          id: 'reconciliation',
          label: '2B Reconciliation',
          shortDesc: '5-Level GSTR-2B automated matching',
          icon: GitCompare,
          badge: matchRate > 0 ? `${matchRate}% Match` : undefined,
          badgeColor: 'bg-purple-100 text-purple-800 border-purple-300',
          isPopular: true
        }
      ]
    },
    {
      groupName: 'Statutory Returns & Workbenches',
      items: [
        {
          id: 'gstr1',
          label: 'GSTR-1 Workbench',
          shortDesc: 'Table 4, 7, 12 HSN & 13 Docs JSON',
          icon: FileCheck2,
          badge: 'v3.2.4 JSON',
          badgeColor: 'bg-emerald-50 text-emerald-700 border-emerald-300',
          isPopular: true
        },
        {
          id: 'gstr3b',
          label: 'GSTR-3B Workbench',
          shortDesc: 'Auto-calculated tax liability & ITC offsets',
          icon: FileSpreadsheet,
          badge: 'Auto-3B',
          badgeColor: 'bg-amber-50 text-amber-800 border-amber-300'
        },
        {
          id: 'itc',
          label: 'ITC Engine (Sec 16/17)',
          shortDesc: '16(2) compliance & 17(5) blocked credits',
          icon: Layers
        },
        {
          id: 'rcm',
          label: 'RCM Engine (Sec 9(3)/9(4))',
          shortDesc: 'GTA, Legal, Director & unregistered RCM',
          icon: Repeat
        },
        {
          id: 'ecommerce',
          label: 'E-Commerce & TCS',
          shortDesc: 'Section 52 & 9(5) marketplace reports',
          icon: ShoppingBag
        }
      ]
    },
    {
      groupName: 'CA Practice & Client Hub',
      items: [
        {
          id: 'admin',
          label: 'Admin Control Panel',
          shortDesc: '1-Click Master Editor for Clients, Invoices & Firm',
          icon: Sliders,
          badge: '1-Click Edit',
          badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-300',
          isPopular: true
        },
        {
          id: 'practice',
          label: 'CA Practice Hub',
          shortDesc: 'Multi-client portfolio & batch filings',
          icon: Briefcase
        },
        {
          id: 'clientmaster',
          label: 'Client Master',
          shortDesc: 'Client database, GSTIN profiles & states',
          icon: Users
        },
        {
          id: 'dashboard',
          label: 'Client Dashboard',
          shortDesc: 'Executive KPIs, monthly turnover & tax summary',
          icon: LayoutDashboard
        }
      ]
    },
    {
      groupName: 'Compliance, Audit & AI',
      items: [
        {
          id: 'exceptions',
          label: 'Exception Center',
          shortDesc: 'Statutory mismatches, GSTIN alerts & tax issues',
          icon: AlertOctagon,
          badge: exceptionsCount > 0 ? `${exceptionsCount} Alerts` : undefined,
          badgeColor: 'bg-rose-100 text-rose-800 border-rose-300'
        },
        {
          id: 'filing',
          label: 'Filing & Human Approval',
          shortDesc: 'Lock workspace, audit check & submit return',
          icon: Send
        },
        {
          id: 'barelaw',
          label: 'Bare Law RAG (2026)',
          shortDesc: 'ICAI CGST/IGST Act & Rules semantic search',
          icon: BookOpen
        },
        {
          id: 'testsuite',
          label: 'Automated Test Suite',
          shortDesc: '25+ ICAI statutory stress tests',
          icon: FlaskConical
        },
        {
          id: 'audit',
          label: 'Audit Trail',
          shortDesc: 'Immutable audit logs & statutory changes',
          icon: History
        }
      ]
    }
  ];

  // Flat lookup for active item info
  const allItems = navGroups.flatMap(g => g.items);
  const currentItem = allItems.find(i => i.id === activeTab) || navGroups[0].items[0];
  const CurrentIcon = currentItem.icon;

  // Filter items if searching
  const filteredGroups = navGroups.map(group => {
    if (!searchTerm.trim()) return group;
    const term = searchTerm.toLowerCase();
    const matchingItems = group.items.filter(
      item =>
        item.label.toLowerCase().includes(term) ||
        item.shortDesc.toLowerCase().includes(term) ||
        item.id.toLowerCase().includes(term)
    );
    return { ...group, items: matchingItems };
  }).filter(group => group.items.length > 0);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      // Auto-focus search input
      setTimeout(() => {
        searchInputRef.current?.focus();
      }, 50);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen]);

  const handleSelectTab = (tabId: NavTab) => {
    onTabChange(tabId);
    setIsOpen(false);
    setSearchTerm('');
  };

  return (
    <div className={`relative inline-block text-left ${className}`} ref={dropdownRef}>
      {/* Dropdown Trigger Button */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className={`group flex items-center gap-2.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all duration-150 border shadow-sm ${
          isOpen
            ? 'bg-emerald-800 text-white border-emerald-900 shadow-md ring-2 ring-emerald-600/30'
            : 'bg-white hover:bg-slate-50 text-slate-800 border-slate-300 hover:border-emerald-600 hover:text-emerald-900'
        }`}
        aria-haspopup="true"
        aria-expanded={isOpen}
      >
        <div className={`p-1 rounded-lg transition ${
          isOpen ? 'bg-emerald-700 text-white' : 'bg-emerald-100 text-emerald-800 group-hover:bg-emerald-200'
        }`}>
          <CurrentIcon className="w-4 h-4" />
        </div>

        <div className="flex flex-col text-left">
          <span className="text-[10px] uppercase font-bold tracking-wider leading-none opacity-75">
            Module
          </span>
          <span className="text-xs font-extrabold truncate max-w-[140px] sm:max-w-[180px]">
            {currentItem.label}
          </span>
        </div>

        {currentItem.badge && (
          <span className="hidden sm:inline-flex text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200/80">
            {currentItem.badge}
          </span>
        )}

        <ChevronDown
          className={`w-4 h-4 transition-transform duration-200 opacity-70 ${
            isOpen ? 'rotate-180 text-white' : 'text-slate-500 group-hover:text-emerald-700'
          }`}
        />
      </button>

      {/* Floating Dropdown Menu Panel */}
      {isOpen && (
        <div className="absolute left-0 sm:left-auto sm:right-0 mt-2 w-[92vw] sm:w-[480px] max-w-[520px] max-h-[82vh] bg-white rounded-2xl shadow-2xl border border-slate-200/90 z-50 flex flex-col overflow-hidden animate-in fade-in slide-in-from-top-2 duration-150">
          {/* Header & Search */}
          <div className="p-3.5 bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white shrink-0">
            <div className="flex items-center justify-between gap-2 mb-2.5">
              <div className="flex items-center gap-2">
                <Compass className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-extrabold tracking-wide uppercase text-slate-100">
                  Software Modules & Registers
                </span>
              </div>
              <span className="text-[10px] text-emerald-300 font-mono bg-emerald-900/60 px-2 py-0.5 rounded-md border border-emerald-500/30">
                15 Modules
              </span>
            </div>

            {/* Quick Search Filter */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                placeholder="Jump to Sales Register, Purchase Register, GSTR-1, 3B..."
                className="w-full bg-slate-800/90 text-white placeholder-slate-400 text-xs rounded-xl pl-9 pr-3 py-2 border border-slate-700 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
              />
              {searchTerm && (
                <button
                  onClick={() => setSearchTerm('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs px-1"
                >
                  ✕
                </button>
              )}
            </div>
          </div>

          {/* Quick Access Top Bar (Sales & Purchase shortcuts) */}
          {!searchTerm && (
            <div className="bg-slate-50 border-b border-slate-200 p-2.5 flex items-center gap-2 overflow-x-auto shrink-0">
              <span className="text-[10px] font-extrabold uppercase text-slate-400 tracking-wider pl-1 shrink-0">
                Popular:
              </span>
              <button
                onClick={() => handleSelectTab('sales')}
                className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold transition shrink-0 border ${
                  activeTab === 'sales'
                    ? 'bg-emerald-700 text-white border-emerald-800 shadow-sm'
                    : 'bg-white hover:bg-emerald-50 text-slate-800 hover:text-emerald-900 border-slate-200'
                }`}
              >
                <ArrowUpRight className="w-3.5 h-3.5 text-emerald-600" />
                <span>Sales Register</span>
                {salesCount > 0 && (
                  <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-100 text-emerald-800">
                    {salesCount}
                  </span>
                )}
              </button>

              <button
                onClick={() => handleSelectTab('purchases')}
                className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold transition shrink-0 border ${
                  activeTab === 'purchases'
                    ? 'bg-blue-700 text-white border-blue-800 shadow-sm'
                    : 'bg-white hover:bg-blue-50 text-slate-800 hover:text-blue-900 border-slate-200'
                }`}
              >
                <ArrowDownLeft className="w-3.5 h-3.5 text-blue-600" />
                <span>Purchase Register</span>
                {purchaseCount > 0 && (
                  <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-blue-100 text-blue-800">
                    {purchaseCount}
                  </span>
                )}
              </button>

              <button
                onClick={() => handleSelectTab('gstr1')}
                className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold transition shrink-0 border ${
                  activeTab === 'gstr1'
                    ? 'bg-emerald-700 text-white border-emerald-800 shadow-sm'
                    : 'bg-white hover:bg-emerald-50 text-slate-800 hover:text-emerald-900 border-slate-200'
                }`}
              >
                <FileCheck2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>GSTR-1</span>
              </button>

              <button
                onClick={() => handleSelectTab('reconciliation')}
                className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold transition shrink-0 border ${
                  activeTab === 'reconciliation'
                    ? 'bg-purple-700 text-white border-purple-800 shadow-sm'
                    : 'bg-white hover:bg-purple-50 text-slate-800 hover:text-purple-900 border-slate-200'
                }`}
              >
                <GitCompare className="w-3.5 h-3.5 text-purple-600" />
                <span>2B Recon</span>
              </button>
            </div>
          )}

          {/* Grouped Modules List */}
          <div className="overflow-y-auto p-3 space-y-4 flex-1">
            {filteredGroups.length === 0 ? (
              <div className="py-8 text-center text-slate-400">
                <Search className="w-8 h-8 mx-auto mb-2 opacity-40" />
                <p className="text-xs font-medium">No matching modules found for "{searchTerm}"</p>
                <button
                  onClick={() => setSearchTerm('')}
                  className="mt-2 text-xs font-bold text-emerald-700 hover:underline"
                >
                  Clear search
                </button>
              </div>
            ) : (
              filteredGroups.map(group => (
                <div key={group.groupName} className="space-y-1.5">
                  <div className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 px-2 py-0.5">
                    {group.groupName}
                  </div>

                  <div className="grid grid-cols-1 gap-1">
                    {group.items.map(item => {
                      const Icon = item.icon;
                      const isActive = activeTab === item.id;

                      return (
                        <button
                          key={item.id}
                          onClick={() => handleSelectTab(item.id)}
                          className={`w-full flex items-center justify-between p-2.5 rounded-xl text-left transition group ${
                            isActive
                              ? 'bg-emerald-50 border-2 border-emerald-600 text-emerald-950 font-bold shadow-xs'
                              : 'hover:bg-slate-100/80 border border-transparent text-slate-800'
                          }`}
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            <div
                              className={`p-2 rounded-lg shrink-0 transition ${
                                isActive
                                  ? 'bg-emerald-600 text-white shadow-sm'
                                  : 'bg-slate-100 text-slate-600 group-hover:bg-emerald-100 group-hover:text-emerald-800'
                              }`}
                            >
                              <Icon className="w-4 h-4" />
                            </div>

                            <div className="truncate">
                              <div className="flex items-center gap-2">
                                <span className={`text-xs truncate ${isActive ? 'font-extrabold text-emerald-950' : 'font-bold text-slate-900 group-hover:text-emerald-900'}`}>
                                  {item.label}
                                </span>
                                {item.badge && (
                                  <span
                                    className={`text-[10px] font-bold px-2 py-0.2 rounded-full border shrink-0 ${
                                      item.badgeColor || 'bg-slate-100 text-slate-700 border-slate-300'
                                    }`}
                                  >
                                    {item.badge}
                                  </span>
                                )}
                              </div>
                              <p className="text-[11px] text-slate-500 truncate group-hover:text-slate-600">
                                {item.shortDesc}
                              </p>
                            </div>
                          </div>

                          {isActive && (
                            <div className="shrink-0 ml-2 text-emerald-700">
                              <Check className="w-4 h-4 stroke-[3]" />
                            </div>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer Status Bar */}
          <div className="p-2.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500 shrink-0">
            <span>Click any module to switch immediately</span>
            <span className="font-mono text-[10px] text-slate-400">Esc to close</span>
          </div>
        </div>
      )}
    </div>
  );
};
